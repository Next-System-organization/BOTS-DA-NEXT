@echo off
title By Smith - Random Gifs
color 5
node .
pause
@echo off
title By Smith - Random Gifs
color 5
node .
pause
@echo off
title By Smith - Random Gifs
color 5
node .
pause
@echo off
title By Smith - Random Gifs
color 5
node .
pause
@echo off
title By Smith - Random Gifs
color 5
node .
pause
@echo off
title By Smith - Random Gifs
color 5
node .
pause
@echo off
title By Smith - Random Gifs
color 5
node .
pause
@echo off
title By Smith - Random Gifs
color 5
node .
pause
@echo off
title By Smith - Random Gifs
color 5
node .
pause
@echo off
title By Smith - Random Gifs
color 5
node .
pause