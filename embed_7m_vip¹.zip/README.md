
# Embed Builder V2 FULL

## Instalação
pip install -r requirements.txt

## Configuração
Coloque seu token no bot.py:

bot.run("SEU_TOKEN_AQUI")

## Rodar
python bot.py

## Comando
/anunciar

## Features
- Botões (Components V2)
- Modal (edição popup)
- Preview
- Enviar embed
- Cancelar
- Autor, rodapé, cor, imagem, etc
