
import discord
from discord.ext import commands
from discord import app_commands

bot = commands.Bot(command_prefix="!", intents=discord.Intents.default())

class ModalField(discord.ui.Modal):
    def __init__(self, builder, field):
        super().__init__(title=f"Editar {field}")
        self.builder = builder
        self.field = field

        self.input = discord.ui.TextInput(label=field, required=False, max_length=2000)
        self.add_item(self.input)

    async def on_submit(self, interaction: discord.Interaction):
        v = self.input.value

        if self.field == "Título":
            self.builder.embed.title = v
        elif self.field == "Descrição":
            self.builder.embed.description = v
        elif self.field == "Imagem":
            self.builder.embed.set_image(url=v)
        elif self.field == "Miniatura":
            self.builder.embed.set_thumbnail(url=v)
        elif self.field == "Autor":
            self.builder.embed.set_author(name=v)
        elif self.field == "Rodapé":
            self.builder.embed.set_footer(text=v)
        elif self.field == "Cor":
            try:
                self.builder.embed.color = int(v.replace("#",""), 16)
            except:
                pass

        await interaction.response.edit_message(embed=self.builder.embed, view=self.builder)


class Builder(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.embed = discord.Embed(
            title="Configure abaixo os campos da embed que deseja configurar.",
            description="Clique nos botões abaixo.",
            color=0x2F3136
        )

    @discord.ui.button(label="Título", style=discord.ButtonStyle.secondary, row=0)
    async def t(self, i, b): await i.response.send_modal(ModalField(self,"Título"))

    @discord.ui.button(label="Descrição", style=discord.ButtonStyle.secondary, row=0)
    async def d(self, i, b): await i.response.send_modal(ModalField(self,"Descrição"))

    @discord.ui.button(label="Imagem", style=discord.ButtonStyle.secondary, row=0)
    async def im(self, i, b): await i.response.send_modal(ModalField(self,"Imagem"))

    @discord.ui.button(label="Miniatura", style=discord.ButtonStyle.secondary, row=0)
    async def th(self, i, b): await i.response.send_modal(ModalField(self,"Miniatura"))

    @discord.ui.button(label="Autor", style=discord.ButtonStyle.secondary, row=1)
    async def au(self, i, b): await i.response.send_modal(ModalField(self,"Autor"))

    @discord.ui.button(label="Rodapé", style=discord.ButtonStyle.secondary, row=1)
    async def ro(self, i, b): await i.response.send_modal(ModalField(self,"Rodapé"))

    @discord.ui.button(label="Cor", style=discord.ButtonStyle.secondary, row=1)
    async def co(self, i, b): await i.response.send_modal(ModalField(self,"Cor"))

    @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.danger, row=2)
    async def cancel(self, i, b):
        await i.message.delete()

    @discord.ui.button(label="Enviar", style=discord.ButtonStyle.success, row=2)
    async def send(self, i, b):
        await i.channel.send(embed=self.embed)
        await i.response.send_message("Embed enviada!", ephemeral=True)

    @discord.ui.button(label="Preview", style=discord.ButtonStyle.primary, row=2)
    async def preview(self, i, b):
        await i.response.send_message(embed=self.embed, ephemeral=True)


@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"Online: {bot.user}")


@bot.tree.command(name="anunciar")
async def anunciar(interaction: discord.Interaction):
    view = Builder()
    await interaction.response.send_message(embed=view.embed, view=view)


bot.run("SEU_TOKEN_AQUI")
