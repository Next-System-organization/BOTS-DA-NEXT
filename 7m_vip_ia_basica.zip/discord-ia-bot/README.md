# 🤖 NovBot — Discord IA Bot

Bot para Discord com **chat por IA** e **geração de imagem** — completamente grátis, sem precisar de API key de IA!

Usa a [Pollinations.ai](https://pollinations.ai) por baixo dos panos.

---

## ✅ Requisitos

- Python 3.10 ou superior
- Conta no [Discord Developer Portal](https://discord.com/developers/applications)

---

## 🚀 Como rodar

### 1. Instale as dependências

```bash
pip install -r requirements.txt
```

### 2. Crie o arquivo `.env`

Copie o exemplo e preencha com o token do seu bot:

```bash
cp .env.example .env
```

Abra o `.env` e troque `cole_seu_token_aqui` pelo token real do seu bot.

**Como pegar o token:**
1. Acesse https://discord.com/developers/applications
2. Crie uma aplicação (ou abra uma existente)
3. Vá em **Bot** → **Reset Token** → copie o token
4. Em **Privileged Gateway Intents**, ative **Message Content Intent**

### 3. Convide o bot para seu servidor

No Developer Portal → **OAuth2** → **URL Generator**:
- Scope: `bot`
- Permissões: `Send Messages`, `Embed Links`, `Attach Files`, `Read Message History`

Cole o link gerado no navegador e adicione o bot.

### 4. Rode o bot

```bash
python bot.py
```

---

## 💬 Comandos

| Comando | Descrição |
|--------|-----------|
| `!chat <mensagem>` | Conversa com a IA (lembra do contexto) |
| `!imagine <descrição>` | Gera uma imagem com IA |
| `!reset` | Limpa o histórico de conversa |
| `!help` | Lista os comandos |

### Aliases disponíveis
- `!chat` → `!ia`, `!ask`, `!c`
- `!imagine` → `!img`, `!draw`, `!gen`
- `!reset` → `!limpar`, `!clear`
- `!help` → `!ajuda`, `!comandos`, `!h`

---

## ⚙️ Personalização

Abra o `bot.py` e edite as variáveis no topo:

```python
SYSTEM_PROMPT = "Mude aqui a personalidade do bot..."
MAX_HISTORY   = 10  # quantas mensagens o bot lembra por usuário
```

---

## 🆓 Por que sem API key?

O bot usa a [Pollinations.ai](https://pollinations.ai), uma plataforma aberta e gratuita que fornece:
- **Chat IA** via modelos como GPT-4, Mistral, LLaMA
- **Geração de imagem** via Stable Diffusion / FLUX

Nenhuma conta ou chave necessária — funciona direto!

---

## 🐛 Problemas comuns

| Erro | Solução |
|------|---------|
| `DISCORD_TOKEN não definido` | Confira o arquivo `.env` |
| `Privileged intents required` | Ative o **Message Content Intent** no portal |
| Timeout na geração de imagem | A API pode estar lenta, tente novamente |
