import discord
from discord.ext import commands
import aiohttp
import os
import io
from urllib.parse import quote
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN", "")

# ─────────────────────────────────────────
#  Config da IA
# ─────────────────────────────────────────
SYSTEM_PROMPT = (
    "Você é um assistente inteligente, divertido e amigável chamado NovBot. "
    "Responda sempre em português do Brasil, de forma clara e objetiva. "
    "Seja criativo quando necessário, mas sempre útil."
)
TEXT_API   = "https://text.pollinations.ai/"
IMAGE_API  = "https://image.pollinations.ai/prompt/{prompt}?width=1024&height=1024&nologo=true&enhance=true"
MAX_HISTORY = 10   # mensagens por usuário

# ─────────────────────────────────────────
#  Histórico de conversa (memória por user)
# ─────────────────────────────────────────
historicos: dict[int, list[dict]] = {}

def get_historico(user_id: int) -> list[dict]:
    return historicos.setdefault(user_id, [])

def add_mensagem(user_id: int, role: str, content: str):
    h = get_historico(user_id)
    h.append({"role": role, "content": content})
    # mantém só as últimas MAX_HISTORY mensagens
    if len(h) > MAX_HISTORY:
        historicos[user_id] = h[-MAX_HISTORY:]

# ─────────────────────────────────────────
#  Bot setup
# ─────────────────────────────────────────
intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

# ─────────────────────────────────────────
#  Eventos
# ─────────────────────────────────────────
@bot.event
async def on_ready():
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="!help para ver comandos"
        )
    )
    print(f"✅ Bot online como {bot.user} (ID: {bot.user.id})")
    print("─" * 40)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.reply("❌ Falta o texto! Exemplo: `!chat Olá, como vai?`")
    elif isinstance(error, commands.CommandNotFound):
        pass  # ignora comandos desconhecidos silenciosamente
    else:
        await ctx.reply(f"❌ Erro inesperado: `{error}`")

# ─────────────────────────────────────────
#  Comando: !chat
# ─────────────────────────────────────────
@bot.command(name="chat", aliases=["ia", "ask", "c"])
async def chat(ctx, *, mensagem: str):
    """Conversa com a IA (tem memória da conversa)"""
    async with ctx.typing():
        add_mensagem(ctx.author.id, "user", mensagem)

        payload = {
            "model": "openai-large",
            "messages": get_historico(ctx.author.id),
            "system": SYSTEM_PROMPT,
            "private": True,
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(TEXT_API, json=payload, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                    resposta = await resp.text()

            if not resposta.strip():
                resposta = "⚠️ A IA não retornou resposta. Tente novamente."

            add_mensagem(ctx.author.id, "assistant", resposta)

            # Quebra em pedaços se for grande
            chunks = [resposta[i:i+1990] for i in range(0, len(resposta), 1990)]
            for i, chunk in enumerate(chunks):
                embed = discord.Embed(description=chunk, color=0x5865F2)
                if i == 0:
                    embed.set_author(
                        name=f"{ctx.author.display_name} perguntou:",
                        icon_url=ctx.author.display_avatar.url
                    )
                if i == len(chunks) - 1:
                    embed.set_footer(text="🤖 NovBot • !reset para limpar memória")
                await ctx.reply(embed=embed) if i == 0 else await ctx.send(embed=embed)

        except aiohttp.ClientError as e:
            await ctx.reply(f"❌ Erro de conexão com a IA: `{e}`")
        except Exception as e:
            await ctx.reply(f"❌ Erro inesperado: `{e}`")

# ─────────────────────────────────────────
#  Comando: !imagine
# ─────────────────────────────────────────
@bot.command(name="imagine", aliases=["img", "image", "draw", "gen"])
async def imagine(ctx, *, prompt: str):
    """Gera uma imagem com IA a partir de uma descrição"""
    async with ctx.typing():
        url = IMAGE_API.format(prompt=quote(prompt))

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=60)) as resp:
                    if resp.status == 200:
                        img_data = await resp.read()
                        arquivo = discord.File(io.BytesIO(img_data), filename="novbot_art.png")
                        embed = discord.Embed(
                            title="🎨 Imagem gerada!",
                            description=f"**Prompt:** {prompt[:200]}",
                            color=0xFF6B6B
                        )
                        embed.set_image(url="attachment://novbot_art.png")
                        embed.set_footer(text="🖼️ NovBot • Powered by Pollinations AI")
                        await ctx.reply(embed=embed, file=arquivo)
                    else:
                        await ctx.reply(f"❌ Falha ao gerar imagem (status {resp.status}). Tente outro prompt.")
        except aiohttp.ClientError as e:
            await ctx.reply(f"❌ Erro de conexão: `{e}`")
        except Exception as e:
            await ctx.reply(f"❌ Erro inesperado: `{e}`")

# ─────────────────────────────────────────
#  Comando: !reset
# ─────────────────────────────────────────
@bot.command(name="reset", aliases=["limpar", "clear"])
async def reset(ctx):
    """Limpa o histórico de conversa do usuário"""
    historicos.pop(ctx.author.id, None)
    embed = discord.Embed(
        description="🗑️ Histórico limpo! Começamos uma nova conversa do zero.",
        color=0x57F287
    )
    await ctx.reply(embed=embed)

# ─────────────────────────────────────────
#  Comando: !help
# ─────────────────────────────────────────
@bot.command(name="help", aliases=["ajuda", "comandos", "h"])
async def help_cmd(ctx):
    """Lista todos os comandos disponíveis"""
    embed = discord.Embed(
        title="🤖 NovBot — Comandos",
        description="Um bot com IA integrada, sem precisar de API key!",
        color=0x5865F2
    )
    embed.add_field(
        name="💬 `!chat <mensagem>`",
        value="Conversa com a IA. Ela lembra do contexto da conversa.\n_Aliases: `!ia`, `!ask`, `!c`_",
        inline=False
    )
    embed.add_field(
        name="🎨 `!imagine <descrição>`",
        value="Gera uma imagem com IA a partir do seu prompt.\n_Aliases: `!img`, `!draw`, `!gen`_",
        inline=False
    )
    embed.add_field(
        name="🗑️ `!reset`",
        value="Limpa o histórico de conversa (começa do zero).\n_Aliases: `!limpar`, `!clear`_",
        inline=False
    )
    embed.set_footer(text="NovBot • Powered by Pollinations AI • Sem API key necessária!")
    await ctx.reply(embed=embed)

# ─────────────────────────────────────────
#  Start
# ─────────────────────────────────────────
if not TOKEN:
    print("❌ ERRO: Defina DISCORD_TOKEN no arquivo .env!")
    exit(1)

bot.run(TOKEN)
