@echo off
echo ========================================
echo      Media Bot - Instalador
echo ========================================
echo.

echo [1/3] Verificando ffmpeg...
ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 (
    echo  ffmpeg NAO encontrado!
    echo  Instalando via winget...
    winget install ffmpeg
    echo  Se der erro, baixe manualmente em: https://ffmpeg.org/download.html
    echo  e adicione ao PATH do sistema.
) else (
    echo  ffmpeg OK!
)

echo.
echo [2/3] Instalando dependencias Python...
pip install -r requirements.txt

echo.
echo [3/3] Iniciando o bot...
echo.
echo LEMBRE-SE: Coloque seu TOKEN em main.py antes de rodar!
echo.
python main.py
pause
