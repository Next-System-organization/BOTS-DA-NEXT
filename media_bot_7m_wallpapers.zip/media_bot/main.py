import discord
from discord.ext import commands
import asyncio
import os

# ─────────────────────────────────────────
#  CONFIGURAÇÕES — edite aqui
# ─────────────────────────────────────────
TOKEN = "SEU_TOKEN_AQUI"
PREFIX = "!"

# ID da categoria onde os canais privados serão criados
# Deixe None para criar sem categoria
CATEGORY_ID = None

# Cargo que não tem limite de uso (ID do cargo Booster ou similar)
BOOSTER_ROLE_ID = None  # Ex: 123456789

# Limite de canais privados simultâneos por usuário normal
MAX_CHANNELS_PER_USER = 5

intents = discord.Intents.all()
bot = commands.Bot(command_prefix=PREFIX, intents=intents)
bot.CATEGORY_ID = CATEGORY_ID
bot.BOOSTER_ROLE_ID = BOOSTER_ROLE_ID
bot.MAX_CHANNELS_PER_USER = MAX_CHANNELS_PER_USER
bot.active_channels = {}  # discord_id -> lista de channel_id ativos

@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"✅ Bot online como {bot.user} ({bot.user.id})")
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="🎬 Convertendo mídias..."
        )
    )

async def load_extensions():
    os.makedirs("./cogs", exist_ok=True)
    for filename in os.listdir("./cogs"):
        if filename.endswith(".py"):
            await bot.load_extension(f"cogs.{filename[:-3]}")
            print(f"  📦 Cog carregado: {filename}")

async def main():
    async with bot:
        await load_extensions()
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())
