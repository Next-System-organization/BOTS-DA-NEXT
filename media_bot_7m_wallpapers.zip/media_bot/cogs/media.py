import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import aiohttp
import os
import sys
import shutil
import tempfile

MAX_FILE_MB = 10
MAX_FILE_BYTES = MAX_FILE_MB * 1024 * 1024

# ─────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────
def find_ffmpeg() -> str | None:
    """Encontra o executável do ffmpeg no sistema (Windows/Linux/Mac)"""
    path = shutil.which("ffmpeg")
    if path:
        return path
    windows_paths = [
        r"C:\ffmpeg\bin\ffmpeg.exe",
        r"C:\Program Files\ffmpeg\bin\ffmpeg.exe",
        r"C:\Program Files (x86)\ffmpeg\bin\ffmpeg.exe",
        os.path.join(os.environ.get("USERPROFILE", ""), "ffmpeg", "bin", "ffmpeg.exe"),
        os.path.join(os.path.dirname(sys.executable), "ffmpeg.exe"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ffmpeg.exe"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ffmpeg", "bin", "ffmpeg.exe"),
    ]
    for p in windows_paths:
        if os.path.isfile(p):
            return p
    return None

FFMPEG_PATH = find_ffmpeg()

async def run_ffmpeg(*args) -> tuple[bool, bytes, str]:
    if not FFMPEG_PATH:
        return False, b"", "ffmpeg nao encontrado"
    proc = await asyncio.create_subprocess_exec(
        FFMPEG_PATH, *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    return proc.returncode == 0, stdout, stderr.decode(errors="replace")

async def download_attachment(attachment: discord.Attachment) -> bytes:
    async with aiohttp.ClientSession() as session:
        async with session.get(attachment.url) as resp:
            return await resp.read()

async def get_or_create_category(guild: discord.Guild, category_id):
    if category_id:
        cat = guild.get_channel(category_id)
        if cat and isinstance(cat, discord.CategoryChannel):
            return cat
    for cat in guild.categories:
        if cat.name == "🎬 Media Bot":
            return cat
    return await guild.create_category("🎬 Media Bot")

async def create_private_channel(guild, user, name, bot):
    category = await get_or_create_category(guild, bot.CATEGORY_ID)
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(read_messages=False),
        user: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
        guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
    }
    channel = await guild.create_text_channel(
        name=name, overwrites=overwrites, category=category,
        topic=f"Canal privado de {user.display_name} | Envie sua midia aqui."
    )
    uid = str(user.id)
    if uid not in bot.active_channels:
        bot.active_channels[uid] = []
    bot.active_channels[uid].append(channel.id)
    return channel

def user_channel_count(bot, user_id) -> int:
    return len(bot.active_channels.get(str(user_id), []))

def has_booster_role(member, role_id) -> bool:
    if not role_id:
        return False
    return any(r.id == role_id for r in member.roles)

async def remove_active_channel(bot, user_id, channel_id):
    uid = str(user_id)
    if uid in bot.active_channels and channel_id in bot.active_channels[uid]:
        bot.active_channels[uid].remove(channel_id)


# ─────────────────────────────────────────
#  VIEW — Menu dropdown
# ─────────────────────────────────────────
class ToolSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.select(
        placeholder="Nada selecionado.",
        custom_id="media:select_tool",
        options=[
            discord.SelectOption(label="Conversor",      description="Transforme seu video em um GIF",     emoji="🎞️", value="conversor"),
            discord.SelectOption(label="Compressor",     description="Diminua o tamanho do seu GIF",       emoji="🔄", value="compressor"),
            discord.SelectOption(label="Extrator",       description="Extraia audio de videos",            emoji="🔊", value="extrator"),
            discord.SelectOption(label="Preto e Branco", description="Deixe sua imagem em preto e branco", emoji="🖤", value="pb"),
        ]
    )
    async def select_tool(self, interaction: discord.Interaction, select: discord.ui.Select):
        tool  = select.values[0]
        user  = interaction.user
        bot   = interaction.client
        guild = interaction.guild

        is_booster = has_booster_role(user, bot.BOOSTER_ROLE_ID)
        count = user_channel_count(bot, str(user.id))
        if not is_booster and count >= bot.MAX_CHANNELS_PER_USER:
            await interaction.response.send_message(
                f"❌ Você já tem **{count} canais** abertos (limite: {bot.MAX_CHANNELS_PER_USER}).\nDelete um antes de criar outro.",
                ephemeral=True
            )
            return

        slugs = {
            "conversor":  ("🎞️", "conversor"),
            "compressor": ("🔄", "compressor"),
            "extrator":   ("🔊", "extrator"),
            "pb":         ("🖤", "preto-e-branco"),
        }
        emoji, slug = slugs[tool]
        channel_name = f"{emoji}・{slug}-{user.name[:10].lower()}"

        await interaction.response.defer(ephemeral=True)
        channel = await create_private_channel(guild, user, channel_name, bot)

        descriptions = {
            "conversor":  ("🎞️ Conversor — Vídeo para GIF",  "Envie seu **vídeo** aqui e eu vou convertê-lo para **GIF** automaticamente."),
            "compressor": ("🔄 Compressor de GIF",            "Envie seu **GIF** aqui e eu vou comprimí-lo para usar no seu perfil."),
            "extrator":   ("🔊 Extrator de Áudio",            "Envie seu **vídeo** aqui e eu vou extrair o **áudio** em MP3."),
            "pb":         ("🖤 Preto e Branco",               "Envie sua **imagem** aqui e eu vou convertê-la para **preto e branco**."),
        }
        title, desc = descriptions[tool]
        embed = discord.Embed(
            title=title,
            description=(
                f"{desc}\n\n"
                f"> ⚠️ O arquivo não pode ultrapassar **{MAX_FILE_MB}MB**.\n"
                "> 🗑️ Este canal será deletado automaticamente após a conversão."
            ),
            color=discord.Color.blurple()
        )
        embed.set_footer(text=f"Canal de {user.display_name} • Media Bot")
        await channel.send(content=user.mention, embed=embed, view=DeleteChannelView(str(user.id)))
        await interaction.followup.send(f"✅ Canal criado: {channel.mention}\nEnvie sua mídia lá!", ephemeral=True)


# ─────────────────────────────────────────
#  VIEW — Botão deletar canal
# ─────────────────────────────────────────
class DeleteChannelView(discord.ui.View):
    def __init__(self, user_id: str):
        super().__init__(timeout=None)
        self.user_id = user_id

    @discord.ui.button(label="🗑️ Deletar Canal", style=discord.ButtonStyle.danger, custom_id="media:delete_channel")
    async def delete_channel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id and not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Apenas o dono do canal pode deletá-lo.", ephemeral=True)
            return
        await interaction.response.send_message("🗑️ Deletando canal...", ephemeral=True)
        await remove_active_channel(interaction.client, self.user_id, interaction.channel.id)
        await asyncio.sleep(1)
        await interaction.channel.delete()


# ─────────────────────────────────────────
#  COG PRINCIPAL
# ─────────────────────────────────────────
class MediaCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        if FFMPEG_PATH:
            print(f"  ✅ ffmpeg encontrado: {FFMPEG_PATH}")
        else:
            print("  ⚠️  ffmpeg NAO encontrado — coloque ffmpeg.exe na pasta do bot!")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.attachments:
            return

        name = message.channel.name.lower()
        tool = None
        if "conversor"  in name: tool = "conversor"
        elif "compressor" in name: tool = "compressor"
        elif "extrator"   in name: tool = "extrator"
        elif "preto"      in name or "pb" in name: tool = "pb"
        if not tool:
            return

        att = message.attachments[0]
        if att.size > MAX_FILE_BYTES:
            await message.channel.send(f"❌ Arquivo muito grande! Máximo: **{MAX_FILE_MB}MB**.")
            return

        # P&B usa Pillow — não precisa de ffmpeg
        if tool != "pb" and not FFMPEG_PATH:
            await message.channel.send(
                "❌ **ffmpeg não encontrado!**\n"
                "**Como instalar:**\n"
                "1. Baixe em: https://ffmpeg.org/download.html\n"
                "2. Extraia e coloque o `ffmpeg.exe` na **mesma pasta do bot** (onde está o `main.py`)\n"
                "3. Reinicie o bot."
            )
            return

        msg = await message.channel.send("⏳ Processando sua mídia, aguarde...")
        try:
            data = await download_attachment(att)
            with tempfile.TemporaryDirectory() as tmpdir:
                inp = os.path.join(tmpdir, f"input_{att.filename}")
                with open(inp, "wb") as f:
                    f.write(data)

                if   tool == "conversor":  await self._to_gif(message, inp, tmpdir, msg)
                elif tool == "compressor": await self._compress(message, inp, tmpdir, msg)
                elif tool == "extrator":   await self._extract(message, inp, tmpdir, msg)
                elif tool == "pb":         await self._to_pb(message, inp, tmpdir, msg, att.filename)

        except Exception as e:
            await msg.edit(content=f"❌ Erro ao processar: `{e}`")

    # ── Vídeo → GIF ──────────────────────────────────────────────
    async def _to_gif(self, message, inp, tmpdir, msg):
        palette = os.path.join(tmpdir, "palette.png")
        output  = os.path.join(tmpdir, "output.gif")
        ok, _, err = await run_ffmpeg("-i", inp, "-vf", "fps=15,scale=480:-1:flags=lanczos,palettegen", palette, "-y")
        if not ok:
            await msg.edit(content=f"❌ Erro ao gerar paleta:\n```{err[-300:]}```"); return
        ok, _, err = await run_ffmpeg("-i", inp, "-i", palette,
            "-lavfi", "fps=15,scale=480:-1:flags=lanczos[x];[x][1:v]paletteuse", output, "-y")
        if not ok:
            await msg.edit(content=f"❌ Erro na conversão:\n```{err[-300:]}```"); return
        await msg.edit(content="✅ GIF gerado com sucesso!")
        await message.channel.send(content=f"{message.author.mention} aqui está seu GIF!",
            file=discord.File(output, "output.gif"))

    # ── GIF → GIF comprimido ─────────────────────────────────────
    async def _compress(self, message, inp, tmpdir, msg):
        output = os.path.join(tmpdir, "compressed.gif")
        ok, _, err = await run_ffmpeg("-i", inp, "-vf", "fps=10,scale=320:-1:flags=lanczos", output, "-y")
        if not ok:
            await msg.edit(content=f"❌ Erro na compressão:\n```{err[-300:]}```"); return
        orig = os.path.getsize(inp) / (1024*1024)
        comp = os.path.getsize(output) / (1024*1024)
        red  = 100 - (comp / orig * 100)
        await msg.edit(content=f"✅ Comprimido! `{orig:.1f}MB → {comp:.1f}MB` ({red:.0f}% menor)")
        await message.channel.send(content=f"{message.author.mention} aqui está seu GIF comprimido!",
            file=discord.File(output, "compressed.gif"))

    # ── Vídeo → MP3 ──────────────────────────────────────────────
    async def _extract(self, message, inp, tmpdir, msg):
        output = os.path.join(tmpdir, "audio.mp3")
        ok, _, err = await run_ffmpeg("-i", inp, "-q:a", "0", "-map", "a", output, "-y")
        if not ok:
            await msg.edit(content=f"❌ Erro na extração:\n```{err[-300:]}```"); return
        await msg.edit(content="✅ Áudio extraído!")
        await message.channel.send(content=f"{message.author.mention} aqui está o áudio!",
            file=discord.File(output, "audio.mp3"))

    # ── Imagem → Preto e Branco (Pillow, sem ffmpeg) ─────────────
    async def _to_pb(self, message, inp, tmpdir, msg, original_name):
        try:
            from PIL import Image
        except ImportError:
            await msg.edit(content="❌ Pillow não instalado. Rode: `pip install Pillow`")
            return
        try:
            ext = os.path.splitext(original_name)[1].lower()
            save_ext = ext if ext in (".png", ".jpg", ".jpeg", ".bmp", ".webp") else ".png"
            output = os.path.join(tmpdir, f"pb{save_ext}")
            img = Image.open(inp).convert("L").convert("RGB")
            img.save(output)
            await msg.edit(content="✅ Imagem convertida para preto e branco!")
            await message.channel.send(
                content=f"{message.author.mention} aqui está sua imagem em preto e branco!",
                file=discord.File(output, f"pb{save_ext}")
            )
        except Exception as e:
            await msg.edit(content=f"❌ Erro na conversão P&B: `{e}`")

    # ── /setup-media ─────────────────────────────────────────────
    @app_commands.command(name="setup-media", description="Envia o painel de ferramentas de midia")
    @app_commands.checks.has_permissions(administrator=True)
    async def setup_media(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="🎬 Media Bot — Ferramentas de Mídia",
            description=(
                "Selecione uma ferramenta abaixo para começar!\n\n"
                "**🎞️ Conversor** — Transforme seu vídeo em GIF\n"
                "**🔄 Compressor** — Diminua o tamanho do seu GIF\n"
                "**🔊 Extrator** — Extraia áudio de vídeos\n"
                "**🖤 Preto e Branco** — Deixe sua imagem em P&B\n\n"
                "**Como funciona?**\n"
                "• Selecione a ferramenta no menu abaixo\n"
                "• Um canal **privado** será criado para você\n"
                "• Envie sua mídia no canal e receba o resultado!\n\n"
                f"> ⚠️ Limite: **{self.bot.MAX_CHANNELS_PER_USER} canais** por usuário\n"
                f"> ⚠️ Arquivo máximo: **{MAX_FILE_MB}MB**\n"
                "> ⭐ O cargo Booster **não possui** limites de uso"
            ),
            color=discord.Color.blurple()
        )
        embed.set_footer(text="Media Bot • Canal privado criado automaticamente")
        await interaction.channel.send(embed=embed, view=ToolSelectView())
        await interaction.response.send_message("✅ Painel enviado!", ephemeral=True)

    # ── /fechar-canal ─────────────────────────────────────────────
    @app_commands.command(name="fechar-canal", description="Fecha seu canal de midia atual")
    async def fechar_canal(self, interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if interaction.channel.id in self.bot.active_channels.get(uid, []):
            await interaction.response.send_message("🗑️ Fechando canal...", ephemeral=True)
            await remove_active_channel(self.bot, uid, interaction.channel.id)
            await asyncio.sleep(1)
            await interaction.channel.delete()
        else:
            await interaction.response.send_message("❌ Este não é um canal de mídia seu.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(MediaCog(bot))
