import discord
from discord.ext import commands
import time
from utils.config import get_config

class Suggestions(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot:
            return

        suggestion_channel_id = get_config("suggestion_channel_id")
        if not suggestion_channel_id or message.channel.id != int(suggestion_channel_id):
            return

        # Apaga a mensagem do usuário
        try:
            await message.delete()
        except discord.Forbidden:
            pass

        # Container da Sugestão (Components V2)
        timestamp = int(time.time())
        components: list[discord.ui.Item[discord.ui.DesignerView]] = [
            discord.ui.Container(
                discord.ui.Section(
                    discord.ui.TextDisplay(content=f"{message.author.display_name} `{message.author.name}`"),
                    discord.ui.TextDisplay(content=f"{message.content}"),
                    discord.ui.TextDisplay(content=f"-# <t:{timestamp}:d> <t:{timestamp}:t>"),
                    accessory=discord.ui.Thumbnail(
                        url=message.author.display_avatar.url,
                    ),
                ),
                discord.ui.Separator(divider=True, spacing=discord.SeparatorSpacingSize.small,),
                discord.ui.ActionRow(
                    discord.ui.Button(
                        style=discord.ButtonStyle.secondary,
                        emoji="<:banhammer:1467813225889403032>",
                        custom_id=f"punish_user_{message.author.id}",
                    ),
                ),
            ),
        ]

        view = discord.ui.DesignerView(*components)
        
        # Envia o container no canal
        suggestion_msg = await message.channel.send(view=view)

        # Cria um tópico a partir da mensagem do container
        thread_name = f"Sugestão de {message.author.display_name}"
        thread = await suggestion_msg.create_thread(
            name=thread_name,
            auto_archive_duration=1440
        )

        # Mensagem fixa no tópico
        fixed_message = (
            f"> **Obrigado por enviar sua sugestão, {message.author.mention} ♥️ **\n"
            "Este canal foi criado para facilitar a discussão e o aprimoramento da sua ideia junto à comunidade.\n"
            "Sinta-se à vontade para compartilhar opiniões e sugestões construtivas aqui.\n"
            "-# Use mensagens claras e respeitosas para contribuir!"
        )
        await thread.send(content=fixed_message)

def setup(bot):
    bot.add_cog(Suggestions(bot))
