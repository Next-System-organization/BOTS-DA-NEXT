import discord
from discord.ext import commands
from utils.config import set_config, get_config

class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def send_panel(self, interaction_or_ctx):
        suggestion_channel_id = get_config("suggestion_channel_id")
        log_channel_id = get_config("log_channel_id")
        staff_role_id = get_config("staff_role_id")

        suggestion_channel = (
            f"<#{suggestion_channel_id}>"
            if suggestion_channel_id else "Não configurado"
        )
        log_channel = (
            f"<#{log_channel_id}>"
            if log_channel_id else "Não configurado"
        )
        staff_role = (
            f"<@&{staff_role_id}>"
            if staff_role_id else "Não configurado"
        )

        components: list[discord.ui.Item[discord.ui.DesignerView]] = [
            discord.ui.Container(
                discord.ui.Section(
                    discord.ui.TextDisplay(content="# Painel de gerenciamento"),
                    discord.ui.TextDisplay(
                        content="Clique no botão `🗑️` para resetar as configurações."
                    ),
                    discord.ui.TextDisplay(
                        content="-# Desenvolvido por **7M VIP** `@7M VIP`"
                    ),
                    accessory=discord.ui.Button(
                        style=discord.ButtonStyle.danger,
                        label="🗑️",
                        custom_id="btn_reset_config",
                    ),
                ),
                discord.ui.Separator(
                    divider=False,
                    spacing=discord.SeparatorSpacingSize.large,
                ),
                discord.ui.Section(
                    discord.ui.TextDisplay(
                        content=f"`Canal de sugestões atual`: {suggestion_channel}"
                    ),
                    discord.ui.TextDisplay(
                        content="-# Canal onde serão criados os tópicos e containers de sugestões."
                    ),
                    accessory=discord.ui.Button(
                        style=discord.ButtonStyle.primary,
                        label="Configurar canal de sugestões",
                        custom_id="btn_config_suggestions",
                    ),
                ),
                discord.ui.Separator(
                    divider=True,
                    spacing=discord.SeparatorSpacingSize.small,
                ),
                discord.ui.Section(
                    discord.ui.TextDisplay(
                        content=f"`Canal de logs atual`: {log_channel}"
                    ),
                    discord.ui.TextDisplay(
                        content="-# Canal onde serão enviadas as logs de punições."
                    ),
                    accessory=discord.ui.Button(
                        style=discord.ButtonStyle.secondary,
                        label="Configurar canal de logs",
                        custom_id="btn_config_logs",
                    ),
                ),
                discord.ui.Separator(
                    divider=True,
                    spacing=discord.SeparatorSpacingSize.small,
                ),
                discord.ui.Section(
                    discord.ui.TextDisplay(
                        content=f"`Cargo de staff atual`: {staff_role}"
                    ),
                    accessory=discord.ui.Button(
                        style=discord.ButtonStyle.success,
                        label="Configurar cargo de staff",
                        custom_id="btn_config_staff",
                    ),
                ),
                discord.ui.TextDisplay(
                    content="-# Cargo que terá permissão de punir usuários."
                ),
                color=discord.Color(10038562),
            ),
        ]

        view = discord.ui.DesignerView(*components)

        # Compatível com ctx OU interaction
        if isinstance(interaction_or_ctx, discord.ApplicationContext):
            await interaction_or_ctx.respond(view=view, ephemeral=True)
        else:
            await interaction_or_ctx.followup.send(view=view, ephemeral=True)

    @discord.slash_command(
        name="painel-sugestoes",
        description="Configura o sistema de sugestões"
    )
    async def painel_sugestoes(self, ctx: discord.ApplicationContext):
        if ctx.author.id != self.bot.owner_id:
            return await ctx.respond(
                "Apenas o dono do bot pode usar este comando.",
                ephemeral=True
            )

        await self.send_panel(ctx)

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component:
            return

        custom_id = interaction.data.get("custom_id")
        if not custom_id:
            return

        if custom_id == "btn_config_suggestions":
            await self.send_config_select(
                interaction,
                "suggestion_channel",
                discord.ComponentType.channel_select
            )

        elif custom_id == "btn_config_logs":
            await self.send_config_select(
                interaction,
                "log_channel",
                discord.ComponentType.channel_select
            )

        elif custom_id == "btn_config_staff":
            await self.send_config_select(
                interaction,
                "staff_role",
                discord.ComponentType.role_select
            )

        elif custom_id == "btn_reset_config":
            set_config("suggestion_channel_id", None)
            set_config("log_channel_id", None)
            set_config("staff_role_id", None)

            await interaction.response.send_message(
                "Configurações resetadas.",
                ephemeral=True
            )

            await self.send_panel(interaction)

        elif custom_id.startswith("select_config_"):
            values = interaction.data.get("values", [])
            if not values:
                return

            key = custom_id.replace("select_config_", "")
            set_config(f"{key}_id", values[0])

            await interaction.response.send_message(
                f"Configuração de **{key}** salva com sucesso!",
                ephemeral=True
            )

            await self.send_panel(interaction)

    async def send_config_select(self, interaction, key, select_type):
        components = [
            discord.ui.ActionRow(
                discord.ui.Select(
                    custom_id=f"select_config_{key}",
                    placeholder=f"Selecione o item para {key}",
                    select_type=select_type,
                )
            )
        ]
        view = discord.ui.DesignerView(*components)
        await interaction.response.send_message(
            "Selecione abaixo:",
            view=view,
            ephemeral=True
        )

def setup(bot):
    bot.add_cog(Admin(bot))