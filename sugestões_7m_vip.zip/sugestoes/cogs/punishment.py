import discord
from discord.ext import commands
import datetime
import time
from utils.config import get_config

class PunishModal(discord.ui.Modal):
    def __init__(self, target_user: discord.Member, container_message: discord.Message, suggestion_content: str):
        super().__init__(title=f"Punir {target_user.display_name}")
        self.target_user = target_user
        self.container_message = container_message
        self.suggestion_content = suggestion_content
        
        self.add_item(
            discord.ui.InputText(
                label=f"Motivo da punição",
                placeholder=f"Digite abaixo o motivo da punição do usuário {target_user.display_name}.",
                style=discord.InputTextStyle.long,
            )
        )

    async def callback(self, interaction: discord.Interaction):
        reason = self.children[0].value
        staff = interaction.user
        timestamp = int(time.time())

        # 1. Aplicar TIMEOUT DE 7 DIAS
        try:
            duration = datetime.timedelta(days=7)
            await self.target_user.timeout_for(duration, reason=reason)
        except Exception as e:
            print(f"Erro ao aplicar timeout: {e}")

        # 4. Enviar DM ao usuário punido (Components V2)
        try:
            dm_components: list[discord.ui.Item[discord.ui.DesignerView]] = [
                discord.ui.Container(
                    discord.ui.Section(
                        discord.ui.TextDisplay(content=f"## Olá, {self.target_user.mention}"),
                        discord.ui.TextDisplay(
                            content="Nossos moderadores analisaram sua sugestão e concluíram que ela violou nossas regras ou foi considerada spam."
                        ),
                        discord.ui.TextDisplay(content=f"-# Conclusão do moderador: {reason}"),
                        accessory=discord.ui.Thumbnail(
                            url=self.target_user.display_avatar.url,
                        ),
                    ),
                    discord.ui.Separator(divider=False, spacing=discord.SeparatorSpacingSize.large,),
                    discord.ui.TextDisplay(
                        content="Se você acredita que houve um erro, pode recorrer da punição clicando no botão abaixo."
                    ),
                    discord.ui.ActionRow(
                        discord.ui.Button(
                            url=f"https://discord.com/users/{interaction.guild.owner_id}",
                            style=discord.ButtonStyle.link,
                            label="Apelar Punição",
                        ),
                    ),
                ),
            ]
            dm_view = discord.ui.DesignerView(*dm_components)
            await self.target_user.send(view=dm_view)
        except Exception as e:
            print(f"Erro ao enviar DM: {e}")

        # 5. Enviar log no canal configurado (Components V2)
        log_channel_id = get_config("log_channel_id")
        if log_channel_id:
            log_channel = interaction.guild.get_channel(int(log_channel_id))
            if log_channel:
                log_components: list[discord.ui.Item[discord.ui.DesignerView]] = [
                    discord.ui.Container(
                        discord.ui.TextDisplay(content="# Punição - Sugestões"),
                        discord.ui.Section(
                            discord.ui.TextDisplay(content=f"Usuário Punido: {self.target_user.mention}"),
                            discord.ui.TextDisplay(content=f"ID do usuário punido: {self.target_user.id}"),
                            discord.ui.TextDisplay(content=f"Motivo da punição: {reason}"),
                            accessory=discord.ui.Thumbnail(
                                url=self.target_user.display_avatar.url,
                            ),
                        ),
                        discord.ui.Separator(divider=True, spacing=discord.SeparatorSpacingSize.small,),
                        discord.ui.Section(
                            discord.ui.TextDisplay(content=f"Staff Responsável: {staff.mention}"),
                            discord.ui.TextDisplay(content=f"ID do staff responsável: {staff.id}"),
                            discord.ui.TextDisplay(content=f"Data da punição: <t:{timestamp}:F>"),
                            accessory=discord.ui.Thumbnail(
                                url=staff.display_avatar.url,
                            ),
                        ),
                        discord.ui.Separator(divider=True, spacing=discord.SeparatorSpacingSize.small,),
                        discord.ui.TextDisplay(content="# Sugestão:"),
                        discord.ui.TextDisplay(content=f"{self.suggestion_content}"),
                    ),
                ]
                log_view = discord.ui.DesignerView(*log_components)
                await log_channel.send(view=log_view)

        # 2. Apagar o container da sugestão
        # 3. Deletar o tópico (se existir)
        await interaction.response.send_message("Punição aplicada com sucesso. O container e o tópico serão removidos.", ephemeral=True)
        
        try:
            if self.container_message.thread:
                await self.container_message.thread.delete()
            await self.container_message.delete()
        except Exception as e:
            print(f"Erro ao deletar container/tópico: {e}")

class Punishment(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component:
            return
        
        custom_id = interaction.data.get("custom_id")
        if not custom_id or not custom_id.startswith("punish_user_"):
            return

        # Verificar cargo configurado
        staff_role_id = get_config("staff_role_id")
        if not staff_role_id:
            return await interaction.response.send_message("O cargo de staff não está configurado.", ephemeral=True)
        
        staff_role = interaction.guild.get_role(int(staff_role_id))
        if not staff_role or staff_role not in interaction.user.roles:
            return await interaction.response.send_message("Você não tem permissão para usar este botão.", ephemeral=True)

        target_user_id = int(custom_id.replace("punish_user_", ""))
        target_user = interaction.guild.get_member(target_user_id)
        
        if not target_user:
            return await interaction.response.send_message("Usuário não encontrado no servidor.", ephemeral=True)

        # Tentar recuperar o conteúdo da sugestão do container
        suggestion_content = "Não consegui encontrar a sugestão :("
        # Em Components V2, o conteúdo está dentro da estrutura do DesignerView
        # Como não temos acesso fácil ao texto bruto via interaction.message.content (pois é um container),
        # vamos usar um placeholder ou tentar extrair se possível.
        
        modal = PunishModal(target_user, interaction.message, suggestion_content)
        await interaction.response.send_modal(modal)

def setup(bot):
    bot.add_cog(Punishment(bot))
