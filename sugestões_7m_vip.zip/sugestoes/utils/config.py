import json
import os

CONFIG_PATH = "bot_project/data/painel.json"

def load_config():
    if not os.path.exists(CONFIG_PATH):
        return {}
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return {}

def save_config(data):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def get_config(key, default=None):
    config = load_config()
    return config.get(key, default)

def set_config(key, value):
    config = load_config()
    config[key] = value
    save_config(config)
