import discord
import os
from dotenv import load_dotenv
from utils.config import get_config

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
OWNER_ID = int(os.getenv("OWNER_ID", 0))

class MyBot(discord.Bot):
    def __init__(self):
        super().__init__(
            intents=discord.Intents.all(),
            owner_id=OWNER_ID
        )

    async def on_ready(self):
        print(f"Bot conectado como {self.user} (ID: {self.user.id})")
        print("------")

bot = MyBot()

# Handler para registrar os cogs
def load_cogs():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    cogs_dir = os.path.join(base_dir, "cogs")

    if not os.path.exists(cogs_dir):
        print(f"ERRO: pasta de cogs não encontrada: {cogs_dir}")
        return

    for filename in os.listdir(cogs_dir):
        if filename.endswith(".py") and not filename.startswith("_"):
            try:
                bot.load_extension(f"cogs.{filename[:-3]}")
                print(f"Cog carregado: {filename}")
            except Exception as e:
                print(f"Falha ao carregar cog {filename}: {e}")

if __name__ == "__main__":
    load_cogs()
    if TOKEN:
        bot.run(TOKEN)
    else:
        print("ERRO: DISCORD_TOKEN não encontrado no arquivo .env")
