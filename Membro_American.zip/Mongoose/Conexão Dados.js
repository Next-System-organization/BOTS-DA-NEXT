const mongoose = require('mongoose');

// Crie instâncias separadas do Mongoose para cada conexão
const mongooseAuth = mongoose.createConnection('mongodb+srv://stormappsrecebimentos:G5F8ub3mqMjwNWzj@cluster0.vdhf9re.mongodb.net/MainBOT-Auth?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const mongooseAuthAPI = mongoose.createConnection('mongodb+srv://stormappsrecebimentos:G5F8ub3mqMjwNWzj@cluster0.vdhf9re.mongodb.net/MainAPI-Auth?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const AuthSchema = new mongoose.Schema({
    Bot: {
        clientid: String,
        token: String,
        client_secret: String,
    },
    Time: String,
    Dono: String,
    Usuarios: {
        type: Array,
        default: []
    },
});



const EstatísticasSchemaAuth = new mongoose.Schema({
    usuario: String,
    quantidade: Number,
    data: String,
    valor: String,
    IdServer: String,
    refill: Boolean
});

 const EstatisticasAuth = mongooseAuth.model('Estatisticas2', EstatísticasSchemaAuth);
 const AuthConfig = mongooseAuthAPI.model('AuthRegistrions', AuthSchema);
 
module.exports = {
    EstatisticasAuth,
    AuthConfig
};