const { ActivityType, EmbedBuilder, ButtonBuilder } = require('discord.js');
const { QuickDB } = require("quick.db");
const db = new QuickDB();
const axios = require('axios');
const { ActionRowBuilder, WebhookClient } = require('discord.js');
const { AuthConfig } = require('../../Mongoose/Conexão Dados');
module.exports = {
    name: 'ready',

    run: async (client) => {

        async function atualizamsg(client) {

            const guild = client.guilds.cache.get(await await db.get(`msgdefault.guildid`));

            const channel = guild.channels.cache.get(await await db.get(`msgdefault.channelid`));
            channel.messages.fetch(await await db.get(`msgdefault.msgid`))
                .then(async message => {
           
                 

                    const verificarid = await AuthConfig.findOne({ 'Bot.clientid': '1174732337804759090'})
     			 const dadosFiltrados = verificarid.Usuarios.filter((item) => item.access_token !== 'unauthorized');
           
              
                    const embed = new EmbedBuilder()
                      .setTitle(`🛡 Venda de Membros | Loja de Membros`)
                      .setDescription(`Segue abaixo a quantidade de **MEMBROS** dísponível para **COMPRA!**`)
                      .addFields(
                        { name: '🛒 Membros Disponíveis: ', value: `*${dadosFiltrados.length}*` }
                      )
                      .setFooter({ text: `Compre seu MEMBROS pelo menor preço do MERCADO.` })
.setImage('https://cdn.discordapp.com/attachments/1175599865674342470/1178453107315847300/black_friday_storm_apps.png?ex=657632fb&is=6563bdfb&hm=aad020972b46f8a217f4a40dab12e5d9ceb826da31801cadb51d6469a46cd106&')

                      .setColor("Green")
                    message.edit({embeds: [embed], content: ``});
                      
                })
                .catch(error => {
                });

        }


        setInterval(() => {
            atualizamsg(client)
        }, 30000);
        


        async function verificarpagamento(client) {
            const ddd = await db.all()

            for (let i = 0; i < ddd.length; i++) {
                const element = ddd[i];
                if (element.value.pagamentos !== undefined) {
                    var res = await axios.get(`https://api.mercadopago.com/v1/payments/${element.value.pagamentos.PagamentoId}`, {
                        headers: {
                            Authorization: `Bearer APP_USR-3744640363763411-112712-d1de927ea8487fcb580985ae53afb61a-1566582955`
                        }
                    })


                    if (res.data.status == 'approved') { //approved

                        const webhookClient = new WebhookClient({ url: 'https://discord.com/api/webhooks/1178867304096858112/S1803fScct_EY8ave4ETVVMYzuEkSKNeXvcLfbXsbEcMg_IXWhwv5ovdDPXVg9gX7XSD' });
                        webhookClient.send({content: `✅ NOVA COMPRA: <@${element.value.user.id}> (${element.value.user.id}) | 💸 Valor: ${element.value.valortotal}`})

                        await db.delete(`${element.id}.pagamentos`)
                        const embed = new EmbedBuilder()
                            .setColor('000000')
                            .setTitle(`${client.user.username} | Sistema de pagamento`)
                            .setDescription(`✅ | Pagamento aprovado!\n\nPara começar o envio dos membros, clique abaixo em Adicionar BOT, adicione em seu servidor com permissão de Administrado! (Nada será mexido apenas será entregue os BOTS!), Após clique em (Enviar Membros)`)
                            .setFooter({ text: `Pagamento Aprovado!`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })


                        const row = new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setCustomId("EnviarMembros")
                                    .setLabel('Enviar Membros')
                                    .setStyle(1)
                                    .setDisabled(false),

                                new ButtonBuilder()
                                    .setURL('https://canary.discord.com/api/oauth2/authorize?client_id=1174732337804759090&permissions=8&scope=applications.commands%20bot')
                                    .setLabel('Adicionar BOT')
                                    .setStyle(5)
                                    .setDisabled(false),
                            )


                        try {
                            await axios.patch(`https://discord.com/api/webhooks/${element.value.pagamentos.applicationid}/${element.value.pagamentos.webhookID}/messages/${element.value.pagamentos.msgid}`, {
                                flags: 64,
                                embeds: [embed],
                                components: [row],


                            });
                        } catch (error) {

                        }


                    }

                }
            }
        }

        setInterval(() => {
            verificarpagamento(client)
        }, 3000);

        console.log(`${client.user.tag} Foi iniciado \n - Atualmente ${client.guilds.cache.size} servidores!\n - Tendo acesso a ${client.channels.cache.size} canais!\n - Contendo ${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)} usuarios!`)

        let activities = [
            `${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)} PESSOAS 👀`,
        ]
        i = 0;
        setInterval(() =>

            client.user.setPresence({
                activities: [{ name: `${activities[i++ % activities.length]}`, type: ActivityType.Watching }],
                status: `ndn`,
            })

            , 4000);
    }
}
