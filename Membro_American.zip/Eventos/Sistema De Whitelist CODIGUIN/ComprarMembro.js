const Discord = require("discord.js");  // npm i discord.js@latest
const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { PermissionsBitField, InteractionType, EmbedBuilder, ButtonBuilder } = require('discord.js');
const { QuickDB } = require("quick.db");
const db = new QuickDB();
const mercadopago = require("mercadopago");
const { EstatisticasAuth, AuthConfig } = require("../../Mongoose/Conexão Dados");
const config = require("../../config.json")

module.exports = {
	name: 'interactionCreate',

	run: async (interaction, client) => {


		if (interaction.isAutocomplete()) {

			if (interaction.commandName == 'refill') {

				var dd = await EstatisticasAuth.find()
				const dataAtual = new Date();

				dataAtual.setDate(dataAtual.getDate() + 3);

				const timestamp = dataAtual.getTime();

				const config = dd.reduce((acc, x) => {
					const usuario = x.usuario;

					if (x.refill == true) {
						if (usuario == interaction.user.id) {




							acc.push({
								name: `ID Server -  ${x.IdServer} | Refill de ${x.quantidade} membros`,
								value: x._id
							});




						}
					}




					return acc;
				}, []);


				interaction.respond(!config.length ? [{ name: `Nenhuma compra foi Encontrada.`, value: `nada` }] : config);
			}
		}



		if (interaction.type == InteractionType.ModalSubmit) {
			if (interaction.customId === 'iddoserverpuxar') {
				const idserver = interaction.fields.getTextInputValue('iddoserverpuxar');

				interaction.update({ content: '🕔 | Estamos verificando se o BOT está no servidor!', components: [], embeds: [] })



				let config = {
					method: 'GET',
					headers: {
						'token': 'b19319017fc14ff5b262885935ec97a2'
					}
				};
const ddddd = await fetch(`http://stormapps.squareweb.app/api/v2/puxar?idnewserver=${idserver}&qtd=${await db.get(`${interaction.user.id}.qtd`)}&clientid=1174732337804759090`, config)
                const info = await ddddd.json()
			

				if (info.code == 2039 || info.code == 2040 || info.code == 2041) {
					const embed = new EmbedBuilder()
						.setColor('000000')
						.setTitle(`${client.user.username} | Sistema de pagamento`)
						.setDescription(`✅ | Pagamento aprovado!\n\nPara começar o envio dos membros, clique abaixo em Adicionar BOT , adicione em seu servidor com permissão de Administrado! (Nada será mexido apenas será entregue os BOTS!), Após clique em (Enviar Membros)`)
						.setFooter({ text: `Pagamento Aprovado!`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })

					const row = new ActionRowBuilder()
						.addComponents(
							new ButtonBuilder()
								.setCustomId("EnviarMembros")
								.setLabel('Enviar Membros')
								.setStyle(1)
								.setDisabled(false),

							new ButtonBuilder()
								.setURL('https://discord.com/api/oauth2/authorize?client_id=1174732337804759090&permissions=8&scope=bot%20applications.commands')
								.setLabel('Adicionar o Bot')
								.setStyle(5)
								.setDisabled(false),
						)

					interaction.editReply({ content: `❌ | O bot Não se encontra no servidor de destino dos membros.`, components: [row], embeds: [embed], ephemeral: true })
					return
				} else if (info.code == 202) {
					await EstatisticasAuth.create({
						data: Date.now(),
						quantidade: await db.get(`${interaction.user.id}.qtd`),
						usuario: interaction.user.id,
						valor: await db.get(`${interaction.user.id}.valortotal`),
						refill: await db.get(`${interaction.user.id}.refill`),
						IdServer: idserver
					})


					const member = await interaction.guild.members.fetch(interaction.user.id);

					try {
						await member.roles.add("1116747469083132075")
					} catch (error) {
						
					}


					const embedppppp = new EmbedBuilder()
						.setColor(
							'000000'
						)
						.setTitle(`${client.user.username} | Compra Aprovada`)
						.addFields(
							{ name: `👥 **| COMPRADOR:**`, value: `${interaction.user} | ${interaction.user.username}` },
							{ name: `📦 **| PRODUTO(S) COMPRADO(S):**`, value: `${await db.get(`${interaction.user.id}.qtd`)}x Membros` },
							{ name: `💸 **| VALOR PAGO:**`, value: `R$${await db.get(`${interaction.user.id}.valortotal`)}` },
							{ name: `🎁 **| VALOR DO DESCONTO:**`, value: `\`R$0\`` },
							{ name: `📅 **| DATA:**`, value: `<t:${Math.ceil(Date.now() / 1000)}> (<t:${Math.ceil(Date.now() / 1000)}:R>)` },

						)
						.setFooter({ text: `${client.user.username} - Todos os direitos reservados.` })


					const channela2 = interaction.guild.channels.cache.get('1178860949013270609');
					await channela2.send({ embeds: [embedppppp] });
					interaction.editReply({ content: `✅ | Estamos puxando todos membros para seu Servidor!, Obrigado Pela Compra!`, components: [], embeds: [] })
				}
			}

			if (interaction.customId === 'escolherqtdproduto') {
    try {
        // Adiciona uma mensagem temporária enquanto processa a solicitação
        await interaction.deferUpdate();

        const qtdddd = interaction.fields.getTextInputValue('escolherqtdproduto');
        const quantidade = parseFloat(qtdddd);

        if (isNaN(quantidade) || quantidade <= 100) {
            await interaction.editReply({ content: `❌ | Quantidade inválida!`, ephemeral: true });
            return;
        }

        const verificarid = await AuthConfig.findOne({ 'Bot.clientid': '1174732337804759090' });
        const dadosFiltrados = verificarid.Usuarios.filter((item) => item.access_token !== 'unauthorized');

        if (quantidade > dadosFiltrados.length) {
            await interaction.editReply({ content: `❌ | Você atingiu a quantidade máxima de MEMBROS disponíveis para compra!`, ephemeral: true });
            return;
        }

        await db.set(`${interaction.user.id}`, { qtd: quantidade, valorrep: config.precos.ComReposicao, valorsemrep: config.precos.SemReposicao });

        const ddd = await db.get(`${interaction.user.id}.valorsemrep`) * quantidade;
        const fff = await db.get(`${interaction.user.id}.valorrep`) * quantidade;

        const embed = new EmbedBuilder()
            .setTitle(`🛡 Venda de Membros ${interaction.guild.name}`)
            .setDescription(`Escolha a mensagem abaixo para!`)
            .addFields(
                { name: 'Quantidade Membros: ', value: `*${quantidade}*` },
                { name: 'Valor à pagar (Reposição): ', value: `*${fff.toFixed(2)}*` },
                { name: 'Valor à pagar (Sem Reposição): ', value: `*${ddd.toFixed(2)}*` }
            )
            .setFooter({ text: `Compre seu MEMBROS pelo menor preço do MERCADO.` })
            .setColor("#2b2d31");

        // Atualiza a mensagem com os resultados
        await interaction.editReply({ content: '', embeds: [embed] });
    } catch (error) {
        console.error(error);
        // Lidar com erros, se necessário
    }
}


		}


		const a = config.precos.ComReposicao
		const b = config.precos.SemReposicao


		if (interaction.isButton()) {
			if (interaction.customId == 'ComprarMembro') {
				const embed = new EmbedBuilder()
					.setTitle(`🛡 Venda de Membros ${interaction.guild.name}`)
					.setDescription(`Escolha a mensagem abaixo para !`)
					.addFields(
						{ name: 'Quantidade Membros: ', value: `*100*` },
						{ name: 'Valor à pagar (Reposição): ', value: `*${a * 100}*` },
						{ name: 'Valor à pagar (Sem Reposição): ', value: `*${b * 100}*` }
					)
					.setFooter({ text: `Compre seu MEMBROS pelo menor preço do MERCADO.` })
					.setColor("#2b2d31");

				const row22 = new ActionRowBuilder().addComponents(
					new ButtonBuilder()
						.setLabel('+')
						.setCustomId('addqtdproducto')
						.setStyle(2),
					new ButtonBuilder()
						.setEmoji('✏️')
						.setCustomId('escolherqtdproduto')
						.setStyle(3),
					new ButtonBuilder()
						.setLabel('-')
						.setCustomId('remqtdproducto')
						.setStyle(2),
					new ButtonBuilder()
						.setLabel('Finalizar Compra')
						.setCustomId('FinalizarCompra')
						.setStyle(1),
				)

				interaction.reply({ ephemeral: true, embeds: [embed], components: [row22] }).then(async msg => {
					await db.set(`${interaction.user.id}`, { qtd: 100, valorrep: config.precos.ComReposicao, valorsemrep: config.precos.SemReposicao, user: interaction.user });
				})
			}

			if (interaction.customId == 'EnviarMembros') {

				const modala = new ModalBuilder()
					.setCustomId('iddoserverpuxar')
					.setTitle(`✏️ | ID do Servidor`);

				const AdicionarNoTicket = new TextInputBuilder()
					.setCustomId('iddoserverpuxar')
					.setLabel("ID do servidor?")
					.setStyle(TextInputStyle.Short)
					.setRequired(true)

				const firstActionRow = new ActionRowBuilder().addComponents(AdicionarNoTicket);

				modala.addComponents(firstActionRow);

				await interaction.showModal(modala);
			}

			if (interaction.customId == '1' || interaction.customId == '2') {

				var valor = 0

				if (interaction.customId == '1') {
					valor = await db.get(`${interaction.user.id}.valorrep`) * await db.get(`${interaction.user.id}.qtd`)
					await db.set(`${interaction.user.id}.refill`, true)
				} else {
					valor = await db.get(`${interaction.user.id}.valorsemrep`) * await db.get(`${interaction.user.id}.qtd`)
					await db.set(`${interaction.user.id}.refill`, false)
				}

				const embed = new EmbedBuilder()
					.setColor('000000')
					.setTitle(`${client.user.username} | Sistema de pagamento`)
					.setDescription(`\`\`\`Escolha a forma de pagamento.\`\`\`\n📦 **| Produto(s):**\n${await db.get(`${interaction.user.id}.qtd`)} Membros\n💸 **| Valor:**\nR$${Number(valor).toFixed(2)}`)
					.setFooter({ text: `Após efetuar o pagamento, o tempo de entrega é de 15 segundos`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
				const row = new ActionRowBuilder()
					.addComponents(
						new ButtonBuilder()
							.setCustomId("pixcopiaecola182381371")
							.setLabel('Pix Copia e Cola')
							.setEmoji(`1155183249375645847`)
							.setStyle(1)
							.setDisabled(false),
						new ButtonBuilder()
							.setCustomId("qrcode182812981")
							.setLabel('Qr Code')
							.setEmoji(`1155186524162363422`)
							.setStyle(1)
							.setDisabled(false),
						new ButtonBuilder()
							.setCustomId("stopcompracancellastfase")
							.setEmoji(`1155186604944666694`)
							.setStyle(4)
							.setDisabled(false))


				interaction.update({ embeds: [embed], components: [row] })


				var payment_data = {
					transaction_amount: Number(valor), //Number(valor)
					description: `Pagamento - ${await db.get(`${interaction.user.id}.qtd`)} Membros`,
					payment_method_id: 'pix',
					payer: {
						email: `${interaction.user.id}@gmail.com`,
						first_name: `Victor André`,
						last_name: `Ricardo Almeida`,
						identification: {
							type: 'CPF',
							number: '15084299872'
						},

						address: {
							zip_code: '86063190',
							street_name: 'Rua Jácomo Piccinin',
							street_number: '971',
							neighborhood: 'Pinheiros',
							city: 'Londrina',
							federal_unit: 'PR'
						}
					}
				}
				mercadopago.configurations.setAccessToken('APP_USR-3744640363763411-112712-d1de927ea8487fcb580985ae53afb61a-1566582955');


				await mercadopago.payment.create(payment_data)
					.then(async function (data) {
						await db.set(`${interaction.user.id}.valortotal`, valor)
						await db.set(`${interaction.user.id}.pagamentos`, { user: interaction.user, PagamentoId: data.body.id, idserver: interaction.guild.id, QrCode: data.body.point_of_interaction.transaction_data.qr_code_base64, pixcopiaecola: data.body.point_of_interaction.transaction_data.qr_code, webhookID: interaction.token, applicationid: interaction.applicationId, msgid: interaction.message.id })

					})




			}

			if (interaction.customId.startsWith('pixcopiaecola182381371')) {
				interaction.reply({ content: `${await db.get(`${interaction.user.id}.pagamentos.pixcopiaecola`)}`, ephemeral: true })
			}
			if (interaction.customId.startsWith('qrcode182812981')) {
				var ttttt = await db.get(`${interaction.user.id}.pagamentos.QrCode`)
				if (
					ttttt == null
				) return interaction.reply({ content: `QR Code invalido, crie outro carrinho.`, ephemeral: true })
				const buffer = Buffer.from(ttttt, "base64");
				const attachment = new Discord.AttachmentBuilder(buffer, { name: "payment.png" });
				interaction.reply({ files: [attachment], ephemeral: true })
			}



			if (interaction.customId == 'FinalizarCompra') {

				const ddd = await db.get(`${interaction.user.id}.valorsemrep`) * await db.get(`${interaction.user.id}.qtd`)
				const fff = await db.get(`${interaction.user.id}.valorrep`) * await db.get(`${interaction.user.id}.qtd`)

				const embed = new EmbedBuilder()
					.setTitle(`🛡 Venda de Membros ${interaction.guild.name}`)
					.setDescription(`Conclusão de Pedido!`)
					.addFields(
						{ name: 'Quantidade Membros: ', value: `*${await db.get(`${interaction.user.id}.qtd`)}*` },
						{ name: 'Valor à pagar (Reposição): ', value: `*${fff.toFixed(2)}*` },
						{ name: 'Valor à pagar (Sem Reposição): ', value: `*${ddd.toFixed(2)}*` }
					)
					.setFooter({ text: `Compre seu MEMBROS pelo menor preço do MERCADO.` })
					.setColor("#2b2d31");

				interaction.update({
					embeds: [embed], components: [

						new ActionRowBuilder()
							.addComponents(
								new ButtonBuilder()
									.setCustomId('1')
									.setLabel('1 - Com Refil')
									.setStyle(3),
								new ButtonBuilder()
									.setCustomId('33')
									.setLabel('ㅤ')
									.setStyle(2)
									.setDisabled(true),
								new ButtonBuilder()
									.setCustomId('2')
									.setLabel('2 - Sem Refil')
									.setStyle(4),
							),
					],
				})



			}








			if (interaction.customId == 'escolherqtdproduto') {

				const modala = new ModalBuilder()
					.setCustomId('escolherqtdproduto')
					.setTitle(`✏️ | Alterar Quantidade`);

				const AdicionarNoTicket = new TextInputBuilder()
					.setCustomId('escolherqtdproduto')
					.setLabel("Quantidade?")
					.setStyle(TextInputStyle.Short)
					.setRequired(true)

				const firstActionRow = new ActionRowBuilder().addComponents(AdicionarNoTicket);

				modala.addComponents(firstActionRow);

				await interaction.showModal(modala);
			}







			if (interaction.customId === 'remqtdproducto') {
    try {
        // Adiciona uma mensagem temporária enquanto processa a solicitação
        await interaction.deferUpdate();

        if (await db.get(`${interaction.user.id}.qtd`) <= 100) {
            await interaction.editReply({ content: `❌ | Você atingiu a quantidade mínima de MEMBROS disponíveis para compra!`, ephemeral: true });
            return;
        }

        await db.set(`${interaction.user.id}`, { qtd: await db.get(`${interaction.user.id}.qtd`) - 1, valorrep: config.precos.ComReposicao, valorsemrep: config.precos.SemReposicao });

        const ddd = await db.get(`${interaction.user.id}.valorsemrep`) * await db.get(`${interaction.user.id}.qtd`);
        const fff = await db.get(`${interaction.user.id}.valorrep`) * await db.get(`${interaction.user.id}.qtd`);

        const embed = new EmbedBuilder()
            .setTitle(`🛡 Venda de Membros ${interaction.guild.name}`)
            .setDescription(`Escolha a mensagem abaixo para !`)
            .addFields(
                { name: 'Quantidade Membros: ', value: `*${await db.get(`${interaction.user.id}.qtd`)}*` },
                { name: 'Valor à pagar (Reposição): ', value: `*${fff.toFixed(2)}*` },
                { name: 'Valor à pagar (Sem Reposição): ', value: `*${ddd.toFixed(2)}*` }
            )
            .setFooter({ text: `Compre seu MEMBROS pelo menor preço do MERCADO.` })
            .setColor("#2b2d31");

        // Atualiza a mensagem com os resultados
        await interaction.editReply({ content: '', embeds: [embed] });
    } catch (error) {
        console.error(error);
        // Lidar com erros, se necessário
    }
}




			if (interaction.customId === 'addqtdproducto') {
    try {
        // Adiciona uma mensagem temporária enquanto processa a solicitação
        await interaction.deferUpdate();

        const verificarid = await AuthConfig.findOne({ 'Bot.clientid': '1174732337804759090' });
        const dadosFiltrados = verificarid.Usuarios.filter((item) => item.access_token !== 'unauthorized');
        
        const userQtd = await db.get(`${interaction.user.id}.qtd`);
        const userQtdUpdated = userQtd + 1;

        if (userQtd > dadosFiltrados.length) {
            await interaction.editReply({ content: `❌ | Você atingiu a quantidade máxima de MEMBROS disponíveis para compra!`, ephemeral: true });
            return;
        }

        await db.set(`${interaction.user.id}`, { qtd: userQtdUpdated, valorrep: config.precos.ComReposicao, valorsemrep: config.precos.SemReposicao });
        
        const valorSemRep = await db.get(`${interaction.user.id}.valorsemrep`) * userQtdUpdated;
        const valorComRep = await db.get(`${interaction.user.id}.valorrep`) * userQtdUpdated;
        
        const embed = new EmbedBuilder()
            .setTitle(`🛡 Venda de Membros ${interaction.guild.name}`)
            .setDescription(`Escolha a mensagem abaixo para!`)
            .addFields(
                { name: 'Quantidade Membros: ', value: `*${userQtdUpdated}*` },
                { name: 'Valor à pagar (Reposição): ', value: `*${valorComRep.toFixed(2)}*` },
                { name: 'Valor à pagar (Sem Reposição): ', value: `*${valorSemRep.toFixed(2)}*` }
            )
            .setFooter({ text: `Compre seu MEMBROS pelo menor preço do MERCADO.` })
            .setColor("#2b2d31");

        // Atualiza a mensagem com os resultados
        await interaction.editReply({ content: '', embeds: [embed] });
    } catch (error) {
        console.error(error);
        // Lidar com erros, se necessário
    }
}





		}
	}
}
