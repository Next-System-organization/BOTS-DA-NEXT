@echo off
title Joãozinho Teste

:loop
node .
goto loop