MEMORY=200
MAIN=index.js
DISPLAY_NAME=Bot Membros
VERSION=recommended
AVATAR=https://cdn.discordapp.com/attachments/1072605146518933585/1156343285363777581/channels4_profile_1.jpg?ex=6514a01b&is=65134e9b&hm=0a8bdc98f770630cd3489574e169d4f5dbac232c29ee6006274e8e0e0d6d7c4e&