const Discord = require("discord.js")
const { EmbedBuilder } = require('discord.js');
const { QuickDB } = require("quick.db");
const { AuthConfig } = require("../../Mongoose/Conexão Dados");
const db = new QuickDB();

module.exports = {
  name: "setpainel",
  description: "Fornece informações sobre o bot.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [],

  run: async (client, interaction, message) => {

    if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.Administrator)) return interaction.reply({ content: `❌ **Calma! Você precisar ser um admin para usar o meu sistema de ticket!**`, ephemeral: true })

    else {
      

      const verificarid = await AuthConfig.findOne({ 'Bot.clientid': '1174732337804759090'})


      const dadosFiltrados = verificarid.Usuarios.filter((item) => item.access_token !== 'unauthorized');


      const embed = new EmbedBuilder()
        .setTitle(`🛡 Venda de Membros | ${interaction.guild.name}`)
        .setDescription(`Segue abaixo a quantidade de **MEMBROS** dísponível para **COMPRA!**`)
        .addFields(
          { name: '🛒 Membros Disponíveis: ', value: `*${dadosFiltrados.length}*` }
        )
        .setFooter({ text: `Compre seu MEMBROS pelo menor preço do MERCADO.` })
        .setColor("Green")

      const row2 = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId("ComprarMembro")
            .setLabel('Comprar Membro')
            .setEmoji(`1104552044951523490`)
            .setStyle(3)
            .setDisabled(false),
        )


      interaction.channel.send({ embeds: [embed], components: [row2] }).then(async msg => {
        await db.set(`msgdefault`, { msgid: msg.id, channelid: interaction.channel.id, guildid: interaction.guild.id })
      })



    }
  }
}

