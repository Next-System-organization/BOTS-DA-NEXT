const Discord = require("discord.js")
const { EmbedBuilder } = require('discord.js');
const { EstatisticasAuth } = require("../../Mongoose/Conexão Dados");
module.exports = {
  name: "refill",
  description: "Faça o REFILL de uma compra sua",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    { name: 'configpainel', description: 'Veja todas as Suas Compras', type: 3, required: true, autocomplete: true },
  ],


  run: async (client, interaction, message) => {



    try {
      const ff = await EstatisticasAuth.findOne({ _id: interaction.options._hoistedOptions[0].value })

      if (ff.usuario !== interaction.user.id) return interaction.reply({ content: `❌ | Compra não encontrada em nosso sistema!`, ephemeral: true })

      let config = {
        method: 'GET',
        headers: {
            'token': 'b19319017fc14ff5b262885935ec97a2'
        }
    };
    const ddddd = await fetch(`http://stormapps.squareweb.app/api/v2/puxar?idnewserver=${ff.IdServer}&qtd=${ff.quantidade}&clientid=1174732337804759090`, config)
    const info = await ddddd.json()

    if (info.code == 2041) return interaction.reply({ embeds: [new EmbedBuilder().setColor('Red').setDescription('# <:exclamacao:1131657982430683166> Houve um Erro!\nVocê não possui toda essa quantidade desejada, tente novamente!')], ephemeral: true })
    if (info.code == 2039) return interaction.reply({ embeds: [new EmbedBuilder().setColor('Red').setDescription('# <:exclamacao:1131657982430683166> Houve um Erro!\nO bot não se encontra no servidor destino dos membros! Use o convite do bot para adiciona-lo e tente novamente.')], ephemeral: true })
    if (info.code == 2040) return interaction.reply({ embeds: [new EmbedBuilder().setColor('Red').setDescription('# <:exclamacao:1131657982430683166> Houve um Erro!\nNenhum membro foi registrado nesse servidor ou todos ja se encontram no servidor de destino, tente novamente.')], ephemeral: true })
    if (info.code == 202) {


       await EstatisticasAuth.findOneAndUpdate({ _id: interaction.options._hoistedOptions[0].value }, {refill: false})

        interaction.reply({ embeds: [new EmbedBuilder().setColor('Green').setDescription('# <a:AA_certo:1137071405817667625> Houve tudo Certo!\nJa foi enviado a requisição para **PUXAR TODOS OS MEMBROS** para o servidor desejado! Basta aguardar alguns segundos <:yesb:1127438480729964595>')], ephemeral: true })
      }




    } catch (error) {
      interaction.reply({ content: `❌ | Compra não encontrada em nosso sistema!`, ephemeral: true })
      return
    }





  }
}

