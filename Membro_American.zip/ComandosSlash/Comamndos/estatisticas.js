const Discord = require("discord.js")
const { EmbedBuilder } = require('discord.js');
const { EstatisticasAuth } = require("../../Mongoose/Conexão Dados");
module.exports = {
  name: "estatisticas",
  description: "Fornece informações sobre o bot.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [],


  run: async (client, interaction, message) => {

    if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.Administrator)) return interaction.reply({ content: `❌ **Calma! Você precisar ser um admin para usar o meu sistema de ticket!**`, ephemeral: true })

    else {

      const ff = await EstatisticasAuth.find()

      const hoje = new Date(); // Data de hoje
      const seteDiasAtras = new Date();
      seteDiasAtras.setDate(hoje.getDate() - 7); // Data de 7 dias atrás
      const trintaDiasAtras = new Date();
      trintaDiasAtras.setDate(hoje.getDate() - 30); // Data de 30 dias atrás

      let ganhosHoje = 0;
      let ganhosUltimosSeteDias = 0;
      let ganhosUltimosTrintaDias = 0;
      let quantidadeVendidaHoje = 0;
      let quantidadeVendidaUltimosSeteDias = 0;
      let quantidadeVendidaUltimosTrintaDias = 0;

      let GanhoTotal = 0
      let QuantidadeTotal = 0

      for (let index = 0; index < ff.length; index++) {
        const element = ff[index];
        const dataElement = new Date(parseInt(element.data));
        const valor = parseFloat(element.valor);
        const quantidade = parseInt(element.quantidade);

        if (dataElement >= hoje || (hoje - dataElement) < 86400000) { // Considera datas de até 24 horas atrás como ganhos de hoje
          ganhosHoje += valor;
          quantidadeVendidaHoje += 1;
        }

        if (dataElement >= seteDiasAtras) {
          ganhosUltimosSeteDias += valor;
          quantidadeVendidaUltimosSeteDias += 1;
        }

        if (dataElement >= trintaDiasAtras) {
          ganhosUltimosTrintaDias += valor;
          quantidadeVendidaUltimosTrintaDias += 1;
        }

        GanhoTotal += valor
        QuantidadeTotal += 1
      }

      const embed = new Discord.EmbedBuilder()
        .setTitle(`Seus rendimentos durante:`)
        .addFields(
          {
            name: `Hoje:`,
            value: `~> Pedidos: \`${quantidadeVendidaHoje}\`\nRecebimentos: \`R$${Number(ganhosHoje).toFixed(2)}\``
          },
          {
            name: `Ultimos 7 dias:`,
            value: `~> Pedidos: \`${quantidadeVendidaUltimosSeteDias}\`\nRecebimentos: \`R$${Number(ganhosUltimosSeteDias).toFixed(2)}\``
          },
          {
            name: `Ultimos 30 dias:`,
            value: `~> Pedidos: \`${quantidadeVendidaUltimosTrintaDias}\`\nRecebimentos: \`R$${Number(ganhosUltimosTrintaDias).toFixed(2)}\``
          },
          {
            name: `Todo Periodo:`,
            value: `~> Pedidos: \`${QuantidadeTotal}\`\nRecebimentos: \`R$${Number(GanhoTotal).toFixed(2)}\``
          }
        )

      interaction.reply({ embeds: [embed], ephemeral: true })




    }
  }
}

