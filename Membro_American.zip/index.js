const Discord = require("discord.js");  
const { GatewayIntentBits, Client, Collection } = require("discord.js")
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
    ]
});
const config = require("./config.json");
const fs = require('fs')
const events = require('./Handler/events')
const slash = require('./Handler/slash')

slash.run(client)
events.run(client)

client.slashCommands = new Collection();
client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

 process.on('unhandRejection', (reason, promise) => {
    console.log(`🚫 Erro Detectado:\n\n` + reason, promise)
 });
 process.on('uncaughtException', (error, origin) => {
    console.log(`🚫 Erro Detectado:\n\n` + error, origin)
 });
 process.on('uncaughtExceptionMonitor', (error, origin) => {
     console.log(`🚫 Erro Detectado:\n\n` + error, origin)
 });

client.login(config.token);


