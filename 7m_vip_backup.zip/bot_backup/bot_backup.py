import discord
from discord import app_commands
from discord.ext import commands
import json
import os

# ─────────────────────────────────────────
#  CONFIGURAÇÃO
# ─────────────────────────────────────────
TOKEN = "SEU_TOKEN_AQUI"          # Substitua pelo token do bot
BACKUP_FILE = "backup.json"       # Arquivo onde o backup fica salvo

# ─────────────────────────────────────────
#  SETUP DO BOT
# ─────────────────────────────────────────
intents = discord.Intents.default()
intents.guilds = True

bot = commands.Bot(command_prefix="!", intents=intents)


# ─────────────────────────────────────────
#  FUNÇÕES AUXILIARES
# ─────────────────────────────────────────
def salvar_backup(guild: discord.Guild) -> dict:
    """Captura a estrutura atual do servidor e retorna como dict."""
    data = {
        "nome": guild.name,
        "categorias": [],
        "canais_sem_categoria": []
    }

    # Canais sem categoria
    for canal in guild.channels:
        if canal.category is None and isinstance(canal, (discord.TextChannel, discord.VoiceChannel)):
            data["canais_sem_categoria"].append({
                "nome": canal.name,
                "tipo": "texto" if isinstance(canal, discord.TextChannel) else "voz",
                "posicao": canal.position
            })

    # Categorias e seus canais
    for categoria in guild.categories:
        cat_data = {
            "nome": categoria.name,
            "posicao": categoria.position,
            "canais": []
        }
        for canal in categoria.channels:
            cat_data["canais"].append({
                "nome": canal.name,
                "tipo": "texto" if isinstance(canal, discord.TextChannel) else "voz",
                "posicao": canal.position
            })
        data["categorias"].append(cat_data)

    return data


def carregar_backup() -> dict | None:
    """Carrega o backup do arquivo JSON. Retorna None se não existir."""
    if not os.path.exists(BACKUP_FILE):
        return None
    with open(BACKUP_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


async def restaurar_backup(guild: discord.Guild, data: dict):
    """Apaga todos os canais e recria com base no backup."""

    # 1. Apaga todos os canais existentes
    for canal in guild.channels:
        try:
            await canal.delete(reason="Restaurando backup")
        except Exception:
            pass

    # 2. Cria canais sem categoria
    for canal_info in sorted(data.get("canais_sem_categoria", []), key=lambda c: c["posicao"]):
        if canal_info["tipo"] == "texto":
            await guild.create_text_channel(canal_info["nome"])
        else:
            await guild.create_voice_channel(canal_info["nome"])

    # 3. Cria categorias e seus canais
    for cat_info in sorted(data.get("categorias", []), key=lambda c: c["posicao"]):
        categoria = await guild.create_category(cat_info["nome"])
        for canal_info in sorted(cat_info["canais"], key=lambda c: c["posicao"]):
            if canal_info["tipo"] == "texto":
                await guild.create_text_channel(canal_info["nome"], category=categoria)
            else:
                await guild.create_voice_channel(canal_info["nome"], category=categoria)


# ─────────────────────────────────────────
#  EVENTOS
# ─────────────────────────────────────────
@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"✅  Bot online como {bot.user}  |  Comandos sincronizados!")


# ─────────────────────────────────────────
#  COMANDO /backup  ─  salva o servidor
# ─────────────────────────────────────────
@bot.tree.command(name="backup", description="Salva o backup atual do servidor")
@app_commands.checks.has_permissions(administrator=True)
async def cmd_backup(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)

    data = salvar_backup(interaction.guild)
    with open(BACKUP_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    total_cat = len(data["categorias"])
    total_canais = sum(len(c["canais"]) for c in data["categorias"]) + len(data["canais_sem_categoria"])

    embed = discord.Embed(
        title="✅  Backup salvo com sucesso!",
        color=discord.Color.green()
    )
    embed.add_field(name="📁  Categorias", value=str(total_cat), inline=True)
    embed.add_field(name="💬  Canais",     value=str(total_canais), inline=True)
    embed.set_footer(text=f"Servidor: {interaction.guild.name}")

    await interaction.followup.send(embed=embed, ephemeral=True)


# ─────────────────────────────────────────
#  COMANDO /backup-fazer  ─  restaura
# ─────────────────────────────────────────
@bot.tree.command(name="backup-fazer", description="Apaga todos os canais e restaura o backup salvo")
@app_commands.checks.has_permissions(administrator=True)
async def cmd_backup_fazer(interaction: discord.Interaction):
    data = carregar_backup()

    if data is None:
        await interaction.response.send_message(
            "❌  Nenhum backup encontrado! Use **/backup** primeiro para salvar.",
            ephemeral=True
        )
        return

    # Confirmação antes de destruir tudo
    view = ConfirmacaoView(interaction.user)
    await interaction.response.send_message(
        "⚠️  **ATENÇÃO!** Isso irá **apagar TODOS os canais** e restaurar o backup.\n"
        "Tem certeza que deseja continuar?",
        view=view,
        ephemeral=True
    )
    await view.wait()

    if not view.confirmado:
        await interaction.edit_original_response(content="❌  Restauração cancelada.", view=None)
        return

    await interaction.edit_original_response(content="⏳  Restaurando backup...", view=None)

    try:
        await restaurar_backup(interaction.guild, data)
        # Tenta avisar em algum canal de texto que surgiu
        for canal in interaction.guild.text_channels:
            try:
                await canal.send("✅  Backup restaurado com sucesso!")
            except Exception:
                pass
            break
    except Exception as e:
        try:
            await interaction.edit_original_response(content=f"❌  Erro ao restaurar: {e}")
        except Exception:
            pass


# ─────────────────────────────────────────
#  VIEW DE CONFIRMAÇÃO
# ─────────────────────────────────────────
class ConfirmacaoView(discord.ui.View):
    def __init__(self, autor: discord.User):
        super().__init__(timeout=30)
        self.autor = autor
        self.confirmado = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.autor.id:
            await interaction.response.send_message("Apenas quem executou o comando pode confirmar.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="✅  Confirmar", style=discord.ButtonStyle.danger)
    async def confirmar(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.confirmado = True
        await interaction.response.defer()
        self.stop()

    @discord.ui.button(label="❌  Cancelar", style=discord.ButtonStyle.secondary)
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.confirmado = False
        await interaction.response.defer()
        self.stop()


# ─────────────────────────────────────────
#  TRATAMENTO DE ERROS DE PERMISSÃO
# ─────────────────────────────────────────
@cmd_backup.error
@cmd_backup_fazer.error
async def erro_permissao(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        await interaction.response.send_message(
            "🚫  Você precisa ser **Administrador** para usar este comando!",
            ephemeral=True
        )


# ─────────────────────────────────────────
#  INICIAR BOT
# ─────────────────────────────────────────
bot.run(TOKEN)
