═══════════════════════════════════════
        BOT DE BACKUP - Discord.py v2
═══════════════════════════════════════

INSTALAÇÃO:
1. Instale as dependências:
   pip install -r requirements.txt

2. Abra o arquivo bot_backup.py e substitua:
   TOKEN = "SEU_TOKEN_AQUI"
   pelo token real do seu bot.

3. No Discord Developer Portal (discord.com/developers):
   - Vá em Bot > Privileged Gateway Intents
   - Ative: SERVER MEMBERS INTENT e MESSAGE CONTENT INTENT
   - Em OAuth2 > URL Generator, marque: bot + applications.commands
   - Permissões: Administrator

4. Rode o bot:
   python bot_backup.py

COMANDOS:
   /backup        → Salva o backup do servidor (só admins)
   /backup-fazer  → Apaga canais e restaura o backup (só admins)

ARQUIVOS:
   bot_backup.py     → Código principal do bot
   requirements.txt  → Dependências Python
   backup.json       → Criado automaticamente ao usar /backup
═══════════════════════════════════════
