const {
  InteractionType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require("discord.js");
const fs = require("fs");
const path = require("path");

const keysFilePath = path.join(process.cwd(), "DataBaseJson", "keys.json");

function findKeyDetails(keyName) {
  const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));
  for (const category in keysData) {
    if (keysData[category].hasOwnProperty(keyName)) {
      return {
        category: category,
        path: keysData[category][keyName],
      };
    }
  }
  return null;
}

function generateConfigPanel(keyName) {
  const details = findKeyDetails(keyName);
  if (!details) {
    return {
      content: "❌ | A key que você estava configurando não existe mais.",
      embeds: [],
      components: [],
    };
  }

  const embed = new EmbedBuilder()
    .setColor("#2f3036")
    .setTitle(`⚙️ Configurando a Key: \`${keyName}\``)
    .setDescription("Selecione uma das opções abaixo para gerenciar esta key.")
    .addFields(
      { name: "Categoria", value: `\`${details.category}\``, inline: true },
      { name: "Arquivo Atual", value: `\`${details.path}\``, inline: true }
    );

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`config_key_edit_name_${keyName}`)
      .setLabel("Editar Nome")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:lapis:1305591472887959663>"),
    new ButtonBuilder()
      .setCustomId(`config_key_delete_${keyName}`)
      .setLabel("Deletar Key")
      .setStyle(ButtonStyle.Danger)
      .setEmoji("<:emoji_71:1305252448310526103>")
  );
  return { embeds: [embed], components: [row], content: "" };
}

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    if (
      interaction.isButton() &&
      interaction.customId.startsWith("config_key_edit_name_")
    ) {
      const originalKeyName = interaction.customId.split("_").pop();
      const modal = new ModalBuilder()
        .setCustomId(`config_modal_edit_name_${originalKeyName}`)
        .setTitle("Editar Nome da Key");
      const newNameInput = new TextInputBuilder()
        .setCustomId("new_key_name_input")
        .setLabel("Insira o novo nome para a key")
        .setStyle(TextInputStyle.Short)
        .setValue(originalKeyName)
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(newNameInput));
      await interaction.showModal(modal);
    }

    if (
      interaction.type === InteractionType.ModalSubmit &&
      interaction.customId.startsWith("config_modal_edit_name_")
    ) {
      await interaction.deferUpdate();
      const originalKeyName = interaction.customId.split("_").pop();
      const newKeyName =
        interaction.fields.getTextInputValue("new_key_name_input");

      const details = findKeyDetails(newKeyName);
      if (details && newKeyName !== originalKeyName) {
        return interaction.editReply({
          content: `❌ | A key \`${newKeyName}\` já existe na categoria \`${details.category}\`.`,
          embeds: [],
          components: [],
        });
      }

      const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));
      const originalDetails = findKeyDetails(originalKeyName);
      if (!originalDetails)
        return interaction.editReply({
          content: "❌ | A key original não foi encontrada para renomear.",
          embeds: [],
          components: [],
        });

      delete keysData[originalDetails.category][originalKeyName];
      keysData[originalDetails.category][newKeyName] = originalDetails.path;
      fs.writeFileSync(keysFilePath, JSON.stringify(keysData, null, 2));

      const newPanel = generateConfigPanel(newKeyName);
      await interaction.editReply({
        content: `✅ | A key foi renomeada com sucesso para \`${newKeyName}\`.`,
        ...newPanel,
      });
    }

    if (
      interaction.isButton() &&
      interaction.customId.startsWith("config_key_delete_")
    ) {
      const keyName = interaction.customId.split("_").pop();
      const confirmationRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`config_delete_confirm_${keyName}`)
          .setLabel("Sim, deletar")
          .setEmoji("<:emoji_71:1305252448310526103>")
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId(`config_delete_cancel_${keyName}`)
          .setEmoji("<:xx1:1306694256559128637>")
          .setLabel("Cancelar")
          .setStyle(ButtonStyle.Secondary)
      );
      await interaction.update({
        content: `❓ | Você tem certeza que deseja deletar permanentemente a key \`${keyName}\` e seu arquivo associado?`,
        components: [confirmationRow],
        embeds: [],
      });
    }

    if (
      interaction.isButton() &&
      interaction.customId.startsWith("config_delete_confirm_")
    ) {
      await interaction.deferUpdate();
      const keyName = interaction.customId.split("_").pop();
      const details = findKeyDetails(keyName);

      if (details) {
        const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));
        const filePathToDelete = path.join(process.cwd(), details.path);
        if (fs.existsSync(filePathToDelete)) fs.unlinkSync(filePathToDelete);
        delete keysData[details.category][keyName];
        fs.writeFileSync(keysFilePath, JSON.stringify(keysData, null, 2));
      }
      await interaction.editReply({
        content: `✅ | A key \`${keyName}\` e seu arquivo foram deletados com sucesso.`,
        components: [],
        embeds: [],
      });
    }

    if (
      interaction.isButton() &&
      interaction.customId.startsWith("config_delete_cancel_")
    ) {
      const keyName = interaction.customId.split("_").pop();
      const panel = generateConfigPanel(keyName);
      await interaction.update({
        content: "👍 | Ação de exclusão cancelada.",
        ...panel,
      });
    }
  },
};
