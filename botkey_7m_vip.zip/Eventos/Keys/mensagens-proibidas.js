const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require("discord.js");
const fs = require("fs");
const path = require("path");
const config = require("../../config.json");

const filePath = path.join(
  process.cwd(),
  "DataBaseJson",
  "mensagens-proibidas.json"
);

function generateForbiddenWordsPanel(client) {
  const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));
  const status = data.active;
  const words = data.mensagens;
  const statusButton = new ButtonBuilder()
    .setCustomId("forbidden_toggle_status")
    .setLabel(status ? "Ligado" : "Desligado")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji(status ? "<:accept:1305153239821324319>" : "<:xx1:1306694256559128637>");
  const addButton = new ButtonBuilder()
    .setCustomId("forbidden_add_word")
    .setLabel("Adicionar Palavra")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("<:adicionar:1305243177803972781>");
  const removeButton = new ButtonBuilder()
    .setCustomId("forbidden_remove_word")
    .setLabel("Remover Palavra")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("<:menos:1305243152952725646>");
  const row = new ActionRowBuilder().addComponents(
    statusButton,
    addButton,
    removeButton
  );
  const wordList =
    words.length > 0
      ? words
          .slice(0, 15)
          .map((w) => `- \`${w}\``)
          .join("\n")
      : "Nenhuma palavra proibida configurada.";
  const embed = new EmbedBuilder()
    .setColor("2f3036")
    .setTitle("🚫 Painel de Palavras Proibidas")
    .setDescription(
      "Gerencie o sistema que impede o envio de palavras específicas em todos os canais."
    )
    .addFields(
      {
        name: "Status Global",
        value: status ? "- **Ativado**" : "- **Desativado**",
        inline: true,
      },
      {
        name: "Palavras Bloqueadas",
        value: wordList,
        inline: false,
      }
    )
    .setFooter({
      text: "O sistema não diferencia maiúsculas de minúsculas.",
      iconURL: client.user.displayAvatarURL(),
    });
  return { embeds: [embed], components: [row] };
}

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;
    if (
      !interaction.customId.startsWith("forbidden_") &&
      !interaction.customId.startsWith("modal_forbidden_")
    )
      return;
    if (interaction.user.id !== config.owner) return;

    if (interaction.customId === "forbidden_toggle_status") {
      const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));
      data.active = !data.active;
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
      const panel = generateForbiddenWordsPanel(client);
      await interaction.update(panel);
    }

    if (
      interaction.customId === "forbidden_add_word" ||
      interaction.customId === "forbidden_remove_word"
    ) {
      const isAdding = interaction.customId === "forbidden_add_word";
      const modal = new ModalBuilder()
        .setCustomId(
          isAdding ? "modal_forbidden_add" : "modal_forbidden_remove"
        )
        .setTitle(
          isAdding ? "Adicionar Palavra Proibida" : "Remover Palavra Proibida"
        );
      const wordInput = new TextInputBuilder()
        .setCustomId("word_input")
        .setLabel("Palavra (sem espaços)")
        .setStyle(TextInputStyle.Short)
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(wordInput));
      await interaction.showModal(modal);
    }

    if (
      interaction.customId === "modal_forbidden_add" ||
      interaction.customId === "modal_forbidden_remove"
    ) {
      const isAdding = interaction.customId === "modal_forbidden_add";
      const word = interaction.fields
        .getTextInputValue("word_input")
        .toLowerCase()
        .trim();
      const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));

      if (isAdding) {
        if (data.mensagens.includes(word))
          return interaction.reply({
            content: "❌ | Esta palavra já está na lista.",
            ephemeral: true,
          });
        data.mensagens.push(word);
      } else {
        if (!data.mensagens.includes(word))
          return interaction.reply({
            content: "❌ | Esta palavra não foi encontrada na lista.",
            ephemeral: true,
          });
        data.mensagens = data.mensagens.filter((w) => w !== word);
      }

      fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
      const panel = generateForbiddenWordsPanel(client);
      await interaction.update(panel);
    }
  },
};
