const { PermissionsBitField } = require("discord.js");
const { joinVoiceChannel } = require("@discordjs/voice");
const config = require("../../config.json");

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    if (
      !interaction.isChannelSelectMenu() ||
      interaction.customId !== "select_voice_channel_to_join"
    ) {
      return;
    }

    if (interaction.user.id !== config.owner) {
      return interaction.reply({
        content: "❌ | Apenas o dono do bot pode interagir com este menu.",
        ephemeral: true,
      });
    }

    const channelId = interaction.values[0];
    const channel = interaction.guild.channels.cache.get(channelId);

    if (!channel) {
      return interaction.reply({
        content:
          "❌ | O canal selecionado não foi encontrado ou não existe mais.",
        ephemeral: true,
      });
    }

    if (!channel.joinable) {
      return interaction.reply({
        content: "❌ | Eu não tenho permissão para entrar neste canal de voz.",
        ephemeral: true,
      });
    }

    if (
      !channel.permissionsFor(client.user).has(PermissionsBitField.Flags.Speak)
    ) {
      return interaction.reply({
        content: "❌ | Eu não tenho permissão para falar neste canal de voz.",
        ephemeral: true,
      });
    }

    try {
      joinVoiceChannel({
        channelId: channel.id,
        guildId: interaction.guild.id,
        adapterCreator: interaction.guild.voiceAdapterCreator,
      });

      await interaction.update({
        content: `✅ | Conectado com sucesso ao canal de voz **${channel.name}**!`,
        embeds: [],
        components: [],
      });
    } catch (error) {
      console.error("Erro ao tentar conectar ao canal de voz:", error);
      await interaction.reply({
        content: "❌ | Ocorreu um erro inesperado ao tentar conectar.",
        ephemeral: true,
      });
    }
  },
};
