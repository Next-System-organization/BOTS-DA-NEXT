const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require("discord.js");
const fs = require("fs");
const path = require("path");
const config = require("../../config.json");

const antilinkFilePath = path.join(
  process.cwd(),
  "DataBaseJson",
  "anti-link.json"
);

function generateAntiLinkPanel(client) {
  const antilinkData = JSON.parse(fs.readFileSync(antilinkFilePath, "utf-8"));
  const status = antilinkData.active;
  const channels = antilinkData.channels;
  const statusButton = new ButtonBuilder()
    .setCustomId("antilink_toggle_status")
    .setLabel(status ? "Ligado" : "Desligado")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji(status ? "<:accept:1305153239821324319>" : "<:xx1:1306694256559128637>");
  const addChannelButton = new ButtonBuilder()
    .setCustomId("antilink_add_channel")
    .setLabel("Adicionar Canal")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("<:adicionar:1305243177803972781>");
  const removeChannelButton = new ButtonBuilder()
    .setCustomId("antilink_remove_channel")
    .setLabel("Remover Canal")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("<:menos:1305243152952725646>");
  const row = new ActionRowBuilder().addComponents(
    statusButton,
    addChannelButton,
    removeChannelButton
  );
  const channelList =
    channels.length > 0
      ? channels
          .slice(0, 15)
          .map((id) => `- <#${id}> (\`${id}\`)`)
          .join("\n")
      : "Nenhum canal configurado.";
  const embed = new EmbedBuilder()
    .setColor("2f3036")
    .setTitle("🛡️ Painel de Controle Anti-Link")
    .setDescription(
      "Gerencie o sistema que impede o envio de links nos canais configurados."
    )
    .addFields(
      {
        name: "Status Global",
        value: status ? "- **Ativado**" : "- **Desativado**",
        inline: true,
      },
      { name: "Canais Protegidos", value: channelList, inline: false }
    )
    .setFooter({
      text: "Clique nos botões para configurar.",
      iconURL: client.user.displayAvatarURL(),
    });
  return { embeds: [embed], components: [row] };
}

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;
    if (
      !interaction.customId.startsWith("antilink_") &&
      !interaction.customId.startsWith("modal_")
    )
      return;
    if (interaction.user.id !== config.owner) return;

    if (interaction.customId === "antilink_toggle_status") {
      const antilinkData = JSON.parse(
        fs.readFileSync(antilinkFilePath, "utf-8")
      );
      antilinkData.active = !antilinkData.active;
      fs.writeFileSync(antilinkFilePath, JSON.stringify(antilinkData, null, 2));
      const panel = generateAntiLinkPanel(client);
      await interaction.update(panel);
    }

    if (
      interaction.customId === "antilink_add_channel" ||
      interaction.customId === "antilink_remove_channel"
    ) {
      const isAdding = interaction.customId === "antilink_add_channel";
      const modal = new ModalBuilder()
        .setCustomId(isAdding ? "modal_add_channel" : "modal_remove_channel")
        .setTitle(
          isAdding
            ? "Adicionar Canal ao Anti-Link"
            : "Remover Canal do Anti-Link"
        );
      const channelInput = new TextInputBuilder()
        .setCustomId("channel_id_input")
        .setLabel("ID do Canal de Texto")
        .setStyle(TextInputStyle.Short)
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(channelInput));
      await interaction.showModal(modal);
    }

    if (
      interaction.customId === "modal_add_channel" ||
      interaction.customId === "modal_remove_channel"
    ) {
      const isAdding = interaction.customId === "modal_add_channel";
      const channelId =
        interaction.fields.getTextInputValue("channel_id_input");
      const antilinkData = JSON.parse(
        fs.readFileSync(antilinkFilePath, "utf-8")
      );

      if (!/^\d{17,19}$/.test(channelId)) {
        return interaction.reply({
          content: "❌ | ID de canal inválido.",
          ephemeral: true,
        });
      }

      if (isAdding) {
        if (antilinkData.channels.includes(channelId)) {
          return interaction.reply({
            content: "❌ | Este canal já está na lista.",
            ephemeral: true,
          });
        }
        antilinkData.channels.push(channelId);
      } else {
        if (!antilinkData.channels.includes(channelId)) {
          return interaction.reply({
            content: "❌ | Este canal não foi encontrado na lista.",
            ephemeral: true,
          });
        }
        antilinkData.channels = antilinkData.channels.filter(
          (id) => id !== channelId
        );
      }

      fs.writeFileSync(antilinkFilePath, JSON.stringify(antilinkData, null, 2));
      const panel = generateAntiLinkPanel(client);
      await interaction.update(panel);
    }
  },
};
