const {
  InteractionType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const fs = require("fs");
const path = require("path");
const axios = require("axios");

const keysFilePath = path.resolve(__dirname, "../../DataBaseJson/keys.json");

async function updateCreationPanel(interaction, session, sessionId) {
  const embed = new EmbedBuilder()
    .setColor("#2f3036")
    .setTitle("Criador de Key")
    .setDescription(
      "Defina a **Key** e a **Categoria** para habilitar a criação."
    )
    .addFields({
      name: "Arquivo Anexado",
      value: `\`${session.originalName}\``,
    });

  if (session.productKey) {
    embed.addFields({
      name: "Key Definida",
      value: `\`${session.productKey}\``,
      inline: true,
    });
  }
  if (session.productCategory) {
    embed.addFields({
      name: "Categoria Definida",
      value: `\`${session.productCategory}\``,
      inline: true,
    });
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`key_set_key_${sessionId}`)
      .setLabel("Definir Key")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:lapis:1305591472887959663>"),
    new ButtonBuilder()
      .setCustomId(`key_set_category_${sessionId}`)
      .setLabel("Definir Categoria")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:ed56:1309962438178766990>"),
    new ButtonBuilder()
      .setCustomId(`key_create_confirm_${sessionId}`)
      .setLabel("Criar Key")
      .setStyle(ButtonStyle.Success)
      .setEmoji("<:adicionar:1305243177803972781>")
      .setDisabled(!session.productKey || !session.productCategory)
  );

  await interaction.update({ embeds: [embed], components: [row] });
}

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    if (
      interaction.isButton() &&
      interaction.customId.startsWith("key_set_key_")
    ) {
      const sessionId = interaction.customId.split("_").pop();
      const session = client.keyCreationSessions.get(sessionId);
      if (!session || session.userId !== interaction.user.id) return;

      const modal = new ModalBuilder()
        .setCustomId(`key_modal_submit_${sessionId}`)
        .setTitle("Definir Key do Produto");
      const keyInput = new TextInputBuilder()
        .setCustomId("product_key_input")
        .setLabel("Insira a Key manualmente")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder("Ex: BotTicket")
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(keyInput));
      await interaction.showModal(modal);
    }

    if (
      interaction.isButton() &&
      interaction.customId.startsWith("key_set_category_")
    ) {
      const sessionId = interaction.customId.split("_").pop();
      const session = client.keyCreationSessions.get(sessionId);
      if (!session || session.userId !== interaction.user.id) return;

      const modal = new ModalBuilder()
        .setCustomId(`modal_category_submit_${sessionId}`)
        .setTitle("Definir Categoria do Produto");
      const categoryInput = new TextInputBuilder()
        .setCustomId("product_category_input")
        .setLabel("Insira o nome da categoria")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder("Ex: Bots")
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(categoryInput));
      await interaction.showModal(modal);
    }

    if (
      interaction.type === InteractionType.ModalSubmit &&
      interaction.customId.startsWith("key_modal_submit_")
    ) {
      const sessionId = interaction.customId.split("_").pop();
      const session = client.keyCreationSessions.get(sessionId);
      if (!session || session.userId !== interaction.user.id) return;

      const proposedKey =
        interaction.fields.getTextInputValue("product_key_input");
      const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));

      for (const category in keysData) {
        if (keysData[category].hasOwnProperty(proposedKey)) {
          return await interaction.reply({
            content: `❌ | A key \`${proposedKey}\` já existe na categoria \`${category}\`.`,
            ephemeral: true,
          });
        }
      }

      session.productKey = proposedKey;
      await updateCreationPanel(interaction, session, sessionId);
    }

    if (
      interaction.type === InteractionType.ModalSubmit &&
      interaction.customId.startsWith("modal_category_submit_")
    ) {
      const sessionId = interaction.customId.split("_").pop();
      const session = client.keyCreationSessions.get(sessionId);
      if (!session || session.userId !== interaction.user.id) return;

      session.productCategory = interaction.fields
        .getTextInputValue("product_category_input")
        .trim();
      await updateCreationPanel(interaction, session, sessionId);
    }

    if (
      interaction.isButton() &&
      interaction.customId.startsWith("key_create_confirm_")
    ) {
      const sessionId = interaction.customId.split("_").pop();
      const session = client.keyCreationSessions.get(sessionId);
      if (!session || !session.productKey || !session.productCategory) return;

      await interaction.deferUpdate();
      try {
        const newKey = session.productKey;
        const category = session.productCategory;

        const response = await axios({
          url: session.attachmentUrl,
          method: "GET",
          responseType: "stream",
        });
        const filePath = path.join(
          process.cwd(),
          "files",
          session.originalName
        );
        const writer = fs.createWriteStream(filePath);

        response.data.pipe(writer);

        await new Promise((resolve, reject) => {
          writer.on("finish", resolve);
          writer.on("error", reject);
        });

        const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));

        if (!keysData[category]) {
          keysData[category] = {};
        }

        keysData[category][newKey] = `./files/${session.originalName}`;
        fs.writeFileSync(keysFilePath, JSON.stringify(keysData, null, 2));

        const finalEmbed = new EmbedBuilder()
          .setColor("#2f3036")
          .setTitle("✅ Sucesso!")
          .setDescription("A key foi criada e o produto foi salvo.")
          .addFields(
            { name: "Arquivo Salvo", value: `\`${session.originalName}\`` },
            { name: "Key Registrada", value: `\`${newKey}\``, inline: true },
            { name: "Categoria", value: `\`${category}\``, inline: true }
          );
        await interaction.editReply({ embeds: [finalEmbed], components: [] });
        client.keyCreationSessions.delete(sessionId);
      } catch (error) {
        console.error("Erro ao criar key:", error);
        await interaction.editReply({
          content:
            "❌ | Ocorreu um erro ao salvar o arquivo ou registrar a key.",
          embeds: [],
          components: [],
        });
      }
    }
  },
};
