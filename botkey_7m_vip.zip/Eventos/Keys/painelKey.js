const {
  InteractionType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  AttachmentBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const fs = require("fs");
const path = require("path");

const keysFilePath = path.resolve(__dirname, "../../DataBaseJson/keys.json");

function generateKeysEmbed(client, page = 0) {
  const itemsPerPage = 5;
  const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));

  const allKeys = Object.entries(keysData).flatMap(([category, keysObj]) =>
    Object.keys(keysObj).map((key) => ({ key, category }))
  );

  const embed = new EmbedBuilder()
    .setColor("#2f3036")
    .setTitle("🔑 | Lista de Keys Registradas");

  if (allKeys.length === 0) {
    embed.setDescription("Nenhuma key encontrada no banco de dados.");
    return { embeds: [embed], components: [] };
  }

  const totalPages = Math.ceil(allKeys.length / itemsPerPage);
  const startIndex = page * itemsPerPage;
  const pageKeys = allKeys.slice(startIndex, startIndex + itemsPerPage);

  const embedFields = pageKeys.map((item) => ({
    name: `Key: \`${item.key}\``,
    value: `Categoria: \`${item.category}\``,
  }));

  embed.addFields(embedFields);

  embed.setFooter({
    text: `Página ${page + 1} de ${totalPages} | Total de Keys: ${
      allKeys.length
    }`,
    iconURL: client.user.displayAvatarURL(),
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`keys_page_${page - 1}`)
      .setLabel("Anterior")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:icoutlinearrowback:1397063579483508837>")
      .setDisabled(page === 0),
    new ButtonBuilder()
      .setCustomId(`keys_page_${page + 1}`)
      .setLabel("Próximo")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:icsharparrowforward1:1397063432494387251>")
      .setDisabled(page >= totalPages - 1)
  );

  return { embeds: [embed], components: [row] };
}

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    if (
      interaction.isButton() &&
      interaction.customId === "resgatar_key_button"
    ) {
      const modal = new ModalBuilder()
        .setCustomId("resgate_key_modal")
        .setTitle("Resgate de Key");
      const keyInput = new TextInputBuilder()
        .setCustomId("key_input")
        .setLabel("Insira sua Key")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder("Ex: BotTicket")
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(keyInput));
      await interaction.showModal(modal);
    }

    if (
      interaction.type === InteractionType.ModalSubmit &&
      interaction.customId === "resgate_key_modal"
    ) {
      const userKey = interaction.fields.getTextInputValue("key_input");
      const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));

      let filePath = null;
      for (const category in keysData) {
        if (keysData[category].hasOwnProperty(userKey)) {
          filePath = keysData[category][userKey];
          break;
        }
      }

      if (filePath) {
        const fullPath = path.join(process.cwd(), filePath);
        if (fs.existsSync(fullPath)) {
          await interaction.reply({
            content:
              "✅ | Sua key foi validada com sucesso! Aqui está o arquivo.",
            files: [new AttachmentBuilder(fullPath)],
            ephemeral: true,
          });
        } else {
          await interaction.reply({
            content:
              "❌ | Key válida, mas o arquivo associado não foi encontrado no servidor.",
            ephemeral: true,
          });
        }
      } else {
        await interaction.reply({
          content:
            "❌ | Key inválida ou o produto associado não foi encontrado.",
          ephemeral: true,
        });
      }
    }

    if (
      interaction.isButton() &&
      (interaction.customId === "ver_keys_button" ||
        interaction.customId.startsWith("keys_page_"))
    ) {
      let page = 0;
      if (interaction.customId.startsWith("keys_page_")) {
        page = parseInt(interaction.customId.split("_")[2], 10);
      }
      const { embeds, components } = generateKeysEmbed(client, page);

      if (interaction.customId === "ver_keys_button") {
        await interaction.reply({ embeds, components, ephemeral: true });
      } else {
        await interaction.update({ embeds, components });
      }
    }
  },
};
