const {
  InteractionType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require("discord.js");
const config = require("../../config.json");
const fs = require("fs");
const path = require("path");

const keysFilePath = path.join(process.cwd(), "DataBaseJson", "keys.json");

function generateMainPanel(client) {
  const embed = new EmbedBuilder()
    .setColor("#2f3036")
    .setTitle("🔧 Configuração do Bot")
    .setDescription("Use os botões abaixo para gerenciar o bot.")
    .setThumbnail(client.user.displayAvatarURL())
    .addFields({ name: "Nome Atual", value: `\`${client.user.username}\`` });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("botconfig_personalizar")
      .setLabel("Personalizar Bot")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:ed36:1309962551110402099>"),
    new ButtonBuilder()
      .setCustomId("botconfig_manage_categories")
      .setLabel("Gerenciar Categorias")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:ed56:1309962438178766990>"),
    new ButtonBuilder()
      .setCustomId("botconfig_view_keys")
      .setLabel("Ver Todas as Keys")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:cisearchmagnifyingglass:1397071717351952416>")
  );
  return { embeds: [embed], components: [row] };
}

function generatePersonalizePanel() {
  const embed = new EmbedBuilder()
    .setColor("#2f3036")
    .setTitle("🎨 Painel de Personalização")
    .setDescription("Escolha qual aspecto do bot você deseja alterar.");
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("botconfig_change_name")
      .setLabel("Mudar Nome")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:lapis:1305591472887959663>"),
    new ButtonBuilder()
      .setCustomId("botconfig_change_avatar")
      .setLabel("Mudar Avatar")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:lapis:1305591472887959663>"),
    new ButtonBuilder()
      .setCustomId("botconfig_back_to_main")
      .setLabel("Voltar")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:icoutlinearrowback:1397063579483508837>")
  );
  return { embeds: [embed], components: [row], content: "" };
}

function generateCategoryPanel() {
  const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));
  const categories =
    Object.keys(keysData).join(", ") || "Nenhuma categoria encontrada.";
  const embed = new EmbedBuilder()
    .setColor("#2f3036")
    .setTitle("📁 Gerenciamento de Categorias")
    .setDescription(
      "Use os botões para adicionar ou remover categorias de keys."
    )
    .addFields({ name: "Categorias Atuais", value: `\`${categories}\`` });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("botconfig_add_category")
      .setLabel("Adicionar Categoria")
      .setStyle(ButtonStyle.Success)
      .setEmoji("<:adicionar:1305243177803972781>"),
    new ButtonBuilder()
      .setCustomId("botconfig_remove_category")
      .setLabel("Remover Categoria")
      .setStyle(ButtonStyle.Danger)
      .setEmoji("<:ed56:1309962438178766990>"),
    new ButtonBuilder()
      .setCustomId("botconfig_back_to_main")
      .setLabel("Voltar")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:icoutlinearrowback:1397063579483508837>")
  );
  return { embeds: [embed], components: [row] };
}

function generateAllKeysPanel(page = 0) {
  const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));
  const allKeys = Object.entries(keysData).flatMap(([category, keysObj]) =>
    Object.entries(keysObj).map(([key, path]) => ({ key, category, path }))
  );
  const itemsPerPage = 5;
  const totalPages = Math.ceil(allKeys.length / itemsPerPage);
  const startIndex = page * itemsPerPage;
  const pageKeys = allKeys.slice(startIndex, startIndex + itemsPerPage);
  const embed = new EmbedBuilder()
    .setColor("#2f3036")
    .setTitle("🔑 Lista de Todas as Keys");
  if (allKeys.length === 0) {
    embed.setDescription("Nenhuma key encontrada em nenhuma categoria.");
  } else {
    const fields = pageKeys.map((item) => ({
      name: `Key: \`${item.key}\``,
      value: `Categoria: \`${item.category}\`\nArquivo: \`${item.path}\``,
    }));
    embed
      .addFields(fields)
      .setFooter({
        text: `Página ${page + 1} de ${totalPages} | Total de Keys: ${
          allKeys.length
        }`,
      });
  }
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`botconfig_keys_page_${page - 1}`)
      .setLabel("Anterior")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:icoutlinearrowback:1397063579483508837>")
      .setDisabled(page === 0),
    new ButtonBuilder()
      .setCustomId("botconfig_back_to_main")
      .setLabel("Voltar ao Início")
      .setEmoji("<:ed41:1309962550149906522>")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId(`botconfig_keys_page_${page + 1}`)
      .setLabel("Próximo")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:icsharparrowforward1:1397063432494387251>")
      .setDisabled(page >= totalPages - 1)
  );
  return { embeds: [embed], components: [row] };
}

module.exports = {
  name: "interactionCreate",
  run: async (client, interaction) => {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;
    if (!interaction.customId.startsWith("botconfig_")) return;
    if (interaction.user.id !== config.owner) return;

    if (interaction.customId === "botconfig_personalizar")
      await interaction.update(generatePersonalizePanel());
    if (interaction.customId === "botconfig_manage_categories")
      await interaction.update(generateCategoryPanel());
    if (interaction.customId === "botconfig_view_keys")
      await interaction.update(generateAllKeysPanel(0));
    if (interaction.customId === "botconfig_back_to_main")
      await interaction.update(generateMainPanel(client));

    if (interaction.customId.startsWith("botconfig_keys_page_")) {
      const page = parseInt(interaction.customId.split("_").pop(), 10);
      await interaction.update(generateAllKeysPanel(page));
    }

    if (interaction.customId === "botconfig_change_name") {
      const modal = new ModalBuilder()
        .setCustomId("botconfig_modal_name")
        .setTitle("Mudar Nome do Bot");
      const nameInput = new TextInputBuilder()
        .setCustomId("bot_new_name_input")
        .setLabel("Novo nome do bot")
        .setStyle(TextInputStyle.Short)
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(nameInput));
      await interaction.showModal(modal);
    }

    if (
      interaction.type === InteractionType.ModalSubmit &&
      interaction.customId === "botconfig_modal_name"
    ) {
      await interaction.deferUpdate();
      const newName =
        interaction.fields.getTextInputValue("bot_new_name_input");
      try {
        await client.user.setUsername(newName);
        await interaction.editReply(generatePersonalizePanel());
        await interaction.followUp({
          content: `✅ | Nome do bot alterado com sucesso para **${newName}**!`,
          ephemeral: true,
        });
      } catch (error) {
        await interaction.followUp({
          content:
            "❌ | Falha ao alterar o nome. Verifique os rate limits do Discord.",
          ephemeral: true,
        });
      }
    }

    if (interaction.customId === "botconfig_change_avatar") {
      const modal = new ModalBuilder()
        .setCustomId("botconfig_modal_avatar")
        .setTitle("Mudar Avatar do Bot");
      const avatarInput = new TextInputBuilder()
        .setCustomId("bot_new_avatar_url")
        .setLabel("URL da nova imagem")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder("https://i.imgur.com/exemplo.png")
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(avatarInput));
      await interaction.showModal(modal);
    }

    if (
      interaction.type === InteractionType.ModalSubmit &&
      interaction.customId === "botconfig_modal_avatar"
    ) {
      await interaction.deferUpdate();
      const newAvatarURL =
        interaction.fields.getTextInputValue("bot_new_avatar_url");
      try {
        await client.user.setAvatar(newAvatarURL);
        await interaction.editReply(generatePersonalizePanel());
        await interaction.followUp({
          content: "✅ | Avatar do bot alterado com sucesso!",
          ephemeral: true,
        });
      } catch (error) {
        await interaction.followUp({
          content:
            "❌ | Falha ao alterar o avatar. Verifique se a URL é válida.",
          ephemeral: true,
        });
      }
    }

    if (
      interaction.customId === "botconfig_add_category" ||
      interaction.customId === "botconfig_remove_category"
    ) {
      const isAdding = interaction.customId === "botconfig_add_category";
      const modal = new ModalBuilder()
        .setCustomId(
          isAdding ? "botconfig_modal_add_cat" : "botconfig_modal_remove_cat"
        )
        .setTitle(isAdding ? "Adicionar Categoria" : "Remover Categoria");
      const categoryInput = new TextInputBuilder()
        .setCustomId("category_name_input")
        .setLabel("Nome da Categoria")
        .setStyle(TextInputStyle.Short)
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(categoryInput));
      await interaction.showModal(modal);
    }

    if (
      interaction.type === InteractionType.ModalSubmit &&
      interaction.customId === "botconfig_modal_add_cat"
    ) {
      await interaction.deferUpdate();
      const categoryName = interaction.fields
        .getTextInputValue("category_name_input")
        .trim();
      const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));
      if (keysData[categoryName]) {
        return interaction.followUp({
          content: `❌ | A categoria \`${categoryName}\` já existe.`,
          ephemeral: true,
        });
      }
      keysData[categoryName] = {};
      fs.writeFileSync(keysFilePath, JSON.stringify(keysData, null, 2));
      await interaction.editReply(generateCategoryPanel());
      await interaction.followUp({
        content: `✅ | Categoria \`${categoryName}\` adicionada com sucesso.`,
        ephemeral: true,
      });
    }

    if (
      interaction.type === InteractionType.ModalSubmit &&
      interaction.customId === "botconfig_modal_remove_cat"
    ) {
      await interaction.deferUpdate();
      const categoryName = interaction.fields
        .getTextInputValue("category_name_input")
        .trim();
      const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));
      if (!keysData[categoryName]) {
        return interaction.followUp({
          content: `❌ | A categoria \`${categoryName}\` não foi encontrada.`,
          ephemeral: true,
        });
      }
      delete keysData[categoryName];
      fs.writeFileSync(keysFilePath, JSON.stringify(keysData, null, 2));
      await interaction.editReply(generateCategoryPanel());
      await interaction.followUp({
        content: `✅ | Categoria \`${categoryName}\` removida com sucesso.`,
        ephemeral: true,
      });
    }
  },
};
