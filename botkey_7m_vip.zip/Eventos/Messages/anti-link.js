const fs = require("fs");
const path = require("path");
const { PermissionsBitField } = require("discord.js");

const antilinkFilePath = path.join(
  process.cwd(),
  "DataBaseJson",
  "anti-link.json"
);

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    if (!message.guild || message.author.bot) return;
    const antilinkData = JSON.parse(fs.readFileSync(antilinkFilePath, "utf-8"));
    if (
      !antilinkData.active ||
      !antilinkData.channels.includes(message.channel.id)
    ) {
      return;
    }
    if (
      message.member.permissions.has(PermissionsBitField.Flags.Administrator)
    ) {
      return;
    }

    const linkRegex =
      /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/[a-zA-Z0-9]+\.[^\s]{2,}|[a-zA-Z0-9]+\.[^\s]{2,})/gi;

    if (linkRegex.test(message.content)) {
      try {
        await message.delete();

        if (message.member && message.member.moderatable) {
          await message.member.timeout(
            60 * 1000,
            "Anti-Link: Envio de link em canal protegido."
          );
          const warningMsg = await message.channel.send(
            `🛡️ | ${message.author}, links não são permitidos. Você foi silenciado por 60 segundos.`
          );
          setTimeout(() => warningMsg.delete().catch(() => {}), 5000);
        } else {
          const warningMsg = await message.channel.send(
            `🛡️ | ${message.author}, links não são permitidos neste canal.`
          );
          setTimeout(() => warningMsg.delete().catch(() => {}), 5000);
        }
      } catch (error) {
        console.error(
          "Erro no sistema Anti-Link (verifique permissões 'ModerateMembers' e 'ManageMessages'):",
          error
        );
      }
    }
  },
};
