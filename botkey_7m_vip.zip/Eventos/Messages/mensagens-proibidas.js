const fs = require("fs");
const path = require("path");
const { PermissionsBitField } = require("discord.js");

const filePath = path.join(
  process.cwd(),
  "DataBaseJson",
  "mensagens-proibidas.json"
);

module.exports = {
  name: "messageCreate",
  run: async (client, message) => {
    if (!message.guild || message.author.bot) return;

    const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));
    if (!data.active || data.mensagens.length === 0) return;
    if (message.member.permissions.has(PermissionsBitField.Flags.Administrator))
      return;

    const messageContent = message.content.toLowerCase();
    const foundWord = data.mensagens.find((word) =>
      messageContent.includes(word)
    );

    if (foundWord) {
      try {
        await message.delete();
        const warningMsg = await message.channel.send(
          `🚫 | ${message.author}, sua mensagem contém uma palavra não permitida.`
        );
        setTimeout(() => warningMsg.delete().catch(() => {}), 5000);
      } catch (error) {
        console.error("Erro ao deletar mensagem de palavra proibida:", error);
      }
    }
  },
};
