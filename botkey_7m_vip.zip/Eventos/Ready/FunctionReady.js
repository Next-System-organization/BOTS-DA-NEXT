const { ActivityType } = require("discord.js");
const axios = require("axios");
const { JsonDatabase } = require("wio.db");

const configDB = new JsonDatabase({ databasePath: "./config.json" });

async function setBotAboutMe(token) {
  try {
    const description =
      "**Bot Key powered by:**https://discord.gg/newcommunity";

    await axios.patch(
      "https://discord.com/api/v10/applications/@me",
      { description: description },
      {
        headers: {
          Authorization: `Bot ${token}`,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error(
      "[ERRO] Falha ao atualizar o 'Sobre Mim' do bot:",
      error.response?.data || error.message
    );
  }
}

module.exports = {
  name: "ready",
  run: async (client) => {
    console.clear();
    console.log(`[LOGS] Bot ${client.user.tag} iniciado com sucesso!`);
    console.log(`[INFO] - Servidores: ${client.guilds.cache.size}`);
    console.log(`[INFO] - Canais: ${client.channels.cache.size}`);
    console.log(
      `[INFO] - Usuários: ${client.guilds.cache.reduce(
        (a, b) => a + b.memberCount,
        0
      )}`
    );

    setInterval(() => {
      client.user.setPresence({
        activities: [
          {
            name: `Made by fodendoruivas_`,
            type: ActivityType.Playing,
          },
        ],
        status: `dnd`,
      });
    }, 15 * 1000);

    const botToken = configDB.get("token");
    if (botToken) {
      await setBotAboutMe(botToken);

      setInterval(() => {
        setBotAboutMe(botToken);
      }, 300000);
    } else {
      console.error(
        "[ERRO] Token do bot não encontrado no config.json. Não foi possível iniciar a atualização do 'Sobre Mim'."
      );
    }
  },
};
