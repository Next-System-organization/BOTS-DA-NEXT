const Discord = require("discord.js");
const { GatewayIntentBits, Client } = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});
const config = require("./config.json");
const events = require("./Handler/events");
client.keyCreationSessions = new Map();

client.on("interactionCreate", (interaction) => {
  if (interaction.type === Discord.InteractionType.ApplicationCommand) {
    const cmd = client.slashCommands.get(interaction.commandName);

    if (!cmd) return interaction.reply(`Error`);

    interaction["member"] = interaction.guild.members.cache.get(
      interaction.user.id
    );

    cmd.run(client, interaction);
  }
});

client.slashCommands = new Discord.Collection();

require("./Handler/slash")(client);

events.run(client);

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

process.on("unhandledRejection", (reason) => {
  console.log(`🚫 Erro Detectado:\n\n${reason.stack}`);
});

process.on("uncaughtException", (error) => {
  console.log(`🚫 Erro Detectado:]\n\n${error.stack}`);
});

process.on("uncaughtExceptionMonitor", (error) => {
  console.log(`🚫 Erro Detectado:\n\n${error.stack}`);
});

client.login(config.token);
