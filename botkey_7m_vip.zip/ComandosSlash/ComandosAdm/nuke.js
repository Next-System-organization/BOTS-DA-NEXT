const { PermissionsBitField } = require("discord.js");

module.exports = {
  name: "nuke",
  description:
    "[💣| Admin] Apaga e recria o canal atual com as mesmas permissões.",
  options: [],

  run: async (client, interaction) => {
    if (
      !interaction.member.permissions.has(
        PermissionsBitField.Flags.Administrator
      )
    ) {
      return interaction.reply({
        content:
          "❌ | Você precisa ter a permissão de 'Administrador' para usar este comando.",
        ephemeral: true,
      });
    }

    if (
      !interaction.guild.members.me.permissions.has(
        PermissionsBitField.Flags.ManageChannels
      )
    ) {
      return interaction.reply({
        content:
          "❌ | Eu não tenho permissão para gerenciar canais neste servidor.",
        ephemeral: true,
      });
    }

    const channel = interaction.channel;
    const position = channel.position;
    const topic = channel.topic;

    try {
      await interaction.deferReply({ ephemeral: true });

      const newChannel = await channel.clone({
        reason: `Canal recriado por ${interaction.user.tag}`,
      });

      await channel.delete();

      await newChannel.setPosition(position);
      if (topic) {
        await newChannel.setTopic(topic);
      }

      await newChannel.send({
        content: "✅ | Canal recriado com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao executar o comando /nuke:", error);
      await interaction.editReply({
        content:
          "❌ | Ocorreu um erro ao tentar recriar o canal. Verifique minhas permissões e tente novamente.",
      });
    }
  },
};
