const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ApplicationCommandOptionType,
} = require("discord.js");
const config = require("../../config.json");

module.exports = {
  name: "criar-key",
  description: "[🔐| Dono] Cria uma nova key para um produto.",
  options: [
    {
      name: "anexo",
      description: "O arquivo do produto que será entregue.",
      type: ApplicationCommandOptionType.Attachment,
      required: true,
    },
  ],

  run: async (client, interaction) => {
    if (interaction.user.id !== config.owner) {
      return interaction.reply({
        content: "❌ | Apenas o dono do bot pode utilizar este comando.",
        ephemeral: true,
      });
    }

    const attachment = interaction.options.getAttachment("anexo");
    const sessionId = interaction.id;

    client.keyCreationSessions.set(sessionId, {
      attachmentUrl: attachment.url,
      originalName: attachment.name,
      userId: interaction.user.id,
      productKey: null,
      productCategory: null,
    });

    const embed = new EmbedBuilder()
      .setColor("#2f3036")
      .setTitle("Criador de Key - Etapa 1/3")
      .setDescription(
        "Anexo recebido com sucesso. Defina a **Key** e a **Categoria** para habilitar a criação."
      )
      .addFields({ name: "Arquivo Anexado", value: `\`${attachment.name}\`` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`key_set_key_${sessionId}`)
        .setLabel("Definir Key")
        .setStyle(ButtonStyle.Secondary)
        .setEmoji("<:lapis:1305591472887959663>"),
      new ButtonBuilder()
        .setCustomId(`key_set_category_${sessionId}`)
        .setLabel("Definir Categoria")
        .setStyle(ButtonStyle.Secondary)
        .setEmoji("<:ed56:1309962438178766990>"),
      new ButtonBuilder()
        .setCustomId(`key_create_confirm_${sessionId}`)
        .setLabel("Criar Key")
        .setStyle(ButtonStyle.Success)
        .setEmoji("<:adicionar:1305243177803972781>")
        .setDisabled(true)
    );

    await interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true,
    });
  },
};
