const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const config = require("../../config.json");
const fs = require("fs");
const path = require("path");

function generateForbiddenWordsPanel(client) {
  const filePath = path.join(
    process.cwd(),
    "DataBaseJson",
    "mensagens-proibidas.json"
  );
  const data = JSON.parse(fs.readFileSync(filePath, "utf-8"));

  const status = data.active;
  const words = data.mensagens;

  const statusButton = new ButtonBuilder()
    .setCustomId("forbidden_toggle_status")
    .setLabel(status ? "Ligado" : "Desligado")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji(status ? "<:accept:1305153239821324319>" : "<:xx1:1306694256559128637>");

  const addButton = new ButtonBuilder()
    .setCustomId("forbidden_add_word")
    .setLabel("Adicionar Palavra")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("<:adicionar:1305243177803972781>");
  const removeButton = new ButtonBuilder()
    .setCustomId("forbidden_remove_word")
    .setLabel("Remover Palavra")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("<:menos:1305243152952725646>");

  const row = new ActionRowBuilder().addComponents(
    statusButton,
    addButton,
    removeButton
  );

  const wordList =
    words.length > 0
      ? words
          .slice(0, 15)
          .map((w) => `- \`${w}\``)
          .join("\n")
      : "Nenhuma palavra proibida configurada.";

  const embed = new EmbedBuilder()
    .setColor("2f3036")
    .setTitle("🚫 Painel de Palavras Proibidas")
    .setDescription(
      "Gerencie o sistema que impede o envio de palavras específicas em todos os canais."
    )
    .addFields(
      {
        name: "Status Global",
        value: status ? "- **Ativado**" : "- **Desativado**",
        inline: true,
      },
      {
        name: "Palavras Bloqueadas",
        value: wordList,
        inline: false,
      }
    )
    .setFooter({
      text: "O sistema não diferencia maiúsculas de minúsculas.",
      iconURL: client.user.displayAvatarURL(),
    });

  return { embeds: [embed], components: [row] };
}

module.exports = {
  name: "mensagens-proibidas",
  description: "[💭| Dono] Gerencia o sistema de palavras proibidas.",
  options: [],

  run: async (client, interaction) => {
    if (interaction.user.id !== config.owner) {
      return interaction.reply({
        content: "❌ | Apenas o dono do bot pode utilizar este comando.",
        ephemeral: true,
      });
    }

    const panel = generateForbiddenWordsPanel(client);
    await interaction.reply({ ...panel, ephemeral: true });
  },
};
