const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const config = require("../../config.json");

module.exports = {
  name: "painel",
  description: "[🔐| Dono] Envia o painel de resgate de keys.",
  options: [],

  run: async (client, interaction) => {
    if (interaction.user.id !== config.owner) {
      return interaction.reply({
        content: "❌ | Apenas o dono do bot pode utilizar este comando.",
        ephemeral: true,
      });
    }

    const description = `
- \`👋\` | **Bem-vindo ao nosso sistema de chaves!**

**Como resgatar a Key?**
> 1. Clique no botão "Resgatar Key" e insira o nome da chave que deseja.
`;

    const embed = new EmbedBuilder()
      .setColor("#2f3036")
      .setTitle("Sistema de Keys")
      .setDescription(description)
      .setTimestamp()
      .setFooter({
        text: "Sistema de Keys",
        iconURL: client.user.displayAvatarURL(),
      });

    const resgateButton = new ButtonBuilder()
      .setCustomId("resgatar_key_button")
      .setLabel("Resgatar Key")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:1245149003012902985:1305152392828031027>");

    const verKeysButton = new ButtonBuilder()
      .setCustomId("ver_keys_button")
      .setLabel("Ver Keys")
      .setStyle(ButtonStyle.Secondary)
      .setEmoji("<:cisearchmagnifyingglass:1397071717351952416>");

    const row = new ActionRowBuilder().addComponents(
      resgateButton,
      verKeysButton
    );

    await interaction.reply({
      content: "✅ | Painel enviado com sucesso neste canal.",
      ephemeral: true,
    });

    await interaction.channel.send({
      embeds: [embed],
      components: [row],
    });
  },
};
