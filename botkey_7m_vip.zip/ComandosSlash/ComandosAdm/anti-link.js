const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const config = require("../../config.json");
const fs = require("fs");
const path = require("path");

function generateAntiLinkPanel(client) {
  const antilinkFilePath = path.join(
    process.cwd(),
    "DataBaseJson",
    "anti-link.json"
  );
  const antilinkData = JSON.parse(fs.readFileSync(antilinkFilePath, "utf-8"));

  const status = antilinkData.active;
  const channels = antilinkData.channels;

  const statusButton = new ButtonBuilder()
    .setCustomId("antilink_toggle_status")
    .setLabel(status ? "Ligado" : "Desligado")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji(status ? "<:accept:1305153239821324319>" : "<:xx1:1306694256559128637>");

  const addChannelButton = new ButtonBuilder()
    .setCustomId("antilink_add_channel")
    .setLabel("Adicionar Canal")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("<:adicionar:1305243177803972781>");
  const removeChannelButton = new ButtonBuilder()
    .setCustomId("antilink_remove_channel")
    .setLabel("Remover Canal")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji("<:menos:1305243152952725646>");

  const row = new ActionRowBuilder().addComponents(
    statusButton,
    addChannelButton,
    removeChannelButton
  );

  const channelList =
    channels.length > 0
      ? channels
          .slice(0, 15)
          .map((id) => `- <#${id}> (\`${id}\`)`)
          .join("\n")
      : "Nenhum canal configurado.";

  const embed = new EmbedBuilder()
    .setColor("2f3036")
    .setTitle("🛡️ Painel de Controle Anti-Link")
    .setDescription(
      "Gerencie o sistema que impede o envio de links nos canais configurados."
    )
    .addFields(
      {
        name: "Status Global",
        value: status ? "- **Ativado**" : "- **Desativado**",
        inline: true,
      },
      { name: "Canais Protegidos", value: channelList, inline: false }
    )
    .setFooter({
      text: "Clique nos botões para configurar.",
      iconURL: client.user.displayAvatarURL(),
    });

  return { embeds: [embed], components: [row] };
}

module.exports = {
  name: "anti-link",
  description: "[🔗| Dono] Gerencia o sistema de anti-link.",
  options: [],

  run: async (client, interaction) => {
    if (interaction.user.id !== config.owner) {
      return interaction.reply({
        content: "❌ | Apenas o dono do bot pode utilizar este comando.",
        ephemeral: true,
      });
    }

    const panel = generateAntiLinkPanel(client);
    await interaction.reply({ ...panel, ephemeral: true });
  },
};
