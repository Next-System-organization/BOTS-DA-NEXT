// /ComandosSlash/ComandosAdm/botconfig.js

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const config = require("../../config.json");

module.exports = {
  name: "botconfig",
  description: "[🤖| Dono] Acessa o painel de configuração do bot.",
  options: [],

  run: async (client, interaction) => {
    if (interaction.user.id !== config.owner) {
      return interaction.reply({
        content: "❌ | Apenas o dono do bot pode utilizar este comando.",
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor("#2f3036")
      .setTitle("🔧 Configuração do Bot")
      .setDescription("Use os botões abaixo para gerenciar o bot.")
      .setThumbnail(client.user.displayAvatarURL())
      .addFields({ name: "Nome Atual", value: `\`${client.user.username}\`` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("botconfig_personalizar")
        .setLabel("Personalizar Bot")
        .setStyle(ButtonStyle.Secondary)
        .setEmoji("<:ed36:1309962551110402099>"),
      new ButtonBuilder()
        .setCustomId("botconfig_manage_categories")
        .setLabel("Gerenciar Categorias")
        .setStyle(ButtonStyle.Secondary)
        .setEmoji("<:ed56:1309962438178766990>"),
      new ButtonBuilder()
        .setCustomId("botconfig_view_keys")
        .setLabel("Ver Todas as Keys")
        .setStyle(ButtonStyle.Secondary)
        .setEmoji("<:cisearchmagnifyingglass:1397071717351952416>")
    );

    await interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true,
    });
  },
};