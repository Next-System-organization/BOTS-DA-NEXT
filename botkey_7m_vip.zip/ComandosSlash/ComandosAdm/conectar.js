const {
  EmbedBuilder,
  ActionRowBuilder,
  ChannelSelectMenuBuilder,
  ChannelType,
} = require("discord.js");
const config = require("../../config.json");

module.exports = {
  name: "conectar",
  description: "[🔌| Dono] Conecta o bot a um canal de voz.",
  options: [],

  run: async (client, interaction) => {
    if (interaction.user.id !== config.owner) {
      return interaction.reply({
        content: "❌ | Apenas o dono do bot pode utilizar este comando.",
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor("#2f3036")
      .setTitle("🔌 Conectar a um Canal de Voz")
      .setDescription(
        "Selecione o canal de voz na lista abaixo para que eu possa entrar."
      );

    const channelMenu = new ChannelSelectMenuBuilder()
      .setCustomId("select_voice_channel_to_join")
      .setPlaceholder("Selecione um canal de voz...")
      .setChannelTypes([ChannelType.GuildVoice]);

    const row = new ActionRowBuilder().addComponents(channelMenu);

    await interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true,
    });
  },
};
