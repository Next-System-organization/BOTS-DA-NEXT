const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ApplicationCommandOptionType,
} = require("discord.js");
const config = require("../../config.json");
const fs = require("fs");
const path = require("path");

module.exports = {
  name: "config-key",
  description: "[⚙️| Dono] Gerencia uma key existente.",
  options: [
    {
      name: "nome",
      description: "O nome da key que você deseja configurar.",
      type: ApplicationCommandOptionType.String,
      required: true,
    },
  ],

  run: async (client, interaction) => {
    if (interaction.user.id !== config.owner) {
      return interaction.reply({
        content: "❌ | Apenas o dono do bot pode utilizar este comando.",
        ephemeral: true,
      });
    }

    const keyName = interaction.options.getString("nome");
    const keysFilePath = path.join(process.cwd(), "DataBaseJson", "keys.json");
    const keysData = JSON.parse(fs.readFileSync(keysFilePath, "utf-8"));

    let foundCategory = null;
    let filePath = null;

    for (const category in keysData) {
      if (keysData[category].hasOwnProperty(keyName)) {
        foundCategory = category;
        filePath = keysData[category][keyName];
        break;
      }
    }

    if (!filePath) {
      return interaction.reply({
        content: `❌ | A key \`${keyName}\` não foi encontrada no banco de dados.`,
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor("#2f3036")
      .setTitle(`⚙️ Configurando a Key: \`${keyName}\``)
      .setDescription(
        "Selecione uma das opções abaixo para gerenciar esta key."
      )
      .addFields(
        { name: "Categoria", value: `\`${foundCategory}\``, inline: true },
        { name: "Arquivo Atual", value: `\`${filePath}\``, inline: true }
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`config_key_edit_name_${keyName}`)
        .setLabel("Editar Nome")
        .setStyle(ButtonStyle.Secondary)
        .setEmoji("<:lapis:1305591472887959663>"),
      new ButtonBuilder()
        .setCustomId(`config_key_delete_${keyName}`)
        .setLabel("Deletar Key")
        .setStyle(ButtonStyle.Danger)
        .setEmoji("<:emoji_71:1305252448310526103>")
    );

    await interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true,
    });
  },
};
