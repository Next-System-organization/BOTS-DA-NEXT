const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("panel")
    .setDescription("Abrir painel de configuração do leilão"),

  async execute(interaction) {

    await interaction.reply({
      content: "📦 Painel de configuração enviado!",
      ephemeral: true
    });

    await interaction.channel.send({
      components: [
        {
          type: 17,
          components: [

            // === TEXTO DO PAINEL === //
            {
              type: 10,
              content: `# <:emoji_1:1446562254521766068> PAINEL LEILÃO

- Configure o canal  
- Configure regras  
- Configure valores, produto e descrição  
- Envie o painel oficial no canal configurado  

> Caso de erro nos contate em nosso servidor oficial.`
            },

            { type: 14, spacing: 1, divider: true },

            // === LINHA 1 === //
            {
              type: 1,
              components: [
                {
                  type: 2,
                  custom_id: "config_channel",
                  label: "Canal",
                  style: 2,
                  emoji: { id: "1446567269181423616" } // 📌
                },
                {
                  type: 2,
                  custom_id: "config_rules",
                  label: "Regras",
                  style: 2,
                  emoji: { id: "1446567282699403294" } // 📜
                }
              ]
            },

            // === LINHA 2 === //
            {
              type: 1,
              components: [
                {
                  type: 2,
                  custom_id: "config_other",
                  label: "Outros",
                  style: 2,
                  emoji: { id: "1446567242488741949" } // ⚙️
                },
                {
                  type: 2,
                  custom_id: "send_auction",
                  label: "Enviar",
                  style: 2,
                  emoji: { id: "1446567256124559531" } // 🚀
                }
              ]
            }
          ]
        }
      ],
      flags: 32768
    });
  }
};