const fs = require("fs");
const path = require("path");
const {
  SlashCommandBuilder,
  EmbedBuilder
} = require("discord.js");

const dbPath = path.join(__dirname, "../databases/auction.json");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("vendido")
    .setDescription("Finaliza o leilão e trava o canal."),

  async execute(interaction) {

    let auction = JSON.parse(fs.readFileSync(dbPath, "utf8"));

    if (!auction.channelId) {
      return interaction.reply({
        content: "❌ Nenhum leilão está ativo.",
        ephemeral: true
      });
    }

    const channel = await interaction.client.channels.fetch(auction.channelId);

    // 🔒 TRAVAR CANAL
    await channel.permissionOverwrites.edit(
      channel.guild.roles.everyone,
      { SendMessages: false }
    );

    auction.ended = true;
    fs.writeFileSync(dbPath, JSON.stringify(auction, null, 2));

    // 📌 EMBED FINAL
    const embed = new EmbedBuilder()
      .setColor("Green")
      .setTitle("🚨 LEILÃO ENCERRADO!")
      .addFields(
        { name: "Item", value: auction.item ?? "Não informado" },
        { name: "Vencedor", value: auction.currentWinner ?? "Ninguém" },
        { name: "Valor final", value: `${auction.currentValue}` }
      )
      .setTimestamp();

    await channel.send({ embeds: [embed] });

    return interaction.reply({
      content: "✔ Leilão encerrado e canal travado!",
      ephemeral: true
    });
  }
};