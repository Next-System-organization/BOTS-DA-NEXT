const fs = require("fs");
const path = require("path");
const { EmbedBuilder } = require("discord.js");

const dbPath = path.join(__dirname, "../databases/auction.json");

module.exports = {
  name: "messageCreate",

  async execute(client, message) {
    try {
      if (message.author.bot) return;

      // ======== LER DB ========
      let auction = JSON.parse(fs.readFileSync(dbPath, "utf8"));

      // Sem canal configurado
      if (!auction.channelId) return;

      // Só funciona no canal configurado
      if (message.channel.id !== auction.channelId) return;

      // ======== VALIDAR LANCE ========
      const value = Number(message.content);

      // Ignora não-números
      if (isNaN(value)) return;

      // Tem que ser maior que o lance atual
      if (value <= auction.currentValue) return;

      // ======== ATUALIZAR DB ========
      auction.currentValue = value;
      auction.currentWinner = `${message.author.username} - ${value}`;

      fs.writeFileSync(dbPath, JSON.stringify(auction, null, 2));

      // ======== PROCURAR A MENSAGEM DO BOT ========
      const channel = await client.channels.fetch(auction.channelId);

      const messages = await channel.messages.fetch({ limit: 10 });

      const lastMsg = messages.find(m =>
        m.author.id === client.user.id && m.embeds.length > 0
      );

      if (!lastMsg) return; // Sem painel nenhum

      // ======== ATUALIZAR EMBED ========
      const embed = EmbedBuilder.from(lastMsg.embeds[0]);

      // Verificar fields existentes
      const fields = embed.data.fields ?? [];

      // Procurar campo "Ganhador atual"
      let field = fields.find(f => f.name === "Ganhador atual");

      if (!field) {
        // Se não existir, cria
        embed.addFields({
          name: "Ganhador atual",
          value: auction.currentWinner
        });
      } else {
        // Se existir, atualizar
        field.value = auction.currentWinner;
      }

      // Editar mensagem
      await lastMsg.edit({ embeds: [embed] });

    } catch (err) {
      console.log("ERRO MESSAGE CREATE:", err);
    }
  }
};