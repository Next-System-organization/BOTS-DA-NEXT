const fs = require("fs");
const path = require("path");
const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  SelectMenuBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

const dbPath = path.join(__dirname, "../databases/auction.json");

module.exports = {
  name: "interactionCreate",
  async execute(client, interaction) {
    // SLASH COMMANDS
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (command) command.execute(interaction);
    }

    // BOTÕES
    if (interaction.isButton()) {
      let auction = JSON.parse(fs.readFileSync(dbPath, "utf8"));

      // CANAL
      if (interaction.customId === "config_channel") {
        const select = new ActionRowBuilder().addComponents(
          new SelectMenuBuilder()
            .setCustomId("select_channel")
            .setPlaceholder("Selecione o canal")
            .addOptions(
              interaction.guild.channels.cache
                .filter(c => c.type === 0)
                .map(c => ({ label: c.name, value: c.id }))
            )
        );
        return interaction.reply({ content: "Escolha o canal:", components: [select], ephemeral: true });
      }

      // REGRAS
      if (interaction.customId === "config_rules") {
        const modal = new ModalBuilder()
          .setCustomId("modal_rules")
          .setTitle("Regras do leilão")
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId("rules_input")
                .setLabel("Regras")
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
            )
          );
        return interaction.showModal(modal);
      }

      // PRODUTO / DESCRIÇÃO / VALOR
      if (interaction.customId === "config_other") {
        const modal = new ModalBuilder()
          .setCustomId("modal_other")
          .setTitle("Produto e Valor")
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId("product_input")
                .setLabel("Produto")
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId("description_input")
                .setLabel("Descrição")
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId("value_input")
                .setLabel("Valor Inicial")
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            )
          );
        return interaction.showModal(modal);
      }

      // 📌 CONFIGURAR PIX
      if (interaction.customId === "config_pix") {
        const modal = new ModalBuilder()
          .setCustomId("modal_pix")
          .setTitle("Configurar chave PIX")
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId("pix_input")
                .setLabel("Chave PIX")
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            )
          );
        return interaction.showModal(modal);
      }

      // 📩 ENVIAR LEILÃO
      if (interaction.customId === "send_auction") {
        if (!auction.channelId)
          return interaction.reply({ content: "Configure o canal primeiro!", ephemeral: true });

        auction.currentValue = auction.initialValue;
        auction.currentWinner = "Ninguém";
        fs.writeFileSync(dbPath, JSON.stringify(auction, null, 2));

        const channel = await client.channels.fetch(auction.channelId);

        const embed = new EmbedBuilder()
          .setTitle("<:emoji_10:1446585207653142568> LEILÃO")
          .addFields(
            { name: "<:emoji_7:1446584910591557714> | Produto", value: auction.product },
            { name: "<:emoji_6:1446584895861297204> | Descrição", value: auction.description },
            { name: "<:emoji_11:1446585806885097623> | Valor Inicial", value: auction.initialValue.toString() },
            { name: "<:emoji_8:1446584924642480290> | Ganhador atual", value: auction.currentWinner }
          )
          .setColor("Gold");

        const btn = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("show_rules")
            .setLabel("Regras")
            .setEmoji("1446567282699403294")
            .setStyle(ButtonStyle.Secondary),

          new ButtonBuilder()
            .setCustomId("pix_button")
            .setLabel("Pix")
            .setEmoji("1446584883131584632")
            .setStyle(ButtonStyle.Success)
        );

        await channel.send({ embeds: [embed], components: [btn] });
        return interaction.reply({ content: "Leilão enviado!", ephemeral: true });
      }

      // 📜 MOSTRAR REGRAS
      if (interaction.customId === "show_rules") {
        return interaction.reply({
          content: `**Regras do leilão:**\n${auction.rules}`,
          ephemeral: true
        });
      }

      // 💸 MOSTRAR PIX
      if (interaction.customId === "pix_button") {
        if (!auction.pix)
          return interaction.reply({
            content: "❌ Nenhuma chave PIX cadastrada.",
            ephemeral: true
          });

        return interaction.reply({
          content: ` **Chave PIX:**\n\`\`\`${auction.pix}\`\`\``,
          ephemeral: true
        });
      }
    }

    // SELECT
    if (interaction.isSelectMenu()) {
      let auction = JSON.parse(fs.readFileSync(dbPath, "utf8"));

      if (interaction.customId === "select_channel") {
        auction.channelId = interaction.values[0];
        fs.writeFileSync(dbPath, JSON.stringify(auction, null, 2));
        return interaction.reply({ content: "Canal configurado!", ephemeral: true });
      }
    }

    // MODAIS
    if (interaction.isModalSubmit()) {
      let auction = JSON.parse(fs.readFileSync(dbPath, "utf8"));

      if (interaction.customId === "modal_rules") {
        auction.rules = interaction.fields.getTextInputValue("rules_input");
      }

      if (interaction.customId === "modal_other") {
        auction.product = interaction.fields.getTextInputValue("product_input");
        auction.description = interaction.fields.getTextInputValue("description_input");
        auction.initialValue = Number(interaction.fields.getTextInputValue("value_input"));
      }

      if (interaction.customId === "modal_pix") {
        auction.pix = interaction.fields.getTextInputValue("pix_input");
      }

      fs.writeFileSync(dbPath, JSON.stringify(auction, null, 2));
      return interaction.reply({ content: "Configurações salvas!", ephemeral: true });
    }
  }
};