Bot de parcerias automáticas com Components V2, ticket/canal automático, IA, TXT oficial por canal, cooldown de 24h e Application Emojis.

## Configuração

Edite apenas `config.json` para dados sensíveis:

```json
{
  "token": "TOKEN_DO_BOT",
  "clientId": "ID_DA_APLICACAO",
  "ownerId": "SEU_ID",
  "mistralApiKey": "SUA_KEY_MISTRAL"
}
```

Depois rode:

```bash
npm install
npm start
```

O bot sincroniza os comandos globais automaticamente ao iniciar.

## Fluxo de parceria

1. O owner usa `/painel` e configura:
   - canal do painel público
   - canal de parcerias
   - canal do TXT oficial
   - canal staff/logs
2. O painel público cria um canal/ticket automático.
3. O parceiro envia o convite do servidor dele.
4. O parceiro envia o TXT/anúncio dele.
5. O bot manda um botão com o link do canal onde está o TXT oficial, para a pessoa copiar diretamente de lá.
6. O parceiro confirma que enviou o TXT e manda uma print.
7. A IA valida principalmente:
   - se o nome do servidor na print bate com o servidor do convite
   - se o link/convite do seu servidor aparece correto
8. Se estiver correto, publica automaticamente o TXT do parceiro no canal de parcerias.

## Importante sobre a validação da print

A IA não exige membros online, quantidade de membros, boosts, data de criação ou métricas. O foco é confirmar servidor correto + link correto.

## TXT oficial

O `/gerar-txt` é opcional. Ele serve só para gerar um TXT com IA caso o servidor ainda não tenha um.

Se você já tem TXT pronto, basta colocar/fixar ele no canal configurado como `canal do TXT oficial` no `/painel`.

## Emojis globais do bot

Edite `data/emojis.json` e coloque os IDs dos Application Emojis que você criou no Discord Developer Portal.

Se quiser criar emojis pela API, coloque imagens em `/emojis` e rode:

```bash
npm run emojis:upload
```