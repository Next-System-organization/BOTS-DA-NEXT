const { Client, GatewayIntentBits, Partials } = require('discord.js');
const config = require('./config.json');
const { loadCommands } = require('./handlers/commandHandler');
const { loadEvents } = require('./handlers/eventHandler');
const logger = require('./utils/logger');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  partials: [Partials.Channel, Partials.Message]
});

loadCommands(client);
loadEvents(client);

client.login(config.token).catch(err => logger.error(`Falha no login: ${err.message}`));
