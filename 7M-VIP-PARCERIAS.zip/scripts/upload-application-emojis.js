const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');
const { createApplicationEmoji, loadEmojiDb, saveEmojiDb } = require('../services/applicationEmojis');

const folder = path.join(__dirname, '..', 'emojis');

(async () => {
  if (!fs.existsSync(folder)) {
    logger.warn('Pasta /emojis não existe. Crie a pasta e coloque .png, .webp ou .gif nela.');
    return;
  }

  const files = fs.readdirSync(folder).filter(file => /\.(png|webp|gif)$/i.test(file));
  if (!files.length) {
    logger.warn('Nenhum arquivo .png, .webp ou .gif encontrado em /emojis.');
    return;
  }

  const db = loadEmojiDb();
  db.emojis ||= {};

  for (const file of files) {
    const name = path.basename(file, path.extname(file)).replace(/[^a-zA-Z0-9_]/g, '_').slice(0, 32);
    try {
      logger.info(`Enviando emoji global: ${name}`);
      const emoji = await createApplicationEmoji(name, path.join(folder, file));
      db.emojis[name] = {
        id: emoji.id,
        name: emoji.name,
        animated: Boolean(emoji.animated),
        fallback: db.emojis[name]?.fallback || ''
      };
      saveEmojiDb(db);
      logger.success(`Emoji criado: ${emoji.name} (${emoji.id})`);
    } catch (err) {
      logger.error(err.message);
    }
  }
})();
