const { REST, Routes } = require('discord.js');
const config = require('./config.json');
const logger = require('./utils/logger');
const { readCommandPayloads } = require('./services/commandSync');

(async () => {
  const rest = new REST({ version: '10' }).setToken(config.token);
  const commands = readCommandPayloads();
  logger.info(`Registrando ${commands.length} comandos globalmente...`);
  await rest.put(Routes.applicationCommands(config.clientId), { body: commands });
  logger.success('Comandos globais atualizados. Comandos apagados foram removidos da lista global.');
})().catch(e => logger.error(e.stack || e.message));
