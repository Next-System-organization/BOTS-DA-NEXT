const tickets = require('../services/tickets');
const settingsSvc = require('../services/settings');
const blacklist = require('../services/blacklist');
const db = require('../utils/jsonDb');
const { sanitizeMentions, hasBlockedMentions } = require('../utils/filter');
const { sendOurTextPanel, publishedPartnerText } = require('../components/panels');
const { analyzeScreenshot } = require('../services/mistral');
const { log } = require('../services/logs');
const logger = require('../utils/logger');
const cooldowns = require('../services/cooldowns');

function inviteCodeFrom(text){
  const m = String(text).match(/(?:discord\.gg\/|discord\.com\/invite\/)([a-zA-Z0-9-]+)/i);
  return m?.[1];
}
module.exports = {
  name: 'messageCreate',
  async execute(message, client){
    if (message.author.bot || !message.guild) return;
    const t = tickets.get(message.channel.id);
    if (!t || t.userId !== message.author.id) return;
    const set = settingsSvc.get(t.hostGuildId);
    try {
      if (t.step === 'await_invite') {
        const code = inviteCodeFrom(message.content);
        if (!code) return message.reply('❌ Envie um convite válido, exemplo: https://discord.gg/codigo');
        const inv = await client.fetchInvite(code).catch(() => null);
        if (!inv || !inv.guild) return message.reply('❌ Convite inválido ou expirado.');
        if (blacklist.isBlocked({ guildId: inv.guild.id, ownerId: inv.guild.ownerId, inviteCode: code })) return message.reply('❌ Este servidor/convite está na blacklist.');
        const wait = cooldowns.remaining(message.guild.id, inv.guild.id);
        if (wait > 0) return message.reply(`⏳ Esse servidor já fechou parceria recentemente aqui. Ele poderá fechar novamente em ${cooldowns.format(wait)}.`);
        // Sem mínimo de membros/online: a parceria valida apenas convite, blacklist, cooldown por servidor parceiro e comprovação por print.
        tickets.update(message.channel.id, {
          step:'await_partner_ad', inviteUrl:`https://discord.gg/${code}`, inviteCode:code,
          partnerGuildId: inv.guild.id, partnerGuildName: inv.guild.name, partnerMemberCount: inv.memberCount || null
        });
        return message.reply('✅ Convite validado. Agora envie o **TXT/anúncio do seu servidor** que será publicado no nosso canal de parcerias.');
      }
      if (t.step === 'await_partner_ad') {
        if (!message.content || message.content.length < 30) return message.reply('❌ Seu TXT está muito curto. Envie um anúncio mais completo.');
        if (hasBlockedMentions(message.content)) await message.reply('⚠️ Removi menções bloqueadas do seu TXT: everyone, here, cargos, membros ou canais.');
        const clean = sanitizeMentions(message.content);
        tickets.update(message.channel.id, { step:'await_confirm_sent', partnerAd: clean });
        const freshSettings = settingsSvc.get(message.guild.id);
        const channelUrl = freshSettings.officialTextChannelId ? `https://discord.com/channels/${message.guild.id}/${freshSettings.officialTextChannelId}` : null;
        return message.reply(sendOurTextPanel(t.requiredText || await settingsSvc.getOfficialText(message.guild), channelUrl));
      }
      if (t.step === 'await_print') {
        const img = message.attachments.find(a => a.contentType?.startsWith('image/') || /\.(png|jpe?g|webp)$/i.test(a.url));
        if (!img) return message.reply('❌ Envie uma imagem/print válida como anexo.');
        await message.reply('🔎 Analisando sua print com IA...');
        const fresh = tickets.get(message.channel.id);
        const result = await analyzeScreenshot({
          imageUrl: img.url,
          requiredText: fresh.requiredText || await settingsSvc.getOfficialText(message.guild),
          realGuildName: message.guild.name,
          partnerGuildName: fresh.partnerGuildName,
          partnerInviteUrl: fresh.inviteUrl
        });
        tickets.update(message.channel.id, { aiScore: result.score, riskLevel: result.riskLevel, aiReason: result.reason, screenshotUrl: img.url });
        
        if (result.approved && result.score >= 70 && result.riskLevel !== 'high') {
          const finalTicket = tickets.get(message.channel.id);
          const partnerChannel = message.guild.channels.cache.get(set.partnershipChannelId);
          if (!partnerChannel) return message.reply('❌ Canal de parcerias configurado não foi encontrado.');
          await partnerChannel.send(publishedPartnerText(finalTicket));
          db.push('partnerships.json', { id: `${Date.now()}`, ...finalTicket, status:'approved', approvedBy:'auto_ai', approvedAt:new Date().toISOString(), messageSent:true, channelId:partnerChannel.id });
          cooldowns.set(message.guild.id, finalTicket.partnerGuildId, set.cooldownMs, { userId: message.author.id, partnerGuildName: finalTicket.partnerGuildName });
          log('partnership_auto_approved', { guildId: message.guild.id, userId: message.author.id, partnerGuildId: finalTicket.partnerGuildId, score: result.score, reason: result.reason, cooldownMs: set.cooldownMs, cooldownType: 'guild_pair' });
          await message.reply(`✅ Print aprovada pela IA (${result.score}/100). Sua parceria foi publicada automaticamente em ${partnerChannel}.`);
          tickets.remove(message.channel.id);
          return setTimeout(() => message.channel.delete().catch(()=>{}), 12000);
        }
        log('partnership_print_rejected', { guildId: message.guild.id, userId: message.author.id, score: result.score, riskLevel: result.riskLevel, reason: result.reason });
        return message.reply(`❌ Print recusada pela IA.\nScore: ${result.score}/100\nRisco: ${result.riskLevel}\nMotivo: ${result.reason}`);
      }
    } catch (e) {
      logger.error(e.stack || e.message);
      return message.reply('❌ Ocorreu um erro durante o fluxo da parceria.');
    }
  }
};
