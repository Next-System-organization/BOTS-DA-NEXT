const { ChannelType, PermissionsBitField, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const logger = require('../utils/logger');
const { isOwner } = require('../utils/guards');
const settingsSvc = require('../services/settings');
const tickets = require('../services/tickets');
const db = require('../utils/jsonDb');
const cooldowns = require('../services/cooldowns');
const { generateOwnerPartnershipText } = require('../services/mistral');
const { publicPanel, configPanel, channelConfigPanel, ticketIntro, txtGeneratorPanel, txtPreview } = require('../components/panels');

function formKey(interaction){ return `${interaction.guild.id}:${interaction.user.id}`; }
function isFormReady(f){ return Boolean(f.serverName && f.permanentLink && f.about); }
async function getOrCreateCategory(guild, categoryName){
  let cat = guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name === categoryName);
  if (!cat) cat = await guild.channels.create({ name: categoryName, type: ChannelType.GuildCategory });
  return cat;
}
function txtModal(existing = {}){
  const modal = new ModalBuilder().setCustomId('txtform:modal').setTitle('Gerador de TXT oficial');
  const input = (id, label, style, required, value) => new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required).setValue(String(value || '').slice(0, style === TextInputStyle.Paragraph ? 4000 : 100));
  modal.addComponents(
    new ActionRowBuilder().addComponents(input('serverName', 'Nome do servidor', TextInputStyle.Short, true, existing.serverName)),
    new ActionRowBuilder().addComponents(input('permanentLink', 'Link permanente', TextInputStyle.Short, true, existing.permanentLink)),
    new ActionRowBuilder().addComponents(input('about', 'Sobre o servidor', TextInputStyle.Paragraph, true, existing.about)),
    new ActionRowBuilder().addComponents(input('products', 'Produtos vendidos, se for loja', TextInputStyle.Paragraph, false, existing.products)),
    new ActionRowBuilder().addComponents(input('extra', 'Informações adicionais', TextInputStyle.Paragraph, false, existing.extra))
  );
  return modal;
}
module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client){
    try {
      if (interaction.isChatInputCommand()) {
        const cmd = client.commands.get(interaction.commandName);
        if (cmd) return cmd.execute(interaction, client);
      }

      if (interaction.isModalSubmit()) {
        if (interaction.customId === 'txtform:modal') {
          if (!isOwner(interaction.user.id)) return interaction.reply({ content:'❌ Apenas o owner do config.json pode usar isso.', ephemeral:true });
          const forms = db.read('txt_forms.json', {});
          const key = formKey(interaction);
          const form = {
            serverName: interaction.fields.getTextInputValue('serverName'),
            permanentLink: interaction.fields.getTextInputValue('permanentLink'),
            about: interaction.fields.getTextInputValue('about'),
            products: interaction.fields.getTextInputValue('products') || '',
            extra: interaction.fields.getTextInputValue('extra') || ''
          };
          forms[key] = form;
          db.write('txt_forms.json', forms);
          return interaction.reply({ ...txtGeneratorPanel(form, isFormReady(form)), ephemeral:true });
        }
      }

      if (interaction.isStringSelectMenu()) {
        if (!isOwner(interaction.user.id)) return interaction.reply({ content:'❌ Apenas o owner do config.json pode configurar.', ephemeral:true });
        const v = interaction.values[0];
        if (interaction.customId === 'config:menu') {
          if (['panel_channel','partnership_channel','staff_channel','txt_channel'].includes(v)) return interaction.update(channelConfigPanel(v, settingsSvc.get(interaction.guild.id)));
          if (v === 'publish_panel') {
            const s = settingsSvc.get(interaction.guild.id);
            const ch = interaction.guild.channels.cache.get(s.panelChannelId || interaction.channel.id);
            await ch.send(publicPanel());
            return interaction.update(configPanel(settingsSvc.get(interaction.guild.id)));
          }
        }
      }

      if (interaction.isChannelSelectMenu()) {
        if (!isOwner(interaction.user.id)) return interaction.reply({ content:'❌ Apenas o owner do config.json pode configurar.', ephemeral:true });
        if (interaction.customId.startsWith('config:set:')) {
          const kind = interaction.customId.split(':')[2];
          const channelId = interaction.values[0];
          const patchMap = {
            panel_channel: { panelChannelId: channelId },
            partnership_channel: { partnershipChannelId: channelId },
            staff_channel: { staffChannelId: channelId },
            txt_channel: { officialTextChannelId: channelId }
          };
          settingsSvc.set(interaction.guild.id, patchMap[kind] || {});
          return interaction.update(configPanel(settingsSvc.get(interaction.guild.id)));
        }
      }

      if (!interaction.isButton()) return;

      if (interaction.customId === 'config:back') {
        if (!isOwner(interaction.user.id)) return interaction.reply({ content:'❌ Apenas o owner do config.json pode configurar.', ephemeral:true });
        return interaction.update(configPanel(settingsSvc.get(interaction.guild.id)));
      }

      if (interaction.customId.startsWith('txtform:')) {
        if (!isOwner(interaction.user.id)) return interaction.reply({ content:'❌ Apenas o owner do config.json pode usar o gerador.', ephemeral:true });
        const forms = db.read('txt_forms.json', {});
        const form = forms[formKey(interaction)] || {};
        if (interaction.customId === 'txtform:edit') return interaction.showModal(txtModal(form));
        if (interaction.customId === 'txtform:generate') {
          if (!isFormReady(form)) return interaction.reply({ content:'⚠️ Preencha nome, link permanente e sobre o servidor primeiro.', ephemeral:true });
          await interaction.deferReply({ ephemeral:true });
          const result = await generateOwnerPartnershipText({ guild: interaction.guild, description: `Nome: ${form.serverName}\nLink: ${form.permanentLink}\nSobre: ${form.about}\nProdutos: ${form.products || 'N/A'}\nExtras: ${form.extra || 'N/A'}` });
          const previews = db.read('txt_previews.json', {});
          previews[interaction.user.id] = { guildId: interaction.guild.id, ...result, sourceForm: form };
          db.write('txt_previews.json', previews);
          return interaction.editReply(txtPreview(result.title, result.text));
        }
      }

      if (interaction.customId.startsWith('txt:')) {
        if (!isOwner(interaction.user.id)) return interaction.reply({ content:'❌ Apenas o owner do config.json pode salvar TXT.', ephemeral:true });
        const previews = db.read('txt_previews.json', {});
        const preview = previews[interaction.user.id];
        if (!preview) return interaction.reply({ content:'❌ Preview expirado. Use /gerar-txt novamente.', ephemeral:true });
        if (interaction.customId === 'txt:save') {
          settingsSvc.set(preview.guildId, { partnerText: preview.text });
          delete previews[interaction.user.id]; db.write('txt_previews.json', previews);
          return interaction.update({ content:'✅ TXT oficial salvo para este servidor.', components: [] });
        }
        if (interaction.customId === 'txt:regenerate') return interaction.reply({ content:'Use /gerar-txt, edite as informações e gere outra versão.', ephemeral:true });
        if (interaction.customId === 'txt:cancel') return interaction.update({ content:'Cancelado.', components: [] });
      }

      if (interaction.customId === 'partner:start') {
        const set = settingsSvc.get(interaction.guild.id);
        const officialText = await settingsSvc.getOfficialText(interaction.guild);
        if (!officialText || !set.partnershipChannelId) return interaction.reply({ content:'❌ Configure o canal de parcerias e o canal do TXT oficial no /painel. Se o canal do TXT já foi configurado, deixe uma mensagem de texto nesse canal ou fixe a mensagem do TXT oficial.', ephemeral:true });
        
        const cat = await getOrCreateCategory(interaction.guild, set.ticketCategoryName);
        const channel = await interaction.guild.channels.create({
          name: `parceria-${interaction.user.id}`,
          type: ChannelType.GuildText,
          parent: cat.id,
          permissionOverwrites: [
            { id: interaction.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.AttachFiles] },
            { id: client.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels] }
          ]
        });
        tickets.create(channel.id, { userId: interaction.user.id, hostGuildId: interaction.guild.id, step:'await_invite', createdAt: new Date().toISOString(), requiredText: officialText });
        await channel.send(ticketIntro(`<@${interaction.user.id}>`));
        await interaction.reply({ content:`✅ Ticket criado: ${channel}`, ephemeral:true });
      }

      if (interaction.customId === 'ticket:confirm_sent') {
        const t = tickets.get(interaction.channel.id); if (!t) return;
        tickets.update(interaction.channel.id, { step:'await_print' });
        const { askPrintPanel } = require('../components/panels');
        return interaction.reply(askPrintPanel());
      }

      if (interaction.customId === 'ticket:cancel') {
        tickets.remove(interaction.channel.id);
        await interaction.reply({ content:'Ticket cancelado. Este canal será apagado em 5 segundos.' });
        setTimeout(() => interaction.channel.delete().catch(()=>{}), 5000);
      }
    } catch (e) {
      logger.error(e.stack || e.message);
      if (!interaction.replied && !interaction.deferred) interaction.reply({ content:'❌ Erro interno.', ephemeral:true }).catch(()=>{});
    }
  }
};
