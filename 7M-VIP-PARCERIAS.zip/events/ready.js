const logger = require('../utils/logger');
const { syncApplicationEmojis } = require('../services/applicationEmojis');
const { syncGlobalCommands } = require('../services/commandSync');

module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client){
    logger.success(`Bot online como ${client.user.tag}`);
    logger.info(`Servidores: ${client.guilds.cache.size}`);
    await syncGlobalCommands(client).catch(err => logger.error(`Erro ao sincronizar comandos: ${err.stack || err.message}`));
    await syncApplicationEmojis().catch(err => logger.error(`Erro ao sincronizar emojis: ${err.stack || err.message}`));
  }
};
