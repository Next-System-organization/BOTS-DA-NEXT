const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');
function loadCommands(client){
  client.commands = new Map();
  const dir = path.join(__dirname, '..', 'commands');
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.js'))){
    const cmd = require(path.join(dir, file));
    client.commands.set(cmd.data.name, cmd);
    logger.info(`Comando carregado: /${cmd.data.name}`);
  }
}
module.exports = { loadCommands };
