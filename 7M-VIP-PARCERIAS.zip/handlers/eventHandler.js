const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');
function loadEvents(client){
  const dir = path.join(__dirname, '..', 'events');
  for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.js'))){
    const event = require(path.join(dir, file));
    if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
    else client.on(event.name, (...args) => event.execute(...args, client));
    logger.info(`Evento carregado: ${event.name}`);
  }
}
module.exports = { loadEvents };
