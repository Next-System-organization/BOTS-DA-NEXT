const { SlashCommandBuilder } = require('discord.js');
const { ownerOnly } = require('../utils/guards');
const { txtGeneratorPanel } = require('../components/panels');
const db = require('../utils/jsonDb');
function ready(form){ return Boolean(form.serverName && form.permanentLink && form.about); }
module.exports = {
  data: new SlashCommandBuilder()
    .setName('gerar-txt')
    .setDescription('Abre o gerador do TXT oficial de parceria deste servidor. Owner only.'),
  async execute(interaction){
    if (!(await ownerOnly(interaction))) return;
    const forms = db.read('txt_forms.json', {});
    const key = `${interaction.guild.id}:${interaction.user.id}`;
    const form = forms[key] || {};
    await interaction.reply({ ...txtGeneratorPanel(form, ready(form)), ephemeral: true });
  }
};
