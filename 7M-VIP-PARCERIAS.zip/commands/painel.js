const { SlashCommandBuilder } = require('discord.js');
const { ownerOnly } = require('../utils/guards');
const settings = require('../services/settings');
const { configPanel } = require('../components/panels');
module.exports = {
  data: new SlashCommandBuilder().setName('painel').setDescription('Abre o painel geral de parcerias. Owner only.'),
  async execute(interaction){
    if (!(await ownerOnly(interaction))) return;
    await interaction.reply({ ...configPanel(settings.get(interaction.guild.id)), ephemeral: true });
  }
};
