const { emojiComponent } = require('../services/applicationEmojis');

const FLAGS = { IsComponentsV2: 32768 };
const Types = {
  ACTION_ROW: 1,
  BUTTON: 2,
  STRING_SELECT: 3,
  CHANNEL_SELECT: 8,
  TEXT_DISPLAY: 10,
  SEPARATOR: 14,
  CONTAINER: 17
};

function resolveEmoji(emoji){
  if (!emoji) return undefined;
  if (typeof emoji === 'object') return emoji;
  return emojiComponent(emoji) || { name: emoji };
}

function text(content){ return { type: Types.TEXT_DISPLAY, content }; }
function sep(){ return { type: Types.SEPARATOR }; }
function button(custom_id, label, style = 3, emoji, disabled = false){
  return { type: Types.BUTTON, custom_id, label, style, disabled, emoji: resolveEmoji(emoji) };
}
function linkButton(url, label, emoji){
  return { type: Types.BUTTON, style: 5, url, label, emoji: resolveEmoji(emoji) };
}
function row(...components){ return { type: Types.ACTION_ROW, components }; }
function select(custom_id, placeholder, options){
  return {
    type: Types.STRING_SELECT,
    custom_id,
    placeholder,
    min_values: 1,
    max_values: 1,
    options: options.map(option => ({ ...option, emoji: resolveEmoji(option.emoji) }))
  };
}
function channelSelect(custom_id, placeholder){
  return { type: Types.CHANNEL_SELECT, custom_id, placeholder, min_values: 1, max_values: 1, channel_types: [0, 5, 15, 16] };
}
function container(...components){ return { type: Types.CONTAINER, accent_color: 0x2ecc71, components }; }
function v2(...components){ return { flags: FLAGS.IsComponentsV2, components }; }

module.exports = { FLAGS, text, sep, button, linkButton, row, select, channelSelect, container, v2, resolveEmoji };
