const c = {
  reset: '\x1b[0m', gray: '\x1b[90m', red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m', cyan: '\x1b[36m', magenta: '\x1b[35m', bold: '\x1b[1m'
};
const time = () => `${c.gray}${new Date().toLocaleTimeString()}${c.reset}`;
module.exports = {
  info: m => console.log(`${time()} ${c.cyan}ℹ${c.reset} ${m}`),
  success: m => console.log(`${time()} ${c.green}✓${c.reset} ${m}`),
  warn: m => console.log(`${time()} ${c.yellow}⚠${c.reset} ${m}`),
  error: m => console.log(`${time()} ${c.red}✗${c.reset} ${m}`),
  debug: m => console.log(`${time()} ${c.magenta}•${c.reset} ${m}`)
};
