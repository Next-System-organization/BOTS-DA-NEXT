const fs = require('fs');
const path = require('path');
const base = path.join(__dirname, '..', 'data');
function file(name){ return path.join(base, name); }
function read(name, fallback){
  try { return JSON.parse(fs.readFileSync(file(name), 'utf8')); }
  catch { write(name, fallback); return fallback; }
}
function write(name, data){ fs.writeFileSync(file(name), JSON.stringify(data, null, 2)); }
function push(name, item){ const arr = read(name, []); arr.push(item); write(name, arr); return item; }
module.exports = { read, write, push };
