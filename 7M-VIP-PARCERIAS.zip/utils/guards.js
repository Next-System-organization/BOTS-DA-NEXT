const config = require('../config.json');
function isOwner(userId){ return String(userId) === String(config.ownerId); }
async function ownerOnly(interaction){
  if (isOwner(interaction.user.id)) return true;
  await interaction.reply({ content: '❌ Apenas o owner definido no config.json pode usar este comando.', ephemeral: true });
  return false;
}
module.exports = { isOwner, ownerOnly };
