function sanitizeMentions(text = ''){
  return String(text)
    .replace(/@everyone/gi, '')
    .replace(/@here/gi, '')
    .replace(/<@!?\d+>/g, '')
    .replace(/<@&\d+>/g, '')
    .replace(/<#\d+>/g, '')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}
function hasBlockedMentions(text = ''){
  return /@everyone|@here|<@!?\d+>|<@&\d+>|<#\d+>/i.test(String(text));
}
module.exports = { sanitizeMentions, hasBlockedMentions };
