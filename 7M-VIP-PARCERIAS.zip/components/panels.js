const { sanitizeMentions } = require('../utils/filter');
const { v2, container, text, sep, row, button, linkButton, select, channelSelect } = require('../utils/componentsV2');
const { emojiText } = require('../services/applicationEmojis');

function publicPanel(){
  return v2(container(
    text('## REALIZE PARCERIA CONOSCO'), sep(),
    text('> Processo 100% automático\n> Rápido e simples\n> Cresça sua comunidade'), sep(),
    text('• Seu servidor será divulgado no canal de parcerias configurado.\n• O bot cria um canal/ticket e guia tudo automaticamente.\n• Menções como everyone, here, cargos, membros e canais são filtradas.'),
    row(button('partner:start', 'Iniciar Parceria', 3, 'partner'))
  ));
}

function configPanel(settings){
  return v2(container(
    text(`## ${emojiText('painel')} Painel Geral de Parcerias`), sep(),
    text(`**Canal do painel:** ${settings.panelChannelId ? `<#${settings.panelChannelId}>` : 'Não definido'}\n**Canal de parcerias:** ${settings.partnershipChannelId ? `<#${settings.partnershipChannelId}>` : 'Não definido'}\n**Canal staff/logs:** ${settings.staffChannelId ? `<#${settings.staffChannelId}>` : 'Não definido'}\n**Canal do TXT oficial:** ${settings.officialTextChannelId ? `<#${settings.officialTextChannelId}>` : 'Não definido'}\n**TXT gerado/salvo:** ${settings.partnerText ? 'Configurado' : 'Não configurado'}\n**Cooldown:** 24 horas`),
    sep(),
    text('Selecione uma opção abaixo. Cada opção abre um menu próprio para escolher o canal, sem precisar digitar ID.'),
    row(select('config:menu', 'Escolha o que deseja configurar', [
      { label:'Configurar canal do painel', value:'panel_channel', emoji:'pin' },
      { label:'Configurar canal de parcerias', value:'partnership_channel', emoji:'partner' },
      { label:'Configurar canal staff/logs', value:'staff_channel', emoji:'shield' },
      { label:'Configurar canal do TXT oficial', value:'txt_channel', emoji:'txt' },
      { label:'Publicar painel público', value:'publish_panel', emoji:'success' }
    ]))
  ));
}

function channelConfigPanel(kind, settings){
  const names = {
    panel_channel: [`${emojiText('pin')} Configurar canal do painel`, 'Onde o painel público de iniciar parceria será enviado.'],
    partnership_channel: [`${emojiText('partner')} Configurar canal de parcerias`, 'Onde o TXT/anúncio do parceiro aprovado será publicado.'],
    staff_channel: [`${emojiText('shield')} Configurar canal staff/logs`, 'Onde logs e avisos administrativos podem ser enviados.'],
    txt_channel: [`${emojiText('txt')} Configurar canal do TXT oficial`, 'Canal onde fica o TXT de parceria do seu servidor. O parceiro precisa postar esse TXT no servidor dele.']
  };
  const [title, desc] = names[kind] || names.panel_channel;
  return v2(container(
    text(`## ${title}`), sep(),
    text(`${desc}\n\nSelecione o canal abaixo. O canal atual onde você está não será usado automaticamente; você escolhe direto pelo select.`),
    row(channelSelect(`config:set:${kind}`, 'Selecione o canal')),
    row(button('config:back', 'Voltar', 2, 'back'))
  ));
}

function ticketIntro(user){
  return v2(container(
    text('## Parceria Automática'), sep(),
    text(`Olá ${user}, tudo bem? Vou te ajudar com a sua parceria.\n\n**Primeiro passo:** envie o convite do seu servidor.`),
    text('💡 Caso tenha mais de um servidor, envie um por vez.\n⚠️ Convites inválidos, servidores em blacklist e flood serão recusados.'),
    row(button('ticket:cancel', 'Cancelar', 4, 'back'))
  ));
}

function sendOurTextPanel(officialText, officialTextChannelUrl){
  return v2(container(
    text(`## ${emojiText('txt')} Próximo passo: envie nosso texto de parceria`), sep(),
    text(`1. Acesse o canal do TXT oficial pelo botão abaixo.\n2. Copie o TXT diretamente lá no canal configurado.\n3. Envie esse TXT no seu servidor.\n4. Depois clique em confirmar e mande uma print.\n\n⚠️ O bot não envia mais o TXT dentro do ticket, porque Components V2 pode dificultar copiar texto grande pelo celular.`),
    row(linkButton(officialTextChannelUrl || 'https://discord.com', 'Abrir canal do TXT oficial', 'txt')),
    row(button('ticket:confirm_sent', 'Confirmar que enviei', 3, 'success'), button('ticket:cancel', 'Cancelar', 4, 'back'))
  ));
}

function askPrintPanel(){
  return v2(container(
    text('## 📷 Envie uma print de comprovação'), sep(),
    text('• A print precisa mostrar o TXT postado no seu servidor.\n• O nome do servidor precisa estar visível e bater com o convite enviado.\n• O link/convite do nosso servidor precisa aparecer igual ao TXT oficial.\n\nNão precisa mostrar membros online, quantidade de membros, boosts ou métricas. O importante é confirmar servidor correto + link correto.'),
    row(button('ticket:cancel', 'Cancelar', 4, 'back'))
  ));
}

function txtGeneratorPanel(form = {}, ready = false){
  const line = (label, value) => `**${label}**\n${value || 'Não informado'}`;
  return v2(container(
    text(`## ${emojiText('robot')} Gerador de TXT com IA`), sep(),
    text(`${line('🌐 Nome do Servidor (Obrigatório)', form.serverName)}\n\n${line('🔗 Link Permanente (Obrigatório)', form.permanentLink)}\n\n${line('ℹ️ Sobre o Servidor (Obrigatório)', form.about)}\n\n${line('🛒 Produtos vendidos (Para lojas)', form.products)}\n\n${line('➕ Informações adicionais (Opcional)', form.extra)}`),
    sep(),
    text(ready ? `${emojiText('success')} Informações obrigatórias preenchidas. Clique em gerar TXT.` : `${emojiText('warning')} Preencha as informações obrigatórias para gerar o TXT.`),
    row(button('txtform:edit', 'Editar Informações', 1, 'painel'), button('txtform:generate', 'Gerar TXT', 3, 'arrow', !ready))
  ));
}

function txtPreview(title, txt){
  return v2(container(
    text('## Preview do TXT gerado pela IA'), sep(),
    text(`**${title}**\n\n${txt}`),
    row(button('txt:save', 'Salvar este TXT', 3, 'success'), button('txt:regenerate', 'Gerar outro', 2, 'refresh'), button('txt:cancel', 'Cancelar', 4, 'cancel'))
  ));
}

function publishedPartnerText(ticket){
  return v2(container(
    text(`## ${ticket.partnerGuildName || 'Novo parceiro'}`), sep(),
    text(sanitizeMentions(ticket.partnerAd || 'Texto do parceiro não informado.')), sep(),
    text(`Servidor: ${ticket.partnerGuildName}\nScore IA: ${ticket.aiScore || 'N/A'}/100`),
    row(linkButton(ticket.inviteUrl, 'Entrar no servidor', 'partner'))
  ));
}
module.exports = { publicPanel, configPanel, channelConfigPanel, ticketIntro, sendOurTextPanel, askPrintPanel, txtGeneratorPanel, txtPreview, publishedPartnerText };
