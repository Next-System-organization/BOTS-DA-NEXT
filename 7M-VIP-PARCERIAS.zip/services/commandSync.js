const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const config = require('../config.json');
const logger = require('../utils/logger');

function readCommandPayloads(){
  const commandsPath = path.join(__dirname, '..', 'commands');
  const files = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
  return files.map(file => {
    delete require.cache[require.resolve(path.join(commandsPath, file))];
    const command = require(path.join(commandsPath, file));
    if (!command.data?.toJSON) throw new Error(`Comando inválido: ${file}`);
    return command.data.toJSON();
  });
}

async function syncGlobalCommands(client){
  if (!config.token || !config.clientId) throw new Error('Configure token e clientId no config.json');
  const rest = new REST({ version: '10' }).setToken(config.token);
  const payload = readCommandPayloads();

  logger.info(`Sincronizando ${payload.length} comandos globais...`);
  await rest.put(Routes.applicationCommands(config.clientId), { body: payload });
  logger.success('Comandos globais sincronizados. Comandos antigos globais foram removidos.');

  for (const guild of client.guilds.cache.values()) {
    try {
      const guildCommands = await rest.get(Routes.applicationGuildCommands(config.clientId, guild.id));
      if (Array.isArray(guildCommands) && guildCommands.length > 0) {
        await rest.put(Routes.applicationGuildCommands(config.clientId, guild.id), { body: [] });
        logger.warn(`Comandos locais antigos removidos em ${guild.name}.`);
      }
    } catch (err) {
      logger.warn(`Não consegui limpar comandos locais em ${guild.name}: ${err.message}`);
    }
  }
}

module.exports = { syncGlobalCommands, readCommandPayloads };
