const db = require('../utils/jsonDb');
function all(){ return db.read('tickets.json', {}); }
function get(channelId){ return all()[channelId]; }
function create(channelId, data){ const a = all(); a[channelId] = data; db.write('tickets.json', a); return data; }
function update(channelId, patch){ const a = all(); a[channelId] = { ...(a[channelId]||{}), ...patch }; db.write('tickets.json', a); return a[channelId]; }
function remove(channelId){ const a = all(); delete a[channelId]; db.write('tickets.json', a); }
module.exports = { get, create, update, remove };
