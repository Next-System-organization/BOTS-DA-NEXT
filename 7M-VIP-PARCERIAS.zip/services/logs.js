const db = require('../utils/jsonDb');
function log(type, payload){ return db.push('logs.json', { id: `${Date.now()}-${Math.random().toString(36).slice(2,8)}`, type, ...payload, createdAt: new Date().toISOString() }); }
module.exports = { log };
