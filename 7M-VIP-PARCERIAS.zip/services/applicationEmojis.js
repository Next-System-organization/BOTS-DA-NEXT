const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');
const db = require('../utils/jsonDb');
const config = require('../config.json');

const EMOJIS_PATH = path.join(__dirname, '..', 'data', 'emojis.json');

function loadEmojiDb(){
  return db.read('emojis.json', { settings:{ enabled:true, strict:false }, emojis:{} });
}

function saveEmojiDb(db){
  require('../utils/jsonDb').write('emojis.json', db);
}

function getEmoji(key){
  const db = loadEmojiDb();
  const item = db.emojis?.[key];
  if (!db.settings?.enabled || !item) return null;
  if (!item.id) return null;
  return { id: String(item.id), name: item.name || key, animated: Boolean(item.animated) };
}

function emojiText(key){
  const db = loadEmojiDb();
  const item = db.emojis?.[key];
  if (!db.settings?.enabled || !item) return '';
  if (item.id) return `<${item.animated ? 'a' : ''}:${item.name || key}:${item.id}>`;
  return item.fallback || '';
}

function emojiComponent(key){
  const db = loadEmojiDb();
  const item = db.emojis?.[key];
  if (!db.settings?.enabled || !item) return undefined;
  if (item.id) return { id: String(item.id), name: item.name || key, animated: Boolean(item.animated) };
  if (item.fallback) return { name: item.fallback };
  return undefined;
}

async function fetchApplicationEmojis(){
  if (!config.token || !config.clientId) throw new Error('config.json precisa de token e clientId para buscar emojis globais.');
  const res = await fetch(`https://discord.com/api/v10/applications/${config.clientId}/emojis`, {
    method: 'GET',
    headers: { Authorization: `Bot ${config.token}` }
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Falha ao buscar Application Emojis: ${res.status} ${JSON.stringify(json)}`);
  return Array.isArray(json.items) ? json.items : Array.isArray(json) ? json : [];
}

async function syncApplicationEmojis(){
  const db = loadEmojiDb();
  if (!db.settings?.enabled) {
    logger.warn('Sistema de emojis globais desligado em data/emojis.json');
    return;
  }

  const configured = Object.entries(db.emojis || {}).filter(([, e]) => e?.id);
  if (!configured.length) {
    logger.warn('Nenhum emoji global configurado em data/emojis.json. Usando emojis padrão como fallback.');
    return;
  }

  try {
    const appEmojis = await fetchApplicationEmojis();
    const appIds = new Set(appEmojis.map(e => String(e.id)));
    let ok = 0;
    let missing = 0;

    for (const [key, emoji] of configured) {
      if (appIds.has(String(emoji.id))) ok++;
      else {
        missing++;
        logger.warn(`Emoji global não encontrado no app: ${key} (${emoji.name}:${emoji.id})`);
      }
    }

    logger.success(`Emojis globais carregados: ${ok}/${configured.length}`);

    if (missing && db.settings?.strict) {
      throw new Error(`${missing} emoji(s) configurados não existem nos Application Emojis.`);
    }
  } catch (err) {
    logger.error(err.message);
    if (db.settings?.strict) throw err;
  }
}

async function createApplicationEmoji(name, imagePath){
  if (!config.token || !config.clientId) throw new Error('config.json precisa de token e clientId.');
  if (!fs.existsSync(imagePath)) throw new Error(`Imagem não encontrada: ${imagePath}`);

  const ext = path.extname(imagePath).toLowerCase();
  const mime = ext === '.gif' ? 'image/gif' : ext === '.webp' ? 'image/webp' : 'image/png';
  const image = fs.readFileSync(imagePath, { encoding: 'base64' });

  const res = await fetch(`https://discord.com/api/v10/applications/${config.clientId}/emojis`, {
    method: 'POST',
    headers: {
      Authorization: `Bot ${config.token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ name, image: `data:${mime};base64,${image}` })
  });

  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Falha ao criar emoji ${name}: ${res.status} ${JSON.stringify(json)}`);
  return json;
}

module.exports = {
  loadEmojiDb,
  saveEmojiDb,
  getEmoji,
  emojiText,
  emojiComponent,
  syncApplicationEmojis,
  createApplicationEmoji
};
