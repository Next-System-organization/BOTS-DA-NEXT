const db = require('../utils/jsonDb');

function defaults(){
  return db.read('server_defaults.json', {
    cooldownMs: 86400000,
    minMembers: 0,
    ticketCategoryName: 'Parcerias Automáticas',
    autoApprove: true
  });
}
function all(){ return db.read('settings.json', {}); }
function get(guildId){
  const data = all();
  const base = defaults();
  return {
    ...base,
    panelChannelId: null,
    partnershipChannelId: null,
    staffChannelId: null,
    officialTextChannelId: null,
    partnerText: null,
    ...(data[guildId] || {})
  };
}
function set(guildId, patch){
  const data = all();
  const current = data[guildId] || {};
  data[guildId] = { ...current, ...patch };
  db.write('settings.json', data);
  return get(guildId);
}

function walkComponents(raw, out = []){
  if (!raw) return out;
  if (Array.isArray(raw)) {
    for (const item of raw) walkComponents(item, out);
    return out;
  }
  if (typeof raw !== 'object') return out;
  // Components V2 Text Display usa "content". Mantemos só textos grandes o suficiente.
  if (typeof raw.content === 'string' && raw.content.trim().length > 20) out.push(raw.content.trim());
  for (const value of Object.values(raw)) {
    if (value && typeof value === 'object') walkComponents(value, out);
  }
  return out;
}

function extractMessageText(message){
  const parts = [];
  if (message.content && message.content.trim()) parts.push(message.content.trim());
  for (const embed of message.embeds || []) {
    if (embed.title) parts.push(embed.title);
    if (embed.description) parts.push(embed.description);
    for (const field of embed.fields || []) {
      if (field.name) parts.push(field.name);
      if (field.value) parts.push(field.value);
    }
  }
  for (const component of message.components || []) {
    try {
      const json = typeof component.toJSON === 'function' ? component.toJSON() : component;
      parts.push(...walkComponents(json));
    } catch {}
  }
  return parts.join('\n').trim();
}

function validOfficialText(text){
  const clean = String(text || '').trim();
  if (clean.length < 20) return false;
  if (/^\/?(painel|gerar-txt|help|config)\b/i.test(clean)) return false;
  return true;
}

async function getOfficialText(guild){
  const s = get(guild.id);
  if (validOfficialText(s.partnerText)) return s.partnerText.trim();
  if (!s.officialTextChannelId) return null;

  const ch = await guild.channels.fetch(s.officialTextChannelId).catch(() => null);
  if (!ch || !ch.messages?.fetch) return null;

  const candidates = [];
  const pinned = await ch.messages.fetchPinned().catch(() => null);
  if (pinned) candidates.push(...pinned.values());

  const recent = await ch.messages.fetch({ limit: 100 }).catch(() => null);
  if (recent) candidates.push(...recent.values());

  const seen = new Set();
  for (const msg of candidates) {
    if (!msg || seen.has(msg.id)) continue;
    seen.add(msg.id);
    const txt = extractMessageText(msg);
    if (validOfficialText(txt)) return txt;
  }
  return null;
}

module.exports = { defaults, get, set, getOfficialText, extractMessageText };
