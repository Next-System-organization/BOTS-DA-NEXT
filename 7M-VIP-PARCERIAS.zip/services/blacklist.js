const db = require('../utils/jsonDb');
function list(){ return db.read('blacklist.json', []); }
function isBlocked({ guildId, ownerId, inviteCode }){ return list().some(x => [guildId, ownerId, inviteCode].filter(Boolean).includes(x.value)); }
function add(type, value, reason, staffId){ const item = { id: Date.now().toString(), type, value, reason, staffId, createdAt: new Date().toISOString() }; const arr = list(); arr.push(item); db.write('blacklist.json', arr); return item; }
module.exports = { list, isBlocked, add };
