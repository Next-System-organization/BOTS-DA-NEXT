const axios = require('axios');
const config = require('../config.json');
const { sanitizeMentions } = require('../utils/filter');

async function mistral(messages){
  if (!config.mistralApiKey || config.mistralApiKey.includes('COLOQUE_')) {
    throw new Error('mistralApiKey ausente no config.json');
  }
  const { data } = await axios.post('https://api.mistral.ai/v1/chat/completions', {
    model: 'mistral-large-latest',
    temperature: 0.2,
    response_format: { type: 'json_object' },
    messages
  }, { headers: { Authorization: `Bearer ${config.mistralApiKey}` } });

  return JSON.parse(data.choices?.[0]?.message?.content || '{}');
}

function extractInvites(text){
  const matches = String(text || '').match(/(?:https?:\/\/)?(?:discord\.gg|discord\.com\/invite)\/[a-zA-Z0-9-]+/gi) || [];
  return [...new Set(matches.map(x => x.replace(/^https?:\/\//i, '').trim()))];
}

async function generateOwnerPartnershipText({ guild, description }){
  const out = await mistral([{ role:'user', content:`Gere um TXT oficial de parceria em PT-BR para o servidor onde o bot está instalado. Esse TXT será enviado para parceiros copiarem e postarem no servidor deles. Não use @everyone, @here, menção a cargos, membros ou canais. Retorne JSON válido: {"title":"","text":""}. Nome real do servidor: ${guild.name}. Membros: ${guild.memberCount}. Descrição enviada pelo owner: ${description}` }]);
  return {
    title: sanitizeMentions(out.title || `Parceria ${guild.name}`),
    text: sanitizeMentions(out.text || description)
  };
}

async function analyzeScreenshot({ imageUrl, requiredText, realGuildName, partnerGuildName, partnerInviteUrl }){
  const expectedInvites = extractInvites(requiredText);
  const prompt = `Você é a IA de validação de prints de parceria Discord.

REGRA PRINCIPAL:
Aprovar se a print mostrar que o parceiro postou o TXT de parceria no servidor dele e se os dois pontos principais estiverem corretos:
1. O nome do servidor parceiro visível na print deve bater com o servidor do convite enviado: "${partnerGuildName}".
2. O link/convite do nosso servidor dentro da postagem deve bater com o link existente no TXT oficial.

NÃO recuse por não mostrar membros online, quantidade total de membros, boosts, data de criação ou métricas. Esses dados não são obrigatórios.
NÃO exija que o texto inteiro esteja 100% idêntico, porque prints podem cortar parte do texto. Foque no nome correto do servidor e no link/convite correto.
Só recuse se o link estiver errado, o nome do servidor não bater, a imagem não mostrar postagem de parceria, ou houver sinal forte de print falso/editado.
Se o nome e o link estiverem corretos, retorne approved=true, score>=80 e riskLevel="low".

Retorne JSON válido exatamente neste formato:
{"approved":boolean,"score":0-100,"riskLevel":"low|medium|high","reason":"","warnings":[]}

Dados esperados:
- Nosso servidor: ${realGuildName}
- Servidor parceiro pelo convite: ${partnerGuildName}
- Convite enviado pelo parceiro: ${partnerInviteUrl || 'N/A'}
- Links/convites esperados no TXT oficial: ${expectedInvites.length ? expectedInvites.join(', ') : 'Nenhum link encontrado no TXT oficial; nesse caso valide pelo nome do servidor e presença de uma postagem de parceria.'}
- TXT oficial completo apenas para contexto, não para comparação exata: ${requiredText}`;

  const out = await mistral([{ role:'user', content:[{ type:'text', text: prompt }, { type:'image_url', image_url: imageUrl }] }]);
  return {
    approved: !!out.approved,
    score: Number(out.score || 0),
    riskLevel: out.riskLevel || 'high',
    reason: out.reason || 'Sem motivo retornado.',
    warnings: out.warnings || []
  };
}

module.exports = { generateOwnerPartnershipText, analyzeScreenshot };
