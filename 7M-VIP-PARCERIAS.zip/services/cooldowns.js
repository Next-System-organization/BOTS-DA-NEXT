const db = require('../utils/jsonDb');

function all(){ return db.read('cooldowns.json', {}); }
function pairKey(hostGuildId, partnerGuildId){ return `${hostGuildId}:${partnerGuildId}`; }

function get(hostGuildId, partnerGuildId){
  return all()[pairKey(hostGuildId, partnerGuildId)] || null;
}

function remaining(hostGuildId, partnerGuildId){
  const item = get(hostGuildId, partnerGuildId);
  if (!item?.expiresAt) return 0;
  return Math.max(0, new Date(item.expiresAt).getTime() - Date.now());
}

function set(hostGuildId, partnerGuildId, cooldownMs, extra = {}){
  const data = all();
  const now = Date.now();
  data[pairKey(hostGuildId, partnerGuildId)] = {
    hostGuildId,
    partnerGuildId,
    partnerGuildName: extra.partnerGuildName || null,
    userId: extra.userId || null,
    lastPartnership: now,
    lastAt: new Date(now).toISOString(),
    expiresAt: new Date(now + cooldownMs).toISOString(),
    cooldownMs
  };
  db.write('cooldowns.json', data);
  return data[pairKey(hostGuildId, partnerGuildId)];
}

function clearExpired(){
  const data = all();
  const now = Date.now();
  let changed = false;
  for (const [k, item] of Object.entries(data)) {
    if (item?.expiresAt && new Date(item.expiresAt).getTime() <= now) {
      delete data[k];
      changed = true;
    }
  }
  if (changed) db.write('cooldowns.json', data);
}

function format(ms){
  const totalMinutes = Math.ceil(ms / 60000);
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  if (h >= 24) {
    const d = Math.floor(h / 24);
    const rh = h % 24;
    return `${d}d ${rh}h ${m}m`;
  }
  return `${h}h ${m}m`;
}

module.exports = { get, remaining, set, clearExpired, format };
