@echo off
echo ========================================
echo   Vision Hub Auth Bot - Instalador
echo ========================================
echo.
echo [1/2] Instalando dependencias...
pip install -r requirements.txt
echo.
echo [2/2] Iniciando o bot...
echo.
echo LEMBRE-SE: Coloque seu TOKEN em main.py antes de rodar!
echo.
python main.py
pause
