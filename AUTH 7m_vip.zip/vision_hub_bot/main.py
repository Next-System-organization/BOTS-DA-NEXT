import discord
from discord.ext import commands
import asyncio
import os
from database import Database

# ─────────────────────────────────────────
#  CONFIGURAÇÕES
# ─────────────────────────────────────────
TOKEN = "SEU_TOKEN_AQUI"
PREFIX = "!"

intents = discord.Intents.all()
bot = commands.Bot(command_prefix=PREFIX, intents=intents)
db = Database()

# ─────────────────────────────────────────
#  EVENTOS
# ─────────────────────────────────────────
@bot.event
async def on_ready():
    await db.init()
    await bot.tree.sync()
    print(f"✅ Bot online como {bot.user} ({bot.user.id})")
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="Vision Hub Auth 🔐"
        )
    )

# ─────────────────────────────────────────
#  CARREGAR COGS
# ─────────────────────────────────────────
async def load_extensions():
    os.makedirs("./cogs", exist_ok=True)  # cria a pasta se não existir
    for filename in os.listdir("./cogs"):
        if filename.endswith(".py"):
            await bot.load_extension(f"cogs.{filename[:-3]}")
            print(f"  📦 Cog carregado: {filename}")

async def main():
    async with bot:
        await load_extensions()
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())
