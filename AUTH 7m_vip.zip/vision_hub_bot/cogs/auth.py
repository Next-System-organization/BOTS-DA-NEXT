import discord
from discord.ext import commands
from discord import app_commands
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import Database

db = Database()


# ─────────────────────────────────────────
#  MODAL — Resgatar Autenticador
# ─────────────────────────────────────────
class AuthModal(discord.ui.Modal, title="🔐 Resgatar Autenticador"):
    token = discord.ui.TextInput(
        label="Qual o novo token que deseja colocar?",
        placeholder="Lembre-se: Faça com bastante atenção nas respostas do Bot",
        style=discord.TextStyle.short,
        required=True,
        max_length=200
    )
    client_secret = discord.ui.TextInput(
        label="Qual o novo client_secret?",
        placeholder="Lembre-se: Faça com bastante atenção nas respostas do Bot",
        style=discord.TextStyle.short,
        required=True,
        max_length=200
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild_id = str(interaction.guild.id) if interaction.guild else None
        await db.register_user(
            discord_id=str(interaction.user.id),
            token=self.token.value,
            client_secret=self.client_secret.value,
            guild_id=guild_id
        )
        embed = discord.Embed(
            title="✅ Autenticador Resgatado!",
            description=(
                f"Seus dados foram salvos com sucesso, {interaction.user.mention}!\n\n"
                "**Token:** `••••••••••••` (salvo com segurança)\n"
                "**Client Secret:** `••••••••••••` (salvo com segurança)\n\n"
                "> ⚠️ Nunca compartilhe seu token ou client_secret com ninguém."
            ),
            color=discord.Color.green()
        )
        embed.set_footer(text="Vision Hub Auth • Sistema Seguro")
        await interaction.followup.send(embed=embed, ephemeral=True)

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        await interaction.response.send_message(
            f"❌ Erro ao processar: `{error}`", ephemeral=True
        )


# ─────────────────────────────────────────
#  MODAL — Puxar Membros
# ─────────────────────────────────────────
class PullMembersModal(discord.ui.Modal, title="👥 Puxar Membros"):
    source_guild = discord.ui.TextInput(
        label="ID do servidor de ORIGEM",
        placeholder="Ex: 123456789012345678",
        required=True,
        max_length=20
    )
    target_guild = discord.ui.TextInput(
        label="ID do servidor de DESTINO",
        placeholder="Ex: 987654321098765432",
        required=True,
        max_length=20
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            source = interaction.client.get_guild(int(self.source_guild.value))
            target = interaction.client.get_guild(int(self.target_guild.value))
        except ValueError:
            await interaction.followup.send("❌ ID inválido. Use apenas números.", ephemeral=True)
            return

        if not source:
            await interaction.followup.send("❌ Servidor de origem não encontrado.", ephemeral=True)
            return
        if not target:
            await interaction.followup.send("❌ Servidor de destino não encontrado.", ephemeral=True)
            return

        embed = discord.Embed(
            title="✅ Pull Iniciado!",
            description=(
                f"**Origem:** `{source.name}` ({source.member_count} membros)\n"
                f"**Destino:** `{target.name}`\n\n"
                "O processo foi iniciado.\n"
                "> ⚠️ O pull real requer OAuth2 com membros autorizados."
            ),
            color=discord.Color.green()
        )
        await interaction.followup.send(embed=embed, ephemeral=True)

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        await interaction.response.send_message(f"❌ Erro: `{error}`", ephemeral=True)


# ─────────────────────────────────────────
#  VIEW — Painel principal (botão resgatar)
# ─────────────────────────────────────────
class AuthPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="🛒 Resgatar Autenticador",
        style=discord.ButtonStyle.primary,
        custom_id="auth:resgatar"
    )
    async def resgatar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(AuthModal())

    @discord.ui.button(
        label="📖 Tutorial",
        style=discord.ButtonStyle.secondary,
        custom_id="auth:tutorial"
    )
    async def tutorial(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="📖 Como usar o Vision Hub Auth",
            color=discord.Color.blurple()
        )
        embed.add_field(
            name="1️⃣ Obtenha seu Token",
            value="Acesse o [Portal do Discord Developer](https://discord.com/developers/applications) e copie o token do seu bot.",
            inline=False
        )
        embed.add_field(
            name="2️⃣ Obtenha o Client Secret",
            value="Na mesma página, vá em **OAuth2** e copie o `Client Secret`.",
            inline=False
        )
        embed.add_field(
            name="3️⃣ Resgate o Autenticador",
            value="Clique em **Resgatar Autenticador** e preencha os campos com atenção.",
            inline=False
        )
        embed.set_footer(text="Vision Hub Auth • Suporte disponível no servidor")
        await interaction.response.send_message(embed=embed, ephemeral=True)


# ─────────────────────────────────────────
#  VIEW — Dashboard do usuário autenticado
# ─────────────────────────────────────────
class AuthDashboardView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="⚙️ Configure sua aplicação", style=discord.ButtonStyle.secondary, row=0)
    async def configure(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "🔧 Painel de configuração em desenvolvimento.", ephemeral=True
        )

    @discord.ui.button(label="👥 Puxar Membros", style=discord.ButtonStyle.primary, row=1)
    async def pull_members(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(PullMembersModal())

    @discord.ui.button(label="🛠️ Configurar Servidores", style=discord.ButtonStyle.secondary, row=1)
    async def config_servers(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "🛠️ Configure os servidores de origem/destino.", ephemeral=True
        )

    @discord.ui.button(label="🎁 Criar Gift-Card(s)", style=discord.ButtonStyle.success, row=1)
    async def create_giftcard(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "🎁 Sistema de Gift-Cards em breve.", ephemeral=True
        )

    @discord.ui.button(label="🔗 Convidar Aplicação", style=discord.ButtonStyle.secondary, row=2)
    async def invite(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "🔗 Acesse: https://discord.com/developers/applications", ephemeral=True
        )

    @discord.ui.button(label="🔔 Status Requests", style=discord.ButtonStyle.secondary, row=2)
    async def status(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="🔔 Status do Sistema",
            description="✅ Todos os sistemas operacionais.",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


# ─────────────────────────────────────────
#  COG
# ─────────────────────────────────────────
class AuthCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="auth", description="Exibe seu painel de autenticação")
    async def auth_command(self, interaction: discord.Interaction):
        user = await db.get_user(str(interaction.user.id))
        total = await db.count_active_users()
        licenses = await db.get_license_by_owner(str(interaction.user.id))

        embed = discord.Embed(
            title="🔐 Fuzion System — Verificação — VisioHub Auth",
            color=discord.Color.blurple()
        )

        if user:
            embed.add_field(name="Nome da Aplicação", value="Fuzion System — Verificação", inline=True)
            embed.add_field(name="Usuário(s) Válido(s)", value=f"{total} usuários", inline=True)
            pulls = licenses[0]["pulls_count"] if licenses else 0
            embed.add_field(name="Quantidades de Puxadas", value=f"{pulls} puxadas", inline=True)
            expires = licenses[0]["expires_at"] if licenses and licenses[0]["expires_at"] else "Sem expiração"
            embed.add_field(name="Expira em", value=expires, inline=True)
            embed.add_field(name="License Users", value=f"• {interaction.user.mention}", inline=True)
            embed.set_footer(text="Só você pode ver esta mensagem")
            await interaction.response.send_message(embed=embed, view=AuthDashboardView(), ephemeral=True)
        else:
            embed.description = (
                "Você ainda não possui autenticação registrada.\n"
                "Clique em **Resgatar Autenticador** para começar."
            )
            embed.color = discord.Color.orange()
            await interaction.response.send_message(embed=embed, view=AuthPanelView(), ephemeral=True)

    @app_commands.command(name="setup-auth", description="Envia o painel de autenticação no canal")
    @app_commands.checks.has_permissions(administrator=True)
    async def setup_auth(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="🔐 VisioHub Auth",
            description=(
                "Sistema de autenticação OAuth2 para o seu servidor.\n\n"
                "**• Backup de Membros** — Armazena membros do servidor.\n"
                "**• Personalização Completa** — Configure o comportamento do bot.\n"
                "**• Mensagens Customizadas** — Crie mensagens e notificações.\n"
                "**• Integração com OAuth2** — Autenticação segura.\n"
                "**• Gerenciamento de Permissões** — Controle integrações.\n"
                "**• Design Modular** — Ative ou desative recursos.\n"
                "**• Logs Detalhados** — Acompanhe tudo.\n"
                "**• Interface Amigável** — Fácil para qualquer membro.\n\n"
                "> ⚠️ Por favor, resgate seu auth caso realmente for utilizá-lo. "
                "Contas offline por muito tempo ou com token expirado serão removidas."
            ),
            color=discord.Color.blurple()
        )
        embed.set_footer(text="Vision Hub Auth • Sistema Oficial")
        await interaction.channel.send(embed=embed, view=AuthPanelView())
        await interaction.response.send_message("✅ Painel enviado!", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(AuthCog(bot))
