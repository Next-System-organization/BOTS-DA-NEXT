import discord
from discord.ext import commands
from discord import app_commands
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import Database

db = Database()


class LicenseCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="criar-licenca", description="Cria uma nova licença de aplicação")
    @app_commands.checks.has_permissions(administrator=True)
    async def criar_licenca(
        self,
        interaction: discord.Interaction,
        app_name: str,
        max_users: int = 100,
        usuario: discord.Member = None,
    ):
        owner = usuario or interaction.user
        key = await db.create_license(
            app_name=app_name,
            owner_id=str(owner.id),
            max_users=max_users
        )
        embed = discord.Embed(title="🎫 Licença Criada!", color=discord.Color.green())
        embed.add_field(name="🔑 Chave", value=f"||`{key}`||", inline=False)
        embed.add_field(name="📛 Aplicação", value=app_name, inline=True)
        embed.add_field(name="👤 Dono", value=owner.mention, inline=True)
        embed.add_field(name="👥 Máx. Usuários", value=str(max_users), inline=True)
        embed.set_footer(text="Vision Hub Auth • Licença gerada com sucesso")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="ver-licenca", description="Veja informações da sua licença")
    async def ver_licenca(self, interaction: discord.Interaction):
        licenses = await db.get_license_by_owner(str(interaction.user.id))
        if not licenses:
            await interaction.response.send_message(
                "❌ Você não possui nenhuma licença ativa.", ephemeral=True
            )
            return

        embed = discord.Embed(title="🎫 Suas Licenças", color=discord.Color.blurple())
        for lic in licenses:
            embed.add_field(
                name=f"📛 {lic['app_name']}",
                value=(
                    f"**Chave:** ||`{lic['license_key']}`||\n"
                    f"**Puxadas:** `{lic['pulls_count']}`\n"
                    f"**Máx. Usuários:** `{lic['max_users']}`\n"
                    f"**Expira em:** `{lic['expires_at'] or 'Nunca'}`\n"
                    f"**Criada em:** `{lic['created_at']}`"
                ),
                inline=False
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="revogar-licenca", description="Revoga uma licença existente")
    @app_commands.checks.has_permissions(administrator=True)
    async def revogar_licenca(self, interaction: discord.Interaction, chave: str):
        lic = await db.get_license(chave)
        if not lic:
            await interaction.response.send_message("❌ Licença não encontrada.", ephemeral=True)
            return
        await db.revoke_license(chave)
        embed = discord.Embed(
            title="🗑️ Licença Revogada",
            description=f"A licença `{chave}` foi revogada com sucesso.",
            color=discord.Color.red()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="listar-usuarios", description="Lista total de usuários autenticados")
    @app_commands.checks.has_permissions(administrator=True)
    async def listar_usuarios(self, interaction: discord.Interaction):
        total = await db.count_active_users()
        embed = discord.Embed(
            title="👥 Usuários Autenticados",
            description=f"Total de usuários ativos: **{total}**",
            color=discord.Color.blurple()
        )
        embed.set_footer(text="Vision Hub Auth • Painel Admin")
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(LicenseCog(bot))
