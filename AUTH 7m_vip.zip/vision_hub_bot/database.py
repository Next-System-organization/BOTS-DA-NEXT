import aiosqlite
import hashlib
import secrets

DB_PATH = "vision_hub.db"

class Database:
    def __init__(self):
        self.path = DB_PATH

    async def init(self):
        async with aiosqlite.connect(self.path) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    discord_id TEXT UNIQUE NOT NULL,
                    token TEXT UNIQUE NOT NULL,
                    client_secret TEXT NOT NULL,
                    guild_id TEXT,
                    registered_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    is_active INTEGER DEFAULT 1
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS licenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    license_key TEXT UNIQUE NOT NULL,
                    owner_id TEXT,
                    app_name TEXT NOT NULL,
                    max_users INTEGER DEFAULT 100,
                    pulls_count INTEGER DEFAULT 0,
                    expires_at TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    is_active INTEGER DEFAULT 1
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS pulls (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    license_key TEXT NOT NULL,
                    pulled_by TEXT NOT NULL,
                    source_guild TEXT NOT NULL,
                    target_guild TEXT NOT NULL,
                    members_count INTEGER DEFAULT 0,
                    pulled_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            await db.commit()
        print("✅ Banco de dados inicializado.")

    async def register_user(self, discord_id: str, token: str, client_secret: str, guild_id: str = None):
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        secret_hash = hashlib.sha256(client_secret.encode()).hexdigest()
        async with aiosqlite.connect(self.path) as db:
            await db.execute("""
                INSERT INTO users (discord_id, token, client_secret, guild_id)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(discord_id) DO UPDATE SET
                    token=excluded.token,
                    client_secret=excluded.client_secret,
                    guild_id=excluded.guild_id,
                    registered_at=CURRENT_TIMESTAMP,
                    is_active=1
            """, (discord_id, token_hash, secret_hash, guild_id))
            await db.commit()

    async def get_user(self, discord_id: str):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM users WHERE discord_id = ? AND is_active = 1", (discord_id,)
            ) as cursor:
                return await cursor.fetchone()

    async def deactivate_user(self, discord_id: str):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "UPDATE users SET is_active = 0 WHERE discord_id = ?", (discord_id,)
            )
            await db.commit()

    async def count_active_users(self):
        async with aiosqlite.connect(self.path) as db:
            async with db.execute("SELECT COUNT(*) FROM users WHERE is_active = 1") as cur:
                row = await cur.fetchone()
                return row[0] if row else 0

    async def create_license(self, app_name: str, owner_id: str, max_users: int = 100, expires_at: str = None):
        key = "VH-" + secrets.token_hex(8).upper()
        async with aiosqlite.connect(self.path) as db:
            await db.execute("""
                INSERT INTO licenses (license_key, owner_id, app_name, max_users, expires_at)
                VALUES (?, ?, ?, ?, ?)
            """, (key, owner_id, app_name, max_users, expires_at))
            await db.commit()
        return key

    async def get_license(self, license_key: str):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM licenses WHERE license_key = ? AND is_active = 1", (license_key,)
            ) as cursor:
                return await cursor.fetchone()

    async def get_license_by_owner(self, owner_id: str):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM licenses WHERE owner_id = ? AND is_active = 1", (owner_id,)
            ) as cursor:
                return await cursor.fetchall()

    async def increment_pulls(self, license_key: str, pulled_by: str, source_guild: str, target_guild: str, count: int):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "UPDATE licenses SET pulls_count = pulls_count + 1 WHERE license_key = ?",
                (license_key,)
            )
            await db.execute("""
                INSERT INTO pulls (license_key, pulled_by, source_guild, target_guild, members_count)
                VALUES (?, ?, ?, ?, ?)
            """, (license_key, pulled_by, source_guild, target_guild, count))
            await db.commit()

    async def revoke_license(self, license_key: str):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "UPDATE licenses SET is_active = 0 WHERE license_key = ?", (license_key,)
            )
            await db.commit()
