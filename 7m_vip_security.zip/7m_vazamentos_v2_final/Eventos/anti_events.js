const { AuditLogEvent, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require("discord.js");

function buildLog(title, description) {
  return new ContainerBuilder()
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${title}`))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(description));
}

async function sendLog(guild, container) {
  const logChannel = guild.channels.cache.find(c => c.name === "logs-antiraid");
  if (logChannel) {
    await logChannel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
  }
}

// ── Anti-Bot Join ────────────────────────────────────────────────────────────
const antiBotJoin = {
  name: "guildMemberAdd",
  run: async (member, client) => {
    if (!member.user.bot) return;
    const guild = member.guild;
    const auditLogs = await guild.fetchAuditLogs({ limit: 1, type: 28 }).catch(() => null);
    if (!auditLogs) return;
    const entry = auditLogs.entries.first();
    if (!entry) return;
    const { executor } = entry;
    if (executor.id === guild.ownerId) return;

    await member.kick("Anti-Raid: Bot adicionado por usuário não autorizado.").catch(() => {});
    await sendLog(guild, buildLog(
      "🛡️ Anti-Raid: Bot Detectado",
      `O bot **${member.user.tag}** foi adicionado por **${executor.tag}** e foi expulso.`
    ));
  },
};

// ── Anti-Channel Create ──────────────────────────────────────────────────────
const antiChannelCreate = {
  name: "channelCreate",
  run: async (channel, client) => {
    const guild = channel.guild;
    const logs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelCreate }).catch(() => null);
    if (!logs) return;
    const entry = logs.entries.first();
    if (!entry) return;
    const { executor } = entry;
    if (executor.id === client.user.id || executor.id === guild.ownerId) return;

    await channel.delete("Anti-Raid: Canal criado por usuário não autorizado.").catch(() => {});
    await sendLog(guild, buildLog(
      "🛡️ Anti-Raid: Canal Criado",
      `O usuário **${executor.tag}** tentou criar o canal **${channel.name}**. O canal foi removido.`
    ));
  },
};

// ── Anti-Channel Delete ──────────────────────────────────────────────────────
const antiChannelDelete = {
  name: "channelDelete",
  run: async (channel, client) => {
    const guild = channel.guild;
    const logs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelDelete }).catch(() => null);
    if (!logs) return;
    const entry = logs.entries.first();
    if (!entry) return;
    const { executor } = entry;
    if (executor.id === client.user.id || executor.id === guild.ownerId) return;

    await channel.clone({ reason: "Anti-Raid: Canal deletado por usuário não autorizado." }).catch(() => {});
    await sendLog(guild, buildLog(
      "🛡️ Anti-Raid: Canal Deletado",
      `O usuário **${executor.tag}** deletou o canal **${channel.name}**. O canal foi recriado.`
    ));
  },
};

// ── Anti-Role Create ─────────────────────────────────────────────────────────
const antiRoleCreate = {
  name: "roleCreate",
  run: async (role, client) => {
    const guild = role.guild;
    const logs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.RoleCreate }).catch(() => null);
    if (!logs) return;
    const entry = logs.entries.first();
    if (!entry) return;
    const { executor } = entry;
    if (executor.id === client.user.id || executor.id === guild.ownerId) return;

    await role.delete("Anti-Raid: Cargo criado por usuário não autorizado.").catch(() => {});
    await sendLog(guild, buildLog(
      "🛡️ Anti-Raid: Cargo Criado",
      `O usuário **${executor.tag}** tentou criar o cargo **${role.name}**. O cargo foi removido.`
    ));
  },
};

// ── Anti-Role Delete ─────────────────────────────────────────────────────────
const antiRoleDelete = {
  name: "roleDelete",
  run: async (role, client) => {
    const guild = role.guild;
    const logs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.RoleDelete }).catch(() => null);
    if (!logs) return;
    const entry = logs.entries.first();
    if (!entry) return;
    const { executor } = entry;
    if (executor.id === client.user.id || executor.id === guild.ownerId) return;

    await guild.roles.create({
      name: role.name, color: role.color, hoist: role.hoist,
      permissions: role.permissions, mentionable: role.mentionable,
      reason: "Anti-Raid: Cargo deletado por usuário não autorizado.",
    }).catch(() => {});
    await sendLog(guild, buildLog(
      "🛡️ Anti-Raid: Cargo Deletado",
      `O usuário **${executor.tag}** deletou o cargo **${role.name}**. O cargo foi recriado.`
    ));
  },
};

// ── Anti-Mass Ban ────────────────────────────────────────────────────────────
const banCounts = new Map();
const antiMassBan = {
  name: "guildBanAdd",
  run: async (ban, client) => {
    const guild = ban.guild;
    const logs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberBanAdd }).catch(() => null);
    if (!logs) return;
    const entry = logs.entries.first();
    if (!entry) return;
    const { executor } = entry;
    if (executor.id === client.user.id || executor.id === guild.ownerId) return;

    const id = executor.id;
    const count = (banCounts.get(id) || 0) + 1;
    banCounts.set(id, count);
    setTimeout(() => { const c = banCounts.get(id); if (c > 0) banCounts.set(id, c - 1); }, 10000);

    if (count >= 3) {
      const member = await guild.members.fetch(id).catch(() => null);
      if (member) {
        await member.roles.set([]).catch(() => {});
        await member.kick("Anti-Raid: Banimento em massa detectado.").catch(() => {});
      }
      await sendLog(guild, buildLog(
        "🛡️ Anti-Raid: Banimento em Massa",
        `O usuário **${executor.tag}** tentou banir múltiplos membros. Suas permissões foram removidas e ele foi expulso.`
      ));
      banCounts.delete(id);
    }
  },
};

module.exports = [antiBotJoin, antiChannelCreate, antiChannelDelete, antiRoleCreate, antiRoleDelete, antiMassBan];
