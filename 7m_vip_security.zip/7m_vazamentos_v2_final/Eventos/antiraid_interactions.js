const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  MessageFlags,
} = require("discord.js");

// Estado em memória das proteções (por servidor)
const protectionState = new Map(); // guildId -> { anti_channel, anti_role, anti_ban, anti_bot, anti_kick }

function getState(guildId) {
  if (!protectionState.has(guildId)) {
    protectionState.set(guildId, {
      anti_channel: false,
      anti_role:    false,
      anti_ban:     false,
      anti_bot:     false,
      anti_kick:    false,
    });
  }
  return protectionState.get(guildId);
}

const LABELS = {
  anti_channel: "Anti-Canal",
  anti_role:    "Anti-Cargo",
  anti_ban:     "Anti-Ban",
  anti_bot:     "Anti-Bot",
  anti_kick:    "Anti-Kick",
};

function buildMainContainer(guildId) {
  const state = getState(guildId);
  const statusLines = Object.entries(LABELS)
    .map(([key, label]) => `${state[key] ? "🟢" : "🔴"} **${label}:** ${state[key] ? "Ativo" : "Inativo"}`)
    .join("\n");

  const container = new ContainerBuilder()
    .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 🛡️ Painel Anti-Raid"))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      "Selecione uma proteção para configurar:\n\n" + statusLines
    ))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));

  const select = new StringSelectMenuBuilder()
    .setCustomId("antiraid_menu")
    .setPlaceholder("Escolha uma proteção para configurar")
    .addOptions([
      { label: "Anti-Canal (Nuke)",    description: "Proteção contra criação/exclusão de canais.", value: "anti_channel", emoji: "📁" },
      { label: "Anti-Cargo (Nuke)",    description: "Proteção contra criação/exclusão de cargos.", value: "anti_role",    emoji: "🛡️" },
      { label: "Anti-Ban (Mass Ban)",  description: "Proteção contra bans em massa.",               value: "anti_ban",    emoji: "🚫" },
      { label: "Anti-Bot (Whitelist)", description: "Apenas bots autorizados podem entrar.",        value: "anti_bot",    emoji: "🤖" },
      { label: "Anti-Kick (Mass Kick)",description: "Proteção contra expulsões em massa.",          value: "anti_kick",   emoji: "👢" },
    ]);

  container
    .addActionRowComponents(new ActionRowBuilder().addComponents(select))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("antiraid_on").setLabel("Ativar Tudo").setStyle(ButtonStyle.Success).setEmoji("✅"),
        new ButtonBuilder().setCustomId("antiraid_off").setLabel("Desativar Tudo").setStyle(ButtonStyle.Danger).setEmoji("❌"),
        new ButtonBuilder().setCustomId("antiraid_status").setLabel("Ver Status").setStyle(ButtonStyle.Secondary).setEmoji("📊")
      )
    );

  return container;
}

function buildProtectionContainer(guildId, key) {
  const state  = getState(guildId);
  const label  = LABELS[key] || key;
  const active = state[key];

  return new ContainerBuilder()
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 🛡️ Configurando: ${label}`))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**Status atual:** ${active ? "🟢 Ativo" : "🔴 Inativo"}\n\n` +
        `Selecione uma ação abaixo para configurar a proteção **${label}**.`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`enable_${key}`).setLabel("Ativar").setStyle(ButtonStyle.Success).setEmoji("✅"),
        new ButtonBuilder().setCustomId(`disable_${key}`).setLabel("Desativar").setStyle(ButtonStyle.Danger).setEmoji("❌"),
        new ButtonBuilder().setCustomId("back_to_main").setLabel("Voltar").setStyle(ButtonStyle.Secondary).setEmoji("⬅️")
      )
    );
}

module.exports = {
  name: "interactionCreate",

  run: async (interaction, client) => {
    // ── Select Menu ──────────────────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === "antiraid_menu") {
      const key = interaction.values[0];
      await interaction.update({
        components: [buildProtectionContainer(interaction.guildId, key)],
        flags: MessageFlags.IsComponentsV2,
      });
      return;
    }

    if (!interaction.isButton()) return;

    const { customId, guildId } = interaction;

    // ── Ativar/Desativar proteção específica ─────────────────────
    if (customId.startsWith("enable_") || customId.startsWith("disable_")) {
      const [action, ...rest] = customId.split("_");
      const key    = rest.join("_");
      const state  = getState(guildId);
      const enable = action === "enable";
      state[key]   = enable;

      const label  = LABELS[key] || key;
      const status = enable ? "ativada ✅" : "desativada ❌";

      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 🛡️ Configuração Atualizada"))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`A proteção **${label}** foi **${status}** com sucesso!`)
        )
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
        .addActionRowComponents(
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("back_to_main").setLabel("Voltar ao Painel").setStyle(ButtonStyle.Secondary).setEmoji("⬅️")
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
      return;
    }

    // ── Ativar Tudo ──────────────────────────────────────────────
    if (customId === "antiraid_on") {
      const state = getState(guildId);
      for (const key of Object.keys(state)) state[key] = true;

      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent("# ✅ Todas as Proteções Ativadas"))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
          Object.entries(LABELS).map(([, l]) => `🟢 **${l}:** Ativo`).join("\n")
        ));

      await interaction.reply({ components: [container], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
      return;
    }

    // ── Desativar Tudo ───────────────────────────────────────────
    if (customId === "antiraid_off") {
      const state = getState(guildId);
      for (const key of Object.keys(state)) state[key] = false;

      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent("# ❌ Todas as Proteções Desativadas"))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
          Object.entries(LABELS).map(([, l]) => `🔴 **${l}:** Inativo`).join("\n")
        ));

      await interaction.reply({ components: [container], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
      return;
    }

    // ── Ver Status ───────────────────────────────────────────────
    if (customId === "antiraid_status") {
      const state = getState(guildId);
      const lines = Object.entries(LABELS)
        .map(([key, label]) => `${state[key] ? "🟢" : "🔴"} **${label}:** ${state[key] ? "Ativo" : "Inativo"}`)
        .join("\n");

      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 📊 Status das Proteções"))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(lines));

      await interaction.reply({ components: [container], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
      return;
    }

    // ── Voltar ao Painel Principal ───────────────────────────────
    if (customId === "back_to_main") {
      await interaction.update({
        components: [buildMainContainer(guildId)],
        flags: MessageFlags.IsComponentsV2,
      });
      return;
    }
  },
};
