module.exports = {
  name: "interactionCreate",

  run: async (interaction, client) => {
    if (interaction.isChatInputCommand()) {
      const command = client.slashCommands.get(interaction.commandName);
      if (!command) return interaction.reply({ content: "Ocorreu algum erro ao encontrar este comando.", ephemeral: true });

      try {
        await command.run(client, interaction);
      } catch (error) {
        console.error(`Erro ao executar o comando ${interaction.commandName}:`, error);
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: "Houve um erro ao executar este comando!", ephemeral: true });
        } else {
          await interaction.reply({ content: "Houve um erro ao executar este comando!", ephemeral: true });
        }
      }
    }
  },
};
