const {
  ApplicationCommandType,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  MessageFlags,
} = require("discord.js");

function buildMainPanel() {
  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent("# 🛡️ Painel Anti-Raid")
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        "Selecione uma opção abaixo para configurar as proteções do servidor.\n\n" +
        "**🛡️ Proteção contra Nukers** — Impede que usuários apaguem canais ou cargos.\n" +
        "**🤖 Proteção contra Bots** — Impede que bots não autorizados entrem no servidor.\n" +
        "**🚫 Proteção contra Bans em Massa** — Impede bans em massa por admins mal-intencionados."
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );

  const select = new StringSelectMenuBuilder()
    .setCustomId("antiraid_menu")
    .setPlaceholder("Escolha uma proteção para configurar")
    .addOptions([
      { label: "Anti-Canal (Nuke)", description: "Proteção contra criação/exclusão de canais.", value: "anti_channel", emoji: "📁" },
      { label: "Anti-Cargo (Nuke)", description: "Proteção contra criação/exclusão de cargos.", value: "anti_role", emoji: "🛡️" },
      { label: "Anti-Ban (Mass Ban)", description: "Proteção contra bans em massa.", value: "anti_ban", emoji: "🚫" },
      { label: "Anti-Bot (Whitelist)", description: "Apenas bots autorizados podem entrar.", value: "anti_bot", emoji: "🤖" },
      { label: "Anti-Kick (Mass Kick)", description: "Proteção contra expulsões em massa.", value: "anti_kick", emoji: "👢" },
    ]);

  const selectRow = new ActionRowBuilder().addComponents(select);
  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("antiraid_on").setLabel("Ativar Tudo").setStyle(ButtonStyle.Success).setEmoji("✅"),
    new ButtonBuilder().setCustomId("antiraid_off").setLabel("Desativar Tudo").setStyle(ButtonStyle.Danger).setEmoji("❌"),
    new ButtonBuilder().setCustomId("antiraid_status").setLabel("Ver Status").setStyle(ButtonStyle.Secondary).setEmoji("📊")
  );

  container.addActionRowComponents(selectRow).addActionRowComponents(buttonRow);
  return container;
}

module.exports = {
  name: "antiraid",
  description: "Configure o sistema de Anti-Raid do servidor.",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("Administrator")) {
      return interaction.reply({
        components: [
          new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent("❌ Apenas administradores podem configurar o Anti-Raid.")
          ),
        ],
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
    }

    await interaction.reply({
      components: [buildMainPanel()],
      flags: MessageFlags.IsComponentsV2,
    });
  },
};
