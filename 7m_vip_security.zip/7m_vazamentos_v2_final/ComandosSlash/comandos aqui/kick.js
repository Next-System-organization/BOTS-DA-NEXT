const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require("discord.js");

module.exports = {
  name: "kick",
  description: "Expulsa um usuário do servidor.",
  type: ApplicationCommandType.ChatInput,
  options: [
    { name: "usuario", description: "O usuário que será expulso.", type: ApplicationCommandOptionType.User, required: true },
    { name: "motivo",  description: "O motivo da expulsão.",       type: ApplicationCommandOptionType.String, required: false },
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
      return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Você não tem permissão para expulsar membros."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    }

    const user   = interaction.options.getUser("usuario");
    const reason = interaction.options.getString("motivo") || "Nenhum motivo informado.";
    const member = interaction.guild.members.cache.get(user.id);

    if (!member)          return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Usuário não encontrado."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    if (!member.kickable) return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Eu não posso expulsar este usuário."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });

    await member.kick(`Expulso por ${interaction.user.tag}: ${reason}`);

    const container = new ContainerBuilder()
      .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 👢 Usuário Expulso"))
      .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `👤 **Usuário:** ${user.tag} (\`${user.id}\`)\n` +
          `👮 **Autor:** ${interaction.user.tag}\n` +
          `📝 **Motivo:** ${reason}`
        )
      );

    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
