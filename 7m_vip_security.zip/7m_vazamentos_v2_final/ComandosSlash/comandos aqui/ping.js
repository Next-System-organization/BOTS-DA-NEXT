const {
  ApplicationCommandType,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require("discord.js");

module.exports = {
  name: "ping",
  description: "Veja o PING do bot!",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    const loading = new ContainerBuilder()
      .addTextDisplayComponents(new TextDisplayBuilder().setContent("🏓 Calculando ping..."));

    const reply = await interaction.reply({
      components: [loading],
      flags: MessageFlags.IsComponentsV2,
      fetchReply: true,
    });

    const latency = reply.createdTimestamp - interaction.createdTimestamp;
    const ws      = client.ws.ping;

    const color = ws < 100 ? "🟢" : ws < 200 ? "🟡" : "🔴";

    const container = new ContainerBuilder()
      .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 🏓 Pong!"))
      .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `${color} **Latência do Bot:** \`${latency}ms\`\n` +
          `⚡ **Latência da API:** \`${ws}ms\``
        )
      );

    setTimeout(() => {
      interaction.editReply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }, 800);
  },
};
