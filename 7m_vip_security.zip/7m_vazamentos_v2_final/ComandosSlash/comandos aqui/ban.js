const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require("discord.js");

module.exports = {
  name: "ban",
  description: "Bane um usuário do servidor.",
  type: ApplicationCommandType.ChatInput,
  options: [
    { name: "usuario", description: "O usuário que será banido.", type: ApplicationCommandOptionType.User, required: true },
    { name: "motivo",  description: "O motivo do banimento.",    type: ApplicationCommandOptionType.String, required: false },
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
      return interaction.reply({
        components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Você não tem permissão para banir membros."))],
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      });
    }

    const user   = interaction.options.getUser("usuario");
    const reason = interaction.options.getString("motivo") || "Nenhum motivo informado.";
    const member = interaction.guild.members.cache.get(user.id);

    if (!member) return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Usuário não encontrado no servidor."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    if (!member.bannable) return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Eu não posso banir este usuário."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });

    await member.ban({ reason: `Banido por ${interaction.user.tag}: ${reason}` });

    const container = new ContainerBuilder()
      .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 🚫 Usuário Banido"))
      .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `👤 **Usuário:** ${user.tag} (\`${user.id}\`)\n` +
          `👮 **Autor:** ${interaction.user.tag}\n` +
          `📝 **Motivo:** ${reason}`
        )
      );

    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
