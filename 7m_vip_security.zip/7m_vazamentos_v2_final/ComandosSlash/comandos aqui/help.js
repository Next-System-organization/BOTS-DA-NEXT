const {
  ApplicationCommandType,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require("discord.js");

module.exports = {
  name: "help",
  description: "Veja todos os comandos disponíveis no bot.",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    const container = new ContainerBuilder()
      .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 🛡️ Comandos do Bot Anti-Raid"))
      .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          "**🛡️ Segurança**\n" +
          "`/antiraid` — Painel de configuração do Anti-Raid.\n\n" +
          "**👮 Administração**\n" +
          "`/ban` — Bane um usuário.\n" +
          "`/kick` — Expulsa um usuário.\n" +
          "`/mute` — Silencia um usuário.\n" +
          "`/unban` — Desbane um usuário.\n" +
          "`/clear` — Limpa mensagens do canal.\n\n" +
          "**📊 Outros**\n" +
          "`/ping` — Veja a latência do bot.\n" +
          "`/help` — Mostra esta mensagem."
        )
      )
      .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent("-# Use os comandos com responsabilidade!")
      );

    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
