const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require("discord.js");

module.exports = {
  name: "clear",
  description: "Limpa mensagens do canal.",
  type: ApplicationCommandType.ChatInput,
  options: [
    { name: "quantidade", description: "Quantidade de mensagens (máx 100).", type: ApplicationCommandOptionType.Integer, required: true, min_value: 1, max_value: 100 },
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Você não tem permissão para limpar mensagens."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    }

    const amount = interaction.options.getInteger("quantidade");

    try {
      const deleted = await interaction.channel.bulkDelete(amount, true);

      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 🧹 Limpeza de Chat"))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`✅ **${deleted.size}** mensagem(ns) removida(s) com sucesso.`)
        );

      await interaction.reply({ components: [container], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    } catch {
      await interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Erro ao limpar mensagens. Mensagens com mais de 14 dias não podem ser apagadas em massa."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    }
  },
};
