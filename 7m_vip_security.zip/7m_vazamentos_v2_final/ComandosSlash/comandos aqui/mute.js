const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require("discord.js");

module.exports = {
  name: "mute",
  description: "Silencia um usuário por um determinado tempo.",
  type: ApplicationCommandType.ChatInput,
  options: [
    { name: "usuario", description: "O usuário que será silenciado.", type: ApplicationCommandOptionType.User,   required: true },
    { name: "tempo",   description: "Tempo de silêncio (ex: 10m, 1h, 1d).", type: ApplicationCommandOptionType.String, required: true },
    { name: "motivo",  description: "O motivo do silêncio.",           type: ApplicationCommandOptionType.String, required: false },
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Você não tem permissão para silenciar membros."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    }

    const user    = interaction.options.getUser("usuario");
    const timeStr = interaction.options.getString("tempo");
    const reason  = interaction.options.getString("motivo") || "Nenhum motivo informado.";
    const member  = interaction.guild.members.cache.get(user.id);

    if (!member)            return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Usuário não encontrado."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    if (!member.moderatable) return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Eu não posso silenciar este usuário."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });

    const match = timeStr.match(/^(\d+)([smhd])$/);
    if (!match) return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Formato inválido! Use: `10s`, `5m`, `1h`, `1d`."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });

    const value = parseInt(match[1]);
    const unit  = match[2];
    const multipliers = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };
    const timeMs = value * multipliers[unit];

    if (timeMs > 28 * 86_400_000) return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ O tempo máximo é de **28 dias**."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });

    await member.timeout(timeMs, `Silenciado por ${interaction.user.tag}: ${reason}`);

    const container = new ContainerBuilder()
      .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 🔇 Usuário Silenciado"))
      .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `👤 **Usuário:** ${user.tag} (\`${user.id}\`)\n` +
          `⏳ **Tempo:** ${timeStr}\n` +
          `👮 **Autor:** ${interaction.user.tag}\n` +
          `📝 **Motivo:** ${reason}`
        )
      );

    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  },
};
