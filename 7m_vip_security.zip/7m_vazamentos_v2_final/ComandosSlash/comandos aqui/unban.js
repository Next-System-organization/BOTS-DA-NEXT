const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require("discord.js");

module.exports = {
  name: "unban",
  description: "Desbane um usuário do servidor.",
  type: ApplicationCommandType.ChatInput,
  options: [
    { name: "id",     description: "O ID do usuário que será desbanido.", type: ApplicationCommandOptionType.String, required: true },
    { name: "motivo", description: "O motivo do desbanimento.",           type: ApplicationCommandOptionType.String, required: false },
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
      return interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Você não tem permissão para desbanir membros."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    }

    const userId = interaction.options.getString("id");
    const reason = interaction.options.getString("motivo") || "Nenhum motivo informado.";

    try {
      await interaction.guild.members.unban(userId, `Desbanido por ${interaction.user.tag}: ${reason}`);

      const container = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent("# 🔓 Usuário Desbanido"))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `👤 **ID do Usuário:** \`${userId}\`\n` +
            `👮 **Autor:** ${interaction.user.tag}\n` +
            `📝 **Motivo:** ${reason}`
          )
        );

      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
    } catch {
      await interaction.reply({ components: [new ContainerBuilder().addTextDisplayComponents(new TextDisplayBuilder().setContent("❌ Não foi possível desbanir. Verifique o ID ou se o usuário está banido."))], flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
    }
  },
};
