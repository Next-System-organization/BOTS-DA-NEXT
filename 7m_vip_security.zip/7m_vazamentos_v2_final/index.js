const { Client, GatewayIntentBits, Collection, ActivityType } = require("discord.js");
const https = require("https");
const config = require("./config.json");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildBans,
  ]
});

client.slashCommands = new Collection();
client.config = config;

require("./Handler/events.js").run(client);
require("./Handler/slash.js").run(client);

// Atualizar bio via API do Discord
async function updateBio(token) {
  const bio = "**By: fantasma_darklegion**\n***https://discord.gg/7mvazamentos***";
  const body = JSON.stringify({ description: bio });

  return new Promise((resolve) => {
    const req = https.request(
      {
        hostname: "discord.com",
        path: "/api/v10/applications/@me",
        method: "PATCH",
        headers: {
          "Authorization": `Bot ${token}`,
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(body),
        },
      },
      (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          if (res.statusCode === 200) {
            console.log("✅ Bio atualizada com sucesso!");
          } else {
            console.error(`❌ Erro ao atualizar bio (${res.statusCode}):`, data);
          }
          resolve();
        });
      }
    );
    req.on("error", (e) => { console.error("❌ Erro na requisição da bio:", e.message); resolve(); });
    req.write(body);
    req.end();
  });
}

client.once("ready", async () => {
  console.log(`✅ Bot online como ${client.user.tag}`);

  // Definir status
  client.user.setPresence({
    activities: [{ name: "By: fantasma_darklegion", type: ActivityType.Custom }],
    status: "online",
  });
  console.log("✅ Status definido: By: fantasma_darklegion");

  // Atualizar bio
  await updateBio(config.token);
});

client.login(config.token).catch((err) => {
  console.error(`Erro ao fazer login: ${err.message}`);
});

process.on("uncaughtException", (error) => {
  console.log(`🚫 Erro Detectado:\n\n${error.stack}`);
});

process.on("uncaughtExceptionMonitor", (error) => {
  console.log(`🚫 Erro Detectado:\n\n${error.stack}`);
});
