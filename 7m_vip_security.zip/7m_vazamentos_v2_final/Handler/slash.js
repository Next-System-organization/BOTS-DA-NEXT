const fs = require("fs");
const path = require("path");

module.exports = {
  run: (client) => {
    const slashArray = [];
    const commandsPath = path.join(__dirname, '../ComandosSlash');
    
    const categories = fs.readdirSync(commandsPath);

    for (const category of categories) {
      const categoryPath = path.join(commandsPath, category);
      if (fs.lstatSync(categoryPath).isDirectory()) {
        const commandFiles = fs.readdirSync(categoryPath).filter(file => file.endsWith('.js'));
        
        for (const file of commandFiles) {
          const command = require(`../ComandosSlash/${category}/${file}`);
          if (command.name) {
            client.slashCommands.set(command.name, command);
            slashArray.push(command);
            console.log(`Comando Slash carregado: ${command.name}`);
          }
        }
      }
    }

    client.on("ready", async () => {
      try {
        await client.application.commands.set(slashArray);
        console.log("Comandos Slash registrados globalmente!");
      } catch (error) {
        console.error("Erro ao registrar comandos Slash:", error);
      }
    });
  }
};
