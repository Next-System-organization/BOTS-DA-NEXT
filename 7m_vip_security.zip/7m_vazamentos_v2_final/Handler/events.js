const fs   = require("fs");
const path = require("path");

module.exports = {
  run: (client) => {
    const eventsPath  = path.join(__dirname, "../Eventos");
    const eventFiles  = fs.readdirSync(eventsPath).filter(f => f.endsWith(".js"));

    for (const file of eventFiles) {
      const exported = require(`../Eventos/${file}`);

      // Suporta tanto module.exports = { name, run } quanto arrays de eventos
      const events = Array.isArray(exported) ? exported : [exported];

      for (const event of events) {
        if (!event.name || !event.run) continue;

        if (event.once) {
          client.once(event.name, (...args) => event.run(...args, client));
        } else {
          client.on(event.name, (...args) => event.run(...args, client));
        }

        console.log(`Evento carregado: ${event.name} (${file})`);
      }
    }
  },
};
