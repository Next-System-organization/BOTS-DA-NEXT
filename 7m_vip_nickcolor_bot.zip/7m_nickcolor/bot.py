import discord
from discord.ext import commands
from discord import app_commands
import json
import os
from typing import Optional

# ─────────────────────────────────────────────
#  CONFIGURAÇÕES GERAIS
# ─────────────────────────────────────────────
TOKEN = "SEU_TOKEN_AQUI"
CONFIG_FILE = "config.json"

# Cores disponíveis: (nome, hex, emoji)
CORES = [
    ("Vermelho",      0xE74C3C, "🔴"),
    ("Laranja",       0xE67E22, "🟠"),
    ("Amarelo",       0xF1C40F, "🟡"),
    ("Verde",         0x2ECC71, "🟢"),
    ("Azul",          0x3498DB, "🔵"),
    ("Roxo",          0x9B59B6, "🟣"),
    ("Rosa",          0xFF6EC7, "🩷"),
    ("Branco",        0xFFFFFF, "⚪"),
    ("Ciano",         0x00FFFF, "🩵"),
    ("Magenta",       0xFF00FF, "💜"),
    ("Dourado",       0xFFD700, "🌟"),
    ("Azul Claro",    0x87CEEB, "💠"),
    ("Salmão",        0xFF8C8C, "🌸"),
    ("Verde Escuro",  0x1A7A4A, "🌿"),
    ("Marrom",        0xA0522D, "🟤"),
    ("Preto",         0x010101, "⚫"),
]

# ─────────────────────────────────────────────
#  PERSISTÊNCIA DE CONFIG
# ─────────────────────────────────────────────
def carregar_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}

def salvar_config(data):
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=4)

# ─────────────────────────────────────────────
#  BOT SETUP
# ─────────────────────────────────────────────
intents = discord.Intents.default()
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

# ─────────────────────────────────────────────
#  VIEWS PERSISTENTES
# ─────────────────────────────────────────────
class SelectCor(discord.ui.Select):
    def __init__(self, pagina: int = 0):
        self.pagina = pagina
        inicio = pagina * 8
        fim = min(inicio + 8, len(CORES))
        opcoes = []
        for nome, _, emoji in CORES[inicio:fim]:
            opcoes.append(discord.SelectOption(
                label=nome,
                value=nome,
                emoji=emoji,
                description=f"Aplicar a cor {nome} no seu apelido"
            ))
        super().__init__(
            placeholder="🎨 Escolha sua cor aqui...",
            min_values=1,
            max_values=1,
            options=opcoes,
            custom_id=f"select_cor_p{pagina}"
        )

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        nome_cor = self.values[0]
        guild = interaction.guild
        member = interaction.user

        # Busca o cargo da cor escolhida
        cargo_alvo = discord.utils.get(guild.roles, name=f"🎨 {nome_cor}")
        if not cargo_alvo:
            return await interaction.followup.send(
                "❌ Cargo não encontrado! Use `/setup` novamente.",
                ephemeral=True
            )

        # Cargos de cor do membro
        cargos_cor = [r for r in member.roles if r.name.startswith("🎨 ")]

        if cargo_alvo in member.roles:
            # Toggle: remove se já tem
            await member.remove_roles(cargo_alvo)
            embed = discord.Embed(
                description=f"✅ Cor **{nome_cor}** removida do seu perfil!",
                color=0x2b2d31
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
        else:
            # Remove outras cores e adiciona a nova
            if cargos_cor:
                await member.remove_roles(*cargos_cor)
            await member.add_roles(cargo_alvo)
            hex_cor = discord.utils.get(guild.roles, name=f"🎨 {nome_cor}").color.value
            embed = discord.Embed(
                description=f"✅ Cor **{nome_cor}** aplicada no seu apelido!",
                color=hex_cor
            )
            await interaction.followup.send(embed=embed, ephemeral=True)


class BotaoRemoverCor(discord.ui.Button):
    def __init__(self):
        super().__init__(
            label="Remover Cor",
            style=discord.ButtonStyle.danger,
            emoji="🗑️",
            custom_id="btn_remover_cor"
        )

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        member = interaction.user
        cargos_cor = [r for r in member.roles if r.name.startswith("🎨 ")]
        if cargos_cor:
            await member.remove_roles(*cargos_cor)
            embed = discord.Embed(
                description="✅ Sua cor foi removida com sucesso!",
                color=0x2b2d31
            )
        else:
            embed = discord.Embed(
                description="⚠️ Você não possui nenhuma cor ativa.",
                color=0xFFCC00
            )
        await interaction.followup.send(embed=embed, ephemeral=True)


class BotaoPagina(discord.ui.Button):
    def __init__(self, pagina: int, label: str, emoji: str, total_pags: int):
        super().__init__(
            label=label,
            emoji=emoji,
            style=discord.ButtonStyle.secondary,
            custom_id=f"btn_pag_{pagina}",
            disabled=(pagina < 0 or pagina >= total_pags)
        )
        self.pagina_destino = pagina

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            view=ViewNickColor(pagina=self.pagina_destino)
        )


class ViewNickColor(discord.ui.View):
    def __init__(self, pagina: int = 0):
        super().__init__(timeout=None)
        total_pags = (len(CORES) + 7) // 8  # ceil division

        # Select de cores da página atual
        self.add_item(SelectCor(pagina=pagina))

        # Botões de navegação
        self.add_item(BotaoPagina(pagina - 1, "Anterior", "◀️", total_pags))
        self.add_item(BotaoPagina(pagina + 1, "Próxima", "▶️", total_pags))

        # Botão remover
        self.add_item(BotaoRemoverCor())


# ─────────────────────────────────────────────
#  FUNÇÃO: CRIAR EMBED PRINCIPAL
# ─────────────────────────────────────────────
def criar_embed_nickcolor():
    embed = discord.Embed(
        title="<a:star:1> 7M VAZAMENTOS — NICK COLOR",
        description=(
            "─────────────────────────────\n"
            "🎨 **Personalize a cor do seu apelido** no servidor!\n"
            "Selecione a cor desejada no menu abaixo.\n"
            "─────────────────────────────\n\n"
            "**Cores Disponíveis:**\n"
        ),
        color=0x9B59B6
    )

    # Lista de cores em colunas
    col1 = ""
    col2 = ""
    mid = (len(CORES) + 1) // 2
    for i, (nome, hex_val, emoji) in enumerate(CORES):
        linha = f"{emoji} **{nome}**\n"
        if i < mid:
            col1 += linha
        else:
            col2 += linha

    embed.add_field(name="​", value=col1, inline=True)
    embed.add_field(name="​", value=col2, inline=True)

    embed.add_field(
        name="─────────────────────────────",
        value=(
            "📌 **Como usar:**\n"
            "> Clique no menu e escolha sua cor.\n"
            "> Clique novamente para **remover** a cor.\n"
            "> Use o botão 🗑️ para remover qualquer cor ativa.\n\n"
            "⚠️ *Apenas uma cor pode estar ativa por vez.*"
        ),
        inline=False
    )

    embed.set_footer(text="7M Vazamentos • Nick Color System V2", icon_url=None)
    embed.set_image(url="https://i.imgur.com/HRxHWZt.gif")  # placeholder gif
    return embed


# ─────────────────────────────────────────────
#  SLASH: /setup  (somente ADM)
# ─────────────────────────────────────────────
@tree.command(name="setup", description="[ADM] Configura o sistema de Nick Color no canal atual")
@app_commands.checks.has_permissions(administrator=True)
async def setup(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild

    # ── Cria cargos de cor ──
    msg_status = await interaction.followup.send(
        "⏳ Criando cargos de cor... Aguarde.", ephemeral=True
    )

    cargos_criados = 0
    cargos_existentes = 0
    for nome, hex_val, _ in CORES:
        nome_cargo = f"🎨 {nome}"
        existente = discord.utils.get(guild.roles, name=nome_cargo)
        if not existente:
            await guild.create_role(
                name=nome_cargo,
                color=discord.Color(hex_val),
                reason="Setup Nick Color 7M Vazamentos"
            )
            cargos_criados += 1
        else:
            cargos_existentes += 1

    # ── Envia embed no canal ──
    embed = criar_embed_nickcolor()
    view = ViewNickColor(pagina=0)
    msg = await interaction.channel.send(embed=embed, view=view)

    # ── Salva config ──
    cfg = carregar_config()
    guild_id = str(guild.id)
    if guild_id not in cfg:
        cfg[guild_id] = {}
    cfg[guild_id]["msg_id"] = msg.id
    cfg[guild_id]["canal_id"] = interaction.channel.id
    salvar_config(cfg)

    await interaction.edit_original_response(
        content=(
            f"✅ **Setup concluído!**\n"
            f"🆕 Cargos criados: `{cargos_criados}`\n"
            f"♻️ Cargos já existentes: `{cargos_existentes}`\n"
            f"📨 Mensagem enviada em {interaction.channel.mention}"
        )
    )


# ─────────────────────────────────────────────
#  SLASH: /configurar  (somente ADM)
# ─────────────────────────────────────────────
@tree.command(name="configurar", description="[ADM] Painel de configurações do Nick Color")
@app_commands.checks.has_permissions(administrator=True)
async def configurar(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)

    cfg = carregar_config()
    guild_id = str(interaction.guild.id)
    dados = cfg.get(guild_id, {})

    canal_id = dados.get("canal_id")
    msg_id = dados.get("msg_id")
    canal_txt = f"<#{canal_id}>" if canal_id else "❌ Não configurado"
    msg_txt = f"`{msg_id}`" if msg_id else "❌ Não enviada"

    # Conta cargos de cor existentes
    cargos_cor = [r for r in interaction.guild.roles if r.name.startswith("🎨 ")]
    total_cargos = len(cargos_cor)

    # Conta membros com cor
    membros_com_cor = sum(
        1 for m in interaction.guild.members
        if any(r.name.startswith("🎨 ") for r in m.roles)
    )

    embed = discord.Embed(
        title="⚙️ Configurações — Nick Color 7M",
        color=0x9B59B6
    )
    embed.add_field(name="📍 Canal Configurado", value=canal_txt, inline=True)
    embed.add_field(name="💬 ID da Mensagem", value=msg_txt, inline=True)
    embed.add_field(name="​", value="​", inline=False)
    embed.add_field(name="🎨 Cargos de Cor", value=f"`{total_cargos}/{len(CORES)}`", inline=True)
    embed.add_field(name="👥 Membros com Cor", value=f"`{membros_com_cor}`", inline=True)
    embed.add_field(
        name="📋 Comandos Disponíveis",
        value=(
            "`/setup` — Envia o painel de cores no canal\n"
            "`/configurar` — Exibe este painel\n"
            "`/nickcolor_reset @membro` — Remove a cor de um membro\n"
            "`/nickcolor_listar` — Lista membros com cor ativa"
        ),
        inline=False
    )
    embed.set_footer(text="7M Vazamentos • Apenas Administradores")

    view = ViewConfigurar()
    await interaction.followup.send(embed=embed, view=view, ephemeral=True)


# ─────────────────────────────────────────────
#  VIEW DE CONFIGURAÇÕES
# ─────────────────────────────────────────────
class ViewConfigurar(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=120)

    @discord.ui.button(label="Reenviar Painel", style=discord.ButtonStyle.primary, emoji="🔄")
    async def reenviar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Sem permissão.", ephemeral=True)
        embed = criar_embed_nickcolor()
        view = ViewNickColor(pagina=0)
        msg = await interaction.channel.send(embed=embed, view=view)
        cfg = carregar_config()
        guild_id = str(interaction.guild.id)
        if guild_id not in cfg:
            cfg[guild_id] = {}
        cfg[guild_id]["msg_id"] = msg.id
        cfg[guild_id]["canal_id"] = interaction.channel.id
        salvar_config(cfg)
        await interaction.response.send_message(
            f"✅ Painel reenviado em {interaction.channel.mention}!", ephemeral=True
        )

    @discord.ui.button(label="Deletar Todos os Cargos de Cor", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def deletar_cargos(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Sem permissão.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        cargos = [r for r in interaction.guild.roles if r.name.startswith("🎨 ")]
        for cargo in cargos:
            try:
                await cargo.delete(reason="Reset Nick Color")
            except Exception:
                pass
        await interaction.followup.send(
            f"✅ `{len(cargos)}` cargos de cor deletados!", ephemeral=True
        )


# ─────────────────────────────────────────────
#  SLASH: /nickcolor_reset  (somente ADM)
# ─────────────────────────────────────────────
@tree.command(name="nickcolor_reset", description="[ADM] Remove a cor de um membro específico")
@app_commands.checks.has_permissions(administrator=True)
@app_commands.describe(membro="Membro que terá a cor removida")
async def nickcolor_reset(interaction: discord.Interaction, membro: discord.Member):
    await interaction.response.defer(ephemeral=True)
    cargos_cor = [r for r in membro.roles if r.name.startswith("🎨 ")]
    if cargos_cor:
        await membro.remove_roles(*cargos_cor)
        await interaction.followup.send(
            f"✅ Cor removida de **{membro.display_name}** com sucesso!", ephemeral=True
        )
    else:
        await interaction.followup.send(
            f"⚠️ **{membro.display_name}** não possui cor ativa.", ephemeral=True
        )


# ─────────────────────────────────────────────
#  SLASH: /nickcolor_listar  (somente ADM)
# ─────────────────────────────────────────────
@tree.command(name="nickcolor_listar", description="[ADM] Lista todos os membros com cor ativa")
@app_commands.checks.has_permissions(administrator=True)
async def nickcolor_listar(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild

    linhas = []
    for member in guild.members:
        cargos_cor = [r for r in member.roles if r.name.startswith("🎨 ")]
        if cargos_cor:
            cor = cargos_cor[0].name.replace("🎨 ", "")
            linhas.append(f"• **{member.display_name}** → {cor}")

    if not linhas:
        return await interaction.followup.send(
            "Nenhum membro com cor ativa no momento.", ephemeral=True
        )

    # Divide em chunks de 20
    chunks = [linhas[i:i+20] for i in range(0, len(linhas), 20)]
    embeds = []
    for i, chunk in enumerate(chunks):
        e = discord.Embed(
            title=f"🎨 Membros com Cor Ativa ({len(linhas)} total) — Pág. {i+1}/{len(chunks)}",
            description="\n".join(chunk),
            color=0x9B59B6
        )
        embeds.append(e)

    await interaction.followup.send(embeds=embeds[:10], ephemeral=True)


# ─────────────────────────────────────────────
#  TRATAMENTO DE ERROS
# ─────────────────────────────────────────────
@setup.error
@configurar.error
@nickcolor_reset.error
@nickcolor_listar.error
async def erro_permissao(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        embed = discord.Embed(
            description="❌ **Sem permissão!** Apenas **Administradores** podem usar este comando.",
            color=0xE74C3C
        )
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message(embed=embed, ephemeral=True)


# ─────────────────────────────────────────────
#  EVENTOS
# ─────────────────────────────────────────────
@bot.event
async def on_ready():
    # Adiciona views persistentes
    total_pags = (len(CORES) + 7) // 8
    for p in range(total_pags):
        bot.add_view(ViewNickColor(pagina=p))

    try:
        synced = await tree.sync()
        print(f"✅ {len(synced)} comando(s) sincronizado(s)")
    except Exception as e:
        print(f"❌ Erro ao sincronizar: {e}")

    print(f"🤖 Bot online: {bot.user} | Servidores: {len(bot.guilds)}")


# ─────────────────────────────────────────────
#  INICIAR
# ─────────────────────────────────────────────
if __name__ == "__main__":
    bot.run(TOKEN)
