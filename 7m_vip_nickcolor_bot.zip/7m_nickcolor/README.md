# 🎨 7M VAZAMENTOS — NICK COLOR BOT V2

Bot de personalização de cor de apelido para o servidor 7M Vazamentos.

---

## 📦 Instalação

### 1. Instalar dependências
```bash
pip install -r requirements.txt
```

### 2. Configurar o token
Abra o arquivo `bot.py` e substitua na linha:
```python
TOKEN = "SEU_TOKEN_AQUI"
```
pelo token do seu bot no [Discord Developer Portal](https://discord.com/developers/applications).

### 3. Permissões necessárias no bot
No Developer Portal, em **Bot > Privileged Gateway Intents**, ative:
- ✅ `SERVER MEMBERS INTENT`

### 4. Permissões necessárias no servidor
O bot precisa dos seguintes cargos/permissões:
- ✅ Gerenciar Cargos
- ✅ Enviar Mensagens
- ✅ Incorporar Links
- ✅ Ler Histórico de Mensagens

> ⚠️ O cargo do bot deve estar **acima** dos cargos de cor na hierarquia!

### 5. Iniciar o bot
```bash
python bot.py
```

---

## 🚀 Comandos

| Comando | Permissão | Descrição |
|--------|-----------|-----------|
| `/setup` | 👑 ADM | Cria os cargos e envia o painel de cores no canal |
| `/configurar` | 👑 ADM | Painel de configurações e estatísticas |
| `/nickcolor_reset @membro` | 👑 ADM | Remove a cor de um membro específico |
| `/nickcolor_listar` | 👑 ADM | Lista todos os membros com cor ativa |

---

## 🎨 Cores Disponíveis (16 cores)

🔴 Vermelho · 🟠 Laranja · 🟡 Amarelo · 🟢 Verde
🔵 Azul · 🟣 Roxo · 🩷 Rosa · ⚪ Branco
🩵 Ciano · 💜 Magenta · 🌟 Dourado · 💠 Azul Claro
🌸 Salmão · 🌿 Verde Escuro · 🟤 Marrom · ⚫ Preto

---

## ⚙️ Como funciona

1. Admin usa `/setup` no canal desejado
2. O bot cria automaticamente os 16 cargos de cor
3. O painel com menu dropdown é enviado
4. Membros selecionam a cor no menu
5. Clicar na mesma cor **remove** ela (toggle)
6. Botão 🗑️ remove qualquer cor ativa

---

## 📁 Arquivos

```
7m_nickcolor/
├── bot.py           # Código principal
├── config.json      # Gerado automaticamente
├── requirements.txt # Dependências
└── README.md        # Este arquivo
```

---

*7M Vazamentos • Nick Color System FULL COMP V2*
