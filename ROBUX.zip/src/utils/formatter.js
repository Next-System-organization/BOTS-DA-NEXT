function formatNumber(n) {
  return Number(n).toLocaleString('pt-BR');
}

function formatRobux(n) {
  return `R$ ${formatNumber(n)}`;
}

function formatDate(date) {
  return new Date(date).toLocaleString('pt-BR', {
    timeZone: 'America/Sao_Paulo',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  if (d > 0) return `${d}d ${h % 24}h`;
  if (h > 0) return `${h}h ${m % 60}m`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

function formatUptime(ms) {
  return formatDuration(ms);
}

function truncate(str, max = 100) {
  return str.length > max ? str.slice(0, max - 3) + '...' : str;
}

function stars(rating) {
  const full = Math.round(rating);
  return '⭐'.repeat(Math.max(0, Math.min(5, full)));
}

function progressBar(current, total, size = 10) {
  const pct = Math.min(1, current / total);
  const filled = Math.round(pct * size);
  return '█'.repeat(filled) + '░'.repeat(size - filled);
}

function goalEmoji(invites) {
  if (invites >= 100) return '💎';
  if (invites >= 50)  return '🔮';
  if (invites >= 35)  return '🥇';
  if (invites >= 20)  return '🥈';
  if (invites >= 10)  return '🥉';
  return '🔰';
}

function rankEmoji(position) {
  if (position === 1) return '👑';
  if (position === 2) return '🥈';
  if (position === 3) return '🥉';
  return `#${position}`;
}

module.exports = { formatNumber, formatRobux, formatDate, formatDuration, formatUptime, truncate, stars, progressBar, goalEmoji, rankEmoji };
