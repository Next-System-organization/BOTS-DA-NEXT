function hexToInt(hex) {
  const clean = hex.replace(/^#/, '').trim();
  const val = parseInt(clean, 16);
  if (isNaN(val)) throw new Error('Cor inválida. Use formato hex: #00ff87 ou 00ff87');
  return val;
}

function intToHex(n) {
  return '#' + n.toString(16).padStart(6, '0').toUpperCase();
}

function validateHex(hex) {
  const clean = hex.replace(/^#/, '').trim();
  return /^[0-9a-fA-F]{6}$/.test(clean);
}

module.exports = { hexToInt, intToHex, validateHex };
