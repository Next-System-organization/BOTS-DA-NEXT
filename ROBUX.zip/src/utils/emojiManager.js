const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const config = require('../config/loader');
const logger = require('./logger');

const CACHE_FILE = path.join(process.cwd(), 'data', 'custom_emojis.json');

const W = `fill="white"`;
const svg = (inner) =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="128" height="128">${inner}</svg>`;

const SVG_ICONS = {
  rb_robux:   svg(`<path ${W} d="M12 2l-5.5 6h11L12 2zm-7 7l3 9h8l3-9H5zm7 7.5a1.5 1.5 0 110-3 1.5 1.5 0 010 3z"/>`),
  rb_invite:  svg(`<path ${W} d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>`),
  rb_reward:  svg(`<path ${W} d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>`),
  rb_stock:   svg(`<path ${W} d="M12 3L2 8l10 5 10-5-10-5zM2 8v8l10 5V13L2 8zm18 0L12 13v8l10-5V8z"/>`),
  rb_admin:   svg(`<path ${W} d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>`),
  rb_success: svg(`<path ${W} d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5l-4-4 1.41-1.41L10 13.67l6.59-6.59L18 8.5l-8 8z"/>`),
  rb_error:   svg(`<path ${W} d="M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm4.3 14.3c-.39.39-1.02.39-1.41 0L12 13.41 9.11 16.3c-.39.39-1.02.39-1.41 0-.39-.39-.39-1.02 0-1.41L10.59 12 7.7 9.11c-.39-.39-.39-1.02 0-1.41.39-.39 1.02-.39 1.41 0L12 10.59l2.89-2.89c.39-.39 1.02-.39 1.41 0 .39.39.39 1.02 0 1.41L13.41 12l2.89 2.89c.38.38.38 1.02 0 1.41z"/>`),
  rb_warn:    svg(`<path ${W} d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>`),
  rb_logs:    svg(`<path ${W} d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 14H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>`),
  rb_review:  svg(`<path ${W} d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27z"/>`),
  rb_user:    svg(`<path ${W} d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>`),
  rb_crown:   svg(`<path ${W} d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .55-.45 1-1 1H6c-.55 0-1-.45-1-1v-1h14v1z"/>`),
  rb_fire:    svg(`<path ${W} d="M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67zM11.71 19c-1.78 0-3.22-1.4-3.22-3.14 0-1.62 1.05-2.76 2.81-3.12 1.77-.36 3.6-1.21 4.62-2.58.39 1.29.59 2.65.59 4.04 0 2.65-2.15 4.8-4.8 4.8z"/>`),
  rb_chart:   svg(`<path ${W} d="M5 9.2h3V19H5zm5.6-4.2h2.8v14h-2.8zm5.6 8h2.8v6h-2.8z"/>`),
  rb_shield:  svg(`<path ${W} d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>`),
  rb_arrow:   svg(`<path ${W} d="M8 5v14l11-7z"/>`),
};

const EMOJI_MAP = {
  robux:   'rb_robux',
  invite:  'rb_invite',
  reward:  'rb_reward',
  stock:   'rb_stock',
  admin:   'rb_admin',
  success: 'rb_success',
  error:   'rb_error',
  warning: 'rb_warn',
  logs:    'rb_logs',
  review:  'rb_review',
  user:    'rb_user',
  crown:   'rb_crown',
  fire:    'rb_fire',
  chart:   'rb_chart',
  shield:  'rb_shield',
  arrow:   'rb_arrow',
};

function loadCache() {
  try {
    if (fs.existsSync(CACHE_FILE)) {
      return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
    }
  } catch {}
  return {};
}

function saveCache(data) {
  fs.writeFileSync(CACHE_FILE, JSON.stringify(data, null, 2));
}

async function svgToPng(svgString) {
  return sharp(Buffer.from(svgString))
    .resize(128, 128)
    .png()
    .toBuffer();
}

async function fetchExistingEmojis(rest, clientId) {
  try {
    const res = await rest.get(Routes.applicationEmojis(clientId));
    return res.items || res || [];
  } catch (err) {
    logger.warn('Não foi possível listar application emojis:', err.message);
    return [];
  }
}

async function uploadEmoji(rest, clientId, name, pngBuffer) {
  const base64 = pngBuffer.toString('base64');
  const image = `data:image/png;base64,${base64}`;
  const result = await rest.post(Routes.applicationEmojis(clientId), {
    body: { name, image },
  });
  return result;
}

async function deleteEmoji(rest, clientId, emojiId) {
  try {
    await rest.delete(Routes.applicationEmoji(clientId, emojiId));
  } catch {}
}

function buildEmojiString(name, id) {
  return `<:${name}:${id}>`;
}

async function setup(client) {
  const cfg = config.get();
  const cache = loadCache();

  if (!cfg.clientId || cfg.clientId === 'YOUR_CLIENT_ID_HERE') {
    logger.warn('clientId não configurado — emojis personalizados ignorados.');
    return;
  }

  const rest = new REST({ version: '10' }).setToken(cfg.token);
  logger.system('Verificando emojis personalizados...');

  let existing;
  try {
    existing = await fetchExistingEmojis(rest, cfg.clientId);
  } catch (err) {
    logger.error('Erro ao buscar emojis:', err.message);
    return;
  }

  const existingMap = {};
  for (const e of existing) existingMap[e.name] = e;

  const emojiIds = { ...cache };
  const toUpload = Object.entries(SVG_ICONS).filter(([name]) => !existingMap[name] || !cache[name]);
  const total = toUpload.length;

  if (total === 0) {
    logger.success('Todos os emojis personalizados já estão carregados.');
    applyToConfig(emojiIds, cfg);
    return;
  }

  logger.system(`Fazendo upload de ${total} emoji(s) personalizado(s)...`);

  let done = 0;
  for (const [name, svgStr] of toUpload) {
    try {
      if (existingMap[name]) {
        emojiIds[name] = existingMap[name].id;
        done++;
        logger.loader(done, total, `Reutilizando ${name}`);
        continue;
      }

      const png = await svgToPng(svgStr);
      const uploaded = await uploadEmoji(rest, cfg.clientId, name, png);
      emojiIds[name] = uploaded.id;
      done++;
      logger.loader(done, total, `Enviado: ${name}`);

      await new Promise(r => setTimeout(r, 350));
    } catch (err) {
      logger.error(`Falha ao enviar ${name}: ${err.message}`);
    }
  }

  saveCache(emojiIds);
  applyToConfig(emojiIds, cfg);
  logger.success('Emojis personalizados configurados com sucesso!');
}

function applyToConfig(emojiIds, cfg) {
  let changed = false;

  for (const [configKey, discordName] of Object.entries(EMOJI_MAP)) {
    const id = emojiIds[discordName];
    if (id) {
      const emojiStr = buildEmojiString(discordName, id);
      if (cfg.appearance.emojis[configKey] !== emojiStr) {
        cfg.appearance.emojis[configKey] = emojiStr;
        changed = true;
      }
    }
  }

  if (changed) {
    config.save(cfg);
    logger.success('Config atualizado com emojis personalizados.');
  }
}

async function reset(client) {
  const cfg = config.get();
  if (!cfg.clientId || cfg.clientId === 'YOUR_CLIENT_ID_HERE') return;

  const rest = new REST({ version: '10' }).setToken(cfg.token);
  const existing = await fetchExistingEmojis(rest, cfg.clientId);

  let deleted = 0;
  for (const e of existing) {
    if (e.name.startsWith('rb_')) {
      await deleteEmoji(rest, cfg.clientId, e.id);
      deleted++;
      await new Promise(r => setTimeout(r, 200));
    }
  }

  if (fs.existsSync(CACHE_FILE)) fs.unlinkSync(CACHE_FILE);
  logger.system(`${deleted} emojis removidos. Execute novamente para recriar.`);
}

module.exports = { setup, reset, EMOJI_MAP, SVG_ICONS };
