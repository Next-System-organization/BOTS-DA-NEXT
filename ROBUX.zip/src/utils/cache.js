class Cache {
  constructor(ttlMs = 60000) {
    this.store = new Map();
    this.ttl = ttlMs;
  }

  set(key, value, ttl) {
    const expires = Date.now() + (ttl || this.ttl);
    this.store.set(key, { value, expires });
  }

  get(key) {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expires) {
      this.store.delete(key);
      return null;
    }
    return entry.value;
  }

  has(key) {
    return this.get(key) !== null;
  }

  delete(key) {
    this.store.delete(key);
  }

  clear() {
    this.store.clear();
  }

  size() {
    return this.store.size;
  }

  cleanup() {
    const now = Date.now();
    for (const [key, entry] of this.store) {
      if (now > entry.expires) this.store.delete(key);
    }
  }
}

const inviteCache = new Cache(300000);
const cooldownCache = new Cache(86400000);
const spamCache = new Cache(30000);
const userCache = new Cache(60000);

setInterval(() => {
  inviteCache.cleanup();
  cooldownCache.cleanup();
  spamCache.cleanup();
  userCache.cleanup();
}, 60000);

module.exports = { Cache, inviteCache, cooldownCache, spamCache, userCache };
