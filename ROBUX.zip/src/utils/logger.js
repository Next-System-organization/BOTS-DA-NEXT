const chalk = require('chalk');

const levels = {
  info:    { label: ' INFO ', color: chalk.bgCyan.black,       text: chalk.cyan },
  success: { label: '  OK  ', color: chalk.bgGreen.black,      text: chalk.green },
  warn:    { label: ' WARN ', color: chalk.bgYellow.black,     text: chalk.yellow },
  error:   { label: ' ERR  ', color: chalk.bgRed.white,        text: chalk.red },
  debug:   { label: ' DBG  ', color: chalk.bgMagenta.black,    text: chalk.magenta },
  system:  { label: ' SYS  ', color: chalk.bgBlue.white,       text: chalk.blue },
  invite:  { label: ' INV  ', color: chalk.bgGreenBright.black,text: chalk.greenBright },
  reward:  { label: ' RWD  ', color: chalk.bgYellowBright.black,text: chalk.yellowBright },
};

function timestamp() {
  return chalk.gray(`[${new Date().toLocaleTimeString('pt-BR', { hour12: false })}]`);
}

function log(level, ...args) {
  const lvl = levels[level] || levels.info;
  const label = lvl.color(lvl.label);
  const msg = args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' ');
  console.log(`${timestamp()} ${label} ${lvl.text(msg)}`);
}

function banner() {
  console.log('');
  console.log(chalk.greenBright('  ██████╗  ██████╗ ██████╗ ██╗   ██╗██╗  ██╗'));
  console.log(chalk.greenBright('  ██╔══██╗██╔═══██╗██╔══██╗██║   ██║╚██╗██╔╝'));
  console.log(chalk.greenBright('  ██████╔╝██║   ██║██████╔╝██║   ██║ ╚███╔╝ '));
  console.log(chalk.greenBright('  ██╔══██╗██║   ██║██╔══██╗██║   ██║ ██╔██╗ '));
  console.log(chalk.greenBright('  ██║  ██║╚██████╔╝██████╔╝╚██████╔╝██╔╝ ██╗'));
  console.log(chalk.greenBright('  ╚═╝  ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝'));
  console.log('');
  console.log(chalk.bold.white('  ') + chalk.bold.greenBright('SISTEMA DE RECOMPENSAS POR INVITES'));
  console.log(chalk.gray('  ') + chalk.gray('Bot Premium para Discord — by Octam'));
  console.log('');
  console.log(chalk.gray('  ─────────────────────────────────────────────'));
  console.log('');
}

function loader(step, total, label) {
  const filled = Math.round((step / total) * 20);
  const bar = chalk.greenBright('█'.repeat(filled)) + chalk.gray('░'.repeat(20 - filled));
  process.stdout.write(`\r  ${bar} ${chalk.white(`${Math.round((step / total) * 100)}%`)} ${chalk.gray(label)}   `);
  if (step === total) process.stdout.write('\n');
}

module.exports = {
  info:    (...a) => log('info', ...a),
  success: (...a) => log('success', ...a),
  warn:    (...a) => log('warn', ...a),
  error:   (...a) => log('error', ...a),
  debug:   (...a) => log('debug', ...a),
  system:  (...a) => log('system', ...a),
  invite:  (...a) => log('invite', ...a),
  reward:  (...a) => log('reward', ...a),
  banner,
  loader,
};
