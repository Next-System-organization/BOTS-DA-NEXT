const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(process.cwd(), 'data', 'config.json');

let config = null;

function load() {
  const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  config = JSON.parse(raw);
  return config;
}

function get() {
  if (!config) load();
  return config;
}

function save(newConfig) {
  config = newConfig;
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(newConfig, null, 2), 'utf8');
}

function reload() {
  config = null;
  return load();
}

function update(path_str, value) {
  const cfg = get();
  const parts = path_str.split('.');
  let obj = cfg;
  for (let i = 0; i < parts.length - 1; i++) {
    if (!obj[parts[i]]) obj[parts[i]] = {};
    obj = obj[parts[i]];
  }
  obj[parts[parts.length - 1]] = value;
  save(cfg);
}

module.exports = { load, get, save, reload, update };
