const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require('discord.js');
const { formatNumber, formatDate, goalEmoji } = require('../utils/formatter');
const config = require('../config/loader');

function buildDeliveryMessage(delivery) {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const link = cfg.link || {};
  const bot = cfg.bot || {};
  const goalIcon = goalEmoji(delivery.invites);

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${em.robux} ${bot.deliveryTitle || 'Entrega Confirmada'} — ${delivery.goalLabel}\n` +
        `${em.arrow} **${bot.deliveryDescription || 'Robux entregues com sucesso!'}**`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `### ${em.user} Destinatário\n` +
        `> **Discord:** <@${delivery.userId}>\n` +
        `> **Roblox:** \`${delivery.robloxNick}\``
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `### ${goalIcon} Meta — ${delivery.goalLabel}\n` +
        `> ${em.invite} **Convites:** \`${delivery.invites}\`\n` +
        `> ${em.robux} **Pagamento:** \`${formatNumber(delivery.robux)} Robux\`\n` +
        `> ${em.stock} **Robux restantes:** \`${formatNumber(delivery.stockAfter)}\``
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `${em.success} **${link.label || 'Acesse o link para receber seus Robux'}:**\n` +
        `> ${link.url || '*Link não configurado*'}\n\n` +
        `${em.shield} *Registrado em ${formatDate(delivery.timestamp)}*`
      )
    );

  if (link.url) {
    container.addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel(link.buttonLabel || '🔗 Acessar Link')
          .setStyle(ButtonStyle.Link)
          .setURL(link.url)
      )
    );
  }

  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

function buildPublicDeliveryLog(delivery) {
  const cfg = config.get();
  const em = cfg.appearance.emojis;

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `${em.success} **Novo resgate registrado!**\n\n` +
        `${em.user} **Usuário:** <@${delivery.userId}>\n` +
        `🎮 **Roblox:** \`${delivery.robloxNick}\`\n` +
        `${em.robux} **Pagamento:** \`${formatNumber(delivery.robux)} Robux\`\n` +
        `${em.stock} **Robux restantes:** \`${formatNumber(delivery.stockAfter)}\`\n` +
        `${em.invite} **Meta:** ${delivery.goalLabel} (${delivery.invites} convites)\n\n` +
        `*${formatDate(delivery.timestamp)}*`
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

module.exports = { buildDeliveryMessage, buildPublicDeliveryLog };
