const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require('discord.js');
const { stars, formatDate, formatNumber } = require('../utils/formatter');
const reviewSystem = require('../systems/reviewSystem');
const config = require('../config/loader');

function buildReviewMessage(review, stats) {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const starsDisplay = stars(review.rating);
  const avgDisplay = stats.average > 0
    ? `${stars(stats.average)} **${stats.average}/5** (${stats.total} avaliações)`
    : 'Primeira avaliação!';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${em.review} Nova Avaliação\n${starsDisplay} **${review.rating}/5**`
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**Avaliador:** <@${review.userId}>\n` +
        `**Comentário:**\n> ${review.comment}\n\n` +
        `**Média atual:** ${avgDisplay}\n` +
        `*${formatDate(review.timestamp)}*`
      )
    );

  return {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

function buildReviewStats() {
  const stats = reviewSystem.getStats();
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const recent = stats.recent || [];

  const recentText = recent.length
    ? recent.map(r => `${stars(r.rating)} **${r.rating}/5** — <@${r.userId}>\n> *"${r.comment.slice(0, 80)}"*`).join('\n\n')
    : '*Nenhuma avaliação ainda.*';

  const avgDisplay = stats.total > 0
    ? `${stars(stats.average)} **${stats.average}/5** — **${stats.total}** avaliações`
    : 'Sem avaliações ainda';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${em.review} Avaliações dos Usuários\n> ${avgDisplay}`
      )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`### Avaliações Recentes\n${recentText}`)
    );

  return {
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

module.exports = { buildReviewMessage, buildReviewStats };
