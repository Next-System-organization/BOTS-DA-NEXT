const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  SeparatorSpacingSize,
  MessageFlags,
} = require('discord.js');
const { formatNumber, progressBar, goalEmoji, stars } = require('../utils/formatter');
const config = require('../config/loader');
const rewardSystem = require('../systems/rewardSystem');
const reviewSystem = require('../systems/reviewSystem');

function buildRewardPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const bot = cfg.bot || {};
  const goals = cfg.goals || [];

  const goalLines = goals.map((g) => {
    const icon = goalEmoji(g.invites);
    return `${icon} **${g.label}** — \`${g.invites} convites\` → **${formatNumber(g.robux)} Robux**`;
  }).join('\n');

  const reviewStats = reviewSystem.getStats();
  const starsDisplay = reviewStats.total > 0
    ? `${stars(reviewStats.average)} **${reviewStats.average}/5** (${reviewStats.total} avaliações)`
    : `Seja o primeiro a avaliar!`;

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# ${em.robux} ${bot.rewardPanelTitle || 'Sistema de Recompensas por Convites'}\n` +
        `${em.fire} **${bot.rewardPanelDescription || 'Convide membros e ganhe Robux de verdade!'}**`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${em.chart} Metas Disponíveis\n${goalLines}`)
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${em.review} Avaliações\n> ${starsDisplay}`)
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `${em.shield} **Sistema 100% legítimo e seguro**\n` +
        `${em.arrow} Clique em **Meus Convites** para ver seu progresso.\n` +
        `${em.arrow} Clique em **Resgatar** quando atingir uma meta.`
      )
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('reward_myinvites').setLabel('Meus Convites').setStyle(ButtonStyle.Primary).setEmoji('📨'),
        new ButtonBuilder().setCustomId('reward_redeem_select').setLabel('Resgatar').setStyle(ButtonStyle.Success).setEmoji('💎'),
        new ButtonBuilder().setCustomId('reward_leaderboard').setLabel('Ranking').setStyle(ButtonStyle.Secondary).setEmoji('👑'),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

function buildUserProgressEmbed(userId) {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const completed = rewardSystem.getCompletedGoals(userId);
  const stats = rewardSystem.getUserValidInvites(userId);
  const nextGoal = rewardSystem.getNextGoal(stats.valid);

  const progressToNext = nextGoal
    ? `${progressBar(stats.valid, nextGoal.invites, 12)} \`${stats.valid}/${nextGoal.invites}\` → **${formatNumber(nextGoal.robux)} Robux**`
    : `${em.crown} **Todas as metas concluídas!**`;

  const goalStatus = completed.map(g => {
    const icon = g.redeemed ? em.success : (g.completed ? em.robux : '⬜');
    const s = g.redeemed ? '~~' : '';
    return `${icon} ${s}**${g.label}** — ${g.invites} conv → ${formatNumber(g.robux)} Robux${s}`;
  }).join('\n');

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${em.user} Seu Progresso — <@${userId}>`)
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `### ${em.chart} Estatísticas\n` +
        `> ${em.invite} **Total:** \`${stats.total}\` · ${em.success} **Válidos:** \`${stats.valid}\` · ${em.error} **Fake/Saíram:** \`${stats.fake + stats.left}\``
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(false))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`### ${em.fire} Próxima Meta\n> ${progressToNext}`)
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`### ${em.reward} Status das Metas\n${goalStatus}`)
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('reward_redeem_select').setLabel('Resgatar').setStyle(ButtonStyle.Success).setEmoji('💎'),
        new ButtonBuilder().setCustomId('reward_panel_back').setLabel('← Voltar').setStyle(ButtonStyle.Secondary),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildGoalSelectMessage(userId) {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const completed = rewardSystem.getCompletedGoals(userId);
  const available = completed.filter(g => g.completed && !g.redeemed);

  if (!available.length) {
    const container = new ContainerBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `## ${em.warning} Sem metas disponíveis\n\n` +
          `Você não possui metas prontas para resgatar.\nContinue convidando membros!`
        )
      )
      .addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('reward_panel_back').setLabel('← Voltar').setStyle(ButtonStyle.Secondary),
        )
      );
    return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
  }

  const goalLines = available.map(g =>
    `${goalEmoji(g.invites)} **${g.label}** — ${formatNumber(g.robux)} Robux (${g.invites} convites)`
  ).join('\n');

  const buttons = available.slice(0, 5).map(g =>
    new ButtonBuilder()
      .setCustomId(`reward_claim:${g.index}`)
      .setLabel(`${g.label} — ${formatNumber(g.robux)} Robux`)
      .setStyle(ButtonStyle.Success)
  );

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${em.reward} Resgatar Recompensa\n\n` +
        `${em.success} **Metas disponíveis:**\n${goalLines}\n\n` +
        `Clique na meta que deseja resgatar:`
      )
    )
    .addActionRowComponents(new ActionRowBuilder().addComponents(...buttons))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('reward_panel_back').setLabel('← Voltar').setStyle(ButtonStyle.Secondary),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

module.exports = { buildRewardPanel, buildUserProgressEmbed, buildGoalSelectMessage };
