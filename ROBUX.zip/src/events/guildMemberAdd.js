const { handleMemberJoin } = require('../systems/inviteTracker');
const Database = require('../database/Database');
const logger = require('../utils/logger');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    try {
      Database.getUser(member.id);
      await handleMemberJoin(member);
    } catch (err) {
      logger.error(`Erro no guildMemberAdd: ${err.message}`);
    }
  },
};
