const { handleMemberLeave } = require('../systems/inviteTracker');
const logger = require('../utils/logger');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member) {
    try {
      await handleMemberLeave(member);
    } catch (err) {
      logger.error(`Erro no guildMemberRemove: ${err.message}`);
    }
  },
};
