const { handleInviteDelete } = require('../systems/inviteTracker');
const logger = require('../utils/logger');

module.exports = {
  name: 'inviteDelete',
  async execute(invite) {
    try {
      await handleInviteDelete(invite);
    } catch (err) {
      logger.error(`Erro no inviteDelete: ${err.message}`);
    }
  },
};
