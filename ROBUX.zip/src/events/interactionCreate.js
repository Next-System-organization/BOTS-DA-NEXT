const { handleButton } = require('../handlers/buttonHandler');
const { handleModal } = require('../handlers/modalHandler');
const { handleChannelSelect, handleRoleSelect } = require('../handlers/selectMenuHandler');
const { buildMainPanel } = require('../panels/adminPanel');
const { buildRewardPanel } = require('../layouts/rewardLayout');
const { getLeaderboard, formatLeaderboardText } = require('../systems/leaderboard');
const { getUserInviteStats } = require('../systems/inviteTracker');
const { isAdmin } = require('../security/validator');
const emojiManager = require('../utils/emojiManager');
const {
  ContainerBuilder,
  TextDisplayBuilder,
  MessageFlags,
} = require('discord.js');
const config = require('../config/loader');
const logger = require('../utils/logger');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    try {
      if (interaction.isChatInputCommand())    return handleSlashCommand(interaction, client);
      if (interaction.isButton())              return handleButton(interaction, client);
      if (interaction.isModalSubmit())         return handleModal(interaction, client);
      if (interaction.isChannelSelectMenu())   return handleChannelSelect(interaction, client);
      if (interaction.isRoleSelectMenu())      return handleRoleSelect(interaction, client);
    } catch (err) {
      logger.error('Erro no interactionCreate:', err.message);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro inesperado.', ephemeral: true }).catch(() => {});
      }
    }
  },
};

async function handleSlashCommand(interaction, client) {
  const { commandName, member, user, guild } = interaction;

  if (commandName === 'admin') {
    if (!isAdmin(member)) {
      return interaction.reply({ content: '❌ Sem permissão para acessar o painel administrativo.', ephemeral: true });
    }
    return interaction.reply(buildMainPanel());
  }

  if (commandName === 'deploy-rewards') {
    if (!isAdmin(member)) {
      return interaction.reply({ content: '❌ Sem permissão.', ephemeral: true });
    }
    await interaction.reply({ content: '✅ Painel de recompensas enviado!', ephemeral: true });
    return interaction.channel.send(buildRewardPanel());
  }

  if (commandName === 'reset-emojis') {
    if (!isAdmin(member)) {
      return interaction.reply({ content: '❌ Sem permissão.', ephemeral: true });
    }
    await interaction.deferReply({ ephemeral: true });
    try {
      await emojiManager.reset(client);
      await emojiManager.setup(client);
      await interaction.editReply({ content: '✅ Emojis personalizados recriados com sucesso!' });
    } catch (err) {
      await interaction.editReply({ content: `❌ Erro ao recriar emojis: ${err.message}` });
    }
    return;
  }

  if (commandName === 'invites') {
    const stats = getUserInviteStats(user.id);
    const cfg = config.get();
    const em = cfg.appearance.emojis;

    const container = new ContainerBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `## ${em.invite} Seus Convites — <@${user.id}>\n\n` +
          `> ${em.success} **Válidos:** \`${stats.valid}\`\n` +
          `> ${em.invite} **Total:** \`${stats.total}\`\n` +
          `> ${em.error} **Fake/Alt:** \`${stats.fake}\`\n` +
          `> ${em.warning} **Saíram:** \`${stats.left}\``
        )
      );

    return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true });
  }

  if (commandName === 'rank') {
    const top = getLeaderboard(15);
    const text = formatLeaderboardText(top);
    const cfg = config.get();
    const em = cfg.appearance.emojis;

    const container = new ContainerBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`## ${em.crown} Top 15 — Ranking de Convites\n\n${text}`)
      );

    return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
  }
}
