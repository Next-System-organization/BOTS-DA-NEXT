const { handleInviteCreate } = require('../systems/inviteTracker');
const logger = require('../utils/logger');

module.exports = {
  name: 'inviteCreate',
  async execute(invite) {
    try {
      await handleInviteCreate(invite);
    } catch (err) {
      logger.error(`Erro no inviteCreate: ${err.message}`);
    }
  },
};
