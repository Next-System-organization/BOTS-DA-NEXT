const { ActivityType, REST, Routes } = require('discord.js');
const { cacheGuildInvites } = require('../systems/inviteTracker');
const emojiManager = require('../utils/emojiManager');
const config = require('../config/loader');
const logger = require('../utils/logger');
const cron = require('node-cron');
const Database = require('../database/Database');

let statusIndex = 0;
let statusInterval = null;

const commands = [
  { name: 'admin',          description: 'Abre o painel administrativo', default_member_permissions: '8' },
  { name: 'deploy-rewards', description: 'Envia o painel de recompensas no canal atual', default_member_permissions: '8' },
  { name: 'invites',        description: 'Veja seus convites e progresso' },
  { name: 'rank',           description: 'Veja o ranking de convites do servidor' },
  { name: 'reset-emojis',   description: 'Remove e recria todos os emojis personalizados do bot', default_member_permissions: '8' },
];

function getActivityType(str) {
  const map = {
    WATCHING:  ActivityType.Watching,
    PLAYING:   ActivityType.Playing,
    LISTENING: ActivityType.Listening,
    COMPETING: ActivityType.Competing,
  };
  return map[(str || '').toUpperCase()] ?? ActivityType.Watching;
}

function rotateStatus(client) {
  const cfg = config.get();
  const msgs = cfg.bot?.statusMessages || ['💎 Robux Rewards'];
  const type = getActivityType(cfg.bot?.activityType);
  client.user.setActivity(msgs[statusIndex % msgs.length], { type });
  statusIndex++;
}

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    const cfg = config.get();
    logger.success(`Bot online como ${client.user.tag}`);

    const guild = client.guilds.cache.get(cfg.guildId);
    if (guild) {
      await cacheGuildInvites(guild);
      logger.success('Cache de invites carregado');
    }

    const rest = new REST({ version: '10' }).setToken(cfg.token);
    try {
      await rest.put(Routes.applicationGuildCommands(cfg.clientId, cfg.guildId), { body: commands });
      logger.success(`${commands.length} slash commands registrados`);
    } catch (err) {
      logger.error('Falha ao registrar slash commands:', err.message);
    }

    await emojiManager.setup(client);

    rotateStatus(client);
    if (statusInterval) clearInterval(statusInterval);
    statusInterval = setInterval(() => rotateStatus(client), 30000);

    if (cfg.systems?.autoBackup) {
      cron.schedule('0 */6 * * *', () => {
        Database.backup();
        logger.system('Backup automático realizado');
      });
    }

    logger.success('Bot totalmente inicializado!');
  },
};
