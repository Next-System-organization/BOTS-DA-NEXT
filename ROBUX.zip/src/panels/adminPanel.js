const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  SeparatorSpacingSize,
  MessageFlags,
  ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelType,
} = require('discord.js');
const { formatNumber, formatDate, goalEmoji } = require('../utils/formatter');
const { intToHex } = require('../utils/colorHelper');
const config = require('../config/loader');
const Database = require('../database/Database');
const stockSystem = require('../systems/stockSystem');
const reviewSystem = require('../systems/reviewSystem');

function resolveEmoji(emojiStr) {
  if (!emojiStr) return null;
  const match = String(emojiStr).match(/^<a?:([^:]+):(\d+)>$/);
  if (match) return { name: match[1], id: match[2] };
  return emojiStr;
}

function btn(id, label, style, emojiStr) {
  const b = new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
  const e = resolveEmoji(emojiStr);
  if (e) b.setEmoji(e);
  return b;
}

function row(...buttons) {
  return new ActionRowBuilder().addComponents(...buttons);
}

function buildMainPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const stock = stockSystem.getStock();
  const rewards = Database.getRewards();
  const reviews = reviewSystem.getStats();
  const users = Database.getAllUsers();
  const userCount = Object.keys(users).length;
  const colorHex = cfg.appearance.primaryColorHex || intToHex(cfg.appearance.primaryColor || 65415);

  const systemLines = Object.entries(cfg.systems)
    .map(([k, v]) => `> ${v ? em.success : em.error} **${k}:** ${v ? 'Ativo' : 'Inativo'}`)
    .join('\n');

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# ${em.admin} Painel Administrativo\n` +
        `> Cor principal: \`${colorHex}\` · Link: ${cfg.link?.url ? `[${cfg.link.label}](${cfg.link.url})` : '*não configurado*'}`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `### ${em.chart} Estatísticas\n` +
        `> ${em.robux} **Estoque:** \`${formatNumber(stock.total)} Robux\`\n` +
        `> ${em.reward} **Resgates:** \`${rewards.total}\` — **${formatNumber(rewards.totalRobux)} Robux** distribuídos\n` +
        `> ${em.user} **Usuários:** \`${userCount}\`\n` +
        `> ${em.review} **Avaliações:** \`${reviews.total}\` (${reviews.average}/5 ★)`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`### ${em.shield} Sistemas\n${systemLines}`)
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`${em.arrow} Navegue pelas seções abaixo para gerenciar tudo.`)
    )
    .addActionRowComponents(
      row(
        btn('admin_stock',     'Estoque',   ButtonStyle.Primary,   em.stock),
        btn('admin_goals',     'Metas',     ButtonStyle.Primary,   em.reward),
        btn('admin_users',     'Usuários',  ButtonStyle.Primary,   em.user),
        btn('admin_blacklist', 'Blacklist', ButtonStyle.Danger,    em.shield),
      )
    )
    .addActionRowComponents(
      row(
        btn('admin_logs',            'Logs',           ButtonStyle.Secondary, em.logs),
        btn('admin_settings',        'Configurações',  ButtonStyle.Secondary, '⚙️'),
        btn('admin_personalization', 'Personalização', ButtonStyle.Secondary, '🎨'),
        btn('admin_test',            'Testes',         ButtonStyle.Secondary, '🧪'),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildStockPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const summary = stockSystem.getStockSummary();
  const history = summary.recentMovements.slice(0, 8);

  const histLines = history.length
    ? history.map(m => {
        const icon = m.type === 'add' ? '🟢' : '🔴';
        return `${icon} \`${m.type.toUpperCase()}\` **${formatNumber(m.amount)}** — <@${m.adminId}> · *${formatDate(m.timestamp)}*`;
      }).join('\n')
    : '*Sem movimentações ainda.*';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${em.stock} Gerenciar Estoque\n` +
        `> **Estoque atual:** \`${formatNumber(summary.total)} Robux\``
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`### Histórico Recente\n${histLines}`))
    .addActionRowComponents(
      row(
        btn('admin_stock_add',    'Adicionar',     ButtonStyle.Success,   '➕'),
        btn('admin_stock_remove', 'Remover',       ButtonStyle.Danger,    '➖'),
        btn('admin_stock_set',    'Definir Total', ButtonStyle.Primary,   '✏️'),
        btn('admin_main',         '← Voltar',      ButtonStyle.Secondary, null),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildGoalsPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const goals = cfg.goals || [];

  const goalLines = goals.map((g, i) =>
    `**${i + 1}.** ${goalEmoji(g.invites)} **${g.label}** — \`${g.invites} convites\` → \`${formatNumber(g.robux)} Robux\``
  ).join('\n');

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${em.reward} Metas de Convites\n${goalLines}\n\n` +
        `*Máximo de 5 metas por linha de botões. Máximo total: 10 metas.*`
      )
    );

  const editButtons = goals.slice(0, 5).map((g, i) =>
    btn(`admin_goal_edit:${i}`, g.label, ButtonStyle.Primary, '✏️')
  );
  const editButtons2 = goals.slice(5, 10).map((g, i) =>
    btn(`admin_goal_edit:${i + 5}`, g.label, ButtonStyle.Primary, '✏️')
  );

  if (editButtons.length) container.addActionRowComponents(row(...editButtons));
  if (editButtons2.length) container.addActionRowComponents(row(...editButtons2));

  container.addActionRowComponents(
    row(
      btn('admin_goal_add',    'Nova Meta',       ButtonStyle.Success,   '➕'),
      btn('admin_goal_delete', 'Remover Última',  ButtonStyle.Danger,    '🗑️'),
      btn('admin_main',        '← Voltar',        ButtonStyle.Secondary, null),
    )
  );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildUsersPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const users = Database.getAllUsers();
  const list = Object.values(users).sort((a, b) => b.invites - a.invites).slice(0, 10);

  const userLines = list.length
    ? list.map((u, i) => {
        const valid = Math.max(0, (u.invites || 0) - (u.fakeInvites || 0) - (u.leftInvites || 0));
        return `**${i + 1}.** <@${u.id}> — \`${valid}\` válidos · \`${formatNumber(u.totalRobuxEarned || 0)}\` Robux`;
      }).join('\n')
    : '*Nenhum usuário registrado.*';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${em.user} Usuários Registrados\n> Total: **${Object.keys(users).length}**\n${userLines}`
      )
    )
    .addActionRowComponents(
      row(
        btn('admin_user_lookup', 'Buscar Usuário', ButtonStyle.Primary,   '🔍'),
        btn('admin_user_reset',  'Reset Resgates', ButtonStyle.Danger,    '🔄'),
        btn('admin_reset',       'Reset Tudo',     ButtonStyle.Danger,    '🔄'),
        btn('admin_main',        '← Voltar',       ButtonStyle.Secondary, null),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildBlacklistPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const bl = Database.getBlacklist();
  const entries = bl.users.slice(0, 10);

  const blLines = entries.length
    ? entries.map(uid => {
        const r = bl.reasons[uid];
        return `${em.error} <@${uid}> — *${r?.reason || 'Sem motivo'}* · por <@${r?.adminId || 'sistema'}>`;
      }).join('\n')
    : '*Blacklist vazia.*';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${em.shield} Blacklist\n> **${bl.users.length}** usuários\n${blLines}`
      )
    )
    .addActionRowComponents(
      row(
        btn('admin_bl_add',    'Banir',    ButtonStyle.Danger,    '🚫'),
        btn('admin_bl_remove', 'Desbanir', ButtonStyle.Success,   '✅'),
        btn('admin_main',      '← Voltar', ButtonStyle.Secondary, null),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildLogsPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const logsData = Database.getLogs();
  const recent = (logsData.entries || []).slice(0, 12);

  const typeIcon = {
    redeem: em.reward, invite: em.invite, fake_invite: em.warning,
    invite_left: em.error, review: em.review, blacklist: em.shield,
    stock_add: '🟢', stock_remove: '🔴', stock_set: '✏️',
    reset_redeems: '🔄', reset_all_redeems: '🔄', error: em.error,
    config_channels: '📢', config_link: '🔗', config_security: em.shield,
    config_goals: em.reward, config_color: '🎨', config_messages: '💬',
    config_emojis: '😀', config_bot: '🤖', config_roles: '👥',
  };

  const logLines = recent.length
    ? recent.map(l => {
        const icon = typeIcon[l.type] || em.logs;
        const who = l.userId || l.inviterId || l.adminId || 'sistema';
        return `${icon} \`${l.type}\` · ${formatDate(l.timestamp)} · <@${who}>`;
      }).join('\n')
    : '*Sem logs.*';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${em.logs} Logs do Sistema\n> **${logsData.entries?.length || 0}** registros\n${logLines}`
      )
    )
    .addActionRowComponents(
      row(
        btn('admin_main', '← Voltar', ButtonStyle.Secondary, null),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildSettingsPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;

  const channelLine = (id) => id ? `<#${id}>` : '*não configurado*';
  const roleLine = (ids) => ids?.length ? ids.map(r => `<@&${r}>`).join(', ') : '*nenhum*';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ⚙️ Configurações`)
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `### 📢 Canais\n` +
        `> ${em.reward} Recompensas: ${channelLine(cfg.channels.rewards)}\n` +
        `> ${em.logs} Logs: ${channelLine(cfg.channels.logs)}\n` +
        `> ${em.review} Avaliações: ${channelLine(cfg.channels.reviews)}\n` +
        `> 📣 Anúncios: ${channelLine(cfg.channels.announcements)}\n\n` +
        `### 👥 Cargos\n` +
        `> ${em.admin} Admin: ${roleLine(cfg.roles?.admin)}\n` +
        `> 🔧 Moderador: ${roleLine(cfg.roles?.moderator)}\n\n` +
        `### 🔗 Link Principal\n` +
        `> **Label:** \`${cfg.link?.label || 'não definido'}\`\n` +
        `> **URL:** ${cfg.link?.url || '*não configurado*'}\n` +
        `> **Botão:** \`${cfg.link?.buttonLabel || 'não definido'}\`\n\n` +
        `*Configurações salvas automaticamente.*`
      )
    )
    .addActionRowComponents(
      row(
        btn('admin_set_channels', 'Canais',         ButtonStyle.Primary, '📢'),
        btn('admin_set_roles',    'Cargos',         ButtonStyle.Primary, '👥'),
        btn('admin_set_link',     'Link Principal', ButtonStyle.Primary, '🔗'),
      )
    )
    .addActionRowComponents(
      row(
        btn('admin_toggle_systems', 'Ativar/Desativar Sistemas', ButtonStyle.Secondary, '🔄'),
        btn('admin_main',           '← Voltar',                 ButtonStyle.Secondary, null),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildPersonalizationPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const colorHex = cfg.appearance.primaryColorHex || intToHex(cfg.appearance.primaryColor || 65415);

  const emojiList = Object.entries(cfg.appearance.emojis)
    .map(([k, v]) => `\`${k}\` ${v}`)
    .join(' · ');

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## 🎨 Personalização do Bot`)
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `### 🖌️ Cor Principal\n> \`${colorHex}\`\n\n` +
        `### 🤖 Textos do Bot\n` +
        `> **Título painel:** *${cfg.bot?.rewardPanelTitle || 'não definido'}*\n` +
        `> **Descrição painel:** *${cfg.bot?.rewardPanelDescription || 'não definida'}*\n` +
        `> **Título entrega:** *${cfg.bot?.deliveryTitle || 'não definido'}*\n\n` +
        `### 😀 Emojis\n> ${emojiList}`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `### 💬 Mensagens Personalizadas\n` +
        `> **Sucesso resgate:** *${cfg.appearance.messages.redeemSuccess}*\n` +
        `> **Sem estoque:** *${cfg.appearance.messages.noStock}*\n` +
        `> **Já resgatou:** *${cfg.appearance.messages.alreadyRedeemed}*\n` +
        `> **Blacklist:** *${cfg.appearance.messages.blacklisted}*`
      )
    )
    .addActionRowComponents(
      row(
        btn('admin_set_color',     'Cor Principal', ButtonStyle.Primary,   '🖌️'),
        btn('admin_set_bot_texts', 'Textos do Bot', ButtonStyle.Primary,   '🤖'),
        btn('admin_set_messages',  'Mensagens',     ButtonStyle.Primary,   '💬'),
        btn('admin_set_emojis1',   'Emojis (1/2)',  ButtonStyle.Secondary, '😀'),
      )
    )
    .addActionRowComponents(
      row(
        btn('admin_set_emojis2', 'Emojis (2/2)', ButtonStyle.Secondary, '😀'),
        btn('admin_main',        '← Voltar',     ButtonStyle.Secondary, null),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildToggleSystemsPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const systems = cfg.systems;

  const lines = Object.entries(systems).map(([k, v]) =>
    `> ${v ? em.success : em.error} **${k}:** ${v ? '**Ativo**' : '~~Inativo~~'}`
  ).join('\n');

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## 🔄 Ativar / Desativar Sistemas\n${lines}\n\n` +
        `*Clique no botão do sistema que deseja alternar.*`
      )
    );

  const toggleButtons = Object.entries(systems).map(([k, v]) =>
    btn(`admin_toggle:${k}`, k, v ? ButtonStyle.Danger : ButtonStyle.Success, v ? '🔴' : '🟢')
  );

  for (let i = 0; i < toggleButtons.length; i += 4) {
    container.addActionRowComponents(row(...toggleButtons.slice(i, i + 4)));
  }

  container.addActionRowComponents(
    row(btn('admin_settings', '← Voltar', ButtonStyle.Secondary, null))
  );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildTestPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const goals = cfg.goals || [];
  const stock = stockSystem.getStock();

  const goalLines = goals.length
    ? goals.map((g, i) => `> **${i + 1}.** ${g.label} — \`${g.invites} convites\` → \`${formatNumber(g.robux)} Robux\``).join('\n')
    : '> *Nenhuma meta configurada.*';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## 🧪 Painel de Testes\n` +
        `> Simule o bot sem precisar de convites reais.\n\n` +
        `### ${em.chart} Estado Atual\n` +
        `> ${em.stock} Estoque: \`${formatNumber(stock.total)} Robux\`\n` +
        `> ${em.reward} Metas configuradas: \`${goals.length}\`\n\n` +
        `### ${em.reward} Metas disponíveis\n${goalLines}`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `### O que testar\n` +
        `> ${em.invite} **Simular Convite** — adiciona convites manualmente a um usuário pelo ID\n` +
        `> ${em.reward} **Ver Painel** — mostra o painel de recompensas como os membros veem\n` +
        `> ${em.success} **Reset de Teste** — zera os dados de teste de um usuário`
      )
    )
    .addActionRowComponents(
      row(
        btn('admin_test_invite',  'Simular Convite', ButtonStyle.Primary,   em.invite),
        btn('admin_test_panel',   'Ver Painel',      ButtonStyle.Primary,   em.reward),
        btn('admin_test_reset',   'Reset de Teste',  ButtonStyle.Danger,    em.error),
        btn('admin_main',         '← Voltar',        ButtonStyle.Secondary, null),
      )
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildChannelConfigPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const ch = cfg.channels || {};

  const chLine = (id) => id ? `<#${id}>` : '*não configurado*';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## 📢 Configurar Canais\n` +
        `> 📦 **Recompensas:** ${chLine(ch.rewards)}\n` +
        `> 📋 **Logs:** ${chLine(ch.logs)}\n` +
        `> ⭐ **Avaliações:** ${chLine(ch.reviews)}\n` +
        `> 📣 **Anúncios:** ${chLine(ch.announcements)}\n\n` +
        `*Selecione abaixo para alterar. Salva automaticamente ao selecionar.*`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
          .setCustomId('select_channel_rewards')
          .setPlaceholder('📦 Canal de Recompensas')
          .addChannelTypes(ChannelType.GuildText)
          .setMinValues(0).setMaxValues(1)
      )
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
          .setCustomId('select_channel_logs')
          .setPlaceholder('📋 Canal de Logs')
          .addChannelTypes(ChannelType.GuildText)
          .setMinValues(0).setMaxValues(1)
      )
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
          .setCustomId('select_channel_reviews')
          .setPlaceholder('⭐ Canal de Avaliações')
          .addChannelTypes(ChannelType.GuildText)
          .setMinValues(0).setMaxValues(1)
      )
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder()
          .setCustomId('select_channel_announcements')
          .setPlaceholder('📣 Canal de Anúncios')
          .addChannelTypes(ChannelType.GuildText)
          .setMinValues(0).setMaxValues(1)
      )
    )
    .addActionRowComponents(
      row(btn('admin_settings', '← Voltar', ButtonStyle.Secondary, null))
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

function buildRoleConfigPanel() {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const roles = cfg.roles || {};

  const roleList = (ids) => ids?.length ? ids.map(r => `<@&${r}>`).join(', ') : '*nenhum*';

  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## 👥 Configurar Cargos\n` +
        `> ${em.admin || '🔐'} **Admin:** ${roleList(roles.admin)}\n` +
        `> 🔧 **Moderador:** ${roleList(roles.moderator)}\n\n` +
        `*Selecione abaixo para alterar. Salva automaticamente ao selecionar.*`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new RoleSelectMenuBuilder()
          .setCustomId('select_role_admin')
          .setPlaceholder('🔐 Cargos Admin (podem acessar /admin)')
          .setMinValues(0).setMaxValues(10)
      )
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new RoleSelectMenuBuilder()
          .setCustomId('select_role_moderator')
          .setPlaceholder('🔧 Cargos Moderador')
          .setMinValues(0).setMaxValues(10)
      )
    )
    .addActionRowComponents(
      row(btn('admin_settings', '← Voltar', ButtonStyle.Secondary, null))
    );

  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

module.exports = {
  buildMainPanel,
  buildStockPanel,
  buildGoalsPanel,
  buildUsersPanel,
  buildBlacklistPanel,
  buildLogsPanel,
  buildSettingsPanel,
  buildPersonalizationPanel,
  buildToggleSystemsPanel,
  buildTestPanel,
  buildChannelConfigPanel,
  buildRoleConfigPanel,
};
