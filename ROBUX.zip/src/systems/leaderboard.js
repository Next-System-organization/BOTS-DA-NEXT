const Database = require('../database/Database');
const { rankEmoji } = require('../utils/formatter');

function getLeaderboard(limit = 10) {
  return Database.getLeaderboard(limit);
}

function getUserRank(userId) {
  const all = Database.getLeaderboard(1000);
  const idx = all.findIndex(u => u.id === userId);
  return idx === -1 ? null : idx + 1;
}

function formatLeaderboardText(entries) {
  if (!entries.length) return '> *Nenhum convite registrado ainda.*';
  return entries.map((u, i) => {
    const valid = Math.max(0, (u.invites || 0) - (u.fakeInvites || 0) - (u.leftInvites || 0));
    const medal = rankEmoji(i + 1);
    return `${medal} **<@${u.id}>** — **${valid}** convites válidos`;
  }).join('\n');
}

module.exports = { getLeaderboard, getUserRank, formatLeaderboardText };
