const Database = require('../database/Database');
const stockSystem = require('./stockSystem');
const config = require('../config/loader');
const logger = require('../utils/logger');
const { formatDate } = require('../utils/formatter');

function getNextGoal(validInvites) {
  const cfg = config.get();
  const goals = cfg.goals || [];
  for (const goal of goals) {
    if (validInvites < goal.invites) return goal;
  }
  return null;
}

function getCompletedGoals(userId) {
  const user = Database.getUser(userId);
  const cfg = config.get();
  const goals = cfg.goals || [];
  const stats = getUserValidInvites(userId);
  return goals.map((goal, i) => ({
    ...goal,
    index: i,
    completed: stats.valid >= goal.invites,
    redeemed: (user.redeemed || []).includes(i),
  }));
}

function getUserValidInvites(userId) {
  const user = Database.getUser(userId);
  const valid = Math.max(0, (user.invites || 0) - (user.fakeInvites || 0) - (user.leftInvites || 0));
  return {
    total: user.invites || 0,
    valid,
    fake: user.fakeInvites || 0,
    left: user.leftInvites || 0,
  };
}

async function processRedeem(userId, goalIndex, robloxNick, guild) {
  const cfg = config.get();
  const goals = cfg.goals || [];
  const goal = goals[goalIndex];
  if (!goal) throw new Error('Meta inválida');

  const stats = getUserValidInvites(userId);
  if (stats.valid < goal.invites) throw new Error('Convites insuficientes');

  const user = Database.getUser(userId);
  if ((user.redeemed || []).includes(goalIndex)) throw new Error('Já resgatado');

  const stock = Database.getStock();
  if (stock.total < goal.robux) throw new Error('Estoque insuficiente');

  stockSystem.deductStock(goal.robux);

  const redeemed = [...(user.redeemed || []), goalIndex];
  Database.saveUser(userId, {
    redeemed,
    robloxNick,
    totalRobuxEarned: (user.totalRobuxEarned || 0) + goal.robux,
  });

  const newStock = Database.getStock();

  const deliveryData = {
    userId,
    robloxNick,
    goalIndex,
    goalLabel: goal.label,
    invites: goal.invites,
    robux: goal.robux,
    stockAfter: newStock.total,
    timestamp: Date.now(),
    formattedDate: formatDate(Date.now()),
  };

  Database.addDelivery(deliveryData);
  Database.addRedeem(deliveryData);

  Database.addLog({
    type: 'redeem',
    userId,
    robloxNick,
    goalIndex,
    robux: goal.robux,
    stockAfter: newStock.total,
  });

  logger.reward(`Resgate: ${userId} → ${robloxNick} — ${goal.robux} Robux`);

  return { delivery: deliveryData, newStock };
}

function resetUserRedeems(userId) {
  const user = Database.getUser(userId);
  if (!user) return;
  Database.saveUser(userId, { redeemed: [] });
  Database.addLog({ type: 'reset_redeems', userId });
}

function resetAllRedeems() {
  const users = Database.getAllUsers();
  for (const userId of Object.keys(users)) {
    Database.saveUser(userId, { redeemed: [] });
  }
  Database.addLog({ type: 'reset_all_redeems' });
}

module.exports = { getNextGoal, getCompletedGoals, getUserValidInvites, processRedeem, resetUserRedeems, resetAllRedeems };
