const Database = require('../database/Database');
const { isSuspiciousInvite } = require('../security/antiAlt');
const logger = require('../utils/logger');

const inviteMap = new Map();

async function cacheGuildInvites(guild) {
  try {
    const invites = await guild.invites.fetch();
    const map = new Map();
    invites.forEach(invite => {
      map.set(invite.code, { uses: invite.uses, inviterId: invite.inviter?.id });
    });
    inviteMap.set(guild.id, map);
    return map;
  } catch (err) {
    logger.error('Falha ao cachear invites:', err.message);
    return new Map();
  }
}

async function handleMemberJoin(member) {
  const guild = member.guild;
  const oldInvites = inviteMap.get(guild.id) || new Map();

  let newInvites;
  try {
    newInvites = await guild.invites.fetch();
  } catch {
    return;
  }

  let usedInvite = null;
  let inviterId = null;

  for (const [code, invite] of newInvites) {
    const old = oldInvites.get(code);
    if (old && invite.uses > old.uses) {
      usedInvite = invite;
      inviterId = invite.inviter?.id;
      break;
    }
    if (!old && invite.uses > 0) {
      usedInvite = invite;
      inviterId = invite.inviter?.id;
      break;
    }
  }

  const newMap = new Map();
  newInvites.forEach(inv => {
    newMap.set(inv.code, { uses: inv.uses, inviterId: inv.inviter?.id });
  });
  inviteMap.set(guild.id, newMap);

  const dbInvites = Database.getInvites();
  if (!dbInvites[member.id]) {
    dbInvites[member.id] = { invitedBy: inviterId || null, joinedAt: Date.now() };
    Database.setInvites(dbInvites);
  }

  if (!inviterId) return;
  if (inviterId === member.id) return;

  const isFake = isSuspiciousInvite(member.user);

  const inviter = Database.getUser(inviterId);

  if (isFake) {
    Database.saveUser(inviterId, {
      fakeInvites: (inviter.fakeInvites || 0) + 1,
    });
    Database.addLog({
      type: 'fake_invite',
      inviterId,
      invitedId: member.id,
      reason: 'conta nova detectada',
    });
    logger.warn(`Invite falso detectado: ${member.user.tag} convidado por ${inviterId}`);
  } else {
    Database.saveUser(inviterId, {
      invites: (inviter.invites || 0) + 1,
    });
    Database.addLog({
      type: 'invite',
      inviterId,
      invitedId: member.id,
      inviteCode: usedInvite?.code,
    });
    logger.invite(`${member.user.tag} entrou via convite de ${inviterId}`);
  }
}

async function handleMemberLeave(member) {
  const dbInvites = Database.getInvites();
  const record = dbInvites[member.id];

  if (record?.invitedBy) {
    const inviterId = record.invitedBy;
    const inviter = Database.getUser(inviterId);
    if (inviter) {
      Database.saveUser(inviterId, {
        leftInvites: (inviter.leftInvites || 0) + 1,
      });
    }
    Database.addLog({
      type: 'invite_left',
      inviterId,
      leftId: member.id,
    });
    logger.invite(`${member.user.tag} saiu — left contabilizado para ${inviterId}`);
  }
}

async function handleInviteCreate(invite) {
  const guild = invite.guild;
  const map = inviteMap.get(guild.id) || new Map();
  map.set(invite.code, { uses: invite.uses || 0, inviterId: invite.inviter?.id });
  inviteMap.set(guild.id, map);
}

async function handleInviteDelete(invite) {
  const guild = invite.guild;
  const map = inviteMap.get(guild.id);
  if (map) {
    map.delete(invite.code);
    inviteMap.set(guild.id, map);
  }
}

function getUserInviteStats(userId) {
  const user = Database.getUser(userId);
  const valid = Math.max(0, (user.invites || 0) - (user.fakeInvites || 0) - (user.leftInvites || 0));
  return {
    total: user.invites || 0,
    valid,
    fake: user.fakeInvites || 0,
    left: user.leftInvites || 0,
  };
}

module.exports = { cacheGuildInvites, handleMemberJoin, handleMemberLeave, handleInviteCreate, handleInviteDelete, getUserInviteStats };
