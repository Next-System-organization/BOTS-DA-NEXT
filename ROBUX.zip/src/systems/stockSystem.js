const Database = require('../database/Database');
const { formatNumber } = require('../utils/formatter');

function getStock() {
  return Database.getStock();
}

function addStock(amount, adminId, reason) {
  if (isNaN(amount) || amount <= 0) throw new Error('Quantidade inválida');
  return Database.addStockMovement('add', amount, adminId, reason || 'Adição manual');
}

function removeStock(amount, adminId, reason) {
  if (isNaN(amount) || amount <= 0) throw new Error('Quantidade inválida');
  const stock = Database.getStock();
  if (stock.total < amount) throw new Error('Estoque insuficiente');
  return Database.addStockMovement('remove', amount, adminId, reason || 'Remoção manual');
}

function deductStock(amount) {
  const stock = Database.getStock();
  if (stock.total < amount) throw new Error('Estoque insuficiente');
  return Database.addStockMovement('deduct', amount, 'system', 'Resgate de recompensa');
}

function setStock(amount, adminId) {
  if (isNaN(amount) || amount < 0) throw new Error('Quantidade inválida');
  const stock = Database.getStock();
  const diff = amount - stock.total;
  if (diff > 0) return Database.addStockMovement('add', diff, adminId, 'Definição manual de estoque');
  if (diff < 0) return Database.addStockMovement('remove', Math.abs(diff), adminId, 'Definição manual de estoque');
  return stock;
}

function getMovementHistory(limit = 20) {
  const stock = Database.getStock();
  return (stock.movements || []).slice(-limit).reverse();
}

function getStockSummary() {
  const stock = Database.getStock();
  const history = getMovementHistory(5);
  return {
    total: stock.total,
    totalFormatted: formatNumber(stock.total),
    reserved: stock.reserved || 0,
    recentMovements: history,
  };
}

module.exports = { getStock, addStock, removeStock, deductStock, setStock, getMovementHistory, getStockSummary };
