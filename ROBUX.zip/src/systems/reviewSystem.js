const Database = require('../database/Database');
const config = require('../config/loader');
const logger = require('../utils/logger');

const AUTO_COMMENTS = [
  'Ótimo sistema! Recebi meus Robux rapidinho.',
  'Super rápido e confiável. Recomendo a todos!',
  'Funcionou perfeitamente. Muito obrigado!',
  'Sistema excelente! Resgate concluído sem problemas.',
  'Recebi tudo certinho e rápido. Muito bom!',
  'Sem enrolação, direto ao ponto. Aprovado!',
  'Incrível! Os Robux chegaram na hora certa.',
];

function addReview(userId, username, rating, comment) {
  const ratingNum = Math.min(5, Math.max(1, parseInt(rating) || 5));
  const reviewData = {
    userId,
    username,
    rating: ratingNum,
    comment: (comment || AUTO_COMMENTS[Math.floor(Math.random() * AUTO_COMMENTS.length)]).slice(0, 300),
    timestamp: Date.now(),
    auto: !comment,
  };

  const updated = Database.addReview(reviewData);
  Database.addLog({ type: 'review', userId, rating: ratingNum });
  logger.info(`Avaliação: ${username} ${ratingNum}/5`);

  return { review: reviewData, stats: updated };
}

function getStats() {
  const reviews = Database.getReviews();
  return {
    total: reviews.ratingCount || 0,
    average: reviews.averageRating || 0,
    recent: (reviews.reviews || []).slice(0, 5),
  };
}

function getRecentReviews(limit = 10) {
  const reviews = Database.getReviews();
  return (reviews.reviews || []).slice(0, limit);
}

module.exports = { addReview, getStats, getRecentReviews, AUTO_COMMENTS };
