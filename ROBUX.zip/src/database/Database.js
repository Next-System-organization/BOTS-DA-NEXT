const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(process.cwd(), 'data');

const files = {
  users: 'users.json',
  invites: 'invites.json',
  stock: 'stock.json',
  rewards: 'rewards.json',
  logs: 'logs.json',
  blacklist: 'blacklist.json',
  reviews: 'reviews.json',
  deliveries: 'deliveries.json',
};

function filePath(name) {
  return path.join(DATA_DIR, files[name]);
}

function read(name) {
  const fp = filePath(name);
  if (!fs.existsSync(fp)) return getDefault(name);
  try {
    return JSON.parse(fs.readFileSync(fp, 'utf8'));
  } catch {
    return getDefault(name);
  }
}

function write(name, data) {
  fs.writeFileSync(filePath(name), JSON.stringify(data, null, 2), 'utf8');
}

function getDefault(name) {
  const defaults = {
    users: {},
    invites: {},
    stock: { total: 10000000, reserved: 0, movements: [] },
    rewards: { redeems: [], total: 0, totalRobux: 0 },
    logs: { entries: [] },
    blacklist: { users: [], reasons: {} },
    reviews: { reviews: [], totalRatings: 0, averageRating: 0, ratingCount: 0 },
    deliveries: { deliveries: [] },
  };
  return defaults[name] || {};
}

const Database = {
  getUser(userId) {
    const users = read('users');
    if (!users[userId]) {
      users[userId] = {
        id: userId,
        invites: 0,
        fakeInvites: 0,
        leftInvites: 0,
        redeemed: [],
        joinedAt: Date.now(),
        robloxNick: null,
        totalRobuxEarned: 0,
        reviewSent: false,
        lastActivity: Date.now(),
      };
      write('users', users);
    }
    return users[userId];
  },

  saveUser(userId, data) {
    const users = read('users');
    users[userId] = { ...users[userId], ...data, lastActivity: Date.now() };
    write('users', users);
    return users[userId];
  },

  getAllUsers() {
    return read('users');
  },

  getInvites() {
    return read('invites');
  },

  setInvites(data) {
    write('invites', data);
  },

  getStock() {
    return read('stock');
  },

  saveStock(data) {
    write('stock', data);
  },

  addStockMovement(type, amount, adminId, reason) {
    const stock = read('stock');
    if (type === 'add') {
      stock.total += amount;
    } else if (type === 'remove') {
      if (stock.total - amount < 0) throw new Error('Estoque insuficiente');
      stock.total -= amount;
    } else if (type === 'deduct') {
      if (stock.total - amount < 0) throw new Error('Estoque insuficiente');
      stock.total -= amount;
    }
    stock.movements.push({
      type,
      amount,
      adminId,
      reason: reason || '',
      timestamp: Date.now(),
      balance: stock.total,
    });
    if (stock.movements.length > 500) stock.movements = stock.movements.slice(-500);
    write('stock', stock);
    return stock;
  },

  getRewards() {
    return read('rewards');
  },

  addRedeem(redeemData) {
    const rewards = read('rewards');
    rewards.redeems.push(redeemData);
    rewards.total += 1;
    rewards.totalRobux += redeemData.robux;
    if (rewards.redeems.length > 1000) rewards.redeems = rewards.redeems.slice(-1000);
    write('rewards', rewards);
  },

  getLogs() {
    return read('logs');
  },

  addLog(entry) {
    const logs = read('logs');
    logs.entries.unshift({ ...entry, timestamp: Date.now() });
    if (logs.entries.length > 1000) logs.entries = logs.entries.slice(0, 1000);
    write('logs', logs);
  },

  getBlacklist() {
    return read('blacklist');
  },

  addToBlacklist(userId, reason, adminId) {
    const bl = read('blacklist');
    if (!bl.users.includes(userId)) {
      bl.users.push(userId);
      bl.reasons[userId] = { reason, adminId, timestamp: Date.now() };
      write('blacklist', bl);
    }
    return bl;
  },

  removeFromBlacklist(userId) {
    const bl = read('blacklist');
    bl.users = bl.users.filter(u => u !== userId);
    delete bl.reasons[userId];
    write('blacklist', bl);
    return bl;
  },

  isBlacklisted(userId) {
    const bl = read('blacklist');
    return bl.users.includes(userId);
  },

  getReviews() {
    return read('reviews');
  },

  addReview(reviewData) {
    const reviews = read('reviews');
    reviews.reviews.unshift(reviewData);
    reviews.ratingCount += 1;
    reviews.totalRatings += reviewData.rating;
    reviews.averageRating = parseFloat((reviews.totalRatings / reviews.ratingCount).toFixed(1));
    if (reviews.reviews.length > 500) reviews.reviews = reviews.reviews.slice(0, 500);
    write('reviews', reviews);
    return reviews;
  },

  getDeliveries() {
    return read('deliveries');
  },

  addDelivery(deliveryData) {
    const deliveries = read('deliveries');
    deliveries.deliveries.unshift(deliveryData);
    if (deliveries.deliveries.length > 1000) deliveries.deliveries = deliveries.deliveries.slice(0, 1000);
    write('deliveries', deliveries);
  },

  backup() {
    const backupDir = path.join(DATA_DIR, 'backups');
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const ts = new Date().toISOString().replace(/[:.]/g, '-');
    const backupData = {};
    for (const [key] of Object.entries(files)) {
      backupData[key] = read(key);
    }
    fs.writeFileSync(path.join(backupDir, `backup-${ts}.json`), JSON.stringify(backupData, null, 2));
    const backups = fs.readdirSync(backupDir).sort();
    if (backups.length > 10) {
      for (let i = 0; i < backups.length - 10; i++) {
        fs.unlinkSync(path.join(backupDir, backups[i]));
      }
    }
  },

  getLeaderboard(limit = 10) {
    const users = read('users');
    return Object.values(users)
      .filter(u => u.invites > 0)
      .sort((a, b) => b.invites - a.invites)
      .slice(0, limit);
  },
};

module.exports = Database;
