const config = require('../config/loader');

function isAltAccount(member) {
  const cfg = config.get();
  if (!cfg.systems.antiAlt) return false;

  const minDays = cfg.security.antiAltDays || 7;
  const createdAt = member.user.createdAt;
  const ageMs = Date.now() - createdAt.getTime();
  const ageDays = ageMs / (1000 * 60 * 60 * 24);

  return ageDays < minDays;
}

function getAccountAge(user) {
  const ageMs = Date.now() - user.createdAt.getTime();
  const ageDays = Math.floor(ageMs / (1000 * 60 * 60 * 24));
  return ageDays;
}

function isSuspiciousInvite(invitedUser) {
  const ageDays = getAccountAge(invitedUser);
  const cfg = config.get();
  const minDays = cfg.security.antiAltDays || 7;
  return ageDays < minDays;
}

module.exports = { isAltAccount, getAccountAge, isSuspiciousInvite };
