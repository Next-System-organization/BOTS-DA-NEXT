const { spamCache } = require('../utils/cache');
const config = require('../config/loader');

function checkSpam(userId) {
  const cfg = config.get();
  const threshold = cfg.security.spamThreshold || 5;
  const window = cfg.security.spamWindowMs || 10000;

  const key = `spam:${userId}`;
  let entry = spamCache.get(key);

  if (!entry) {
    entry = { count: 0, firstAt: Date.now() };
  }

  const now = Date.now();
  if (now - entry.firstAt > window) {
    entry = { count: 1, firstAt: now };
  } else {
    entry.count += 1;
  }

  spamCache.set(key, entry, window);

  return entry.count > threshold;
}

function resetSpam(userId) {
  spamCache.delete(`spam:${userId}`);
}

function getSpamCount(userId) {
  const entry = spamCache.get(`spam:${userId}`);
  return entry ? entry.count : 0;
}

module.exports = { checkSpam, resetSpam, getSpamCount };
