const Database = require('../database/Database');
const config = require('../config/loader');
const { cooldownCache } = require('../utils/cache');

function isAdmin(member) {
  const cfg = config.get();
  if (!member) return false;
  if (member.permissions.has('Administrator')) return true;
  const adminRoles = cfg.roles?.admin || [];
  return adminRoles.some(roleId => member.roles.cache.has(roleId));
}

function isModerator(member) {
  const cfg = config.get();
  if (!member) return false;
  if (isAdmin(member)) return true;
  const modRoles = cfg.roles?.moderator || [];
  return modRoles.some(roleId => member.roles.cache.has(roleId));
}

function checkCooldown(userId, action, seconds) {
  const key = `cd:${action}:${userId}`;
  const entry = cooldownCache.get(key);
  if (entry) {
    const remaining = Math.ceil((entry.expires - Date.now()) / 1000);
    return { onCooldown: true, remaining };
  }
  cooldownCache.set(key, { expires: Date.now() + seconds * 1000 }, seconds * 1000);
  return { onCooldown: false, remaining: 0 };
}

function removeCooldown(userId, action) {
  cooldownCache.delete(`cd:${action}:${userId}`);
}

function validateRobloxNick(nick) {
  if (!nick || typeof nick !== 'string') return false;
  const trimmed = nick.trim();
  if (trimmed.length < 3 || trimmed.length > 20) return false;
  return /^[a-zA-Z0-9_]+$/.test(trimmed);
}

function canRedeem(userId, goalIndex) {
  const user = Database.getUser(userId);
  if (!user) return { ok: false, reason: 'user_not_found' };
  if (Database.isBlacklisted(userId)) return { ok: false, reason: 'blacklisted' };

  const cfg = config.get();
  const goals = cfg.goals || [];
  const goal = goals[goalIndex];
  if (!goal) return { ok: false, reason: 'invalid_goal' };

  const validInvites = user.invites - (user.fakeInvites || 0) - (user.leftInvites || 0);
  if (validInvites < goal.invites) return { ok: false, reason: 'not_enough_invites', needed: goal.invites, has: validInvites };

  const alreadyRedeemed = (user.redeemed || []).includes(goalIndex);
  if (alreadyRedeemed) return { ok: false, reason: 'already_redeemed' };

  const stock = Database.getStock();
  if (stock.total < goal.robux) return { ok: false, reason: 'no_stock' };

  return { ok: true, goal, validInvites };
}

module.exports = { isAdmin, isModerator, checkCooldown, removeCooldown, validateRobloxNick, canRedeem };
