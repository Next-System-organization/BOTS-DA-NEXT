const {
  ContainerBuilder,
  TextDisplayBuilder,
  MessageFlags,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { processRedeem } = require('../systems/rewardSystem');
const { addReview } = require('../systems/reviewSystem');
const { addStock, removeStock, setStock } = require('../systems/stockSystem');
const { validateRobloxNick, canRedeem } = require('../security/validator');
const { buildDeliveryMessage, buildPublicDeliveryLog } = require('../layouts/deliveryLayout');
const { buildReviewMessage } = require('../layouts/reviewLayout');
const adminPanel = require('../panels/adminPanel');
const Database = require('../database/Database');
const config = require('../config/loader');
const logger = require('../utils/logger');
const { formatNumber, goalEmoji } = require('../utils/formatter');
const { hexToInt, validateHex } = require('../utils/colorHelper');

async function handleModal(interaction, client) {
  const { customId } = interaction;

  try {
    if (customId.startsWith('modal_claim:'))    return handleClaimModal(interaction, client);
    if (customId === 'modal_stock_add')         return handleStockAdd(interaction);
    if (customId === 'modal_stock_remove')      return handleStockRemove(interaction);
    if (customId === 'modal_stock_set')         return handleStockSet(interaction);
    if (customId.startsWith('modal_goal_edit:')) return handleGoalEdit(interaction);
    if (customId === 'modal_goal_add')          return handleGoalAdd(interaction);
    if (customId === 'modal_user_lookup')       return handleUserLookup(interaction);
    if (customId === 'modal_user_reset')        return handleUserReset(interaction);
    if (customId === 'modal_bl_add')            return handleBlacklistAdd(interaction);
    if (customId === 'modal_bl_remove')         return handleBlacklistRemove(interaction);
    if (customId === 'modal_set_link')          return handleSetLink(interaction);
    if (customId === 'modal_test_invite')       return handleTestInvite(interaction);
    if (customId === 'modal_test_reset')        return handleTestReset(interaction);
    if (customId === 'modal_set_color')         return handleSetColor(interaction);
    if (customId === 'modal_set_bot_texts')     return handleSetBotTexts(interaction);
    if (customId === 'modal_set_messages')      return handleSetMessages(interaction);
    if (customId === 'modal_set_emojis1')       return handleSetEmojis1(interaction);
    if (customId === 'modal_set_emojis2')       return handleSetEmojis2(interaction);
  } catch (err) {
    logger.error('Erro modalHandler:', err.message);
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: `❌ Erro: ${err.message}`, ephemeral: true }).catch(() => {});
    }
  }
}

function getField(interaction, id, fallback = '') {
  try { return interaction.fields.getTextInputValue(id)?.trim() || fallback; }
  catch { return fallback; }
}

function successMsg(text, backId, backLabel = '← Voltar') {
  const container = new ContainerBuilder()
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(text))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(backId).setLabel(backLabel).setStyle(ButtonStyle.Secondary)
      )
    );
  return { components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true };
}

async function handleClaimModal(interaction, client) {
  const goalIndex = parseInt(interaction.customId.split(':')[1]);
  const robloxNick = getField(interaction, 'roblox_nick');

  if (!validateRobloxNick(robloxNick)) {
    return interaction.reply({
      content: '❌ Username Roblox inválido. Use apenas letras, números e underscore (3–20 caracteres).',
      ephemeral: true,
    });
  }

  const check = canRedeem(interaction.user.id, goalIndex);
  if (!check.ok) {
    const msgs = config.get().appearance.messages;
    const reasonMap = {
      blacklisted: msgs.blacklisted,
      not_enough_invites: `${msgs.notEnoughInvites} (você tem **${check.has}**, precisa de **${check.needed}**)`,
      already_redeemed: msgs.alreadyRedeemed,
      no_stock: msgs.noStock,
      invalid_goal: '❌ Meta inválida.',
    };
    return interaction.reply({ content: `❌ ${reasonMap[check.reason] || 'Erro desconhecido.'}`, ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });

  const result = await processRedeem(interaction.user.id, goalIndex, robloxNick, interaction.guild);
  const delivery = result.delivery;
  const deliveryMsg = buildDeliveryMessage(delivery, interaction.guild);

  await interaction.editReply(deliveryMsg);

  const cfg = config.get();
  if (cfg.channels.logs) {
    const ch = interaction.guild.channels.cache.get(cfg.channels.logs);
    if (ch) await ch.send(buildPublicDeliveryLog(delivery)).catch(() => {});
  }

  logger.reward(`Resgate: ${interaction.user.tag} → ${robloxNick} — ${delivery.robux} Robux`);

  try {
    const reviewResult = addReview(interaction.user.id, interaction.user.username, 5, null);
    if (cfg.channels.reviews) {
      const reviewCh = interaction.guild.channels.cache.get(cfg.channels.reviews);
      if (reviewCh) await reviewCh.send(buildReviewMessage(reviewResult.review, reviewResult.stats)).catch(() => {});
    }
  } catch {}
}

async function handleStockAdd(interaction) {
  const amount = parseInt(getField(interaction, 'amount').replace(/\D/g, ''));
  const reason = getField(interaction, 'reason') || 'Adição manual';
  if (isNaN(amount) || amount <= 0) return interaction.reply({ content: '❌ Quantidade inválida.', ephemeral: true });

  const newStock = addStock(amount, interaction.user.id, reason);
  Database.addLog({ type: 'stock_add', amount, adminId: interaction.user.id, reason, newTotal: newStock.total });
  await interaction.reply(successMsg(
    `✅ **Estoque adicionado!**\n> Adicionado: \`${formatNumber(amount)} Robux\`\n> Novo total: \`${formatNumber(newStock.total)} Robux\``,
    'admin_stock', '← Voltar ao Estoque'
  ));
}

async function handleStockRemove(interaction) {
  const amount = parseInt(getField(interaction, 'amount').replace(/\D/g, ''));
  const reason = getField(interaction, 'reason') || 'Remoção manual';
  if (isNaN(amount) || amount <= 0) return interaction.reply({ content: '❌ Quantidade inválida.', ephemeral: true });

  const newStock = removeStock(amount, interaction.user.id, reason);
  Database.addLog({ type: 'stock_remove', amount, adminId: interaction.user.id, reason, newTotal: newStock.total });
  await interaction.reply(successMsg(
    `✅ **Estoque removido!**\n> Removido: \`${formatNumber(amount)} Robux\`\n> Novo total: \`${formatNumber(newStock.total)} Robux\``,
    'admin_stock', '← Voltar ao Estoque'
  ));
}

async function handleStockSet(interaction) {
  const amount = parseInt(getField(interaction, 'amount').replace(/\D/g, ''));
  if (isNaN(amount) || amount < 0) return interaction.reply({ content: '❌ Quantidade inválida.', ephemeral: true });

  const newStock = setStock(amount, interaction.user.id);
  Database.addLog({ type: 'stock_set', amount, adminId: interaction.user.id, newTotal: newStock.total });
  await interaction.reply(successMsg(
    `✅ **Estoque definido!**\n> Novo total: \`${formatNumber(newStock.total)} Robux\``,
    'admin_stock', '← Voltar ao Estoque'
  ));
}

async function handleGoalEdit(interaction) {
  const goalIndex = parseInt(interaction.customId.split(':')[1]);
  const label   = getField(interaction, 'label');
  const invites = parseInt(getField(interaction, 'invites').replace(/\D/g, ''));
  const robux   = parseInt(getField(interaction, 'robux').replace(/\D/g, ''));

  if (!label || isNaN(invites) || isNaN(robux) || invites <= 0 || robux <= 0) {
    return interaction.reply({ content: '❌ Dados inválidos. Preencha todos os campos corretamente.', ephemeral: true });
  }

  const cfg = config.get();
  if (!cfg.goals[goalIndex]) return interaction.reply({ content: '❌ Meta não encontrada.', ephemeral: true });

  cfg.goals[goalIndex] = { invites, robux, label };
  cfg.goals.sort((a, b) => a.invites - b.invites);
  config.save(cfg);

  Database.addLog({ type: 'config_goals', adminId: interaction.user.id, action: 'edit', goalIndex, label });
  await interaction.reply(successMsg(
    `✅ **Meta "${label}" atualizada!**\n> ${invites} convites → ${formatNumber(robux)} Robux`,
    'admin_goals', '← Voltar às Metas'
  ));
}

async function handleGoalAdd(interaction) {
  const label   = getField(interaction, 'label');
  const invites = parseInt(getField(interaction, 'invites').replace(/\D/g, ''));
  const robux   = parseInt(getField(interaction, 'robux').replace(/\D/g, ''));

  if (!label || isNaN(invites) || isNaN(robux) || invites <= 0 || robux <= 0) {
    return interaction.reply({ content: '❌ Dados inválidos.', ephemeral: true });
  }

  const cfg = config.get();
  if (cfg.goals.length >= 10) return interaction.reply({ content: '❌ Máximo de 10 metas atingido.', ephemeral: true });

  cfg.goals.push({ invites, robux, label });
  cfg.goals.sort((a, b) => a.invites - b.invites);
  config.save(cfg);

  Database.addLog({ type: 'config_goals', adminId: interaction.user.id, action: 'add', label });
  await interaction.reply(successMsg(
    `✅ **Meta "${label}" criada!**\n> ${invites} convites → ${formatNumber(robux)} Robux`,
    'admin_goals', '← Voltar às Metas'
  ));
}

async function handleUserLookup(interaction) {
  const userId = getField(interaction, 'user_id').replace(/[<@!>]/g, '');
  const user = Database.getUser(userId);
  const em = config.get().appearance.emojis;
  const valid = Math.max(0, (user.invites || 0) - (user.fakeInvites || 0) - (user.leftInvites || 0));

  await interaction.reply(successMsg(
    `## ${em.user} Usuário: <@${userId}>\n` +
    `> ${em.invite} **Convites válidos:** \`${valid}\`\n` +
    `> Total: \`${user.invites || 0}\` · Fake: \`${user.fakeInvites || 0}\` · Saíram: \`${user.leftInvites || 0}\`\n` +
    `> ${em.robux} **Robux ganhos:** \`${formatNumber(user.totalRobuxEarned || 0)}\`\n` +
    `> 🎮 **Roblox nick:** \`${user.robloxNick || 'não definido'}\`\n` +
    `> Metas resgatadas: \`${(user.redeemed || []).length}\`\n` +
    `> Blacklist: \`${Database.isBlacklisted(userId) ? 'SIM ⚠️' : 'Não'}\``,
    'admin_users', '← Voltar'
  ));
}

async function handleUserReset(interaction) {
  const userId = getField(interaction, 'user_id').replace(/[<@!>]/g, '');
  const { resetUserRedeems } = require('../systems/rewardSystem');
  resetUserRedeems(userId);
  Database.addLog({ type: 'reset_redeems', targetId: userId, adminId: interaction.user.id });
  await interaction.reply(successMsg(`✅ Resgates de <@${userId}> resetados.`, 'admin_users', '← Voltar'));
}

async function handleBlacklistAdd(interaction) {
  const userId = getField(interaction, 'user_id').replace(/[<@!>]/g, '');
  const reason = getField(interaction, 'reason');
  Database.addToBlacklist(userId, reason, interaction.user.id);
  Database.addLog({ type: 'blacklist_add', targetId: userId, adminId: interaction.user.id, reason });
  await interaction.reply(successMsg(`🚫 <@${userId}> adicionado à blacklist.\nMotivo: *${reason}*`, 'admin_blacklist', '← Voltar'));
}

async function handleBlacklistRemove(interaction) {
  const userId = getField(interaction, 'user_id').replace(/[<@!>]/g, '');
  Database.removeFromBlacklist(userId);
  Database.addLog({ type: 'blacklist_remove', targetId: userId, adminId: interaction.user.id });
  await interaction.reply(successMsg(`✅ <@${userId}> removido da blacklist.`, 'admin_blacklist', '← Voltar'));
}

async function handleSetLink(interaction) {
  const url    = getField(interaction, 'link_url');
  const label  = getField(interaction, 'link_label');
  const button = getField(interaction, 'link_button');

  if (!url.startsWith('http')) {
    return interaction.reply({ content: '❌ URL inválida. Use uma URL completa (https://...).', ephemeral: true });
  }

  const cfg = config.get();
  cfg.link = { url, label, buttonLabel: button };
  config.save(cfg);

  Database.addLog({ type: 'config_link', adminId: interaction.user.id, url });
  await interaction.reply(successMsg(
    `✅ **Link principal atualizado!**\n> **Label:** ${label}\n> **URL:** ${url}\n> **Botão:** ${button}`,
    'admin_settings', '← Voltar'
  ));
}

async function handleTestInvite(interaction) {
  const userId      = getField(interaction, 'user_id');
  const inviteCount = parseInt(getField(interaction, 'invite_count'));

  if (!userId || !/^\d{17,20}$/.test(userId)) {
    return interaction.reply({ content: '❌ ID de usuário inválido.', ephemeral: true });
  }
  if (isNaN(inviteCount) || inviteCount < 1 || inviteCount > 9999) {
    return interaction.reply({ content: '❌ Quantidade inválida (1–9999).', ephemeral: true });
  }

  const user = Database.getUser(userId);
  user.invites = (user.invites || 0) + inviteCount;
  user.testInvites = (user.testInvites || 0) + inviteCount;
  Database.saveUser(userId, user);
  Database.addLog({ type: 'test_invite', adminId: interaction.user.id, targetId: userId, count: inviteCount });

  const cfg = config.get();
  const em  = cfg.appearance.emojis;
  const totalValid = Math.max(0, (user.invites || 0) - (user.fakeInvites || 0) - (user.leftInvites || 0));
  const nextGoal   = (cfg.goals || []).filter(g => g.invites > totalValid).sort((a, b) => a.invites - b.invites)[0];

  await interaction.reply(successMsg(
    `✅ **Convites simulados com sucesso!**\n` +
    `> ${em.user} Usuário: <@${userId}>\n` +
    `> ${em.invite} Convites adicionados: \`+${inviteCount}\`\n` +
    `> ${em.invite} Total válido agora: \`${totalValid}\`\n` +
    `> ${nextGoal ? `${em.reward} Próxima meta: **${nextGoal.label}** (faltam \`${nextGoal.invites - totalValid}\` convites)` : `${em.crown} Usuário atingiu todas as metas!`}`,
    'admin_test', '← Voltar aos Testes'
  ));
}

async function handleTestReset(interaction) {
  const userId = getField(interaction, 'user_id');

  if (!userId || !/^\d{17,20}$/.test(userId)) {
    return interaction.reply({ content: '❌ ID de usuário inválido.', ephemeral: true });
  }

  const user = Database.getUser(userId);
  const testInvites = user.testInvites || 0;
  if (testInvites === 0) {
    return interaction.reply({ content: `ℹ️ <@${userId}> não tem convites de teste para resetar.`, ephemeral: true });
  }

  user.invites   = Math.max(0, (user.invites || 0) - testInvites);
  user.testInvites = 0;
  user.redeemed  = false;
  Database.saveUser(userId, user);
  Database.addLog({ type: 'test_reset', adminId: interaction.user.id, targetId: userId, removed: testInvites });

  const cfg = config.get();
  const em  = cfg.appearance.emojis;
  await interaction.reply(successMsg(
    `✅ **Reset de teste concluído!**\n` +
    `> ${em.user} Usuário: <@${userId}>\n` +
    `> ${em.invite} Convites de teste removidos: \`${testInvites}\`\n` +
    `> ${em.success} Resgate resetado para novo teste`,
    'admin_test', '← Voltar aos Testes'
  ));
}

async function handleSetColor(interaction) {
  const hex = getField(interaction, 'color_hex');

  if (!validateHex(hex)) {
    return interaction.reply({ content: '❌ Cor inválida. Use formato hex: `#00ff87` ou `00ff87`', ephemeral: true });
  }

  const colorInt = hexToInt(hex);
  const cleanHex = '#' + hex.replace(/^#/, '').toUpperCase();

  const cfg = config.get();
  cfg.appearance.primaryColor = colorInt;
  cfg.appearance.primaryColorHex = cleanHex;
  config.save(cfg);

  Database.addLog({ type: 'config_color', adminId: interaction.user.id, color: cleanHex });
  await interaction.reply(successMsg(
    `✅ **Cor principal atualizada!**\n> Nova cor: \`${cleanHex}\``,
    'admin_personalization', '← Voltar'
  ));
}

async function handleSetBotTexts(interaction) {
  const panelTitle    = getField(interaction, 'panel_title');
  const panelDesc     = getField(interaction, 'panel_desc');
  const deliveryTitle = getField(interaction, 'delivery_title');
  const deliveryDesc  = getField(interaction, 'delivery_desc');

  const cfg = config.get();
  if (!cfg.bot) cfg.bot = {};
  if (panelTitle)    cfg.bot.rewardPanelTitle = panelTitle;
  if (panelDesc)     cfg.bot.rewardPanelDescription = panelDesc;
  if (deliveryTitle) cfg.bot.deliveryTitle = deliveryTitle;
  if (deliveryDesc)  cfg.bot.deliveryDescription = deliveryDesc;
  config.save(cfg);

  Database.addLog({ type: 'config_bot', adminId: interaction.user.id });
  await interaction.reply(successMsg(
    `✅ **Textos do bot atualizados!**\n` +
    `> Painel: *${cfg.bot.rewardPanelTitle}*\n` +
    `> Entrega: *${cfg.bot.deliveryTitle}*`,
    'admin_personalization', '← Voltar'
  ));
}

async function handleSetMessages(interaction) {
  const noStock        = getField(interaction, 'no_stock');
  const alreadyRedeem  = getField(interaction, 'already_redeemed');
  const blacklisted    = getField(interaction, 'blacklisted');
  const redeemSuccess  = getField(interaction, 'redeem_success');

  const cfg = config.get();
  if (noStock)       cfg.appearance.messages.noStock = noStock;
  if (alreadyRedeem) cfg.appearance.messages.alreadyRedeemed = alreadyRedeem;
  if (blacklisted)   cfg.appearance.messages.blacklisted = blacklisted;
  if (redeemSuccess) cfg.appearance.messages.redeemSuccess = redeemSuccess;
  config.save(cfg);

  Database.addLog({ type: 'config_messages', adminId: interaction.user.id });
  await interaction.reply(successMsg('✅ **Mensagens personalizadas atualizadas!**', 'admin_personalization', '← Voltar'));
}

async function handleSetEmojis1(interaction) {
  const fields = ['robux', 'invite', 'reward', 'stock', 'crown'];
  const cfg = config.get();
  for (const f of fields) {
    const val = getField(interaction, f);
    if (val) cfg.appearance.emojis[f] = val;
  }
  config.save(cfg);
  Database.addLog({ type: 'config_emojis', adminId: interaction.user.id });
  await interaction.reply(successMsg('✅ **Emojis (1/2) atualizados!**', 'admin_personalization', '← Voltar'));
}

async function handleSetEmojis2(interaction) {
  const fields = ['success', 'error', 'shield', 'fire', 'review'];
  const cfg = config.get();
  for (const f of fields) {
    const val = getField(interaction, f);
    if (val) cfg.appearance.emojis[f] = val;
  }
  config.save(cfg);
  Database.addLog({ type: 'config_emojis', adminId: interaction.user.id });
  await interaction.reply(successMsg('✅ **Emojis (2/2) atualizados!**', 'admin_personalization', '← Voltar'));
}

module.exports = { handleModal };
