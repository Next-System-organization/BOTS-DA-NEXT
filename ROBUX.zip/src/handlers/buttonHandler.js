const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  MessageFlags,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const adminPanel = require('../panels/adminPanel');
const { buildUserProgressEmbed, buildGoalSelectMessage } = require('../layouts/rewardLayout');
const { isAdmin } = require('../security/validator');
const { checkSpam } = require('../security/antiSpam');
const { formatNumber } = require('../utils/formatter');
const Database = require('../database/Database');
const config = require('../config/loader');
const logger = require('../utils/logger');

async function handleButton(interaction, client) {
  const { customId, member, user } = interaction;

  if (checkSpam(user.id)) {
    return interaction.reply({ content: '⚠️ Muitas ações em sequência. Aguarde alguns segundos.', ephemeral: true });
  }

  const isAdminAction = customId.startsWith('admin_');
  if (isAdminAction && !isAdmin(member)) {
    return interaction.reply({ content: '❌ Sem permissão para acessar o painel administrativo.', ephemeral: true });
  }

  try {
    switch (true) {
      case customId === 'reward_myinvites':         return handleMyInvites(interaction);
      case customId === 'reward_redeem_select':     return handleRedeemSelect(interaction);
      case customId === 'reward_panel_back':        return handlePanelBack(interaction);
      case customId === 'reward_leaderboard':       return handleLeaderboard(interaction);
      case customId.startsWith('reward_claim:'):   return handleClaim(interaction);

      case customId === 'admin_main':              return interaction.update(adminPanel.buildMainPanel());
      case customId === 'admin_stock':             return interaction.update(adminPanel.buildStockPanel());
      case customId === 'admin_goals':             return interaction.update(adminPanel.buildGoalsPanel());
      case customId === 'admin_users':             return interaction.update(adminPanel.buildUsersPanel());
      case customId === 'admin_blacklist':         return interaction.update(adminPanel.buildBlacklistPanel());
      case customId === 'admin_logs':              return interaction.update(adminPanel.buildLogsPanel());
      case customId === 'admin_settings':          return interaction.update(adminPanel.buildSettingsPanel());
      case customId === 'admin_personalization':   return interaction.update(adminPanel.buildPersonalizationPanel());
      case customId === 'admin_toggle_systems':    return interaction.update(adminPanel.buildToggleSystemsPanel());

      case customId === 'admin_stock_add':         return openModal(interaction, 'modal_stock_add', 'Adicionar ao Estoque', [
        field('amount', 'Quantidade de Robux', 'Ex: 50000', true),
        field('reason', 'Motivo (opcional)', 'Adição de estoque', false),
      ]);
      case customId === 'admin_stock_remove':      return openModal(interaction, 'modal_stock_remove', 'Remover do Estoque', [
        field('amount', 'Quantidade de Robux', 'Ex: 10000', true),
        field('reason', 'Motivo (opcional)', 'Remoção de estoque', false),
      ]);
      case customId === 'admin_stock_set':         return openModal(interaction, 'modal_stock_set', 'Definir Estoque Total', [
        field('amount', 'Novo valor total (Robux)', 'Ex: 5000000', true),
      ]);

      case customId.startsWith('admin_goal_edit:'): return handleGoalEdit(interaction);
      case customId === 'admin_goal_add':           return openModal(interaction, 'modal_goal_add', 'Adicionar Nova Meta', [
        field('label', 'Nome da meta', 'Ex: Lendário', true),
        field('invites', 'Convites necessários', 'Ex: 150', true),
        field('robux', 'Robux da recompensa', 'Ex: 200000', true),
      ]);
      case customId === 'admin_goal_delete':        return handleGoalDeleteLast(interaction);

      case customId === 'admin_user_lookup':        return openModal(interaction, 'modal_user_lookup', 'Buscar Usuário', [
        field('user_id', 'ID do usuário', 'Ex: 123456789012345678', true),
      ]);
      case customId === 'admin_user_reset':         return openModal(interaction, 'modal_user_reset', 'Resetar Resgates de Usuário', [
        field('user_id', 'ID do usuário', 'Ex: 123456789012345678', true),
      ]);
      case customId === 'admin_reset':             return handleResetConfirm(interaction);
      case customId === 'admin_reset_confirm':     return handleResetAll(interaction);

      case customId === 'admin_bl_add':            return openModal(interaction, 'modal_bl_add', 'Adicionar à Blacklist', [
        field('user_id', 'ID do usuário', 'Ex: 123456789012345678', true),
        field('reason', 'Motivo', 'Ex: fraude de convites', true),
      ]);
      case customId === 'admin_bl_remove':         return openModal(interaction, 'modal_bl_remove', 'Remover da Blacklist', [
        field('user_id', 'ID do usuário', 'Ex: 123456789012345678', true),
      ]);

      case customId === 'admin_set_channels':      return interaction.update(adminPanel.buildChannelConfigPanel());
      case customId === 'admin_set_roles':         return interaction.update(adminPanel.buildRoleConfigPanel());
      case customId === 'admin_set_link':          return handleSetLinkModal(interaction);

      case customId === 'admin_set_color':         return openModal(interaction, 'modal_set_color', 'Definir Cor Principal', [
        field('color_hex', 'Cor em hex (ex: #00FF87 ou 00FF87)', 'Ex: #00ff87', true),
      ]);
      case customId === 'admin_set_bot_texts':     return handleSetBotTextsModal(interaction);
      case customId === 'admin_set_messages':      return handleSetMessagesModal(interaction);
      case customId === 'admin_set_emojis1':       return handleSetEmojis1Modal(interaction);
      case customId === 'admin_set_emojis2':       return handleSetEmojis2Modal(interaction);

      case customId.startsWith('admin_toggle:'):  return handleToggleSystem(interaction);

      case customId === 'admin_test':             return interaction.update(adminPanel.buildTestPanel());
      case customId === 'admin_test_invite':      return openModal(interaction, 'modal_test_invite', 'Simular Convite', [
        field('user_id',       'ID do usuário',          'Ex: 123456789012345678', true),
        field('invite_count',  'Quantidade de convites', 'Ex: 10',                 true),
      ]);
      case customId === 'admin_test_panel':       return handleTestPanel(interaction);
      case customId === 'admin_test_reset':       return openModal(interaction, 'modal_test_reset', 'Reset de Teste', [
        field('user_id', 'ID do usuário a resetar', 'Ex: 123456789012345678', true),
      ]);

      default: break;
    }
  } catch (err) {
    logger.error('Erro buttonHandler:', err.message);
    const reply = { content: `❌ Erro: ${err.message}`, ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(reply).catch(() => {});
    } else {
      await interaction.reply(reply).catch(() => {});
    }
  }
}

function field(id, label, placeholder, required, long = false, value = undefined) {
  const input = new TextInputBuilder()
    .setCustomId(id)
    .setLabel(label.slice(0, 45))
    .setStyle(long ? TextInputStyle.Paragraph : TextInputStyle.Short)
    .setPlaceholder(placeholder.slice(0, 100))
    .setRequired(required);
  if (value !== undefined) input.setValue(String(value));
  return new ActionRowBuilder().addComponents(input);
}

async function openModal(interaction, id, title, rows) {
  const modal = new ModalBuilder().setCustomId(id).setTitle(title.slice(0, 45)).addComponents(...rows);
  await interaction.showModal(modal);
}

async function handleMyInvites(interaction) {
  await interaction.reply(buildUserProgressEmbed(interaction.user.id));
}

async function handleRedeemSelect(interaction) {
  await interaction.reply(buildGoalSelectMessage(interaction.user.id));
}

async function handlePanelBack(interaction) {
  const { buildRewardPanel } = require('../layouts/rewardLayout');
  await interaction.reply({ ...buildRewardPanel(), ephemeral: true });
}

async function handleLeaderboard(interaction) {
  const { getLeaderboard, formatLeaderboardText } = require('../systems/leaderboard');
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const top = getLeaderboard(15);
  const text = formatLeaderboardText(top);
  const container = new ContainerBuilder()
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${em.crown} Top 15 — Ranking de Convites\n${text}`));
  await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true });
}

async function handleClaim(interaction) {
  const goalIndex = parseInt(interaction.customId.split(':')[1]);
  const modal = new ModalBuilder()
    .setCustomId(`modal_claim:${goalIndex}`)
    .setTitle('Resgatar Recompensa')
    .addComponents(
      field('roblox_nick', 'Seu username no Roblox', 'Ex: NomeDeConta123', true)
    );
  await interaction.showModal(modal);
}

async function handleGoalEdit(interaction) {
  const goalIndex = parseInt(interaction.customId.split(':')[1]);
  const cfg = config.get();
  const goal = cfg.goals[goalIndex];
  if (!goal) return interaction.reply({ content: '❌ Meta não encontrada.', ephemeral: true });

  const modal = new ModalBuilder()
    .setCustomId(`modal_goal_edit:${goalIndex}`)
    .setTitle(`Editar Meta: ${goal.label}`)
    .addComponents(
      field('label', 'Nome da meta', goal.label, true, false, goal.label),
      field('invites', 'Convites necessários', String(goal.invites), true, false, goal.invites),
      field('robux', 'Robux da recompensa', String(goal.robux), true, false, goal.robux),
    );
  await interaction.showModal(modal);
}

async function handleGoalDeleteLast(interaction) {
  const cfg = config.get();
  if (!cfg.goals.length) return interaction.reply({ content: '❌ Nenhuma meta para remover.', ephemeral: true });
  const removed = cfg.goals.pop();
  config.save(cfg);
  Database.addLog({ type: 'config_goals', adminId: interaction.user.id, action: 'delete', label: removed.label });

  const container = new ContainerBuilder()
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`✅ Meta **${removed.label}** removida com sucesso.`))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('admin_goals').setLabel('← Voltar às Metas').setStyle(ButtonStyle.Secondary)
      )
    );
  await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 });
}

async function handleResetConfirm(interaction) {
  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ⚠️ Confirmar Reset Geral\n\nIsso vai resetar os resgates de **TODOS** os usuários. Tem certeza?`
      )
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('admin_reset_confirm').setLabel('✅ Sim, resetar tudo').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('admin_users').setLabel('❌ Cancelar').setStyle(ButtonStyle.Secondary),
      )
    );
  await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 });
}

async function handleResetAll(interaction) {
  const { resetAllRedeems } = require('../systems/rewardSystem');
  resetAllRedeems();
  const container = new ContainerBuilder()
    .addTextDisplayComponents(new TextDisplayBuilder().setContent('✅ **Todos os resgates foram resetados.**'))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('admin_main').setLabel('← Voltar').setStyle(ButtonStyle.Secondary)
      )
    );
  await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 });
}

async function handleSetLinkModal(interaction) {
  const cfg = config.get();
  const link = cfg.link || {};
  const modal = new ModalBuilder()
    .setCustomId('modal_set_link')
    .setTitle('Configurar Link Principal')
    .addComponents(
      field('link_url', 'URL completa do link', 'Ex: https://discord.gg/...', true, false, link.url || ''),
      field('link_label', 'Descrição do link (texto)', 'Ex: Acessar Grupo Roblox', true, false, link.label || ''),
      field('link_button', 'Label do botão', 'Ex: 🎮 Acessar Grupo', true, false, link.buttonLabel || ''),
    );
  await interaction.showModal(modal);
}

async function handleTestPanel(interaction) {
  const { buildRewardPanel } = require('../layouts/rewardLayout');
  const panel = buildRewardPanel();
  await interaction.reply({ ...panel, ephemeral: true });
}

async function handleSetBotTextsModal(interaction) {
  const cfg = config.get();
  const bot = cfg.bot || {};
  const modal = new ModalBuilder()
    .setCustomId('modal_set_bot_texts')
    .setTitle('Textos do Bot')
    .addComponents(
      field('panel_title', 'Título do painel de recompensas', 'Ex: Sistema de Recompensas', true, false, bot.rewardPanelTitle || ''),
      field('panel_desc', 'Descrição do painel', 'Ex: Convide e ganhe!', true, false, bot.rewardPanelDescription || ''),
      field('delivery_title', 'Título da mensagem de entrega', 'Ex: Entrega Confirmada', true, false, bot.deliveryTitle || ''),
      field('delivery_desc', 'Descrição da entrega', 'Ex: Sucesso!', true, false, bot.deliveryDescription || ''),
    );
  await interaction.showModal(modal);
}

async function handleSetMessagesModal(interaction) {
  const cfg = config.get();
  const msgs = cfg.appearance.messages;
  const modal = new ModalBuilder()
    .setCustomId('modal_set_messages')
    .setTitle('Mensagens Personalizadas')
    .addComponents(
      field('no_stock', 'Mensagem: sem estoque', 'Ex: Estoque indisponível.', true, false, msgs.noStock),
      field('already_redeemed', 'Mensagem: já resgatou', 'Ex: Já foi resgatado.', true, false, msgs.alreadyRedeemed),
      field('blacklisted', 'Mensagem: blacklist', 'Ex: Sem permissão.', true, false, msgs.blacklisted),
      field('redeem_success', 'Mensagem: resgate ok', 'Ex: Sucesso!', true, false, msgs.redeemSuccess),
    );
  await interaction.showModal(modal);
}

async function handleSetEmojis1Modal(interaction) {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const modal = new ModalBuilder()
    .setCustomId('modal_set_emojis1')
    .setTitle('Emojis (1/2)')
    .addComponents(
      field('robux', 'Emoji: robux', '💎', true, false, em.robux),
      field('invite', 'Emoji: invite', '📨', true, false, em.invite),
      field('reward', 'Emoji: reward', '🎁', true, false, em.reward),
      field('stock', 'Emoji: stock', '📦', true, false, em.stock),
      field('crown', 'Emoji: crown', '👑', true, false, em.crown),
    );
  await interaction.showModal(modal);
}

async function handleSetEmojis2Modal(interaction) {
  const cfg = config.get();
  const em = cfg.appearance.emojis;
  const modal = new ModalBuilder()
    .setCustomId('modal_set_emojis2')
    .setTitle('Emojis (2/2)')
    .addComponents(
      field('success', 'Emoji: success', '✅', true, false, em.success),
      field('error', 'Emoji: error', '❌', true, false, em.error),
      field('shield', 'Emoji: shield', '🛡️', true, false, em.shield),
      field('fire', 'Emoji: fire', '🔥', true, false, em.fire),
      field('review', 'Emoji: review', '⭐', true, false, em.review),
    );
  await interaction.showModal(modal);
}

async function handleToggleSystem(interaction) {
  const systemKey = interaction.customId.split(':')[1];
  const cfg = config.get();

  if (cfg.systems[systemKey] === undefined) {
    return interaction.reply({ content: '❌ Sistema não encontrado.', ephemeral: true });
  }

  cfg.systems[systemKey] = !cfg.systems[systemKey];
  config.save(cfg);

  Database.addLog({ type: `toggle_${systemKey}`, adminId: interaction.user.id, value: cfg.systems[systemKey] });
  await interaction.update(adminPanel.buildToggleSystemsPanel());
}

module.exports = { handleButton };
