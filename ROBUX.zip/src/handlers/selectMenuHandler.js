const { isAdmin } = require('../security/validator');
const config = require('../config/loader');
const Database = require('../database/Database');
const logger = require('../utils/logger');

async function handleChannelSelect(interaction) {
  if (!isAdmin(interaction.member)) {
    return interaction.reply({ content: '❌ Sem permissão.', flags: 64 });
  }

  const { customId, values } = interaction;
  const cfg = config.get();

  const map = {
    select_channel_rewards:       'rewards',
    select_channel_logs:          'logs',
    select_channel_reviews:       'reviews',
    select_channel_announcements: 'announcements',
  };

  const key = map[customId];
  if (key) {
    cfg.channels[key] = values[0] || null;
    config.save(cfg);
    Database.addLog({ type: 'config_channels', adminId: interaction.user.id, channel: key, value: values[0] || null });
    logger.system(`Canal ${key} configurado: ${values[0] || 'removido'}`);
  }

  const { buildChannelConfigPanel } = require('../panels/adminPanel');
  await interaction.update(buildChannelConfigPanel());
}

async function handleRoleSelect(interaction) {
  if (!isAdmin(interaction.member)) {
    return interaction.reply({ content: '❌ Sem permissão.', flags: 64 });
  }

  const { customId, values } = interaction;
  const cfg = config.get();
  if (!cfg.roles) cfg.roles = {};

  if (customId === 'select_role_admin') {
    cfg.roles.admin = values;
    Database.addLog({ type: 'config_roles', adminId: interaction.user.id, role: 'admin', count: values.length });
  } else if (customId === 'select_role_moderator') {
    cfg.roles.moderator = values;
    Database.addLog({ type: 'config_roles', adminId: interaction.user.id, role: 'moderator', count: values.length });
  }

  config.save(cfg);
  logger.system(`Cargos ${customId} configurados: ${values.length} selecionado(s)`);

  const { buildRoleConfigPanel } = require('../panels/adminPanel');
  await interaction.update(buildRoleConfigPanel());
}

module.exports = { handleChannelSelect, handleRoleSelect };
