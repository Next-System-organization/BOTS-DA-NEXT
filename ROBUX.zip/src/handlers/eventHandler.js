const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

async function loadEvents(client) {
  const eventsDir = path.join(__dirname, '..', 'events');
  const files = fs.readdirSync(eventsDir).filter(f => f.endsWith('.js'));

  let count = 0;
  for (const file of files) {
    const event = require(path.join(eventsDir, file));
    if (!event.name || !event.execute) {
      logger.warn(`Evento inválido: ${file}`);
      continue;
    }
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args, client));
    } else {
      client.on(event.name, (...args) => event.execute(...args, client));
    }
    count++;
    logger.success(`Evento carregado: ${event.name}`);
  }
  logger.system(`${count} eventos carregados`);
}

module.exports = { loadEvents };
