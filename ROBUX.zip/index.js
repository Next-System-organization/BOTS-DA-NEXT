const { Client, GatewayIntentBits, Partials } = require('discord.js');
const { loadEvents } = require('./src/handlers/eventHandler');
const config = require('./src/config/loader');
const logger = require('./src/utils/logger');
const fs = require('fs');
const path = require('path');

process.on('uncaughtException', err => {
  logger.error('Exceção não capturada:', err.message);
});

process.on('unhandledRejection', err => {
  logger.error('Promise rejeitada:', err?.message || err);
});

function ensureDataFiles() {
  const dataDir = path.join(__dirname, 'data');
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

  const defaults = {
    'users.json': {},
    'invites.json': {},
    'stock.json': { total: 10000000, reserved: 0, movements: [] },
    'rewards.json': { redeems: [], total: 0, totalRobux: 0 },
    'logs.json': { entries: [] },
    'blacklist.json': { users: [], reasons: {} },
    'reviews.json': { reviews: [], totalRatings: 0, averageRating: 0, ratingCount: 0 },
    'deliveries.json': { deliveries: [] },
  };

  for (const [file, def] of Object.entries(defaults)) {
    const fp = path.join(dataDir, file);
    if (!fs.existsSync(fp)) {
      fs.writeFileSync(fp, JSON.stringify(def, null, 2));
    }
  }
}

async function main() {
  logger.banner();

  const steps = [
    'Verificando arquivos de dados...',
    'Carregando configurações...',
    'Inicializando cliente Discord...',
    'Carregando eventos...',
    'Conectando ao Discord...',
  ];

  logger.loader(1, steps.length, steps[0]);
  ensureDataFiles();
  await delay(100);

  logger.loader(2, steps.length, steps[1]);
  const cfg = config.load();
  await delay(100);

  if (!cfg.token || cfg.token === 'YOUR_BOT_TOKEN_HERE') {
    logger.error('Token não configurado! Edite data/config.json e defina o token.');
    process.exit(1);
  }
  if (!cfg.clientId || cfg.clientId === 'YOUR_CLIENT_ID_HERE') {
    logger.error('clientId não configurado! Edite data/config.json.');
    process.exit(1);
  }
  if (!cfg.guildId || cfg.guildId === 'YOUR_GUILD_ID_HERE') {
    logger.error('guildId não configurado! Edite data/config.json.');
    process.exit(1);
  }

  logger.loader(3, steps.length, steps[2]);
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildInvites,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
    partials: [Partials.GuildMember],
  });
  await delay(100);

  logger.loader(4, steps.length, steps[3]);
  await loadEvents(client);
  await delay(100);

  logger.loader(5, steps.length, steps[4]);

  client.login(cfg.token).catch(err => {
    logger.error('Falha ao conectar:', err.message);
    process.exit(1);
  });
}

function delay(ms) {
  return new Promise(r => setTimeout(r, ms));
}

main();
