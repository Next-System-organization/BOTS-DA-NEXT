## BOT DE RECOMPENSAS DE R0BUX F4K3

-# ~~                                                                                                                                                                           ~~
### COMANDO DE CONFIGURAÇÃO

### -# - /admin - Painel de configuração do bot de R0BUX.

-# ~~                                                                                                                                                                           ~~
### INFORMAÇÕES DO BOT
### -# - Bot full comp V2
### -# - Bot feito 100% por mim, <@Ayann> .
### -# - Consiga membros com esse bot.

-# ~~                                                                                                                                                                           ~~