const { ApplicationCommandType } = require("discord.js");
const { owner } = require("../../config.json");

module.exports = {
  name: "painel_cloner",
  description: "[🤖] Envie o painel de clonagem.",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    if (interaction.user.id !== owner) {
      return interaction.reply({
        content: "<:no:1409545199461597337> Você não tem permissão para usar este comando.",
        ephemeral: true,
      });
    }

    try {
      await interaction.reply({
        content: "<:yes:1422213840136966254> Sucesso",
        ephemeral: true,
      });

      const BotFoto = "https://media.discordapp.net/attachments/1417672870334566440/1424942334839357501/Sem_titulo-removebg-preview.png?ex=68eb0e76&is=68e9bcf6&hm=0663f30036bf627f56b82da2dd770134f462e17ef963af4a475d80e094ea3909&=&format=webp&quality=lossless"

      await interaction.channel.send({
        content: "",
        components: [
          {
            type: 17,
            components: [
              {
                type: 9,
                accessory: {
                  type: 11,
                  media: {
                    url: BotFoto,
                  },
                  description: null,
                  spoiler: false,
                },
                components: [
                  {
                    type: 10,
                    content: `## Painel de Clonagem\n> Olá, Membro! Utilize os botões abaixo para acessar o painel de clonagem.`,
                  },
                  {
                    type: 10,
                    content: "## Ensinamentos\n • Necessário ID do servidor que será clonado e do servidor que irá receber.\n • A conta precisa estar presente em ambos os servidores.\n • O token da conta será exigido!",
                  },
                ],
              },
              {
                type: 14,
                spacing: 1,
                divider: true,
              },
              {
                type: 1,
                components: [
                  {
                    type: 2,
                    custom_id: "panel_cloner",
                    label: "Clonar Servidor",
                    style: 2,
                    emoji: {
                      id: "1426559071233773621",
                    },
                  },
                  {
                    type: 2,
                    custom_id: "clonersite",
                    label: "Clonar Site",
                    style: 2,
                    emoji: {
                      id: "1426559071233773621",
                      
                    },
                  },
                  {
                    type: 2,
                    label: "Ajuda?",
                    style: 5,
                    url: "https://discord.com/channels/1419103210559504494/1419810403969662997",
                    emoji: {
                      id: "1425167713973702858",
                      
                    },
                  },                
                ],
              },
              {
                type: 10,
                content: "-# Quem for o engraçadnho de usar o nosso cloner para clonar o nosso servidor vai rodar !",
              },
            ],
          },
        ],
        flags: 32768,
      });

    } catch (error) {
      console.error("Erro:", error);
      if (!interaction.replied) {
        await interaction.reply({
          content: "<:no:1409545199461597337> Vish deu erro aqui pae",
          ephemeral: true,
        });
      }
    }
  }, 
};
