const { JsonDatabase } = require("wio.db");
const { QuickDB } = require("quick.db");
const path = require("path");
const fs = require("fs");

const db = new JsonDatabase({ databasePath: path.join(__dirname, "configuration.json") });
const lg = new QuickDB({ filePath: path.join(__dirname, "logs.sqlite") });

const tempPath = path.join(__dirname, "temporario.json");
function getTempData(userId) {
    let all = {};
    try { all = JSON.parse(fs.readFileSync(tempPath, 'utf8')); } catch {}
    return all[userId] || {};
}
function setTempData(userId, data) {
    let all = {};
    try { all = JSON.parse(fs.readFileSync(tempPath, 'utf8')); } catch {}
    all[userId] = data;
    fs.writeFileSync(tempPath, JSON.stringify(all, null, 2));
}
function deleteTempData(userId) {
    let all = {};
    try { all = JSON.parse(fs.readFileSync(tempPath, 'utf8')); } catch {}
    delete all[userId];
    fs.writeFileSync(tempPath, JSON.stringify(all, null, 2));
}

const sendPath = path.join(__dirname, "sendmembers.json");
function getSentMembers(userId) {
    let all = {};
    try { all = JSON.parse(fs.readFileSync(sendPath, 'utf8')); } catch {}
    return Array.isArray(all[userId]) ? all[userId] : [];
}
function addSentMember(userId, memberId) {
    let all = {};
    try { all = JSON.parse(fs.readFileSync(sendPath, 'utf8')); } catch {}
    if (!Array.isArray(all[userId])) all[userId] = [];
    if (!all[userId].includes(memberId)) all[userId].push(memberId);
    fs.writeFileSync(sendPath, JSON.stringify(all, null, 2));
}
function clearSentMembers(userId) {
    let all = {};
    try { all = JSON.parse(fs.readFileSync(sendPath, 'utf8')); } catch {}
    delete all[userId];
    fs.writeFileSync(sendPath, JSON.stringify(all, null, 2));
}

// O banco agora armazena configurações individuais por usuário: tokens_<userId>, guildId_<userId>, etc.

module.exports = {
    db,
    lg,
    getTempData,
    setTempData,
    deleteTempData,
    getSentMembers,
    addSentMember,
    clearSentMembers
}; 