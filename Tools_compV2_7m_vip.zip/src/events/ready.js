module.exports = (client) => {
  console.log('\x1b[32m[BOT] Online como ' + client.user.tag + '\x1b[0m');
  client.user.setPresence({
    activities: [{ name: 'discord.gg/ferramentas', type: 0 }],
    status: 'online',
  })
  .then(() => console.log('Presença definida com sucesso!'))
  .catch(console.error);

  if (client.application && client.application.edit) {
    client.application.edit({ description: '**Desenvolvido por eumendesdev**\nhttps://discord.gg/xMEgUn3cFS' }).catch(() => {});
  }
};