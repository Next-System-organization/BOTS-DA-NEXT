const { gerarEstruturaServidorIA, startBotIA } = require('../functions/ServidoresIA');
const { PermissionsBitField, ChannelType, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../config.json');
let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const tempPath = path.join(__dirname, '../database/servidoresiatemp.json');

function loadTempDB() {
    try {
        return JSON.parse(fs.readFileSync(tempPath, 'utf8'));
    } catch {
        return {};
    }
}

function saveTempDB(db) {
    fs.writeFileSync(tempPath, JSON.stringify(db, null, 2));
}

function setTempEstrutura(userId, prompt, estrutura) {
    const db = loadTempDB();
    db[userId] = { prompt, estrutura, timestamp: Date.now() };
    saveTempDB(db);
}

function getTempEstrutura(userId) {
    const db = loadTempDB();
    return db[userId];
}

function removeTempEstrutura(userId) {
    const db = loadTempDB();
    delete db[userId];
    saveTempDB(db);
}

/**
 * Handler para criar sugestão de servidor via IA.
 * @param {string} promptUsuario - O que o usuário descreveu.
 * @param {string} userId - ID do usuário para armazenar temporariamente.
 * @returns {Promise<object>} - Estrutura sugerida pela IA (parseada).
 */
async function sugerirServidorIA(promptUsuario, userId) {
    const sugestao = await gerarEstruturaServidorIA(promptUsuario);
    let estrutura;
    try {
        estrutura = typeof sugestao === 'string' ? JSON.parse(sugestao) : sugestao;
    } catch {
        estrutura = { texto: sugestao };
    }
    setTempEstrutura(userId, promptUsuario, estrutura);
    return estrutura;
}

/**
 * Cria cargos, categorias, canais e log único no servidor com base na estrutura da IA.
 * @param {string} userId - ID do usuário para buscar estrutura temporária.
 * @param {string} guildId - ID do servidor de destino.
 * @param {Interaction} interaction - Interação para feedback.
 */
async function criarServidorComEstruturaIA(userId, guildId, interaction) {
    config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    const temp = getTempEstrutura(userId);
    if (!temp || !temp.estrutura) {
        await interaction.followUp({ content: '❌ Estrutura não encontrada. Gere uma sugestão primeiro.', flags: 64 });
        return;
    }
    // Inicia o bot IA e busca o guild
    const botIA = await startBotIA();
    let guild = botIA.guilds.cache.get(guildId);
    if (!guild) {
        try {
            guild = await botIA.guilds.fetch(guildId);
        } catch {
            await interaction.followUp({ content: '❌ O bot IA não está no servidor de destino.', flags: 64 });
            return;
        }
    }
    const estrutura = temp.estrutura;
    let logChannel = null;
    if (config["log-ia"]) {
        try {
            logChannel = guild.channels.cache.get(config["log-ia"]) || await guild.channels.fetch(config["log-ia"]);
        } catch {}
    }
    if (!logChannel && config.log_clonagem) {
        try {
            logChannel = guild.channels.cache.get(config.log_clonagem) || await guild.channels.fetch(config.log_clonagem);
        } catch {}
    }
    // Sempre criar tudo
    const cargosCriados = [];
    const categoriasCriadas = [];
    const canaisCriados = [];
    try {
        // 1. Criar cargos
        if (estrutura.cargos && Array.isArray(estrutura.cargos)) {
            for (const nomeCargo of estrutura.cargos) {
                if (!guild.roles.cache.find(r => r.name === nomeCargo)) {
                    const role = await guild.roles.create({ name: nomeCargo, reason: 'Criado pela IA' });
                    cargosCriados.push(role.name);
                }
            }
        }
        // 2. Criar categorias e canais
        if (estrutura.categorias && Array.isArray(estrutura.categorias)) {
            for (const cat of estrutura.categorias) {
                let categoria = await guild.channels.create({
                    name: cat.nome,
                    type: ChannelType.GuildCategory,
                    reason: 'Criado pela IA'
                });
                categoriasCriadas.push(categoria.name);
                if (cat.canais && Array.isArray(cat.canais)) {
                    for (const canalNome of cat.canais) {
                        const canal = await guild.channels.create({
                            name: canalNome,
                            type: ChannelType.GuildText,
                            parent: categoria ? categoria.id : undefined,
                            reason: 'Criado pela IA'
                        });
                        canaisCriados.push(`${canal.name}${categoria ? ` (Categoria: ${categoria.name})` : ''}`);
                    }
                }
            }
        }
        await interaction.followUp({ content: '`✅` Estrutura criada com sucesso!', flags: 64 });
        // Log único
        if (logChannel) {
            const embed = new EmbedBuilder()
                .setTitle('🛠️ [LOG - IA] Estrutura de Servidor Criada')
                .setColor(0x1E90FF)
                .setDescription(`👤 **Usuário:** <@${interaction.user.id}> (${interaction.user.id})\n🕒 **Data/Hora:** <t:${Math.floor(Date.now()/1000)}:F>`)
                .addFields([
                    { name: '📝 Prompt do Usuário', value: temp.prompt?.slice(0, 1024) || 'N/A' },
                    { name: '🏷️ Cargos Criados', value: cargosCriados.length ? '• ' + cargosCriados.join('\n• ').slice(0, 1024) : 'Nenhum', inline: false },
                    { name: '🗂️ Categorias Criadas', value: categoriasCriadas.length ? '• ' + categoriasCriadas.join('\n• ').slice(0, 1024) : 'Nenhuma', inline: false },
                    { name: '#️⃣ Canais Criados', value: canaisCriados.length ? '• ' + canaisCriados.join('\n• ').slice(0, 1024) : 'Nenhum', inline: false }
                ])
                .setFooter({ text: 'GG Tools • IA Server Builder' })
                .setTimestamp();
            await logChannel.send({ embeds: [embed] });
        }
        removeTempEstrutura(userId);
    } catch (err) {
        await interaction.followUp({ content: '❌ Erro ao criar estrutura: ' + err.message, flags: 64 });
    }
}

module.exports = {
    sugerirServidorIA,
    criarServidorComEstruturaIA,
    setTempEstrutura,
    getTempEstrutura,
    removeTempEstrutura
};
