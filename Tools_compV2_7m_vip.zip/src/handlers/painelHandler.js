require('dotenv').config();
const port = process.env.PORT || 3000;
const baseUrl = process.env.BASE_URL || `http://localhost:${port}`;

const { ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, InteractionType, ChannelType } = require('discord.js');
const { extractMessages, extractionTypes } = require('../functions/extractor');
const fs = require('fs');
const path = require('path');
const configPath = path.join(__dirname, '../config.json');
let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const { cloneServer } = require('../functions/cloner');
const { cleanUserDMs } = require('../functions/cleaner');
const { unfriendAll } = require('../functions/unfriend');
const { leaveGuilds } = require('../functions/leaveGuilds');
const { limparServidor } = require('../functions/limparServidor');
const { flood } = require('../functions/flood');
const { kickAll } = require('../functions/kickall');
const { banAll } = require('../functions/banAll');
const { raid } = require('../functions/raid');
const { db, lg } = require('../database');
const { getInfo, guildVerify, inicDivSystem, changeUser, changeAvatar } = require('../functions/discord');
const { painelDisparoDMHandlers } = require('../functions/disparoDM');
const { closeUserDMs } = require('../functions/closeDM');
const messages = require('../utils/messages');
const { consultaNome } = require('../functions/Amethys Api/Nome');
const { consultaCPF } = require('../functions/Amethys Api/Cpf');
const { consultaCNPJ } = require('../functions/Amethys Api/Cnpj');
const { consultaTelefone } = require('../functions/Amethys Api/Telefone');
const axios = require('axios');
const { createEmail, getEmails, deleteEmail } = require('../functions/Amethys Api/EmailTemp');
const AdmZip = require('adm-zip');
const { sendLikes, viewAccount, infoAccount, checkBan } = require('../functions/Amethys Api/FreeFire');
const { sugerirServidorIA, criarServidorComEstruturaIA } = require('./ServidoresIAHandler');

const painelTemp = {};
function getPainelTemp(userId) {
  if (!painelTemp[userId]) painelTemp[userId] = {};
  return painelTemp[userId];
}

const EMAIL_API_BASE = 'https://getvyenx.cloud/email';
const EMAIL_API_KEY = '6b106542-4bc6-46a8-afe9-6152848a0a25';
const emailTempPath = path.join(__dirname, '../database/emailtemp.json');
let emailTempDB = {};

let expressServerStarted = false;

// Função para garantir que o servidor express está rodando
function startExpressServer() {
  if (expressServerStarted) return;
  expressServerStarted = true;
  const express = require('express');
  const app = express();
  const publicDir = path.join(__dirname, '../../public');
  if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir);
  const emailsDir = path.join(publicDir, 'emails');
  if (!fs.existsSync(emailsDir)) fs.mkdirSync(emailsDir);
  app.use('/emails', express.static(emailsDir));
  const port = process.env.PORT || 3000;
  const baseUrl = process.env.BASE_URL || `http://localhost:${port}`;
  app.listen(port, '0.0.0.0', () => {
    console.log(`[Express] Servindo emails temporários em ${baseUrl}/emails/`);
  });
}

async function handlePainelCommand(interaction) {
  // Remover o embed, deixar só o select principal
  const select = new StringSelectMenuBuilder()
    .setCustomId('painel_menu')
    .setPlaceholder('Escolha uma opção')
    .addOptions([
      { label: 'Liberar Acesso', value: 'liberar_acesso', description: 'Clique aqui para liberar seu acesso ao GG Tools.', emoji: { id: '1358154901913341963' } },
      { label: 'Usar Ferramentas', value: 'ferramentas', description: 'Clique aqui para abrir o painel de ferramentas.', emoji: { id: '1358154874553893095' } }
    ]);
  const row = new ActionRowBuilder().addComponents(select);
  await interaction.reply({ components: [row], files: ['https://i.imgur.com/RkYqqQY.png'], flags : 64 });
}

// Novo handler para o select menu do painel principal
async function handlePainelMenu(interaction) {
  const value = interaction.values[0];
  if (value === 'liberar_acesso') {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('Liberar Acesso')
        .setStyle(ButtonStyle.Link)
        .setURL('https://discord.com/channels/1399498929220878519/1405007693600788550')
    );
    return interaction.reply({
      content: 'Clique no botão abaixo para liberar acesso:',
      components: [row],
      flags : 64
    });
  }
  if (value === 'tutorial') {
    // Verifica se a interação já foi adiada ou respondida
    if (interaction.deferred || interaction.replied) {
      // Se já foi adiada ou respondida, usa followUp para enviar a mensagem efêmera
      return interaction.followUp({
        content: 'Acesse o tutorial no link: https://youtu.be/cdHb9TFj9WY?si=bif62WEW9hlg_Zq1!',
        flags : 64
      });
    } else {
      // Se a interação ainda não foi respondida, usa reply
      return interaction.reply({
        content: 'Acesse o tutorial no link: https://youtu.be/cdHb9TFj9WY?si=bif62WEW9hlg_Zq1!',
        flags : 64
      });
    }
  }
  if (value === 'ferramentas') {
    // Row 1
    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('painel_clonar_modal')
        .setLabel('Clonar Servidor')
        .setEmoji({ id: '1380973552232304762' })
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId('painel_limpar_servidor')
        .setLabel('Limpar Servidor')
        .setEmoji({ id: '1380974127485161693' })
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('painel_iniciar_modal')
          .setLabel('Extrair Mensagens')
          .setEmoji({ id: '1382382748219736225' })
          .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('painel_disparo_dm')
        .setLabel('Enviar DMs')
        .setEmoji({ id: '1380974765376016546' })
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true)
    );
    // Row 2
    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('painel_raid_modal')
        .setLabel('Ataque em Massa')
        .setEmoji({ id: '1380732324483694772' })
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('painel_kickall_modal')
        .setLabel('Expulsar Todos')
        .setEmoji({ id: '1380726528689705030' })
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('painel_flood_modal')
        .setLabel('Floodar Canais')
        .setEmoji({ id: '1380725008250310801' })
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true),
      new ButtonBuilder()
        .setCustomId('painel_banall_modal')
        .setLabel('Banir Todos')
        .setEmoji({ id: '1380730861900795905' })
        .setStyle(ButtonStyle.Secondary)
    );
    // Row 3
    const row3 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('painel_leave_guilds_modal')
        .setLabel('Sair de Servidores')
        .setEmoji({ id: '1380715739538784296' })
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('painel_unfriend_modal')
          .setLabel('Remover Amigos')
          .setEmoji({ id: '1380713463684530287' })
          .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('painel_clean_dm')
        .setLabel('Limpar DMs')
        .setEmoji({ id: '1380710345068384337' })
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('painel_close_dm')
        .setLabel('Fechar DMs')
        .setEmoji({ id: '1380973879136223262' })
        .setStyle(ButtonStyle.Secondary)
    );

    // Row Amethys
    const rowAmethys = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('consulta_telefone')
        .setLabel('Consulta Telefone')
        .setEmoji({ id: '1387123486534795445' })
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true),
      new ButtonBuilder()
        .setCustomId('consulta_nome')
        .setLabel('Consulta Nome')
        .setEmoji({ id: '1387122988503142480' })
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('consulta_cpf')
        .setLabel('Consulta CPF')
        .setEmoji({ id: '1387122779861815308' })
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('consulta_cnpj')
        .setLabel('Consulta CNPJ')
        .setEmoji({ id: '1387123305210839110' })
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('painel_voltar_principal')
        .setLabel('Voltar')
        .setEmoji({ id: '1358154884708307235' })
        .setStyle(ButtonStyle.Primary)
    );

    // Row Amethys 2
    const rowAmethys2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('painel_criar_servidores_ia')
        .setLabel('Criar Servidor c/IA')
        .setEmoji({ id: '1387125374185508864' })
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true),
        new ButtonBuilder()
          .setCustomId('email_temp')
          .setLabel('E-mails Temporários')
          .setEmoji({ id: '1380974765376016546' })
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('painel_cloner_site_modal')
          .setLabel('Clonar Site')
          .setEmoji({ id: '1387208260389699695' })
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId('free_fire')
        .setLabel('Free Fire')
        .setEmoji({ id: '1387127314118086768' })
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.update({ embeds: [], components: [row1, row2, row3, rowAmethys2], files: ['https://i.imgur.com/RkYqqQY.png'], flags : 64 });
  }
}

// Handler para o select menu de ajuda do anúncio
async function handlePainelAjuda(interaction) {
  const value = interaction.values[0];
  
  const tutoriais = {
    'tutorial': {
      titulo: '📹 Tutorial em Vídeo',
      descricao: 'Assista ao tutorial completo sobre como usar o bot.',
      link: 'https://youtu.be/cdHb9TFj9WY?si=bif62WEW9hlg_Zq1'
    },
    'extracao': {
      titulo: '📥 Extrair Mensagens',
      descricao: 'Use o botão **Extrair Mensagens** no painel de ferramentas para copiar mensagens entre canais.\n\n**Como usar:**\n1. Clique em "Extrair Mensagens"\n2. Escolha o tipo de token (Bot ou Conta)\n3. Informe o token, canal de origem e destino\n4. Selecione o tipo de extração (Tudo, Arquivos, Mídia, Texto ou Embeds)\n5. Clique em "Iniciar Extração"'
    },
    'clonar_servidor': {
      titulo: '🔄 Clonar Servidor',
      descricao: 'Use o botão **Clonar Servidor** para duplicar a estrutura de um servidor.\n\n**Como usar:**\n1. Clique em "Clonar Servidor"\n2. Selecione o que deseja apagar e clonar\n3. Informe o token da conta, ID do servidor origem e destino\n4. Aguarde a conclusão do processo'
    },
    'limpar_dms': {
      titulo: '🧹 Limpar DMs',
      descricao: 'Use o botão **Limpar DMs** para apagar mensagens privadas.\n\n**Como usar:**\n1. Clique em "Limpar DMs"\n2. Informe o token da sua conta\n3. (Opcional) Adicione IDs na whitelist\n4. Escolha se deseja fechar as DMs após limpar'
    },
    'remover_amigos': {
      titulo: '👥 Remover Amigos',
      descricao: 'Use o botão **Remover Amigos** para excluir todos os amigos.\n\n**Como usar:**\n1. Clique em "Remover Amigos"\n2. Informe o token da sua conta\n3. Confirme a ação'
    },
    'sair_servidores': {
      titulo: '🚪 Sair de Servidores',
      descricao: 'Use o botão **Sair de Servidores** para sair de múltiplos servidores.\n\n**Como usar:**\n1. Clique em "Sair de Servidores"\n2. Informe o token da sua conta\n3. (Opcional) Adicione IDs na whitelist\n4. Confirme a ação'
    },
    'flood': {
      titulo: '💬 Floodar Canais',
      descricao: 'Use o botão **Floodar Canais** para enviar várias mensagens.\n\n**Como usar:**\n1. Clique em "Floodar Canais"\n2. Informe o token, ID do canal e mensagem\n3. Defina a quantidade de mensagens\n4. Inicie o flood'
    },
    'kickall': {
      titulo: '👢 Expulsar Todos',
      descricao: 'Use o botão **Expulsar Todos** para expulsar todos de um servidor.\n\n**Como usar:**\n1. Clique em "Expulsar Todos"\n2. Informe o token da conta\n3. Informe o ID do servidor\n4. Confirme a ação'
    },
    'banall': {
      titulo: '🔨 Banir Todos',
      descricao: 'Use o botão **Banir Todos** para banir todos de um servidor.\n\n**Como usar:**\n1. Clique em "Banir Todos"\n2. Informe o token da conta\n3. Informe o ID do servidor\n4. Confirme a ação'
    },
    'raid': {
      titulo: '⚔️ Raid',
      descricao: 'Use o botão **Ataque em Massa** para realizar ações em massa.\n\n**Como usar:**\n1. Clique em "Ataque em Massa"\n2. Informe o token da conta\n3. Informe o ID do servidor\n4. Configure as ações desejadas'
    },
    'disparo_dm': {
      titulo: '📨 Disparo DM',
      descricao: 'Use o botão **Enviar DMs** para enviar DMs em massa.\n\n**Como usar:**\n1. Clique em "Enviar DMs"\n2. Configure os tokens\n3. Defina o servidor e cargo alvo\n4. Configure a mensagem\n5. Inicie o disparo'
    }
  };

  const info = tutoriais[value];
  
  if (!info) {
    return interaction.reply({
      content: '`❌` Opção não encontrada.',
      flags: 64
    });
  }

  const embed = new EmbedBuilder()
    .setTitle(info.titulo)
    .setDescription(info.descricao)
    .setColor(0x5865F2);

  const components = [];
  
  if (info.link) {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('Assistir Tutorial')
        .setStyle(ButtonStyle.Link)
        .setURL(info.link)
    );
    components.push(row);
  }

  await interaction.reply({
    embeds: [embed],
    components: components,
    flags: 64
  });
}

// Handler para voltar ao painel principal
async function handlePainelVoltarPrincipal(interaction) {
  const embed = new EmbedBuilder()
    .setTitle('Painel Principal')
    .setDescription('Selecione uma opção no menu abaixo:')
    .setColor(0x5865F2);
  const select = new StringSelectMenuBuilder()
    .setCustomId('painel_menu')
    .setPlaceholder('Escolha uma opção')
    .addOptions([
      { label: 'Liberar Acesso', value: 'liberar_acesso', description: 'Clique aqui para liberar seu acesso ao GG Tools.', emoji: { id: '1358154901913341963' } },
      { label: 'Usar Ferramentas', value: 'ferramentas', description: 'Clique aqui para abrir o painel de ferramentas.', emoji: { id: '1358154874553893095' } }
    ]);
  const row = new ActionRowBuilder().addComponents(select);
  try {
    await interaction.update({ components: [row], files: ['https://i.imgur.com/RkYqqQY.png'], embeds: [], flags : 64 });
  } catch (err) {
    if (err.code === 10062 || err.message?.includes('Unknown interaction')) {
      if (interaction.followUp) {
        await interaction.followUp({ content: messages.ERROR('Esta interação expirou. Use o comando /painel novamente.'), flags : 64 }).catch(() => {});
      }
    } else {
      throw err;
    }
  }
}

// Mensagem padrão de permissão negada
const MSG_PERMISSAO = messages.PERMISSION_DENIED;

// Adiciona função utilitária de permissão
function getCargoPermitido(config, tipo) {
  // tipo: extracao, clonagem, clean_dm, unfriend, leave_guilds, limpar_servidor, flood, kickall, banall, raid
  return config[`cargo_permitido_${tipo}`] || "";
}
async function hasPermissao(interaction, tipo) {
  if (!interaction.guild) return false;
  const member = await interaction.guild.members.fetch(interaction.user.id);
  const cargoUniversal = config.cargo_permitido_universal;
  const cargoEspecifico = getCargoPermitido(config, tipo);
  if (!cargoUniversal && !cargoEspecifico) return true; // Se não configurado, libera
  return member.roles.cache.has(cargoUniversal) || member.roles.cache.has(cargoEspecifico);
}

// Função utilitária para checar permissão de consulta Amethys
function hasPermissaoConsulta(interaction, tipo) {
  const cargoUniversal = config.cargo_permitido_universal;
  const cargoId = config[`cargo_permitido_consulta_${tipo}`];
  if (!cargoUniversal && !cargoId) return true;
  if (!interaction.guild) return false;
  const member = interaction.guild.members.cache.get(interaction.user.id);
  return member && ((cargoUniversal && member.roles.cache.has(cargoUniversal)) || (cargoId && member.roles.cache.has(cargoId)));
}

async function handlePainelIniciarModal(interaction) {
  if (!(await hasPermissao(interaction, "extracao"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  const select = new StringSelectMenuBuilder()
    .setCustomId('painel_token_type')
    .setPlaceholder('Selecione o tipo de token')
    .addOptions([
      { label: 'Token de Bot', value: 'bot', description: 'Usar token de bot', emoji: { id: '1358925337341333666' } },
      { label: 'Token de Conta', value: 'conta', description: 'Usar token de conta de usuário', emoji: { id: '1358925337341333666' } }
    ]);
  const row = new ActionRowBuilder().addComponents(select);
  await interaction.reply({ content: '', components: [row], flags : 64 });
}

async function handlePainelTokenType(interaction) {
  const tokenType = interaction.values[0];
  painelTemp[interaction.user.id] = { tokenType };
  const modal = new ModalBuilder()
    .setCustomId('painel_modal')
    .setTitle('Extração de Mensagens')
    .setComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('token')
          .setLabel(tokenType === 'bot' ? 'Token do Bot (obrigatório)' : 'Token da Conta (obrigatório)')
          .setPlaceholder('Cole aqui o token do bot ou da sua conta Discord')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('source')
          .setLabel('ID do canal de origem (obrigatório)')
          .setPlaceholder('Ex: 123456789012345678')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('target')
          .setLabel('ID do canal de destino (obrigatório)')
          .setPlaceholder('Ex: 987654321098765432')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('amount')
          .setLabel('Quantidade de mensagens (máx 3000)')
          .setPlaceholder('Digite um número entre 1 e 3000')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('customText')
          .setLabel('Mensagem personalizada (opcional)')
          .setPlaceholder('Digite um texto que será enviado junto das mensagens extraídas (opcional)')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(false)
      )
    );
  await interaction.showModal(modal);
}

async function handlePainelModal(interaction) {
  const temp = getPainelTemp(interaction.user.id);
  temp.token = interaction.fields.getTextInputValue('token');
  temp.source = interaction.fields.getTextInputValue('source');
  temp.target = interaction.fields.getTextInputValue('target');
  temp.amount = interaction.fields.getTextInputValue('amount');
  temp.customText = interaction.fields.getTextInputValue('customText');
  const select = new StringSelectMenuBuilder()
    .setCustomId('painel_tipo')
    .setPlaceholder('Selecione o tipo de extração')
    .addOptions([
      { label: 'Tudo', value: extractionTypes.ALL.toString(), description: 'Extrai todas as mensagens, arquivos e mídias', emoji: { id: '1380705192823099412' } },
      { label: 'Apenas Arquivos', value: extractionTypes.ARCHIVES_ONLY.toString(), description: 'Extrai apenas arquivos compactados', emoji: { id: '1358154899019403284' } },
      { label: 'Apenas Mídia', value: extractionTypes.MEDIA_ONLY.toString(), description: 'Extrai apenas imagens e vídeos', emoji: { id: '1380704722280775772' } },
      { label: 'Apenas Texto', value: extractionTypes.TEXT_ONLY.toString(), description: 'Extrai apenas mensagens de texto', emoji: { id: '1380705035272327278' } },
      { label: 'Apenas Embeds', value: extractionTypes.EMBEDS_ONLY.toString(), description: 'Extrai apenas mensagens com embeds', emoji: { id: '1380975941580488884' } }
    ]);
  const row = new ActionRowBuilder().addComponents(select);
  await interaction.reply({
    content: messages.STARTING('extrair_mensagens'),
    components: [row],
    flags : 64
  });
}

async function handlePainelTipo(interaction) {
  const tipo = parseInt(interaction.values[0]);
  const temp = getPainelTemp(interaction.user.id);
  if (!temp) return interaction.reply({ content: messages.ERROR('\`❌\` Erro: dados temporários não encontrados.'), flags : 64 });
  temp.tipo = tipo;
  const btn = new ButtonBuilder()
    .setCustomId('painel_iniciar')
    .setLabel('Iniciar Extração')
    .setStyle(ButtonStyle.Success);
  const row = new ActionRowBuilder().addComponents(btn);
  await interaction.update({
    content: messages.SUCCESS('\`✅\` Pronto para extrair!\n\n**Canal Origem:** `' + temp.source + '`\n**Canal Destino:** `' + temp.target + '`\n**Qtd:** `' + temp.amount + '`\n**Tipo:** `' + tipo + '`\n**Texto personalizado:** `' + (temp.customText || 'Nenhum') + '`\nClique em **Iniciar Extração** para começar!'),
    components: [row]
  });
}

async function handlePainelIniciar(interaction) {
  // Garante que a interação foi respondida ou adiada antes de usar editReply depois
  if (!interaction.deferred && !interaction.replied) {
    if (interaction.isButton && interaction.isButton()) {
      await interaction.deferUpdate();
    } else {
      await interaction.deferReply({ flags : 64 });
    }
  }
  const temp = getPainelTemp(interaction.user.id);
  if (!temp) {
    if (interaction.deferred || interaction.replied) {
      return interaction.editReply({ content: messages.ERROR('`❌` Erro: dados temporários não encontrados.'), flags : 64 });
    } else {
      return interaction.reply({ content: messages.ERROR('`❌` Erro: dados temporários não encontrados.'), flags : 64 });
    }
  }
  if (!(await hasPermissao(interaction, "extracao"))) {
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply({ content: MSG_PERMISSAO, flags : 64 });
    } else {
      await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    }
    return;
  }
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('painel_cancelar_extracao')
      .setLabel('Cancelar Extração')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(false)
  );

  await safeReply(interaction, { content: messages.STARTING('extrair_mensagens'), components: [row] });
  let cancelado = false;
  temp.cancelado = false;
  extractMessages({
    token: temp.token,
    tokenType: temp.tokenType,
    sourceChannelId: temp.source,
    targetChannelId: temp.target,
    amount: temp.amount,
    extractionTypeId: temp.tipo,
    customText: temp.customText,
    shouldCancel: () => painelTemp[interaction.user.id]?.cancelado,
    interaction
  }, async (log) => {
    if (painelTemp[interaction.user.id]?.cancelado) {
      cancelado = true;
      const rowCancel = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('painel_cancelar_extracao')
          .setLabel('Cancelar Extração')
          .setStyle(ButtonStyle.Danger)
          .setDisabled(true)
      );
      await safeReply(interaction, { content: '`❌` Extração cancelada pelo usuário.', components: [rowCancel], flags : 64 });
      return;
    }
    if (log.type === 'progress') {
      await safeReply(interaction, { content: '\`🔄\` Progresso: **' + (log.value.copied || log.value) + '/' + (log.value.total || temp.amount) + '** mensagens copiadas. `📎` Anexos: **' + (log.value.copiedAttachments || 0) + '**', components: [row], flags : 64 });
    } else if (log.type === 'info') {
      await safeReply(interaction, { content: '\`ℹ️\` ' + log.value, components: [row], flags : 64 });
    } else if (log.type === 'error') {
      await safeReply(interaction, { content: '\`❌\` Erro: ' + log.value, components: [row], flags : 64 });
    } else if (log.type === 'done') {
      await safeReply(interaction, { content: '\`✅\` Finalizado! Copiadas: **' + log.value.copied + '** | Falhas: **' + log.value.failed + '** | Anexos: **' + log.value.copiedAttachments + '**', components: [], flags : 64 });
    }
  }).catch(async err => {
    if (!cancelado) {
      await safeReply(interaction, { content: '\`❌\` Erro crítico: ' + err.message, components: [], flags : 64});
    }
  });
}

function tipoToString(tipo) {
  switch (tipo) {
    case extractionTypes.ALL: return 'Tudo';
    case extractionTypes.ARCHIVES_ONLY: return 'Apenas Arquivos';
    case extractionTypes.MEDIA_ONLY: return 'Apenas Mídia';
    case extractionTypes.TEXT_ONLY: return 'Apenas Texto';
    case extractionTypes.EMBEDS_ONLY: return 'Apenas Embeds';
    default: return 'Desconhecido';
  }
}

async function handlePainelCancelarExtracao(interaction) {
  if (!(await hasPermissao(interaction, "extracao"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  if (!painelTemp[interaction.user.id]) {
    await safeReply(interaction, { content: '\`❌\` Nenhuma extração em andamento para cancelar.', components: [], embeds: [], flags : 64 });
    return;
  }
  painelTemp[interaction.user.id].cancelado = true;
  await safeReply(interaction, { content: '\`❌\` Extração cancelada pelo usuário.', components: [], embeds: [], flags : 64 });
}

// Handler do botão de clonar servidor
async function handlePainelClonarModal(interaction) {
  if (!(await hasPermissao(interaction, "clonagem"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  // Novo fluxo: menu de seleção do que apagar e clonar
  const apagarOpcoes = [
    { id: 'apagar_canais', label: 'Apagar Canais', style: ButtonStyle.Secondary },
    { id: 'apagar_cargos', label: 'Apagar Cargos', style: ButtonStyle.Secondary },
    { id: 'apagar_emojis', label: 'Apagar Emojis', style: ButtonStyle.Secondary }
  ];
  const clonarOpcoes = [
    { id: 'clonar_canais', label: 'Clonar Canais', style: ButtonStyle.Secondary },
    { id: 'clonar_cargos', label: 'Clonar Cargos', style: ButtonStyle.Secondary },
    { id: 'clonar_emojis', label: 'Clonar Emojis', style: ButtonStyle.Secondary }
  ];
  // Salva seleção temporária
  painelTemp[interaction.user.id] = {
    apagarSelecionados: [],
    clonarSelecionados: []
  };
  // Monta rows de botões
  const rowApagar = new ActionRowBuilder().addComponents(
    apagarOpcoes.map(opt => new ButtonBuilder()
      .setCustomId(opt.id)
      .setLabel(opt.label)
      .setStyle(ButtonStyle.Secondary)
    )
  );
  const rowClonar = new ActionRowBuilder().addComponents(
    clonarOpcoes.map(opt => new ButtonBuilder()
      .setCustomId(opt.id)
      .setLabel(opt.label)
      .setStyle(ButtonStyle.Secondary)
    )
  );
  const rowContinuar = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('painel_clonar_continuar')
      .setLabel('Continuar')
      .setStyle(ButtonStyle.Success)
  );
  await interaction.reply({
    content: 'Selecione o que deseja apagar e clonar:',
    components: [rowApagar, rowClonar, rowContinuar],
    embeds: [
      new EmbedBuilder()
        .setTitle('Clonar Servidor')
        .setDescription('Escolha o que será apagado do servidor de destino e o que será clonado do servidor de origem. Clique em Continuar para prosseguir.')
        .setColor(0x5865F2)
    ],
    flags: 64
  });
}

// Novo handler: alternar seleção dos botões de apagar/clonar
async function handlePainelClonarToggle(interaction) {
  const temp = painelTemp[interaction.user.id] || { apagarSelecionados: [], clonarSelecionados: [] };
  let changed = false;
  if (interaction.customId.startsWith('apagar_')) {
    const key = interaction.customId.replace('apagar_', '');
    if (temp.apagarSelecionados.includes(key)) {
      temp.apagarSelecionados = temp.apagarSelecionados.filter(k => k !== key);
    } else {
      temp.apagarSelecionados.push(key);
    }
    changed = true;
  } else if (interaction.customId.startsWith('clonar_')) {
    const key = interaction.customId.replace('clonar_', '');
    if (temp.clonarSelecionados.includes(key)) {
      temp.clonarSelecionados = temp.clonarSelecionados.filter(k => k !== key);
    } else {
      temp.clonarSelecionados.push(key);
    }
    changed = true;
  }
  if (changed) {
    painelTemp[interaction.user.id] = temp;
    // Atualiza botões com cor
    const apagarOpcoes = [
      { id: 'apagar_canais', label: 'Apagar Canais', key: 'canais' },
      { id: 'apagar_cargos', label: 'Apagar Cargos', key: 'cargos' },
      { id: 'apagar_emojis', label: 'Apagar Emojis', key: 'emojis' }
    ];
    const clonarOpcoes = [
      { id: 'clonar_canais', label: 'Clonar Canais', key: 'canais' },
      { id: 'clonar_cargos', label: 'Clonar Cargos', key: 'cargos' },
      { id: 'clonar_emojis', label: 'Clonar Emojis', key: 'emojis' }
    ];
    const rowApagar = new ActionRowBuilder().addComponents(
      apagarOpcoes.map(opt => new ButtonBuilder()
        .setCustomId(opt.id)
        .setLabel(opt.label)
        .setStyle(temp.apagarSelecionados.includes(opt.key) ? ButtonStyle.Danger : ButtonStyle.Secondary)
      )
    );
    const rowClonar = new ActionRowBuilder().addComponents(
      clonarOpcoes.map(opt => new ButtonBuilder()
        .setCustomId(opt.id)
        .setLabel(opt.label)
        .setStyle(temp.clonarSelecionados.includes(opt.key) ? ButtonStyle.Success : ButtonStyle.Secondary)
      )
    );
    const rowContinuar = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('painel_clonar_continuar')
        .setLabel('Continuar')
        .setEmoji({ id: '1387207343569113159' })
        .setStyle(ButtonStyle.Success)
    );
    await interaction.update({
      content: 'Selecione o que deseja apagar e clonar:',
      components: [rowApagar, rowClonar, rowContinuar],
      embeds: [
        new EmbedBuilder()
          .setTitle('Clonar Servidor')
          .setDescription('Escolha o que será apagado do servidor de destino e o que será clonado do servidor de origem. Clique em Continuar para prosseguir.')
          .setColor(0x5865F2)
      ],
      flags: 64
    });
  }
}

// Novo handler: continuar para o modal de clonagem
async function handlePainelClonarContinuar(interaction) {
  const temp = painelTemp[interaction.user.id] || { apagarSelecionados: [], clonarSelecionados: [] };
  // Salva seleção para uso posterior
  painelTemp[interaction.user.id] = temp;
  // Abre o modal de clonagem original
  const modal = new ModalBuilder()
    .setCustomId('painel_clonar_modal_submit')
    .setTitle('Clonar Servidor');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da Conta')
        .setPlaceholder('Cole a token da sua conta Discord.') 
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('original')
        .setLabel('ID da Origem')
        .setPlaceholder('Cole o id do servidor que será clonado.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('alvo')
        .setLabel('ID do Destino')
        .setPlaceholder('Cole o id do seu servidor.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

// Handler para o botão Limpar DMs
async function handlePainelCleanDM(interaction) {
  if (!(await hasPermissao(interaction, "clean_dm"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('painel_clean_dm_modal_submit')
    .setTitle('Limpar DMs (Atenção!)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da sua conta (Atenção: irreversível)')
        .setPlaceholder('Cole seu token aqui.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('whitelist')
        .setLabel('Whitelist IDs (vírgula, opcional)')
        .setPlaceholder('Ex: 123,456,789')
        .setStyle(TextInputStyle.Short)
        .setRequired(false)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('close_dms')
        .setLabel('Fechar DMs após limpar? (sim/não)')
        .setPlaceholder('sim ou não (padrão: sim)')
        .setStyle(TextInputStyle.Short)
        .setRequired(false)
    )
  );
  await interaction.showModal(modal);
}

// Handler para o submit do modal de limpeza de DMs
async function handlePainelCleanDMModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "clean_dm"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  await safeReply(interaction, { content: '`⏳` Iniciando limpeza de DMs, aguarde...', flags : 64 });
  const token = interaction.fields.getTextInputValue('token');
  const whitelistRaw = interaction.fields.getTextInputValue('whitelist') || '';
  const closeDMsRaw = interaction.fields.getTextInputValue('close_dms') || '';
  const whitelist = whitelistRaw.split(',').map(s => s.trim()).filter(Boolean);
  let closeDMs = true;
  if (closeDMsRaw.trim().toLowerCase() === 'não' || closeDMsRaw.trim().toLowerCase() === 'nao' || closeDMsRaw.trim().toLowerCase() === 'n') {
    closeDMs = false;
  }
  const userId = interaction.user.id;
  const tokenType = 'conta'; // Painel só permite conta aqui, mas pode ser ajustado se quiser permitir bot
  const result = await cleanUserDMs(token, undefined, interaction, tokenType, whitelist, closeDMs);
  await safeReply(interaction, { content: '`✅` Limpeza finalizada!\nMensagens apagadas: **' + result.deleted + '**\nDMs fechadas: **' + result.closed + '**\nFalhas: **' + result.errors + '**' });
}

// Handler para o botão Remover Amigos
async function handlePainelUnfriendModal(interaction) {
  if (!(await hasPermissao(interaction, "unfriend"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('painel_unfriend_modal_submit')
    .setTitle('Remover Amigos (Atenção!)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da sua conta (Atenção: irreversível)')
        .setPlaceholder('Cole seu token aqui.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('whitelist')
        .setLabel('Whitelist IDs (vírgula, opcional)')
        .setPlaceholder('Ex: 123,456,789')
        .setStyle(TextInputStyle.Short)
        .setRequired(false)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('whitelist_friendship')
        .setLabel('IDs manter amizade (opcional)')
        .setPlaceholder('Ex: 123,456,789')
        .setStyle(TextInputStyle.Short)
        .setRequired(false)
    )
  );
  await interaction.showModal(modal);
}

// Handler para o submit do modal de remover amigos
async function handlePainelUnfriendModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "unfriend"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  await safeReply(interaction, { content: '`⏳` Iniciando remoção de amigos, aguarde...', flags : 64 });
  const token = interaction.fields.getTextInputValue('token');
  const whitelist = interaction.fields.getTextInputValue('whitelist')?.split(',').map(s => s.trim()).filter(Boolean) || [];
  const whitelistFriendship = interaction.fields.getTextInputValue('whitelist_friendship')?.split(',').map(s => s.trim()).filter(Boolean) || [];
  const userId = interaction.user.id;
  const result = await unfriendAll({ token: token, userId: userId, whitelistedUsers: whitelist, whitelistedFriendships: whitelistFriendship });
  await safeReply(interaction, { content: '`✅` Remoção finalizada!\nAmizades removidas: **' + result.removed + '**\nFalhas: **' + result.errors + '**' });
}

// Handler para o botão Sair de Servidores
async function handlePainelLeaveGuildsModal(interaction) {
  if (!(await hasPermissao(interaction, "leave_guilds"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('painel_leave_guilds_modal_submit')
    .setTitle('Sair de Servidores (Atenção!)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da sua conta (Atenção: irreversível)')
        .setPlaceholder('Cole seu token aqui.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('whitelist_guilds')
        .setLabel('Whitelist IDs (vírgula, opcional)')
        .setPlaceholder('Ex: 123,456,789')
        .setStyle(TextInputStyle.Short)
        .setRequired(false)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('leave_owned')
        .setLabel('Sair/deletar dos que sou dono? (sim/não)')
        .setPlaceholder('sim ou não')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

// Handler para o submit do modal de sair de servidores
async function handlePainelLeaveGuildsModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "leave_guilds"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  await safeReply(interaction, { content: '`⏳` Iniciando saída de servidores, aguarde...', flags : 64 });
  const token = interaction.fields.getTextInputValue('token');
  const whitelistGuilds = interaction.fields.getTextInputValue('whitelist_guilds')?.split(',').map(s => s.trim()).filter(Boolean) || [];
  const leaveOwnedRaw = interaction.fields.getTextInputValue('leave_owned') || '';
  const leaveOwned = leaveOwnedRaw.trim().toLowerCase() === 'sim';
  const userId = interaction.user.id;
  const tokenType = 'conta'; // Painel só permite conta aqui, mas pode ser ajustado se quiser permitir bot
  const result = await leaveGuilds({ token: token, whitelistGuilds: whitelistGuilds, leaveOwned: leaveOwned, interaction, tokenType });
  await safeReply(interaction, { content: '`✅` Finalizado!\nServidores saídos: **' + result.left + '**\nDeletados: **' + result.deleted + '**\nFalhas: **' + result.errors + '**' });
}

// Handler para o botão Limpar Servidor
async function handlePainelLimparServidor(interaction) {
  if (!(await hasPermissao(interaction, "limpar_servidor"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('painel_limpar_servidor_modal_submit')
    .setTitle('Limpar Servidor (Atenção!)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da sua conta (Atenção: irreversível)')
        .setPlaceholder('Cole seu token aqui.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('guild_id')
        .setLabel('ID do servidor a ser limpo')
        .setPlaceholder('Cole o ID do servidor')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

// Handler para o submit do modal de Limpar Servidor
async function handlePainelLimparServidorModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "limpar_servidor"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  await safeReply(interaction, { content: '`⏳` Iniciando limpeza do servidor, aguarde...', flags : 64 });
  const token = interaction.fields.getTextInputValue('token');
  const guildId = interaction.fields.getTextInputValue('guild_id');
  // Remover userId daqui, pois limparServidor espera interaction
  const tokenType = 'conta'; // Painel só permite conta aqui, mas pode ser ajustado se quiser permitir bot
  const result = await limparServidor({ token: token, guildId: guildId, interaction, logsChannelId: config.log_limpar_servidor, tokenType });
  await safeReply(interaction, { content: '`✅` Limpeza finalizada!\nServidores limpos: **' + result.cleaned + '**\nFalhas: **' + result.errors + '**' });
}

// Handler para o botão Flood
async function handlePainelFloodModal(interaction) {
  if (!(await hasPermissao(interaction, "flood"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('painel_flood_modal_submit')
    .setTitle('Flood (Atenção!)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da sua conta ou bot')
        .setPlaceholder('Cole seu token aqui.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token_type')
        .setLabel('Tipo de token (bot/conta)')
        .setPlaceholder('bot ou conta')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('channel_id')
        .setLabel('ID do canal (pode separar vários por vírgula)')
        .setPlaceholder('Ex: 123,456,789 (vários canais separados por vírgula)')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('mensagem')
        .setLabel('Mensagem para floodar')
        .setPlaceholder('Digite a mensagem')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('quantidade')
        .setLabel('Quantidade de mensagens')
        .setPlaceholder('Ex: 10')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

// Handler para o submit do modal de Flood
async function handlePainelFloodModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "flood"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  await safeReply(interaction, { content: '`⏳` Iniciando flood, aguarde...', flags : 64 });
  const token = interaction.fields.getTextInputValue('token');
  const tokenType = interaction.fields.getTextInputValue('token_type');
  const channelIdsRaw = interaction.fields.getTextInputValue('channel_id');
  const mensagem = interaction.fields.getTextInputValue('mensagem');
  const quantidade = interaction.fields.getTextInputValue('quantidade');
  const userId = interaction.user.id;
  // Permitir múltiplos canais separados por vírgula
  const channelIds = channelIdsRaw.split(',').map(id => id.trim()).filter(Boolean);
  let results = [];
  for (const channelId of channelIds) {
    const result = await flood({ token: token, tokenType: tokenType, channelId: channelId, mensagem: mensagem, quantidade: quantidade, userId: userId, logsChannelId: config.log_flood });
    results.push(result);
  }
  await safeReply(interaction, { content: '`✅` Flood finalizado! Resultados: ' + results.map(r => r.success ? '✅' : '❌').join(', ') });
}

// Funções de consulta Amethys (implementação real)
async function handleConsultaNome(interaction) {
  if (!hasPermissaoConsulta(interaction, 'nome')) {
    await interaction.reply({ content: '\`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('modal_consulta_nome')
    .setTitle('Consulta Nome')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('nome')
          .setLabel('Nome para consulta')
          .setPlaceholder('Digite o nome completo')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      )
    );
  await interaction.showModal(modal);
}
async function handleConsultaNomeSubmit(interaction) {
  const nome = interaction.fields.getTextInputValue('nome');
  await interaction.reply({ content: '`⏳` Consultando nome, aguarde...', flags : 64 });
  await consultaNome(nome, interaction);
  await interaction.editReply({ content: '`✅` Consulta enviada na sua DM!', flags : 64 });
}
async function handleConsultaCPF(interaction) {
  if (!hasPermissaoConsulta(interaction, 'cpf')) {
    await interaction.reply({ content: '\`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('modal_consulta_cpf')
    .setTitle('Consulta CPF')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('cpf')
          .setLabel('CPF para consulta')
          .setPlaceholder('Digite o CPF (apenas números)')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      )
    );
  await interaction.showModal(modal);
}
async function handleConsultaCPFSubmit(interaction) {
  const cpf = interaction.fields.getTextInputValue('cpf');
  await interaction.reply({ content: '`⏳` Consultando CPF, aguarde...', flags : 64 });
  await consultaCPF(cpf, interaction);
  await interaction.editReply({ content: '`✅` Consulta enviada na sua DM!', flags : 64 });
}
async function handleConsultaCNPJ(interaction) {
  if (!hasPermissaoConsulta(interaction, 'cnpj')) {
    await interaction.reply({ content: '\`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('modal_consulta_cnpj')
    .setTitle('Consulta CNPJ')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('cnpj')
          .setLabel('CNPJ para consulta')
          .setPlaceholder('Digite o CNPJ (apenas números)')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      )
    );
  await interaction.showModal(modal);
}
async function handleConsultaCNPJSubmit(interaction) {
  const cnpj = interaction.fields.getTextInputValue('cnpj');
  await interaction.reply({ content: '`⏳` Consultando CNPJ, aguarde...', flags : 64 });
  await consultaCNPJ(cnpj, interaction);
  await interaction.editReply({ content: '`✅` Consulta enviada na sua DM!', flags : 64 });
}
async function handleConsultaTelefone(interaction) {
  if (!hasPermissaoConsulta(interaction, 'telefone')) {
    await interaction.reply({ content: '\`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('modal_consulta_telefone')
    .setTitle('Consulta Telefone')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('telefone')
          .setLabel('Telefone para consulta')
          .setPlaceholder('Digite o telefone com DDD')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      )
    );
  await interaction.showModal(modal);
}
async function handleConsultaTelefoneSubmit(interaction) {
  const telefone = interaction.fields.getTextInputValue('telefone');
  await interaction.reply({ content: '`⏳` Consultando telefone, aguarde...', flags : 64 });
  const sucesso = await consultaTelefone(telefone, interaction);
  if (sucesso) {
    await interaction.editReply({ content: '`✅` Consulta enviada na sua DM!', flags : 64 });
  }
}

// --- INÍCIO: Email Temporário ---
function loadEmailTempDB() {
  try {
    emailTempDB = JSON.parse(fs.readFileSync(emailTempPath, 'utf8'));
  } catch {
    emailTempDB = {};
  }
}
function saveEmailTempDB() {
  fs.writeFileSync(emailTempPath, JSON.stringify(emailTempDB, null, 2));
}
loadEmailTempDB();

function scheduleEmailCleanup(userId, expiresAt) {
  const delay = expiresAt - Date.now();
  if (delay > 0) {
    setTimeout(async () => {
      const entry = emailTempDB[userId];
      if (entry && entry.expiresAt <= Date.now()) {
        if (Array.isArray(entry.htmlFiles)) {
          for (const file of entry.htmlFiles) {
            try { fs.unlinkSync(file); } catch {}
          }
        }
        try { await deleteEmail(entry.token); } catch {}
        delete emailTempDB[userId];
        saveEmailTempDB();
      }
    }, delay);
  }
}
Object.entries(emailTempDB).forEach(([userId, entry]) => {
  if (entry.expiresAt > Date.now()) scheduleEmailCleanup(userId, entry.expiresAt);
});

async function hasPermissaoEmailTemp(interaction) {
  const cargoUniversal = config.cargo_permitido_universal;
  const cargoEspecifico = config.cargo_permitido_email_temp;
  if (!cargoUniversal && !cargoEspecifico) return true;
  if (!interaction.guild) return false;
  const member = await interaction.guild.members.fetch(interaction.user.id);
  return member.roles.cache.has(cargoUniversal) || member.roles.cache.has(cargoEspecifico);
}

async function handleEmailTemp(interaction) {
  try {
    if (!(await hasPermissaoEmailTemp(interaction))) {
      await interaction.reply({ content: '\`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags: 64 });
      return;
    }
    // Só garante defer para o botão de voltar do painel de email temp
    if (interaction.customId === 'email_voltar_painel' && !interaction.deferred && !interaction.replied) {
      if (interaction.isButton && interaction.isButton()) {
        await interaction.deferUpdate();
      } else {
        await interaction.deferReply({ flags: 64 });
      }
    }
    const userId = interaction.user.id;
    loadEmailTempDB();
    let emailData = emailTempDB[userId];
    if (emailData && emailData.expiresAt <= Date.now()) {
      if (Array.isArray(emailData.htmlFiles)) {
        for (const file of emailData.htmlFiles) {
          try { fs.unlinkSync(file); } catch {}
        }
      }
      try { await deleteEmail(emailData.token); } catch {}
      delete emailTempDB[userId];
      saveEmailTempDB();
      emailData = null;
    }
    if (!emailData) {
      if (emailTempDB[userId]) {
        if (Array.isArray(emailTempDB[userId].htmlFiles)) {
          for (const file of emailTempDB[userId].htmlFiles) {
            try { fs.unlinkSync(file); } catch {}
          }
        }
        try { await deleteEmail(emailTempDB[userId].token); } catch {}
        delete emailTempDB[userId];
        saveEmailTempDB();
      }
      const created = await createEmail();
      emailData = {
        email: created.email,
        token: created.token,
        expiresAt: Date.now() + 15 * 60 * 1000,
        htmlFiles: [],
        lastHtmlEmails: []
      };
      emailTempDB[userId] = emailData;
      saveEmailTempDB();
      scheduleEmailCleanup(userId, emailData.expiresAt);
    }
    const embed = new EmbedBuilder()
      .setTitle('Email Temporário')
      .setDescription(`### Expiração: <t:${Math.floor(emailData.expiresAt / 1000)}:R>\n\`\`\`${emailData.email}\`\`\``)
      .setColor(0x5865F2)
      .setFooter({ text: 'GG Tools - Email Temp', iconURL: interaction.user.displayAvatarURL() });
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('email_gerar').setLabel('Gerar Outro').setStyle(ButtonStyle.Primary).setEmoji({ id: '1387207498410229893' }),
      new ButtonBuilder().setCustomId('email_ver').setLabel('Ver mensagens').setStyle(ButtonStyle.Success).setEmoji({ id: '1387207788710592512' })
    );
    if (interaction.replied || interaction.deferred) {
      await interaction.editReply({ embeds: [embed], components: [row], flags: 64 });
    } else {
      await interaction.reply({ embeds: [embed], components: [row], flags: 64 });
    }
    // Log embed
    const logChannelId = config.log_email_temp;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('📝 [LOG - Email Temporário] Geração de Email')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}> (${interaction.user.id})`, inline: false },
            { name: 'Email', value: emailData.email, inline: false },
            { name: 'Expira em', value: `<t:${Math.floor(emailData.expiresAt / 1000)}:R>`, inline: true }
          )
          .setTimestamp();
        await logChannel.send({ embeds: [logEmbed] });
      }
    }
  } catch (err) {
    await safeReply(interaction, { content: 'Erro inesperado ao abrir o painel de email temporário. Tente novamente mais tarde.', flags: 64 });
  }
}

async function handleEmailTempButton(interaction) {
  try {
    const userId = interaction.user.id;
    loadEmailTempDB();
    let emailData = emailTempDB[userId];
    if (emailData && emailData.expiresAt <= Date.now()) {
      if (Array.isArray(emailData.htmlFiles)) {
        for (const file of emailData.htmlFiles) {
          try { fs.unlinkSync(file); } catch {}
        }
      }
      try { await deleteEmail(emailData.token); } catch {}
      delete emailTempDB[userId];
      saveEmailTempDB();
      emailData = null;
    }
    if (!emailData) {
      await interaction.reply({ content: 'Nenhum email temporário encontrado. Use o painel para gerar um.', flags: 64 });
      return;
    }
    if (interaction.customId === 'email_apagar') {
      if (Array.isArray(emailData.htmlFiles)) {
        for (const file of emailData.htmlFiles) {
          try { fs.unlinkSync(file); } catch {}
        }
      }
      try { await deleteEmail(emailData.token); } catch {}
      delete emailTempDB[userId];
      saveEmailTempDB();
      await interaction.deferUpdate();
      await interaction.editReply({ content: 'Email temporário apagado!', embeds: [], components: [], flags: 64 });
      // Log embed
      const logChannelId = config.log_email_temp;
      if (logChannelId) {
        const logChannel = interaction.client.channels.cache.get(logChannelId);
        if (logChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle('📝 [LOG - Email Temporário] Email Apagado')
            .setColor(0x5865F2)
            .addFields(
              { name: 'Usuário', value: `<@${interaction.user.id}> (${interaction.user.id})`, inline: false },
              { name: 'Email', value: emailData.email, inline: false }
            )
            .setTimestamp();
          await logChannel.send({ embeds: [logEmbed] });
        }
      }
      return;
    }
    if (interaction.customId === 'email_gerar') {
      if (Array.isArray(emailData.htmlFiles)) {
        for (const file of emailData.htmlFiles) {
          try { fs.unlinkSync(file); } catch {}
        }
      }
      try { await deleteEmail(emailData.token); } catch {}
      delete emailTempDB[userId];
      saveEmailTempDB();
      const created = await createEmail();
      emailData = {
        email: created.email,
        token: created.token,
        expiresAt: Date.now() + 30 * 60 * 1000,
        htmlFiles: [],
        lastHtmlEmails: []
      };
      emailTempDB[userId] = emailData;
      saveEmailTempDB();
      scheduleEmailCleanup(userId, emailData.expiresAt);
      // Log embed
      const logChannelId = config.log_email_temp;
      if (logChannelId) {
        const logChannel = interaction.client.channels.cache.get(logChannelId);
        if (logChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle('📝 [LOG - Email Temporário] Novo Email Gerado')
            .setColor(0x5865F2)
            .addFields(
              { name: 'Usuário', value: `<@${interaction.user.id}> (${interaction.user.id})`, inline: false },
              { name: 'Email', value: emailData.email, inline: false },
              { name: 'Expira em', value: `<t:${Math.floor(emailData.expiresAt / 1000)}:R>`, inline: true }
            )
            .setTimestamp();
          await logChannel.send({ embeds: [logEmbed] });
        }
      }
    }
    if (interaction.customId === 'email_atualizar' || interaction.customId === 'email_gerar') {
      if (!emailData || !emailData.email) {
        await interaction.deferUpdate();
        await interaction.editReply({ content: 'Erro ao criar email temporário. Tente novamente mais tarde.', embeds: [], components: [], flags: 64 });
        return;
      }
      const embed = new EmbedBuilder()
        .setTitle('Email Temporário')
        .setDescription(`### Expiração: <t:${Math.floor(emailData.expiresAt / 1000)}:R>\n\`\`\`${emailData.email}\`\`\``)
        .setColor(0x5865F2)
        .setFooter({ text: 'GG Tools - Email Temp', iconURL: interaction.user.displayAvatarURL() });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('email_gerar').setLabel('Gerar Outro').setStyle(ButtonStyle.Primary).setEmoji({ id: '1387207498410229893' }),
        new ButtonBuilder().setCustomId('email_ver').setLabel('Ver mensagens').setStyle(ButtonStyle.Success).setEmoji({ id: '1387207788710592512' })
      );
      await interaction.deferUpdate();
      await interaction.editReply({ embeds: [embed], components: [row], flags: 64 });
      return;
    }
    if (interaction.customId === 'email_select') {
      const htmlEmails = emailData?.lastHtmlEmails || [];
      const idx = parseInt(interaction.values[0], 10);
      const email = htmlEmails[idx];
      if (!email) {
        if (!interaction.deferred && !interaction.replied) {
          await interaction.reply({ content: 'Email não encontrado.', flags: 64 });
        } else {
          await interaction.followUp({ content: 'Email não encontrado.', flags: 64 });
        }
        return;
      }
      const link = `${baseUrl}/emails/${userId}/email_${idx + 1}.html`;
      const embed = new EmbedBuilder()
        .setTitle(email.subject || `Sem Assunto #${idx + 1}`)
        .setDescription('Clique no botão abaixo para ver o email no site.')
        .setColor(0x5865F2)
        .setTimestamp();
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('Ver no Site').setURL(link).setEmoji({ id: '1387208260389699695' }),
        new ButtonBuilder().setStyle(ButtonStyle.Secondary).setLabel('Voltar').setCustomId('email_voltar_painel').setEmoji({ id: '1358154884708307235' })
      );
      if (!interaction.deferred && !interaction.replied) {
        if (interaction.isStringSelectMenu && interaction.isStringSelectMenu()) {
          await interaction.deferUpdate();
        } else {
          await interaction.deferReply({ flags: 64 });
        }
      }
      await interaction.editReply({ embeds: [embed], components: [row], flags: 64 });
      // Log embed
      const logChannelId = config.log_email_temp;
      if (logChannelId) {
        const logChannel = interaction.client.channels.cache.get(logChannelId);
        if (logChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle('📝 [LOG - Email Temporário] Visualização de Mensagens')
            .setColor(0x5865F2)
            .addFields(
              { name: 'Usuário', value: `<@${interaction.user.id}> (${interaction.user.id})`, inline: false },
              { name: 'Email', value: emailData.email, inline: false },
              { name: 'Qtd Mensagens', value: String(Array.isArray(emailData.lastHtmlEmails) ? emailData.lastHtmlEmails.length : 0), inline: true }
            )
            .setTimestamp();
          await logChannel.send({ embeds: [logEmbed] });
        }
      }
      return;
    }
    if (interaction.customId === 'email_voltar') {
      const htmlEmails = emailData?.lastHtmlEmails || [];
      if (!htmlEmails.length) {
        if (!interaction.deferred && !interaction.replied) {
          if (interaction.isButton && interaction.isButton()) {
            await interaction.deferUpdate();
          } else {
            await interaction.deferReply({ flags: 64 });
          }
        }
        await interaction.editReply({ content: 'Nenhum email HTML disponível.', embeds: [], components: [], flags: 64 });
        return;
      }
      if (!interaction.deferred && !interaction.replied) {
        if (interaction.isButton && interaction.isButton()) {
          await interaction.deferUpdate();
        } else {
          await interaction.deferReply({ flags: 64 });
        }
      }
      const select = new StringSelectMenuBuilder()
        .setCustomId('email_select')
        .setPlaceholder('Selecione um email para visualizar')
        .setMinValues(1)
        .setMaxValues(1)
        .addOptions(htmlEmails.map((e, i) => ({
          label: e.subject ? e.subject.substring(0, 80) : `Sem Assunto #${i + 1}`,
          value: String(i),
          description: e.from ? `De: ${e.from}` : undefined
        })));
      const row = new ActionRowBuilder().addComponents(select);
      await interaction.editReply({ content: 'Selecione um email para visualizar:', embeds: [], components: [row], flags: 64 });
      return;
    }
    if (interaction.customId === 'email_ver') {
      if (!interaction.deferred && !interaction.replied) {
        if (interaction.isButton && interaction.isButton()) {
          await interaction.deferUpdate();
        } else {
          await interaction.deferReply({ flags: 64 });
        }
      }
      // 1. Carrega emails antigos do JSON
      let oldEmails = Array.isArray(emailData.lastHtmlEmails) ? emailData.lastHtmlEmails : [];
      let res;
      try {
        res = await getEmails(emailData.token);
      } catch (e) {
        await interaction.editReply({ content: 'Erro ao buscar mensagens do email temporário. Tente novamente mais tarde.', embeds: [], components: [], flags: 64 });
        return;
      }
      // 2. Emails novos da API
      const apiEmails = res?.emails?.filter(e => e.html) || [];
      // 3. Mescla sem duplicar (por 'date' ou 'html')
      const allEmails = [...oldEmails];
      for (const newEmail of apiEmails) {
        if (!allEmails.some(e => (e.date && newEmail.date && e.date === newEmail.date) || (e.html && newEmail.html && e.html === newEmail.html))) {
          allEmails.push(newEmail);
        }
      }
      if (allEmails.length === 0) {
        await interaction.followUp({ content: 'Nenhuma mensagem recebida ainda.', flags: 64 });
        return;
      }
      // 4. Gera HTMLs para todos
      startExpressServer();
      const userDir = path.join(__dirname, '../../public/emails', String(userId));
      if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true });
      const htmlFiles = [];
      allEmails.forEach((e, i) => {
        const filePath = path.join(userDir, `email_${i + 1}.html`);
        fs.writeFileSync(filePath, e.html, 'utf-8');
        htmlFiles.push(filePath);
      });
      // 5. Atualiza DB
      emailTempDB[userId].htmlFiles = htmlFiles;
      emailTempDB[userId].lastHtmlEmails = allEmails;
      saveEmailTempDB();
      // 6. Monta SelectMenu
      const select = new StringSelectMenuBuilder()
        .setCustomId('email_select')
        .setPlaceholder('Selecione um email para visualizar')
        .setMinValues(1)
        .setMaxValues(1)
        .addOptions(allEmails.map((e, i) => ({
          label: e.subject ? e.subject.substring(0, 80) : `Sem Assunto #${i + 1}`,
          value: String(i),
          description: e.from ? `De: ${e.from}` : undefined
        })));
      const row = new ActionRowBuilder().addComponents(select);
      if (interaction.replied || interaction.deferred) {
        await interaction.editReply({ content: 'Selecione um email para visualizar:', embeds: [], components: [row], flags: 64 });
      } else {
        await interaction.reply({ content: 'Selecione um email para visualizar:', embeds: [], components: [row], flags: 64 });
      }
      return;
    }
  } catch (err) {
    console.error('[EmailTempButton][ERRO]', {
      customId: interaction.customId,
      userId: interaction.user?.id,
      emailTempDB: emailTempDB[interaction.user?.id],
      error: err
    });
    await safeReply(interaction, { content: 'Erro inesperado ao processar o painel de email temporário. Tente novamente mais tarde.', flags: 64 });
  }
}
// --- FIM: Email Temporário ---

// Função utilitária para evitar crash em reply duplicado
async function safeReply(interaction, data) {
  try {
    // Sempre força flags: 64 para respostas de extração
    if (!data.flags) data.flags = 64;
    if (interaction.replied || interaction.deferred) {
      // Usa editReply para atualizar a resposta efêmera
      await interaction.editReply(data);
    } else {
      await interaction.reply(data);
    }
  } catch (e) {
    // ignora erro
  }
}

// --- FREE FIRE HANDLERS ---
async function hasPermissaoFreeFire(interaction) {
  const cargoUniversal = config.cargo_permitido_universal;
  const cargoEspecifico = config.cargo_permitido_free_fire;
  if (!cargoUniversal && !cargoEspecifico) return true;
  if (!interaction.guild) return false;
  const member = await interaction.guild.members.fetch(interaction.user.id);
  return member.roles.cache.has(cargoUniversal) || member.roles.cache.has(cargoEspecifico);
}
async function handleFreeFire(interaction) {
  if (!(await hasPermissaoFreeFire(interaction))) {
    await interaction.reply({ content: '\`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags: 64 });
    return;
  }
  const select = new StringSelectMenuBuilder()
    .setCustomId('free_fire_select')
    .setPlaceholder('Escolha uma opção do Free Fire')
    .addOptions([
      { label: 'Enviar Likes', value: 'send_likes', description: 'Enviar likes para uma conta (100 p/dia)', emoji: { id: '1387227400852602920' } },
      { label: 'Ver Conta', value: 'view_account', description: 'Ver contas disponíveis para likes', emoji: { id: '1387227546277380096' } },
      { label: 'Info da Conta', value: 'info_account', description: 'Ver informações de uma conta', emoji: { id: '1387227712350851122' } },
      { label: 'Checar Ban', value: 'check_ban', description: 'Verificar se uma conta está banida', emoji: { id: '1387227948733698089' } }
    ]);
  const row = new ActionRowBuilder().addComponents(select);
  await interaction.reply({ content: 'Selecione uma opção do Free Fire:', components: [row], flags: 64 });
}
async function handleFreeFireSelect(interaction) {
  const value = interaction.values[0];
  let modal;
  if (value === 'send_likes') {
    modal = new ModalBuilder()
      .setCustomId('free_fire_modal_send_likes')
      .setTitle('Enviar Likes')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('uid')
            .setLabel('UID do Jogador')
            .setPlaceholder('Digite o UID do jogador')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        )
      );
  } else if (value === 'view_account') {
    // Não abre modal, executa direto
    await handleFreeFireModalViewAccount(interaction);
    return;
  } else if (value === 'info_account') {
    modal = new ModalBuilder()
      .setCustomId('free_fire_modal_info_account')
      .setTitle('Info da Conta')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('uid')
            .setLabel('UID do Jogador')
            .setPlaceholder('Digite o UID do jogador')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        )
      );
  } else if (value === 'check_ban') {
    modal = new ModalBuilder()
      .setCustomId('free_fire_modal_check_ban')
      .setTitle('Checar Ban')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('uid')
            .setLabel('UID do Jogador')
            .setPlaceholder('Digite o UID do jogador')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        )
      );
  }
  if (modal) await interaction.showModal(modal);
}
async function handleFreeFireModalSendLikes(interaction) {
  const uid = interaction.fields.getTextInputValue('uid');
  await interaction.reply({ content: '`⏳` Enviando likes, aguarde...', flags: 64 });
  try {
    const result = await sendLikes(uid);
    // Formatar resposta amigável
    const txt =
      `Resultado do Envio de Likes (Free Fire)\n` +
      `====================================\n\n` +
      `🎯 UID Alvo: ${result.target_id || uid}\n` +
      `🌎 Região: ${result.region || '-'}\n` +
      `👍 Likes enviados: ${result.likes_enviados || 0}\n` +
      `❌ Falhas: ${result.falhas || 0}\n` +
      `✅ Sucessos: ${result.sucessos || 0}\n`;
    // Enviar na DM
    await interaction.user.send({
      content: 'Olá <@' + interaction.user.id + '> aqui está o resultado do envio de likes no Free Fire:',
      files: [{ attachment: Buffer.from(txt, 'utf-8'), name: 'likes_freefire.txt' }]
    });
    await interaction.editReply({ content: '`✅` Resultado enviado na sua DM!', flags: 64 });
    // Log
    const logChannelId = config.log_free_fire;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('📝 [LOG - Free Fire] Envio de Likes')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}> (${interaction.user.id})`, inline: false },
            { name: 'UID Alvo', value: `${result.target_id || uid}`, inline: true },
            { name: 'Região', value: `${result.region || '-'}`, inline: true },
            { name: 'Likes enviados', value: `${result.likes_enviados || 0}`, inline: true },
            { name: 'Falhas', value: `${result.falhas || 0}`, inline: true },
            { name: 'Sucessos', value: `${result.sucessos || 0}`, inline: true }
          )
          .setTimestamp();
        await logChannel.send({
          embeds: [embed],
          files: [{ attachment: Buffer.from(txt, 'utf-8'), name: 'likes_freefire.txt' }]
        });
      }
    }
  } catch (e) {
    await interaction.editReply({ content: '`❌` Erro ao enviar likes: ' + ((e && e.response && e.response.data && e.response.data.message) || e.message), flags: 64 });
  }
}
async function handleFreeFireModalViewAccount(interaction) {
  await interaction.reply({ content: '`⏳` Buscando contas, aguarde...', flags: 64 });
  try {
    const result = await viewAccount();
    // Formatar resposta amigável
    const txt =
      `Contas Disponíveis para Likes (Free Fire)\n` +
      `========================================\n\n` +
      `🇧🇷 Brasil\n` +
      `  - Disponíveis: ${result.accounts_available_for_sending_likes_brazil}\n` +
      `  - Não disponíveis: ${result.accounts_not_available_to_send_likes_brazil}\n\n` +
      `🇮🇳 Índia\n` +
      `  - Disponíveis: ${result.accounts_available_for_sending_likes_india}\n` +
      `  - Não disponíveis: ${result.accounts_not_available_to_send_likes_india}\n`;
    // Enviar na DM
    await interaction.user.send({
      content: 'Olá <@' + interaction.user.id + '> aqui está a lista de contas disponíveis para envio de likes no Free Fire:',
      files: [{ attachment: Buffer.from(txt, 'utf-8'), name: 'contas_freefire.txt' }]
    });
    await interaction.editReply({ content: '`✅` Consulta enviada na sua DM!', flags: 64 });
    // Log
    const logChannelId = config.log_free_fire;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('📝 [LOG - Free Fire] Consulta de Contas Disponíveis')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}> (${interaction.user.id})`, inline: false },
            { name: '🇧🇷 Brasil', value: `Disponíveis: ${result.accounts_available_for_sending_likes_brazil}\nNão disponíveis: ${result.accounts_not_available_to_send_likes_brazil}`, inline: true },
            { name: '🇮🇳 Índia', value: `Disponíveis: ${result.accounts_available_for_sending_likes_india}\nNão disponíveis: ${result.accounts_not_available_to_send_likes_india}`, inline: true }
          )
          .setTimestamp();
        await logChannel.send({
          embeds: [embed],
          files: [{ attachment: Buffer.from(txt, 'utf-8'), name: 'contas_freefire.txt' }]
        });
      }
    }
  } catch (e) {
    await interaction.editReply({ content: '`❌` Erro ao buscar contas: ' + ((e && e.response && e.response.data && e.response.data.message) || e.message), flags: 64 });
  }
}
async function handleFreeFireModalInfoAccount(interaction) {
  const uid = interaction.fields.getTextInputValue('uid');
  await interaction.reply({ content: '`⏳` Buscando info da conta, aguarde...', flags: 64 });
  try {
    const result = await infoAccount(uid);
    const info = result.basicInfo || {};
    const txt =
      `Informações do Jogador (Free Fire)\n` +
      `===============================\n\n` +
      `🎮 Nickname: ${info.nickname || '-'}\n` +
      `🆔 UID: ${info.accountId || uid}\n` +
      `⭐ Level: ${info.level || '-'}\n` +
      `💥 EXP: ${info.exp || '-'}\n` +
      `🏅 Likes: ${info.liked || '-'}\n` +
      `📅 Criado em: ${info.createAt ? new Date(Number(info.createAt) * 1000).toLocaleString('pt-BR') : '-'}\n`;
    await interaction.user.send({
      content: 'Olá <@' + interaction.user.id + '> aqui está o resultado da consulta da info da conta:',
      files: [{ attachment: Buffer.from(txt, 'utf-8'), name: 'info_jogador_freefire.txt' }]
    });
    await interaction.editReply({ content: '`✅` Info enviada na sua DM!', flags: 64 });
    // Log
    const logChannelId = config.log_free_fire;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('📝 [LOG - Free Fire] Consulta de Info de Jogador')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}> (${interaction.user.id})`, inline: false },
            { name: 'Nickname', value: `${info.nickname || '-'}`, inline: true },
            { name: 'UID', value: `${info.accountId || uid}`, inline: true },
            { name: 'Level', value: `${info.level || '-'}`, inline: true },
            { name: 'EXP', value: `${info.exp || '-'}`, inline: true },
            { name: 'Likes', value: `${info.liked || '-'}`, inline: true },
            { name: 'Criado em', value: `${info.createAt ? new Date(Number(info.createAt) * 1000).toLocaleString('pt-BR') : '-'}`, inline: true }
          )
          .setTimestamp();
        await logChannel.send({
          embeds: [embed],
          files: [{ attachment: Buffer.from(txt, 'utf-8'), name: 'info_jogador_freefire.txt' }]
        });
      }
    }
  } catch (e) {
    await interaction.editReply({ content: '`❌` Erro ao buscar info: ' + ((e && e.response && e.response.data && e.response.data.message) || e.message), flags: 64 });
  }
}
async function handleFreeFireModalCheckBan(interaction) {
  const uid = interaction.fields.getTextInputValue('uid');
  await interaction.reply({ content: '`⏳` Checando ban, aguarde...', flags: 64 });
  try {
    const result = await checkBan(uid);
    const txt =
      `Status de Banimento (Free Fire)\n` +
      `============================\n\n` +
      `🆔 UID: ${result.uid || uid}\n` +
      `🚫 Banido: ${result.is_banned == 1 ? 'Sim' : 'Não'}\n` +
      (result.is_banned == 1 ? `⏳ Período: ${result.ban_period || '-'} mês(es)\n` : '') +
      (result.message ? `💬 Motivo: ${result.message}\n` : '');
    await interaction.user.send({
      content: 'Olá <@' + interaction.user.id + '> aqui está o resultado da consulta de banimento:',
      files: [{ attachment: Buffer.from(txt, 'utf-8'), name: 'banimento_freefire.txt' }]
    });
    await interaction.editReply({ content: '`✅` Status enviado na sua DM!', flags: 64 });
    // Log
    const logChannelId = config.log_free_fire;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('📝 [LOG - Free Fire] Consulta de Banimento')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}> (${interaction.user.id})`, inline: false },
            { name: 'UID', value: `${result.uid || uid}`, inline: true },
            { name: 'Banido', value: `${result.is_banned == 1 ? 'Sim' : 'Não'}`, inline: true },
            ...(result.is_banned == 1 ? [{ name: 'Período', value: `${result.ban_period || '-'} mês(es)`, inline: true }] : []),
            ...(result.message ? [{ name: 'Motivo', value: `${result.message}`, inline: false }] : [])
          )
          .setTimestamp();
        await logChannel.send({
          embeds: [embed],
          files: [{ attachment: Buffer.from(txt, 'utf-8'), name: 'banimento_freefire.txt' }]
        });
      }
    }
  } catch (e) {
    await interaction.editReply({ content: '`❌` Erro ao checar ban: ' + ((e && e.response && e.response.data && e.response.data.message) || e.message), flags: 64 });
  }
}
// --- FIM FREE FIRE HANDLERS ---

// Handler do submit do modal de clonagem
async function handlePainelClonarModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "clonagem"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  await safeReply(interaction, { content: '`🔄` Iniciando clonagem, aguarde...', flags : 64 });
  const token = interaction.fields.getTextInputValue('token');
  const original = interaction.fields.getTextInputValue('original');
  const alvo = interaction.fields.getTextInputValue('alvo');
  const userId = interaction.user.id;
  // Recupera seleções do painelTemp
  const temp = painelTemp[userId] || { apagarSelecionados: [], clonarSelecionados: [] };
  await cloneServer({
    token,
    originalId: original,
    targetId: alvo,
    interaction,
    logsChannelId: config.log_clonagem,
    apagarSelecionados: temp.apagarSelecionados,
    clonarSelecionados: temp.clonarSelecionados
  });
}

// Handler para o botão "Criar Servidores com IA"
async function handlePainelCriarServidoresIA(interaction) {
  const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  const guilds = interaction.client.guilds.cache;
  // Checa permissão em todos os servidores que o bot está
  const cargosPermitidos = [
    config["cargo-permitido-ia"],
    config.cargo_permitido_universal
  ].filter(Boolean);

  if (cargosPermitidos.length > 0) {
    let temPermissao = false;
    for (const guild of guilds.values()) {
      try {
        const member = await guild.members.fetch(interaction.user.id);
        if (cargosPermitidos.some(cargoId => member.roles.cache.has(cargoId))) {
          temPermissao = true;
          break;
        }
      } catch {}
    }
    if (!temPermissao) {
      await interaction.reply({ content: '\`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags: 64 });
      return;
    }
  }
  const modal = new ModalBuilder()
    .setCustomId('modal_criar_servidor_ia')
    .setTitle('Criar Servidor com IA')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('prompt_servidor_ia')
          .setLabel('Descreva como quer seu servidor')
          .setPlaceholder('Ex: Um servidor de jogos com canais para LOL, Valorant e área de staff')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
      )
    );
  await interaction.showModal(modal);
}

// Handler para o submit do modal de criação de servidor com IA
async function handleModalCriarServidorIASubmit(interaction) {
  const promptUsuario = interaction.fields.getTextInputValue('prompt_servidor_ia');
  // Prompt base para IA com exemplo de estrutura
  const promptBase = `Você é uma IA especialista em criar servidores do Discord. Gere uma estrutura de servidor Discord em formato estritamente JSON, SEM explicação, apenas o JSON, seguindo exatamente o padrão abaixo:\n\n{
  "nome": "Nome do Servidor",
  "cargos": ["Admin", "Moderador", "Membro", "Visitante"],
  "categorias": [
    {
      "nome": "Geral",
      "canais": ["chat-geral", "regras", "anúncios"]
    },
    {
      "nome": "Jogos",
      "canais": ["lol", "valorant", "minecraft", "outros-jogos"]
    },
    {
      "nome": "Comunidade",
      "canais": ["apresentações", "off-topic", "suporte"]
    }
  ]
}\n\n- Gere quantos cargos, categorias e canais forem necessários para o pedido do usuário.\n- Use nomes de canais e categorias descritivos e adequados ao tema.\n- Não explique, apenas gere o JSON.\n- Os campos devem ser exatamente: nome, cargos, categorias (com nome e canais).\n\nPedido do usuário: `;
  const prompt = promptBase + promptUsuario;
  await interaction.reply({ content: '`⏳` Gerando sugestão de servidor com IA, aguarde...', flags: 64 });
  const estrutura = await sugerirServidorIA(prompt, interaction.user.id);

  // Se estrutura.texto for um JSON válido, parseie
  if (estrutura.texto && typeof estrutura.texto === 'string') {
    try {
      const parsed = JSON.parse(estrutura.texto);
      estrutura.nome = parsed.nome || parsed.name;
      estrutura.cargos = parsed.cargos || parsed.roles;
      estrutura.categorias = parsed.categorias || parsed.categories;
    } catch (e) {
      // Se não for JSON, deixa como está
    }
  }

  // Aceitar campos alternativos (caso a IA retorne name/roles/categories direto)
  estrutura.nome = estrutura.nome || estrutura.name;
  estrutura.cargos = estrutura.cargos || estrutura.roles;
  estrutura.categorias = estrutura.categorias || estrutura.categories;

  let sugestaoNome = estrutura.nome || estrutura.sugestao_nome || '';
  let cargos = estrutura.cargos || [];
  let categorias = estrutura.categorias || [];

  const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
  const embed = new EmbedBuilder()
    .setTitle('✨ Estrutura Sugerida para seu Servidor')
    .setColor(0x2ECC71)
    .setDescription('Veja abaixo a estrutura sugerida pela IA. Você pode editar, aprovar ou pedir uma nova sugestão!')
    .setFooter({ text: 'Visualização gerada por IA • GG Tools', iconURL: interaction.user.displayAvatarURL() })
    .setTimestamp();
  if (sugestaoNome) embed.addFields({ name: '🏷️ Nome sugerido', value: sugestaoNome });
  if (cargos.length) {
    let cargosStr = cargos.slice(0, 15).map(c => `• ${c}`).join('\n');
    if (cargos.length > 15) cargosStr += `\n...e mais ${cargos.length - 15}`;
    embed.addFields({ name: '🏷️ Cargos', value: cargosStr.slice(0, 1024) });
  }
  if (categorias.length) {
    let catStr = '';
    categorias.slice(0, 8).forEach(cat => {
      const nomeCat = cat.nome || cat.name;
      catStr += `🗂️ **${nomeCat}**\n`;
      const canais = cat.canais || cat.channels || [];
      if (Array.isArray(canais) && canais.length) {
        let canaisStr = canais.slice(0, 10).map(canal => `   #️⃣ ${canal}`).join('\n');
        if (canais.length > 10) canaisStr += `\n   ...e mais ${canais.length - 10}`;
        catStr += canaisStr + '\n';
      }
    });
    if (categorias.length > 8) catStr += `...e mais ${categorias.length - 8} categorias`;
    embed.addFields({ name: '🗂️ Categorias e Canais', value: catStr.slice(0, 1024) });
  }
  // Botão de invite e avançar
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  const botId = config.id_bot_ia || 'SEU_CLIENT_ID_DO_BOT';
  const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${botId}&permissions=8&scope=bot%20applications.commands`;
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel('Adicionar o Bot ao seu Servidor')
      .setStyle(ButtonStyle.Link)
      .setURL(inviteUrl),
    new ButtonBuilder()
      .setCustomId('painel_ia_avancar_estrutura')
      .setLabel('Avançar')
      .setStyle(ButtonStyle.Success)
  );
  await interaction.editReply({
    content: '',
    embeds: [embed],
    components: [row],
    flags: 64
  });
}

// Handler para o botão "Avançar" após ver a estrutura
async function handlePainelIAAvancarEstrutura(interaction) {
  // Ao clicar em avançar, já mostra o modal para informar o ID do servidor
  const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
  const modal = new ModalBuilder()
    .setCustomId('modal_ia_informar_guild')
    .setTitle('Criar em qual servidor?')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('guild_id_ia')
          .setLabel('ID do servidor (guild)')
          .setPlaceholder('Ex: 123456789012345678')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      )
    );
  await interaction.showModal(modal);
}

// Handler para o submit do modal de guild
async function handleModalIAInformarGuild(interaction) {
  const guildId = interaction.fields.getTextInputValue('guild_id_ia');
  await interaction.reply({ content: '`⏳` Criando estrutura no servidor, aguarde...', flags: 64 });
  const { criarServidorComEstruturaIA } = require('./ServidoresIAHandler');
  await criarServidorComEstruturaIA(interaction.user.id, guildId, interaction);
}

// Handler para mostrar o modal de clonar site
async function handlePainelClonerSiteModal(interaction) {
  // Permissão: cargo_permitido_cloner_site OU cargo_permitido_universal
  const cargoUniversal = config.cargo_permitido_universal;
  const cargoEspecifico = config.cargo_permitido_cloner_site;
  let temPermissao = false;
  if (!cargoUniversal && !cargoEspecifico) {
    temPermissao = true;
  } else if (interaction.guild) {
    const member = await interaction.guild.members.fetch(interaction.user.id);
    if ((cargoUniversal && member.roles.cache.has(cargoUniversal)) || (cargoEspecifico && member.roles.cache.has(cargoEspecifico))) {
      temPermissao = true;
    }
  }
  if (!temPermissao) {
    await interaction.reply({ content: '`❌` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags: 64 });
    return;
  }
  const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
  const modal = new ModalBuilder()
    .setCustomId('painel_cloner_site_modal_submit')
    .setTitle('Clonar Site');

  const option1 = new TextInputBuilder()
    .setCustomId('name-site')
    .setLabel('Nome do arquivo')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('Ex: meu-site')
    .setRequired(true);

  const option2 = new TextInputBuilder()
    .setCustomId('url-input')
    .setLabel('URL do site')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('https://exemplo.com')
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(option1),
    new ActionRowBuilder().addComponents(option2)
  );
  await interaction.showModal(modal);
}

// Handler para processar o modal de clonar site
async function handlePainelClonerSiteModalSubmit(interaction) {
  // Permissão: cargo_permitido_cloner_site OU cargo_permitido_universal
  const cargoUniversal = config.cargo_permitido_universal;
  const cargoEspecifico = config.cargo_permitido_cloner_site;
  let temPermissao = false;
  if (!cargoUniversal && !cargoEspecifico) {
    temPermissao = true;
  } else if (interaction.guild) {
    const member = await interaction.guild.members.fetch(interaction.user.id);
    if ((cargoUniversal && member.roles.cache.has(cargoUniversal)) || (cargoEspecifico && member.roles.cache.has(cargoEspecifico))) {
      temPermissao = true;
    }
  }
  if (!temPermissao) {
    await interaction.reply({ content: '`❌` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags: 64 });
    return;
  }
  const { clonerSite } = require('../functions/clonerSite');
  try {
    const filename = interaction.fields.getTextInputValue('name-site');
    const url = interaction.fields.getTextInputValue('url-input');
    await interaction.reply({ content: `🔁 | Espere um momento, estamos trabalhando nisso...`, ephemeral: true, flags: 64 });
    const htmlBuffer = await clonerSite(url);
    if (htmlBuffer) {
      await interaction.editReply({
        content: `Aqui está seu HTML do site clonado:`,
        files: [{ attachment: htmlBuffer, name: `${filename}.html` }],
        ephemeral: true,
        flags: 64
      });
    } else {
      await interaction.editReply({ content: `\`❌\` Ocorreu um erro ao tentar clonar o site. Talvez o site tenha bloqueado o acesso.`, ephemeral: true, flags: 64 });
    }
  } catch (error) {
    console.error('Erro durante a clonagem do site:', error);
    await interaction.editReply({ content: `\`❌\` Ocorreu um erro ao tentar clonar o site. Talvez o site tenha bloqueado o acesso.`, ephemeral: true, flags: 64 });
  }
}

// Handler para o botão BanAll
async function handlePainelBanAllModal(interaction) {
  if (!(await hasPermissao(interaction, "banall"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('painel_banall_modal_submit')
    .setTitle('Banir Todos (Atenção!)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da sua conta ou bot')
        .setPlaceholder('Cole seu token aqui.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token_type')
        .setLabel('Tipo de token (bot/conta)')
        .setPlaceholder('bot ou conta')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('guild_id')
        .setLabel('ID do servidor')
        .setPlaceholder('Cole o ID do servidor')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}
// Handler para o submit do modal de BanAll
async function handlePainelBanAllModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "banall"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  await safeReply(interaction, { content: '`⏳` Iniciando banAll, aguarde...', flags : 64 });
  const token = interaction.fields.getTextInputValue('token');
  const tokenType = interaction.fields.getTextInputValue('token_type');
  const guildId = interaction.fields.getTextInputValue('guild_id');
  await banAll({ token, guildId, tokenType, interaction, logsChannelId: config.log_banall });
}
// Handler para o botão KickAll
async function handlePainelKickAllModal(interaction) {
  if (!(await hasPermissao(interaction, "kickall"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('painel_kickall_modal_submit')
    .setTitle('Expulsar Todos (Atenção!)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da sua conta ou bot')
        .setPlaceholder('Cole seu token aqui.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token_type')
        .setLabel('Tipo de token (bot/conta)')
        .setPlaceholder('bot ou conta')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('guild_id')
        .setLabel('ID do servidor')
        .setPlaceholder('Cole o ID do servidor')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}
// Handler para o submit do modal de KickAll
async function handlePainelKickAllModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "kickall"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  await safeReply(interaction, { content: '`⏳` Iniciando kickAll, aguarde...', flags : 64 });
  const token = interaction.fields.getTextInputValue('token');
  const tokenType = interaction.fields.getTextInputValue('token_type');
  const guildId = interaction.fields.getTextInputValue('guild_id');
  await kickAll({ token, guildId, tokenType, interaction, logsChannelId: config.log_kickall });
}

// Adiciona função para fechar DMs
async function handlePainelCloseDM(interaction) {
  if (!(await hasPermissao(interaction, "close_dm"))) {
    await interaction.reply({ content: messages.PERMISSION_DENIED, flags: 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('painel_close_dm_modal_submit')
    .setTitle('Fechar DMs (Atenção!)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da sua conta (Atenção: irreversível)')
        .setPlaceholder('Cole seu token aqui.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('whitelist')
        .setLabel('Whitelist IDs (vírgula, opcional)')
        .setPlaceholder('Ex: 123,456,789')
        .setStyle(TextInputStyle.Short)
        .setRequired(false)
    )
  );
  await interaction.showModal(modal);
}

// Handler para o submit do modal de fechar DMs
async function handlePainelCloseDMModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "close_dm"))) {
    await interaction.reply({ content: messages.PERMISSION_DENIED, flags: 64 });
    return;
  }
  await safeReply(interaction, { content: '`⏳` Iniciando fechamento de DMs, aguarde...', flags: 64 });
  const token = interaction.fields.getTextInputValue('token');
  const whitelist = interaction.fields.getTextInputValue('whitelist')?.split(',').map(s => s.trim()).filter(Boolean) || [];
  const result = await closeUserDMs(token, undefined, whitelist, interaction);
  await safeReply(interaction, { content: '`✅` Fechamento finalizado! DMs fechadas: **' + result.closed + '** | Puladas: **' + result.skipped + '** | Falhas: **' + result.errors + '**', flags: 64 });
}

// Handler para o botão Raid
async function handlePainelRaidModal(interaction) {
  if (!(await hasPermissao(interaction, "raid"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  const modal = new ModalBuilder()
    .setCustomId('painel_raid_modal_submit')
    .setTitle('Ataque em Massa (Raid)');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token')
        .setLabel('Token da sua conta ou bot')
        .setPlaceholder('Cole seu token aqui.')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('token_type')
        .setLabel('Tipo de token (bot/conta)')
        .setPlaceholder('bot ou conta')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('guild_id')
        .setLabel('ID do servidor')
        .setPlaceholder('Cole o ID do servidor')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

// Handler para o submit do modal de Raid
async function handlePainelRaidModalSubmit(interaction) {
  if (!(await hasPermissao(interaction, "raid"))) {
    await interaction.reply({ content: MSG_PERMISSAO, flags : 64 });
    return;
  }
  await safeReply(interaction, { content: '`⏳` Iniciando raid, aguarde...', flags : 64 });
  const token = interaction.fields.getTextInputValue('token');
  const tokenType = interaction.fields.getTextInputValue('token_type');
  const guildId = interaction.fields.getTextInputValue('guild_id');
  // Aqui você deve chamar a função de raid real, exemplo:
  // await raid({ token, guildId, tokenType, interaction, logsChannelId: config.log_raid });
  // Por enquanto, só responde sucesso:
  await safeReply(interaction, { content: '`✅` Raid finalizado! (handler placeholder)', flags: 64 });
}

// Handler para o botão Disparo DM
async function handlePainelDisparoDM(interaction) {
  return painelDisparoDMHandlers.handlePainelDisparoDM(interaction);
}

module.exports = {
  painelHandlers: {
    handlePainelCommand,
    handlePainelMenu,
    handlePainelAjuda,
    handlePainelVoltarPrincipal,
    handlePainelIniciarModal,
    handlePainelTokenType,
    handlePainelModal,
    handlePainelTipo,
    handlePainelIniciar,
    handlePainelCancelarExtracao,
    handlePainelClonarModal,
    handlePainelClonarToggle,
    handlePainelClonarContinuar,
    handlePainelCleanDM,
    handlePainelCleanDMModalSubmit,
    handlePainelUnfriendModal,
    handlePainelUnfriendModalSubmit,
    handlePainelLeaveGuildsModal,
    handlePainelLeaveGuildsModalSubmit,
    handlePainelLimparServidor,
    handlePainelLimparServidorModalSubmit,
    handlePainelFloodModal,
    handlePainelFloodModalSubmit,
    handleConsultaNome,
    handleConsultaNomeSubmit,
    handleConsultaCPF,
    handleConsultaCPFSubmit,
    handleConsultaCNPJ,
    handleConsultaCNPJSubmit,
    handleConsultaTelefone,
    handleConsultaTelefoneSubmit,
    handleEmailTemp,
    handleEmailTempButton,
    handleFreeFire,
    handleFreeFireSelect,
    handleFreeFireModalSendLikes,
    handleFreeFireModalViewAccount,
    handleFreeFireModalInfoAccount,
    handleFreeFireModalCheckBan,
    handlePainelClonarModalSubmit,
    handlePainelCriarServidoresIA,
    handleModalCriarServidorIASubmit,
    handlePainelIAAvancarEstrutura,
    handleModalIAInformarGuild,
    handlePainelClonerSiteModal,
    handlePainelClonerSiteModalSubmit,
    handlePainelBanAllModal,
    handlePainelBanAllModalSubmit,
    handlePainelKickAllModal,
    handlePainelKickAllModalSubmit,
    handlePainelCloseDM,
    handlePainelCloseDMModalSubmit,
    handlePainelRaidModal,
    handlePainelRaidModalSubmit,
    handlePainelDisparoDM
  }
};