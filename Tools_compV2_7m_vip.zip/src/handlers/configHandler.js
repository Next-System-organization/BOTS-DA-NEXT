const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const configPath = path.join(__dirname, '../config.json');
let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

async function handleConfigCommand(interaction) {
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  if (!config.owner_id || interaction.user.id !== config.owner_id) {
    await interaction.reply({ content: '\`❌\` Apenas meus desenvolvedores podem utilizar este comando.', flags : 64 });
    return;
  }
  // Lista de todos os campos
  const cargoFields = [
    { name: 'Owner', value: config.owner_id ? `<@${config.owner_id}>` : 'Não configurado', inline: true },
    { name: 'Cargo Universal', value: config.cargo_permitido_universal ? `<@&${config.cargo_permitido_universal}>` : 'Não configurado', inline: true },
    { name: 'Cargo Extração', value: config.cargo_permitido_extracao ? `<@&${config.cargo_permitido_extracao}>` : 'Não configurado', inline: true },
    { name: 'Cargo Clonagem', value: config.cargo_permitido_clonagem ? `<@&${config.cargo_permitido_clonagem}>` : 'Não configurado', inline: true },
    { name: 'Cargo Clean DM', value: config.cargo_permitido_clean_dm ? `<@&${config.cargo_permitido_clean_dm}>` : 'Não configurado', inline: true },
    { name: 'Cargo Unfriend', value: config.cargo_permitido_unfriend ? `<@&${config.cargo_permitido_unfriend}>` : 'Não configurado', inline: true },
    { name: 'Cargo Leave Guilds', value: config.cargo_permitido_leave_guilds ? `<@&${config.cargo_permitido_leave_guilds}>` : 'Não configurado', inline: true },
    { name: 'Cargo Limpar Servidor', value: config.cargo_permitido_limpar_servidor ? `<@&${config.cargo_permitido_limpar_servidor}>` : 'Não configurado', inline: true },
    { name: 'Cargo Flood', value: config.cargo_permitido_flood ? `<@&${config.cargo_permitido_flood}>` : 'Não configurado', inline: true },
    { name: 'Cargo Kickall', value: config.cargo_permitido_kickall ? `<@&${config.cargo_permitido_kickall}>` : 'Não configurado', inline: true },
    { name: 'Cargo Banall', value: config.cargo_permitido_banall ? `<@&${config.cargo_permitido_banall}>` : 'Não configurado', inline: true },
    { name: 'Cargo Raid', value: config.cargo_permitido_raid ? `<@&${config.cargo_permitido_raid}>` : 'Não configurado', inline: true },
    { name: 'Cargo Disparo DM', value: config.cargo_permitido_disparo_dm ? `<@&${config.cargo_permitido_disparo_dm}>` : 'Não configurado', inline: true },
    { name: 'Cargo Extração Avançada', value: config.cargo_permitido_extractor ? `<@&${config.cargo_permitido_extractor}>` : 'Não configurado', inline: true },
    { name: 'Cargo Clonagem Avançada', value: config.cargo_permitido_cloner ? `<@&${config.cargo_permitido_cloner}>` : 'Não configurado', inline: true },
    { name: 'Cargo Cleaner', value: config.cargo_permitido_cleaner ? `<@&${config.cargo_permitido_cleaner}>` : 'Não configurado', inline: true },
    { name: 'Cargo Fechar DMs', value: config.cargo_permitido_close_dm ? `<@&${config.cargo_permitido_close_dm}>` : 'Não configurado', inline: true },
    { name: 'Cargo Consulta Nome', value: config.cargo_permitido_consulta_nome ? `<@&${config.cargo_permitido_consulta_nome}>` : 'Não configurado', inline: true },
    { name: 'Cargo Consulta CPF', value: config.cargo_permitido_consulta_cpf ? `<@&${config.cargo_permitido_consulta_cpf}>` : 'Não configurado', inline: true },
    { name: 'Cargo Consulta CNPJ', value: config.cargo_permitido_consulta_cnpj ? `<@&${config.cargo_permitido_consulta_cnpj}>` : 'Não configurado', inline: true },
    { name: 'Cargo Consulta Telefone', value: config.cargo_permitido_consulta_telefone ? `<@&${config.cargo_permitido_consulta_telefone}>` : 'Não configurado', inline: true },
    { name: 'Cargo Free Fire', value: config.cargo_permitido_free_fire ? `<@&${config.cargo_permitido_free_fire}>` : 'Não configurado', inline: true },
    { name: 'Cargo Email Temporário', value: config.cargo_permitido_email_temp ? `<@&${config.cargo_permitido_email_temp}>` : 'Não configurado', inline: true },
    { name: 'Cargo IA', value: config["cargo-permitido-ia"] ? `<@&${config["cargo-permitido-ia"]}>` : 'Não configurado', inline: true },
    { name: 'Cargo Cloner Site', value: config.cargo_permitido_cloner_site ? `<@&${config.cargo_permitido_cloner_site}>` : 'Não configurado', inline: true },
  ];
  const logFields = [
    { name: 'Log Extração', value: config.log_extracao ? `<#${config.log_extracao}>` : 'Não configurado', inline: true },
    { name: 'Log Clonagem', value: config.log_clonagem ? `<#${config.log_clonagem}>` : 'Não configurado', inline: true },
    { name: 'Log Clean DM', value: config.log_clean_dm ? `<#${config.log_clean_dm}>` : 'Não configurado', inline: true },
    { name: 'Log Unfriend', value: config.log_unfriend ? `<#${config.log_unfriend}>` : 'Não configurado', inline: true },
    { name: 'Log Leave Guilds', value: config.log_leave_guilds ? `<#${config.log_leave_guilds}>` : 'Não configurado', inline: true },
    { name: 'Log Limpar Servidor', value: config.log_limpar_servidor ? `<#${config.log_limpar_servidor}>` : 'Não configurado', inline: true },
    { name: 'Log Flood', value: config.log_flood ? `<#${config.log_flood}>` : 'Não configurado', inline: true },
    { name: 'Log Kickall', value: config.log_kickall ? `<#${config.log_kickall}>` : 'Não configurado', inline: true },
    { name: 'Log BanAll', value: config.log_banall ? `<#${config.log_banall}>` : 'Não configurado', inline: true },
    { name: 'Log Raid', value: config.log_raid ? `<#${config.log_raid}>` : 'Não configurado', inline: true },
    { name: 'Log Disparo DM', value: config.log_disparo_dm ? `<#${config.log_disparo_dm}>` : 'Não configurado', inline: true },
    { name: 'Log Fechar DMs', value: config.log_close_dm ? `<#${config.log_close_dm}>` : 'Não configurado', inline: true },
    { name: 'Log Cleaner', value: config.log_cleaner ? `<#${config.log_cleaner}>` : 'Não configurado', inline: true },
    { name: 'Log Extração Avançada', value: config.log_extractor ? `<#${config.log_extractor}>` : 'Não configurado', inline: true },
    { name: 'Log Clonagem Avançada', value: config.log_cloner ? `<#${config.log_cloner}>` : 'Não configurado', inline: true },
    { name: 'Log Consulta Nome', value: config.log_consulta_nome ? `<#${config.log_consulta_nome}>` : 'Não configurado', inline: true },
    { name: 'Log Consulta CPF', value: config.log_consulta_cpf ? `<#${config.log_consulta_cpf}>` : 'Não configurado', inline: true },
    { name: 'Log Consulta CNPJ', value: config.log_consulta_cnpj ? `<#${config.log_consulta_cnpj}>` : 'Não configurado', inline: true },
    { name: 'Log Consulta Telefone', value: config.log_consulta_telefone ? `<#${config.log_consulta_telefone}>` : 'Não configurado', inline: true },
    { name: 'Log Free Fire', value: config.log_free_fire ? `<#${config.log_free_fire}>` : 'Não configurado', inline: true },
    { name: 'Log Email Temporário', value: config.log_email_temp ? `<#${config.log_email_temp}>` : 'Não configurado', inline: true },
    { name: 'Log IA', value: config["log-ia"] ? `<#${config["log-ia"]}>` : 'Não configurado', inline: true },
    { name: 'Log Cloner Site', value: config.log_cloner_site ? `<#${config.log_cloner_site}>` : 'Não configurado', inline: true },
  ];
  const embed1 = new EmbedBuilder()
    .setTitle('`⚙️` Painel de Configuração - Cargos')
    .setDescription('Configure as opções de cargos do bot usando os botões abaixo:')
    .setColor(0x5865F2)
    .addFields(cargoFields);
  const embed2 = new EmbedBuilder()
    .setTitle('`⚙️` Painel de Configuração - Logs')
    .setDescription('Configure os logs do bot usando os botões abaixo:')
    .setColor(0x5865F2)
    .addFields(logFields);
  const embeds = [embed1, embed2];

  // Select para configurar cargos permitidos
  const cargoOptions = [
    { label: 'Universal', value: 'cargo_permitido_universal' },
    { label: 'Extração', value: 'cargo_permitido_extracao' },
    { label: 'Clonagem', value: 'cargo_permitido_clonagem' },
    { label: 'Clean DM', value: 'cargo_permitido_clean_dm' },
    { label: 'Unfriend', value: 'cargo_permitido_unfriend' },
    { label: 'Leave Guilds', value: 'cargo_permitido_leave_guilds' },
    { label: 'Limpar Servidor', value: 'cargo_permitido_limpar_servidor' },
    { label: 'Flood', value: 'cargo_permitido_flood' },
    { label: 'Kickall', value: 'cargo_permitido_kickall' },
    { label: 'Banall', value: 'cargo_permitido_banall' },
    { label: 'Raid', value: 'cargo_permitido_raid' },
    { label: 'Disparo DM', value: 'cargo_permitido_disparo_dm' },
    { label: 'Extração Avançada', value: 'cargo_permitido_extractor' },
    { label: 'Clonagem Avançada', value: 'cargo_permitido_cloner' },
    { label: 'Cleaner', value: 'cargo_permitido_cleaner' },
    { label: 'Fechar DMs', value: 'cargo_permitido_close_dm' },
    { label: 'Consulta Nome', value: 'cargo_permitido_consulta_nome' },
    { label: 'Consulta CPF', value: 'cargo_permitido_consulta_cpf' },
    { label: 'Consulta CNPJ', value: 'cargo_permitido_consulta_cnpj' },
    { label: 'Consulta Telefone', value: 'cargo_permitido_consulta_telefone' },
    { label: 'Free Fire', value: 'cargo_permitido_free_fire' },
    { label: 'Email Temporário', value: 'cargo_permitido_email_temp' },
    { label: 'IA', value: 'cargo-permitido-ia' },
    { label: 'Cloner Site', value: 'cargo_permitido_cloner_site' },
  ];
  const selectCargoConfig = new StringSelectMenuBuilder()
    .setCustomId('config_cargo_select')
    .setPlaceholder('Selecione o tipo de cargo para configurar')
    .addOptions(cargoOptions);
  const rowCargoConfig = new ActionRowBuilder().addComponents(selectCargoConfig);

  // Select para configurar logs
  const logOptions = [
    { label: 'Log Extração', value: 'log_extracao' },
    { label: 'Log Clonagem', value: 'log_clonagem' },
    { label: 'Log Clean DM', value: 'log_clean_dm' },
    { label: 'Log Unfriend', value: 'log_unfriend' },
    { label: 'Log Leave Guilds', value: 'log_leave_guilds' },
    { label: 'Log Limpar Servidor', value: 'log_limpar_servidor' },
    { label: 'Log Flood', value: 'log_flood' },
    { label: 'Log Kickall', value: 'log_kickall' },
    { label: 'Log BanAll', value: 'log_banall' },
    { label: 'Log Raid', value: 'log_raid' },
    { label: 'Log Disparo DM', value: 'log_disparo_dm' },
    { label: 'Log Fechar DMs', value: 'log_close_dm' },
    { label: 'Log Cleaner', value: 'log_cleaner' },
    { label: 'Log Extração Avançada', value: 'log_extractor' },
    { label: 'Log Clonagem Avançada', value: 'log_cloner' },
    { label: 'Log Consulta Nome', value: 'log_consulta_nome' },
    { label: 'Log Consulta CPF', value: 'log_consulta_cpf' },
    { label: 'Log Consulta CNPJ', value: 'log_consulta_cnpj' },
    { label: 'Log Consulta Telefone', value: 'log_consulta_telefone' },
    { label: 'Log Free Fire', value: 'log_free_fire' },
    { label: 'Log Email Temporário', value: 'log_email_temp' },
    { label: 'Log IA', value: 'log-ia' },
    { label: 'Log Cloner Site', value: 'log_cloner_site' },
  ];
  const selectLogConfig = new StringSelectMenuBuilder()
    .setCustomId('config_log_select')
    .setPlaceholder('Selecione o tipo de log para configurar')
    .addOptions(logOptions);
  const rowLogConfig = new ActionRowBuilder().addComponents(selectLogConfig);

  // Adicionar botão para criar canais e cargos de logs automáticos
  const rowAutoCreate = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('config_criar_logs_auto')
      .setLabel('Criar Canais e Cargos de Logs Automáticos')
      .setStyle(ButtonStyle.Success)
      .setEmoji({ id: '1358154876013772802' })
  );
  await interaction.reply({ embeds, components: [rowCargoConfig, rowLogConfig, rowAutoCreate], flags : 64 });
}

async function handleConfigCargo(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_cargo_modal')
    .setTitle('Buscar Cargo Permitido');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('cargo_nome')
        .setLabel('Digite parte do nome do cargo')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigCargoModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const busca = interaction.fields.getTextInputValue('cargo_nome').toLowerCase();
  const roles = interaction.guild.roles.cache.filter(r => r.id !== interaction.guild.id && r.name.toLowerCase().includes(busca));
  const options = Array.from(roles.values())
    .slice(0, 25)
    .map(r => ({ label: r.name, value: r.id }));
  if (options.length === 0) {
    await interaction.reply({ content: '\`❌\` Nenhum cargo encontrado com esse nome.', flags : 64 });
    return;
  }
  const select = new StringSelectMenuBuilder()
    .setCustomId('config_cargo_select')
    .setPlaceholder('Selecione o cargo permitido')
    .addOptions(options);
  const row = new ActionRowBuilder().addComponents(select);
  await interaction.reply({ content: '`📝` Selecione o cargo permitido para extração:', components: [row], flags : 64 });
}

async function handleConfigCargoSelect(interaction) {
  const value = interaction.values[0];
  const labelMap = {
    universal: 'Universal',
    extracao: 'Extração',
    clonagem: 'Clonagem',
    clean_dm: 'Clean DM',
    unfriend: 'Unfriend',
    leave_guilds: 'Leave Guilds',
    limpar_servidor: 'Limpar Servidor',
    flood: 'Flood',
    kickall: 'Kickall',
    banall: 'Banall',
    raid: 'Raid'
  };
  const modal = new ModalBuilder().setCustomId('config_cargo_' + value + '_modal').setTitle('Configurar Cargo');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('cargo_id').setLabel('ID do cargo').setStyle(TextInputStyle.Short).setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigOwner(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_owner_modal')
    .setTitle('Configurar Owner');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('owner_id')
        .setLabel('ID do novo Owner')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigOwnerModal(interaction) {
  const ownerId = interaction.fields.getTextInputValue('owner_id');
  const user = await interaction.client.users.fetch(ownerId).catch(() => null);
  if (!user) {
    await interaction.reply({ content: '\`❌\` ID de usuário inválido.', flags : 64 });
    return;
  }
  config.owner_id = ownerId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8')); // Recarregar config
  await interaction.reply({ content: '\`✅\` Owner atualizado para <@' + config.owner_id + '>!', flags : 64 });
}

async function handleConfigLogExtracao(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_extracao_modal')
    .setTitle('Configurar Log de Extração');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_extracao_id')
        .setLabel('ID do canal de logs de extração')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogExtracaoModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_extracao_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_extracao = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8')); // Recarregar config
  await interaction.reply({ content: '\`✅\` Canal de logs de extração atualizado para <#' + config.log_extracao + '>!', flags : 64 });
}

async function handleConfigLogClonagem(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_clonagem_modal')
    .setTitle('Configurar Log de Clonagem');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_clonagem_id')
        .setLabel('ID do canal de logs de clonagem')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogClonagemModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_clonagem_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_clonagem = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8')); // Recarregar config
  await interaction.reply({ content: '\`✅\` Canal de logs de clonagem atualizado para <#' + config.log_clonagem + '>!', flags : 64 });
}

async function handleConfigLogCleanDM(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_clean_dm_modal')
    .setTitle('Configurar Log de Clean DM');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_clean_dm_id')
        .setLabel('ID do canal de logs de clean dm')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogCleanDMModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_clean_dm_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_clean_dm = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de clean dm atualizado para <#' + config.log_clean_dm + '>!', flags : 64 });
}

async function handleConfigLogUnfriend(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_unfriend_modal')
    .setTitle('Configurar Log de Unfriend');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_unfriend_id')
        .setLabel('ID do canal de logs de unfriend')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogUnfriendModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_unfriend_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_unfriend = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de unfriend atualizado para <#' + config.log_unfriend + '>!', flags : 64 });
}

async function handleConfigLogLeaveGuilds(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_leave_guilds_modal')
    .setTitle('Configurar Log de Leave Guilds');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_leave_guilds_id')
        .setLabel('ID do canal de logs de leave guilds')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogLeaveGuildsModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_leave_guilds_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_leave_guilds = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de leave guilds atualizado para <#' + config.log_leave_guilds + '>!', flags : 64 });
}

async function handleConfigLogLimparServidor(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_limpar_servidor_modal')
    .setTitle('Configurar Log de Limpar Servidor');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_limpar_servidor_id')
        .setLabel('ID do canal de logs de Limpar Servidor')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogLimparServidorModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_limpar_servidor_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_limpar_servidor = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de Limpar Servidor atualizado para <#' + config.log_limpar_servidor + '>!', flags : 64 });
}

async function handleConfigLogFlood(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_flood_modal')
    .setTitle('Configurar Log de Flood');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_flood_id')
        .setLabel('ID do canal de logs de Flood')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogFloodModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_flood_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_flood = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de Flood atualizado para <#' + config.log_flood + '>!', flags : 64 });
}

async function handleConfigLogKickall(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_kickall_modal')
    .setTitle('Configurar Log de Kickall');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_kickall_id')
        .setLabel('ID do canal de logs de Kickall')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogKickallModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_kickall_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_kickall = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de Kickall atualizado para <#' + config.log_kickall + '>!', flags : 64 });
}

async function handleConfigLogBanAll(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_banall_modal')
    .setTitle('Configurar Log de BanAll');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_banall_id')
        .setLabel('ID do canal de logs de BanAll')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogBanAllModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_banall_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_banall = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de BanAll atualizado para <#' + config.log_banall + '>!', flags : 64 });
}

async function handleConfigLogRaid(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_raid_modal')
    .setTitle('Configurar Log de Raid');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_raid_id')
        .setLabel('ID do canal de logs de raid')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogRaidModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_raid_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_raid = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de Raid atualizado para <#' + config.log_raid + '>!', flags : 64 });
}

async function handleConfigCargoUniversal(interaction) {
  const modal = new ModalBuilder().setCustomId('config_cargo_universal_modal').setTitle('Configurar Cargo');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('cargo_id').setLabel('ID do cargo universal').setStyle(TextInputStyle.Short).setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigCargoUniversalModal(interaction) {
  const cargoId = interaction.fields.getTextInputValue('cargo_id');
  config.cargo_permitido_universal = cargoId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Cargo universal configurado para <@&' + cargoId + '>!', flags : 64 });
}

// Handlers para cargos permitidos por ferramenta
async function handleConfigCargoGenerico(interaction, campo, label) {
  const modal = new ModalBuilder().setCustomId('config_cargo_' + campo + '_modal').setTitle('Configurar Cargo');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('cargo_id').setLabel('ID do cargo para ' + label).setStyle(TextInputStyle.Short).setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigCargoGenericoModal(interaction, campo, label) {
  const cargoId = interaction.fields.getTextInputValue('cargo_id');
  config['cargo_permitido_' + campo] = cargoId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Cargo de ' + label + ' configurado para <@&' + cargoId + '>!', flags : 64 });
}

async function handleConfigCargoExtracao(interaction) { return handleConfigCargoGenerico(interaction, 'extracao', 'Extração'); }
async function handleConfigCargoExtracaoModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'extracao', 'Extração'); }
async function handleConfigCargoClonagem(interaction) { return handleConfigCargoGenerico(interaction, 'clonagem', 'Clonagem'); }
async function handleConfigCargoClonagemModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'clonagem', 'Clonagem'); }
async function handleConfigCargoCleanDM(interaction) { return handleConfigCargoGenerico(interaction, 'clean_dm', 'Clean DM'); }
async function handleConfigCargoCleanDMModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'clean_dm', 'Clean DM'); }
async function handleConfigCargoUnfriend(interaction) { return handleConfigCargoGenerico(interaction, 'unfriend', 'Unfriend'); }
async function handleConfigCargoUnfriendModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'unfriend', 'Unfriend'); }
async function handleConfigCargoLeaveGuilds(interaction) { return handleConfigCargoGenerico(interaction, 'leave_guilds', 'Leave Guilds'); }
async function handleConfigCargoLeaveGuildsModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'leave_guilds', 'Leave Guilds'); }
async function handleConfigCargoLimparServidor(interaction) { return handleConfigCargoGenerico(interaction, 'limpar_servidor', 'Limpar Servidor'); }
async function handleConfigCargoLimparServidorModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'limpar_servidor', 'Limpar Servidor'); }
async function handleConfigCargoFlood(interaction) { return handleConfigCargoGenerico(interaction, 'flood', 'Flood'); }
async function handleConfigCargoFloodModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'flood', 'Flood'); }
async function handleConfigCargoKickall(interaction) { return handleConfigCargoGenerico(interaction, 'kickall', 'Kickall'); }
async function handleConfigCargoKickallModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'kickall', 'Kickall'); }
async function handleConfigCargoBanall(interaction) { return handleConfigCargoGenerico(interaction, 'banall', 'Banall'); }
async function handleConfigCargoBanallModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'banall', 'Banall'); }
async function handleConfigCargoRaid(interaction) { return handleConfigCargoGenerico(interaction, 'raid', 'Raid'); }
async function handleConfigCargoRaidModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'raid', 'Raid'); }

// Handler para configurar log_disparo_dm
async function handleConfigLogDisparoDM(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_disparo_dm_modal')
    .setTitle('Configurar Log de Disparo DM');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_disparo_dm_id')
        .setLabel('ID do canal de logs de Disparo DM')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogDisparoDMModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_disparo_dm_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_disparo_dm = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de Disparo DM atualizado para <#' + config.log_disparo_dm + '>!', flags : 64 });
}

async function handleConfigCargoDisparoDM(interaction) { return handleConfigCargoGenerico(interaction, 'disparo_dm', 'Disparo DM'); }
async function handleConfigCargoDisparoDMModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'disparo_dm', 'Disparo DM'); }
async function handleConfigCargoExtractor(interaction) { return handleConfigCargoGenerico(interaction, 'extractor', 'Extração Avançada'); }
async function handleConfigCargoExtractorModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'extractor', 'Extração Avançada'); }
async function handleConfigCargoCloner(interaction) { return handleConfigCargoGenerico(interaction, 'cloner', 'Clonagem Avançada'); }
async function handleConfigCargoClonerModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'cloner', 'Clonagem Avançada'); }
async function handleConfigCargoCleaner(interaction) { return handleConfigCargoGenerico(interaction, 'cleaner', 'Cleaner'); }
async function handleConfigCargoCleanerModal(interaction) { return handleConfigCargoGenericoModal(interaction, 'cleaner', 'Cleaner'); }

// Handlers para logs extras
async function handleConfigLogCloseDM(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_close_dm_modal')
    .setTitle('Configurar Log de Fechar DMs');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_close_dm_id')
        .setLabel('ID do canal de logs de Fechar DMs')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogCloseDMModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_close_dm_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_close_dm = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de Fechar DMs atualizado para <#' + config.log_close_dm + '>!', flags : 64 });
}

async function handleConfigLogCleaner(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_cleaner_modal')
    .setTitle('Configurar Log de Cleaner');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_cleaner_id')
        .setLabel('ID do canal de logs de Cleaner')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogCleanerModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_cleaner_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_cleaner = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de Cleaner atualizado para <#' + config.log_cleaner + '>!', flags : 64 });
}

async function handleConfigLogExtractor(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_extractor_modal')
    .setTitle('Configurar Log de Extração Avançada');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_extractor_id')
        .setLabel('ID do canal de logs de Extração Avançada')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogExtractorModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_extractor_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_extractor = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de Extração Avançada atualizado para <#' + config.log_extractor + '>!', flags : 64 });
}

async function handleConfigLogCloner(interaction) {
  const modal = new ModalBuilder()
    .setCustomId('config_log_cloner_modal')
    .setTitle('Configurar Log de Clonagem Avançada');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('log_cloner_id')
        .setLabel('ID do canal de logs de Clonagem Avançada')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleConfigLogClonerModal(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '\`❌\` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const logId = interaction.fields.getTextInputValue('log_cloner_id');
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '\`❌\` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config.log_cloner = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '\`✅\` Canal de logs de Clonagem Avançada atualizado para <#' + config.log_cloner + '>!', flags : 64 });
}

// Handler para o select de configuração de logs
async function handleConfigLogSelect(interaction) {
  const logField = interaction.values[0];
  // Mapeamento para label amigável
  const labelMap = {
    log_extracao: 'Extração',
    log_clonagem: 'Clonagem',
    log_clean_dm: 'Clean DM',
    log_unfriend: 'Unfriend',
    log_leave_guilds: 'Leave Guilds',
    log_limpar_servidor: 'Limpar Servidor',
    log_flood: 'Flood',
    log_kickall: 'Kickall',
    log_banall: 'BanAll',
    log_raid: 'Raid',
    log_disparo_dm: 'Disparo DM',
    log_close_dm: 'Fechar DMs',
    log_cleaner: 'Cleaner',
    log_extractor: 'Extração Avançada',
    log_cloner: 'Clonagem Avançada'
  };
  const label = labelMap[logField] || logField;
  const modal = new ModalBuilder()
    .setCustomId('config_log_select_modal_' + logField)
    .setTitle('Configurar Log')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('log_channel_id')
          .setLabel('ID do canal de logs de ' + label)
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      )
    );
  await interaction.showModal(modal);
}

// Handler para o modal do select de logs
async function handleConfigLogSelectModal(interaction) {
  // Extrai o campo do customId
  const match = interaction.customId.match(/^config_log_select_modal_(.+)$/);
  if (!match) return;
  const logField = match[1];
  const logId = interaction.fields.getTextInputValue('log_channel_id');
  if (!interaction.guild) {
    await interaction.reply({ content: '`❌` Este comando só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  const channel = interaction.guild.channels.cache.get(logId);
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: '`❌` ID de canal inválido ou o canal não é um canal de texto.', flags : 64 });
    return;
  }
  config[logField] = logId;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.reply({ content: '`✅` Canal de logs atualizado para <#' + logId + '>!', flags : 64 });
}

// Handler para criar canais e cargos de logs automáticos
async function handleConfigCriarLogsAuto(interaction) {
  if (!interaction.guild) {
    await interaction.reply({ content: '`❌` Só pode ser usado em um servidor.', flags : 64 });
    return;
  }
  await interaction.deferReply({ flags : 64 });
  // 1. Criar categoria
  let category = interaction.guild.channels.cache.find(c => c.type === 4 && c.name === 'Logs GG TOOLS');
  if (!category) {
    category = await interaction.guild.channels.create({
      name: 'Logs GG TOOLS',
      type: 4,
      permissionOverwrites: [
        {
          id: interaction.guild.id, // @everyone
          type: 0,
          deny: ['ViewChannel']
        }
      ]
    });
  }
  // 2. Criar canais de log
  const logFieldsAuto = [
    'log_extracao', 'log_clonagem', 'log_clean_dm', 'log_unfriend', 'log_leave_guilds', 'log_limpar_servidor',
    'log_flood', 'log_kickall', 'log_banall', 'log_raid', 'log_disparo_dm', 'log_close_dm', 'log_cleaner', 'log_extractor', 'log_cloner',
    'log_consulta_nome', 'log_consulta_cpf', 'log_consulta_cnpj', 'log_consulta_telefone',
    'log_free_fire', 'log_email_temp', 'log_ia', 'log_cloner_site'
  ];
  const logNames = {
    log_extracao: 'log-extracao',
    log_clonagem: 'log-clonagem',
    log_clean_dm: 'log-clean-dm',
    log_unfriend: 'log-unfriend',
    log_leave_guilds: 'log-leave-guilds',
    log_limpar_servidor: 'log-limpar-servidor',
    log_flood: 'log-flood',
    log_kickall: 'log-kickall',
    log_banall: 'log-banall',
    log_raid: 'log-raid',
    log_disparo_dm: 'log-disparo-dm',
    log_close_dm: 'log-close-dm',
    log_cleaner: 'log-cleaner',
    log_extractor: 'log-extractor',
    log_cloner: 'log-cloner',
    log_consulta_nome: 'log-consulta-nome',
    log_consulta_cpf: 'log-consulta-cpf',
    log_consulta_cnpj: 'log-consulta-cnpj',
    log_consulta_telefone: 'log-consulta-telefone',
    log_free_fire: 'log-free-fire',
    log_email_temp: 'log-email-temp',
    log_ia: 'log-ia',
    log_cloner_site: 'log-cloner-site'
  };
  for (const field of logFieldsAuto) {
    let channel = interaction.guild.channels.cache.find(c => c.name === logNames[field] && c.parentId === category.id);
    if (!channel) {
      channel = await interaction.guild.channels.create({
        name: logNames[field],
        type: 0,
        parent: category.id,
        permissionOverwrites: [
          {
            id: interaction.guild.id, // @everyone
            type: 0,
            deny: ['ViewChannel']
          }
        ]
      });
    }
    config[field] = channel.id;
  }
  // 3. Criar cargos necessários
  const cargoFieldsAuto = [
    'cargo_permitido_universal', 'cargo_permitido_extracao', 'cargo_permitido_clonagem', 'cargo_permitido_clean_dm',
    'cargo_permitido_unfriend', 'cargo_permitido_leave_guilds', 'cargo_permitido_limpar_servidor', 'cargo_permitido_flood',
    'cargo_permitido_kickall', 'cargo_permitido_banall', 'cargo_permitido_raid', 'cargo_permitido_disparo_dm',
    'cargo_permitido_extractor', 'cargo_permitido_cloner', 'cargo_permitido_cleaner', 'cargo_permitido_close_dm',
    'cargo_permitido_consulta_nome', 'cargo_permitido_consulta_cpf', 'cargo_permitido_consulta_cnpj', 'cargo_permitido_consulta_telefone',
    'cargo_permitido_free_fire', 'cargo_permitido_email_temp', 'cargo_permitido_cloner_site'
  ];
  for (const field of cargoFieldsAuto) {
    const roleName = field.replace('cargo_permitido_', '').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    let role = interaction.guild.roles.cache.find(r => r.name === roleName);
    if (!role) {
      role = await interaction.guild.roles.create({ name: roleName });
    }
    config[field] = role.id;
  }
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  await interaction.editReply({ content: '`✅` Canais de logs e cargos criados/configurados automaticamente!', flags : 64 });
}

exports.configHandlers = {
  handleConfigCommand,
  handleConfigCargo,
  handleConfigCargoModal,
  handleConfigCargoSelect,
  handleConfigOwner,
  handleConfigOwnerModal,
  handleConfigLogExtracao,
  handleConfigLogExtracaoModal,
  handleConfigLogClonagem,
  handleConfigLogClonagemModal,
  handleConfigLogCleanDM,
  handleConfigLogCleanDMModal,
  handleConfigLogUnfriend,
  handleConfigLogUnfriendModal,
  handleConfigLogLeaveGuilds,
  handleConfigLogLeaveGuildsModal,
  handleConfigLogLimparServidor,
  handleConfigLogLimparServidorModal,
  handleConfigLogFlood,
  handleConfigLogFloodModal,
  handleConfigLogKickall,
  handleConfigLogKickallModal,
  handleConfigLogBanAll,
  handleConfigLogBanAllModal,
  handleConfigLogRaid,
  handleConfigLogRaidModal,
  handleConfigCargoUniversal,
  handleConfigCargoUniversalModal,
  handleConfigCargoExtracao,
  handleConfigCargoExtracaoModal,
  handleConfigCargoClonagem,
  handleConfigCargoClonagemModal,
  handleConfigCargoCleanDM,
  handleConfigCargoCleanDMModal,
  handleConfigCargoUnfriend,
  handleConfigCargoUnfriendModal,
  handleConfigCargoLeaveGuilds,
  handleConfigCargoLeaveGuildsModal,
  handleConfigCargoLimparServidor,
  handleConfigCargoLimparServidorModal,
  handleConfigCargoFlood,
  handleConfigCargoFloodModal,
  handleConfigCargoKickall,
  handleConfigCargoKickallModal,
  handleConfigCargoBanall,
  handleConfigCargoBanallModal,
  handleConfigCargoRaid,
  handleConfigCargoRaidModal,
  handleConfigLogDisparoDM,
  handleConfigLogDisparoDMModal,
  handleConfigCargoDisparoDM,
  handleConfigCargoDisparoDMModal,
  handleConfigLogCloseDM,
  handleConfigLogCloseDMModal,
  handleConfigLogCleaner,
  handleConfigLogCleanerModal,
  handleConfigLogExtractor,
  handleConfigLogExtractorModal,
  handleConfigLogCloner,
  handleConfigLogClonerModal,
  handleConfigLogSelect,
  handleConfigLogSelectModal,
  handleConfigCriarLogsAuto
};