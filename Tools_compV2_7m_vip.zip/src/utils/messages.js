// Centralização de mensagens padronizadas para feedback ao usuário

module.exports = {
  WAITING: '⏳ Aguarde, processando...',
  STARTING: (action) => `🔄 Iniciando ${action}, aguarde...`,
  ERROR: (err) => `❌ Erro: ${err}`,
  SUCCESS: (action) => `✅ ${action} finalizado com sucesso!`,
  QUEUED: 'Você já está na fila. Aguarde sua vez!',
  POSITION: (pos) => `Você está na fila. Posição: ${pos}`,
  PERMISSION_DENIED: '\`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.',
  INVALID_TOKEN: '\`❌\` Token inválido, tente novamente!',
  NOT_FOUND: (item) => `\`❌\` ${item} não encontrado ou sem permissão.`,
  // Adicione outras mensagens padronizadas conforme necessário
}; 