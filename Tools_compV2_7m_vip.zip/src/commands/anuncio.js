const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ThumbnailBuilder, SeparatorBuilder, SeparatorSpacingSize, ContainerBuilder, TextDisplayBuilder, SectionBuilder, MessageFlags, StringSelectMenuBuilder } = require('discord.js');
const { painelHandlers } = require('../handlers/painelHandler');
const fs = require('fs');
const path = require('path');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('anuncio')
    .setDescription('Mostra um anúncio sobre a Over Tools com botões de acesso.'),
  async execute(interaction) {
    const configPath = path.join(__dirname, '../config.json');
    let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    if (!config.owner_id || interaction.user.id !== config.owner_id) {
      await interaction.reply({ content: '`❌` Apenas meus desenvolvedores podem utilizar este comando.', ephemeral: true });
      return;
    }

    await interaction.reply({ content: "Painel enviado com sucesso!", ephemeral: true });


    const container = new ContainerBuilder();

    const iconUrl = interaction.guild?.iconURL() ?? 'https://cdn.discordapp.com/embed/avatars/0.png';

    container.addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder({
            content: "Por demanda da comunidade, apresentamos um bot inovador equipado com um sistema avançado integrado a uma tecnologia anti-spam para garantir segurança e eficiência.\n### Como Funciona\nVeja o tutorial acessando o painel no botão abaixo.\n\n"
          })
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder({
            media: { url: iconUrl }
          })
        )
    );

    container.addSeparatorComponents(
      new SeparatorBuilder({
        spacing: SeparatorSpacingSize.Small,
        divider: true,
      })
    );

    container.addActionRowComponents(
      new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('anuncio_painel')
      .setLabel('Acessar Painel')
      .setEmoji({ id: '1441805432623730688' })
      .setStyle(ButtonStyle.Secondary)
        )
    );

    const ajudaSelect = new StringSelectMenuBuilder()
      .setCustomId('painel_ajuda')
      .setPlaceholder('Selecione uma ferramenta para ver como funciona')
      .addOptions([
        { label: 'Tutorial em Vídeo (Incompleto)', value: 'tutorial', description: 'Como usar o bot', emoji: { id: `1441805432623730688` } },
        { label: 'Extrair Mensagens', value: 'extracao', description: 'Copiar mensagens entre canais', emoji: { id: `1441805432623730688` } },
        { label: 'Clonar Servidor', value: 'clonar_servidor', description: 'Duplicar estrutura de servidor', emoji: { id: `1441805432623730688` } },
        { label: 'Limpar DMs', value: 'limpar_dms', description: 'Apagar mensagens privadas', emoji: { id: `1441805432623730688` } },
        { label: 'Remover Amigos', value: 'remover_amigos', description: 'Excluir todos os amigos', emoji: { id: `1441805432623730688` } },
        { label: 'Sair de Servidores', value: 'sair_servidores', description: 'Sair de múltiplos servidores', emoji: { id: `1441805432623730688` } },
        { label: 'Floodar Canais', value: 'flood', description: 'Enviar várias mensagens', emoji: { id: `1441805432623730688` } },
        { label: 'Expulsar Todos', value: 'kickall', description: 'Expulsar todos de um servidor', emoji: { id: `1441805432623730688` } },
        { label: 'Banir Todos', value: 'banall', description: 'Banir todos de um servidor', emoji: { id: `1441805432623730688` } },
        { label: 'Raid', value: 'raid', description: 'Ações em massa', emoji: { id: `1441805432623730688` } },
        { label: 'Disparo DM', value: 'disparo_dm', description: 'Enviar DMs em massa', emoji: { id: `1441805432623730688` } }
      ]);
    container.addActionRowComponents(new ActionRowBuilder().addComponents(ajudaSelect));

    await interaction.channel.send({
      flags: [MessageFlags.IsComponentsV2],
      components: [container],
    });
  },
}
