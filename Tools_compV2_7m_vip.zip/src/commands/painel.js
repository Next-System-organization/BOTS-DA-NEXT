const { handlePainelCommand } = require('../handlers/painelHandler');

module.exports = {
  data: {
    name: 'painel',
    description: 'Abre o painel principal de seu GG Tools.'
  },
  execute: handlePainelCommand
}; 