const { handleConfigCommand } = require('../handlers/configHandler');

module.exports = {
  data: {
    name: 'config',
    description: 'Abre o painel de configuração do seu GG Tools.'
  },
  execute: handleConfigCommand
}; 