const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, MessageFlags, StringSelectMenuBuilder, ButtonStyle } = require('discord.js');
const { db, lg, getTempData, setTempData, deleteTempData, getSentMembers, addSentMember, clearSentMembers } = require('../database');
const { getInfo, guildVerify, inicDivSystem } = require('./discord');
const fs = require('fs');

const painelDisparoDMHandlers = {};

const sleep = ms => new Promise(r => setTimeout(r, ms));
function randomDelay(min = 7000, max = 15000) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Utilitário para obter/salvar config de mensagem customizada
async function getMsgConfig(userId) {
    return (await getTempData(userId)) || {};
}
async function setMsgConfig(userId, cfg) {
    await setTempData(userId, cfg);
}

// Função utilitária para checar permissão de Disparo DM
async function hasPermissaoDisparoDM(interaction) {
    const config = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, '../config.json'), 'utf8'));
    const cargoUniversal = config.cargo_permitido_universal;
    const cargoEspecifico = config.cargo_permitido_disparo_dm;
    if (!cargoUniversal && !cargoEspecifico) return true;
    if (!interaction.guild) return false;
    const member = await interaction.guild.members.fetch(interaction.user.id);
    return member.roles.cache.has(cargoUniversal) || member.roles.cache.has(cargoEspecifico);
}

// Painel principal do Disparo DM
painelDisparoDMHandlers.handlePainelDisparoDM = async function(interaction, forceUpdate = false) {
    if (!(await hasPermissaoDisparoDM(interaction))) {
        await interaction.reply({ content: '`❌` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags: 64 });
        return;
    }
    const temp = getTempData(interaction.user.id) || {};
    const tokensArr = Array.isArray(temp.tokens) ? temp.tokens : [];
    const guildId = temp.guild_id || '';
    const roleId = temp.role_id || '';
    const message = temp.message || '';
    const userIds = Array.isArray(temp.user_ids) ? temp.user_ids : [];
    const status = temp.status || { success: 0, progress: 0 };
    const enviadosArr = getSentMembers(interaction.user.id);
    let msgStr = typeof message === 'string' ? message : (message && typeof message.content === 'string' ? message.content : '');
    // Checa se há mensagem configurada para habilitar o Preview
    const msgcfg = await getMsgConfig(interaction.user.id);
    const hasMsg = !!(msgcfg && (msgcfg.content || msgcfg.title || msgcfg.description || msgcfg.imagem || msgcfg.thumbnail || msgcfg.fileImage));
    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('disparo_dm_mensagem').setLabel('Editar Mensagem').setStyle(2).setEmoji({ id: '1380705035272327278' }),
        new ButtonBuilder().setCustomId('disparo_dm_preview').setLabel('Preview').setStyle(2).setEmoji({ id: '1380908058477072505' }).setDisabled(!hasMsg),
    );
    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('disparo_dm_config').setLabel('Configurar').setStyle(1).setEmoji({ id: '1358154909761011953' }),
        new ButtonBuilder().setCustomId('disparo_dm_reset').setLabel('Resetar Config').setStyle(4).setEmoji({ id: '1358154897241145559' }),
        new ButtonBuilder().setCustomId('disparo_dm_cleardb').setLabel('Limpar DB').setStyle(4).setEmoji({ id: '1380927646896099328' }),
        new ButtonBuilder().setCustomId('disparo_dm_start').setLabel('Disparar').setStyle(3).setEmoji({ id: '1358154901913341963' })
    );
    const painelMsg = {
        embeds: [
            new EmbedBuilder()
                .setAuthor({ name: `Divulgação Tools`, iconURL: interaction.guild.iconURL() })
                .setDescription(`Configure os campos abaixo para disparar DMs para todos os membros de um servidor com tokens de bots.\n> -# Para que serve o "limpar DB"?\n> **-# Limpa a lista de membros que já receberam a mensagem.**`)
                .setColor(0x5865F2)
                .addFields(
                    { name: 'Tokens cadastrados', value: `Bots: **${String(tokensArr.length || 0)}**`, inline: true },
                    { name: 'Servidor', value: guildId ? String(guildId) : 'Não configurado', inline: true },
                    { name: 'Cargo', value: roleId ? String(roleId) : 'Não configurado', inline: true },
                    { name: 'Mensagem', value: msgStr ? String(msgStr.slice(0, 50)) + (msgStr.length > 50 ? '...' : '') : 'Não configurada', inline: false },
                    { name: 'Membros alvo', value: userIds && userIds.length ? `**${String(userIds.length)}**` : 'Não coletado', inline: false }
     //               { name: 'Status', value: `Enviados: ${enviadosArr.length} | Faltando: ${Math.max(0, userIds.length - enviadosArr.length)}`, inline: false }
                )
        ],
        components: [row2, row1],
        flags : 64
    };
    if (forceUpdate) {
        try {
            await interaction.update(painelMsg);
            return;
        } catch (e) {}
    }
    try {
        await interaction.reply(painelMsg);
    } catch (err1) {
        try {
            await interaction.followUp(painelMsg);
        } catch (err2) {
            try {
                await interaction.followUp({ content: '❌ Não foi possível abrir o painel. Tente novamente.', flags : 64 });
            } catch {}
        }
    }
};

// Handler para abrir modal de configuração
painelDisparoDMHandlers.handleConfig = async function(interaction) {
    const temp = getTempData(interaction.user.id);
    const tokensArr = Array.isArray(temp.tokens) ? temp.tokens : [];
    const guildId = temp.guild_id || '';
    const roleId = temp.role_id || '';
    const message = temp.message || '';
    const modal = new ModalBuilder()
        .setCustomId('disparo_dm_modal_config')
        .setTitle('Configurar Disparo DM');
    modal.addComponents(
        new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId('tokens')
                .setLabel('Tokens de Bot (um por linha)')
                .setStyle(2)
                .setRequired(true)
                .setPlaceholder('token1\ntoken2\ntoken3')
                .setValue(tokensArr.map(t => t.token).join('\n'))
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId('guild_id')
                .setLabel('ID do Servidor')
                .setPlaceholder('Cole o ID do servidor aqui')
                .setStyle(1)
                .setRequired(true)
                .setValue(guildId)
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId('role_id')
                .setLabel('ID do Cargo (opcional)')
                .setStyle(1)
                .setRequired(false)
                .setPlaceholder('Deixe vazio para todos do servidor')
                .setValue(roleId)
        )
    );
    if (interaction.replied || interaction.deferred) {
        if (interaction.followUp) {
            await interaction.followUp({ content: '❌ Não foi possível abrir o modal. Tente novamente.', flags: 64 });
        }
        return;
    }
    await interaction.showModal(modal);
};

// Handler para salvar config e buscar membros do cargo
painelDisparoDMHandlers.handleConfigModal = async function(interaction) {
    const tokens = interaction.fields.getTextInputValue('tokens').split('\n').map(t => t.trim()).filter(Boolean);
    const guildId = interaction.fields.getTextInputValue('guild_id').trim();
    const roleId = interaction.fields.getTextInputValue('role_id').trim();
    const { Client, GatewayIntentBits } = require('discord.js');
    let members = [];
    let erro = false;
    let erroMsg = '';
    let erroEtapa = '';
    for (const token of tokens) {
        let client;
        try {
            console.log('[DEBUG][handleConfigModal] Tentando login com token:', token.substring(0, 10));
            client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });
            await client.login(token);
            console.log('[DEBUG][handleConfigModal] Login realizado com sucesso.');
            const guild = await client.guilds.fetch(guildId);
            console.log('[DEBUG][handleConfigModal] Guild encontrada:', guild.id, guild.name);
            // Tenta buscar todos os membros (force: true)
            await guild.members.fetch({ force: true });
            console.log('[DEBUG][handleConfigModal] Membros buscados. Quantidade no cache:', guild.members.cache.size);
            if (roleId) {
                // Buscar membros do cargo
                const role = await guild.roles.fetch(roleId);
                if (!role) {
                    erro = true;
                    erroMsg = 'Cargo não encontrado';
                    erroEtapa = 'fetch role';
                    console.error('[DEBUG][handleConfigModal] Cargo não encontrado:', roleId);
                    await client.destroy();
                    continue;
                }
                members = Array.from(role.members.keys());
                console.log('[DEBUG][handleConfigModal] Membros do cargo:', members.length);
            } else {
                // Buscar todos os membros do servidor
                members = Array.from(guild.members.cache.keys());
                console.log('[DEBUG][handleConfigModal] Membros do servidor:', members.length);
            }
            await client.destroy();
            if (members.length > 0) break;
        } catch (e) {
            erro = true;
            erroMsg = e && e.message ? e.message : String(e);
            erroEtapa = erroEtapa || 'geral';
            console.error('[DEBUG][handleConfigModal] Erro na etapa', erroEtapa, ':', erroMsg, e);
            if (client && client.destroy) await client.destroy();
        }
    }
    if (!members.length) {
        return interaction.reply({ content: `\`❌\` Não foi possível coletar os membros. Erro: ${erroMsg || 'Verifique o ID do servidor, tokens de bot e, se usado, o ID do cargo.'} (Etapa: ${erroEtapa})`, flags : 64 });
    }
    await setTempData(interaction.user.id, {
        tokens: tokens.map(token => ({ token, tipo: 'bot' })),
        guild_id: guildId,
        role_id: roleId,
        user_ids: members
    });
    await painelDisparoDMHandlers.handlePainelDisparoDM(interaction, true);
};

// Handler para preview da mensagem
painelDisparoDMHandlers.handlePreview = async function(interaction) {
    const msgcfg = await getMsgConfig(interaction.user.id);
    // Monta embed preview
    const embed = new EmbedBuilder();
    if (msgcfg.imagem) embed.setImage(msgcfg.imagem);
    if (msgcfg.thumbnail) embed.setThumbnail(msgcfg.thumbnail);
    if (msgcfg.author) embed.setAuthor({ name: msgcfg.author });
    if (msgcfg.title) embed.setTitle(msgcfg.title);
    if (msgcfg.description) embed.setDescription(msgcfg.description);
    if (msgcfg.color) embed.setColor(msgcfg.color);
    if (msgcfg.footer) embed.setFooter({ text: msgcfg.footer });
    // Botões customizados
    let msgButtons = [];
    if (msgcfg.buttons && msgcfg.buttons.length > 0) {
        let currentRow = new ActionRowBuilder();
        for (const button of msgcfg.buttons.slice(0, 10)) {
            const newButton = new ButtonBuilder()
                .setLabel(button.label)
                .setURL(button.url)
                .setStyle(ButtonStyle.Link);
            if (button.emoji) newButton.setEmoji(button.emoji);
            if (currentRow.components.length >= 5) {
                msgButtons.push(currentRow);
                currentRow = new ActionRowBuilder();
            }
            currentRow.addComponents(newButton);
        }
        if (currentRow.components.length > 0) msgButtons.push(currentRow);
    }
    const previewMsg = {
        content: msgcfg.content || '',
        embeds: (msgcfg.title || msgcfg.description || msgcfg.imagem || msgcfg.thumbnail) ? [embed] : [],
        components: msgButtons,
        flags : 64
    };
    if (msgcfg.fileImage) {
        previewMsg.files = [{ attachment: msgcfg.fileImage }];
    }
    await interaction.reply(previewMsg);
};

// Handler principal do painel de edição de mensagem
painelDisparoDMHandlers.handlePainelMensagemDM = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    // Monta embed preview
    const embed = new EmbedBuilder();
    if (cfg.imagem) embed.setImage(cfg.imagem);
    if (cfg.thumbnail) embed.setThumbnail(cfg.thumbnail);
    if (cfg.author) embed.setAuthor({ name: cfg.author });
    if (cfg.title) embed.setTitle(cfg.title);
    if (cfg.description) embed.setDescription(cfg.description);
    if (cfg.color) embed.setColor(cfg.color);
    if (cfg.footer) embed.setFooter({ text: cfg.footer });
    if (!embed.data.description && !cfg.title) embed.setDescription('Clique nos botões abaixo para configurar a mensagem.');
    // Botões customizados
    const msgButtons = [];
    if (cfg.buttons && cfg.buttons.length > 0) {
        let currentRow = new ActionRowBuilder();
        for (const button of cfg.buttons.slice(0, 10)) {
            const newButton = new ButtonBuilder()
                .setLabel(button.label)
                .setURL(button.url)
                .setStyle(ButtonStyle.Link);
            if (button.emoji) newButton.setEmoji(button.emoji);
            if (currentRow.components.length >= 5) {
                msgButtons.push(currentRow);
                currentRow = new ActionRowBuilder();
            }
            currentRow.addComponents(newButton);
        }
        if (currentRow.components.length > 0) msgButtons.push(currentRow);
    }
    // Botões de configuração
    const configButtons = [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('dmmsg_definir_msg').setLabel('Mensagem').setEmoji({ id: '1359507010650898513' }).setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('dmmsg_definir_embed').setLabel('Embed').setEmoji({ id: '1358154886197281020' }).setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('dmmsg_definir_img').setLabel('Imagem').setEmoji({ id: '1359507338826088609' }).setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('dmmsg_definir_btns').setLabel('Botões').setEmoji({ id: '1359507471219298384' }).setStyle(ButtonStyle.Secondary)
        ),
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('dmmsg_limpar_msg').setLabel('Limpar Msg').setEmoji({ id: '1358154903876403401' }).setDisabled(!cfg.content).setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('dmmsg_limpar_embed').setLabel('Limpar Embed').setEmoji({ id: '1358154903876403401' }).setDisabled(!cfg.title && !cfg.description).setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('dmmsg_limpar_img').setLabel('Limpar Img').setEmoji({ id: '1358154903876403401' }).setDisabled(!cfg.fileImage && !cfg.imagem && !cfg.thumbnail).setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('dmmsg_limpar_btns').setLabel('Limpar Btns').setEmoji({ id: '1358154903876403401' }).setDisabled(!cfg.buttons || cfg.buttons.length === 0).setStyle(ButtonStyle.Danger)
        ),
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('dmmsg_voltar').setLabel('Voltar').setEmoji({ id: '1358154884708307235' }).setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('dmmsg_salvar').setLabel('Salvar').setEmoji({ id: '1358154876013772802' }).setStyle(ButtonStyle.Success)
        )
    ];
    // Preview
    const updatemsg = {
        content: cfg.content || '',
        embeds: (cfg.title || cfg.description || cfg.imagem || cfg.thumbnail) ? [embed] : [],
        components: [...msgButtons, ...configButtons].slice(0, 5),
        flags : 64
    };
    if (cfg.fileImage) {
        updatemsg.files = [{ attachment: cfg.fileImage }];
    }
    // Tenta update, depois reply, depois followUp
    try {
        await interaction.update(updatemsg);
    } catch (err1) {
        try {
            await interaction.reply(updatemsg);
        } catch (err2) {
            try {
                await interaction.followUp(updatemsg);
            } catch (err3) {
                try {
                    await interaction.followUp({ content: '❌ Não foi possível abrir o painel de edição. Tente novamente.', flags : 64 });
                } catch {}
            }
        }
    }
};

// Handlers dos botões de edição
painelDisparoDMHandlers.handleDefinirMsg = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    const modal = new ModalBuilder().setCustomId('dmmsg_modal_msg').setTitle('Definir Mensagem');
    modal.addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('content').setLabel('Mensagem de texto').setStyle(2).setRequired(true).setMaxLength(2000).setValue(cfg.content || '').setPlaceholder('Digite aqui a mensagem de texto')
    ));
    if (interaction.replied || interaction.deferred) {
        if (interaction.followUp) {
            await interaction.followUp({ content: '❌ Não foi possível abrir o modal. Tente novamente.', flags: 64 });
        }
        return;
    }
    await interaction.showModal(modal);
};

painelDisparoDMHandlers.handleDefinirEmbed = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    const modal = new ModalBuilder().setCustomId('dmmsg_modal_embed').setTitle('Definir Embed');
    modal.addComponents(
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('author').setLabel('Author (opcional)').setStyle(1).setRequired(false).setMaxLength(256).setValue(cfg.author || '').setPlaceholder('Nome do autor do embed')
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('title').setLabel('Título (opcional)').setStyle(1).setRequired(false).setMaxLength(256).setValue(cfg.title || '').setPlaceholder('Título do embed')
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('description').setLabel('Descrição (opcional)').setStyle(2).setRequired(false).setMaxLength(4000).setValue(cfg.description || '').setPlaceholder('Descrição do embed')
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('color').setLabel('Cor (opcional)').setStyle(1).setRequired(false).setMaxLength(7).setValue(cfg.color || '').setPlaceholder('#FFFFFF ou RANDOM')
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('footer').setLabel('Footer (opcional)').setStyle(1).setRequired(false).setMaxLength(2048).setValue(cfg.footer || '').setPlaceholder('Texto do rodapé do embed')
        )
    );
    if (interaction.replied || interaction.deferred) {
        if (interaction.followUp) {
            await interaction.followUp({ content: '❌ Não foi possível abrir o modal. Tente novamente.', flags: 64 });
        }
        return;
    }
    await interaction.showModal(modal);
};

painelDisparoDMHandlers.handleDefinirImg = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    const modal = new ModalBuilder().setCustomId('dmmsg_modal_img').setTitle('Imagens da Mensagem');
    modal.addComponents(
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('fileImage').setLabel('URL da imagem fora do embed (anexo)').setStyle(1).setRequired(false).setMaxLength(1024).setValue(cfg.fileImage || '').setPlaceholder('https://exemplo.com/imagemfora.png')
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('imagem').setLabel('URL do banner do embed').setStyle(1).setRequired(false).setMaxLength(1024).setValue(cfg.imagem || '').setPlaceholder('https://exemplo.com/banner.png')
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('thumbnail').setLabel('URL do thumbnail do embed').setStyle(1).setRequired(false).setMaxLength(1024).setValue(cfg.thumbnail || '').setPlaceholder('https://exemplo.com/thumb.png')
        )
    );
    if (interaction.replied || interaction.deferred) {
        if (interaction.followUp) {
            await interaction.followUp({ content: '❌ Não foi possível abrir o modal. Tente novamente.', flags: 64 });
        }
        return;
    }
    await interaction.showModal(modal);
};

painelDisparoDMHandlers.handleDefinirBtns = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    const modal = new ModalBuilder().setCustomId('dmmsg_modal_btns').setTitle('Adicionar Botão');
    modal.addComponents(
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('label').setLabel('Nome do botão').setStyle(1).setRequired(true).setMaxLength(80).setPlaceholder('Exemplo: Clique aqui')
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('url').setLabel('URL do botão').setStyle(1).setRequired(true).setMaxLength(512).setPlaceholder('https://exemplo.com')
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('emoji').setLabel('Emoji do botão (opcional)').setStyle(1).setRequired(false).setMaxLength(50).setPlaceholder('Exemplo: 🔗')
        )
    );
    if (interaction.replied || interaction.deferred) {
        if (interaction.followUp) {
            await interaction.followUp({ content: '❌ Não foi possível abrir o modal. Tente novamente.', flags: 64 });
        }
        return;
    }
    await interaction.showModal(modal);
};

// Handlers para limpar partes
painelDisparoDMHandlers.handleLimparMsg = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    delete cfg.content;
    await setMsgConfig(userId, cfg);
    await painelDisparoDMHandlers.handlePainelMensagemDM(interaction);
};
painelDisparoDMHandlers.handleLimparEmbed = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    delete cfg.author; delete cfg.title; delete cfg.description; delete cfg.color; delete cfg.footer;
    await setMsgConfig(userId, cfg);
    await painelDisparoDMHandlers.handlePainelMensagemDM(interaction);
};
painelDisparoDMHandlers.handleLimparImg = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    delete cfg.fileImage; delete cfg.imagem; delete cfg.thumbnail;
    await setMsgConfig(userId, cfg);
    await painelDisparoDMHandlers.handlePainelMensagemDM(interaction);
};
painelDisparoDMHandlers.handleLimparBtns = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    cfg.buttons = [];
    await setMsgConfig(userId, cfg);
    await painelDisparoDMHandlers.handlePainelMensagemDM(interaction);
};

// Handlers dos modais
painelDisparoDMHandlers.handleModalMsg = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    cfg.content = interaction.fields.getTextInputValue('content');
    await setMsgConfig(userId, cfg);
    await painelDisparoDMHandlers.handlePainelMensagemDM(interaction);
};
painelDisparoDMHandlers.handleModalEmbed = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    cfg.author = interaction.fields.getTextInputValue('author');
    cfg.title = interaction.fields.getTextInputValue('title');
    cfg.description = interaction.fields.getTextInputValue('description');
    cfg.color = interaction.fields.getTextInputValue('color');
    cfg.footer = interaction.fields.getTextInputValue('footer');
    await setMsgConfig(userId, cfg);
    await painelDisparoDMHandlers.handlePainelMensagemDM(interaction);
};
painelDisparoDMHandlers.handleModalImg = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    cfg.fileImage = interaction.fields.getTextInputValue('fileImage');
    cfg.imagem = interaction.fields.getTextInputValue('imagem');
    cfg.thumbnail = interaction.fields.getTextInputValue('thumbnail');
    await setMsgConfig(userId, cfg);
    await painelDisparoDMHandlers.handlePainelMensagemDM(interaction);
};
painelDisparoDMHandlers.handleModalBtns = async function(interaction) {
    const userId = interaction.user.id;
    const cfg = await getMsgConfig(userId);
    if (!cfg.buttons) cfg.buttons = [];
    if (cfg.buttons.length >= 10) return await interaction.reply({ content: 'Limite de 10 botões atingido.', flags : 64 });
    const label = interaction.fields.getTextInputValue('label').trim();
    const url = interaction.fields.getTextInputValue('url').trim();
    let emoji = interaction.fields.getTextInputValue('emoji').trim();
    if (!label || !url) return await interaction.reply({ content: 'Nome e URL do botão são obrigatórios.', flags : 64 });
    if (!url.startsWith('http://') && !url.startsWith('https://')) return await interaction.reply({ content: 'A URL deve começar com http:// ou https://', flags : 64 });
    cfg.buttons.push({ label, url, emoji: emoji || null });
    await setMsgConfig(userId, cfg);
    await painelDisparoDMHandlers.handlePainelMensagemDM(interaction);
};

// Handlers dos botões de Voltar e Salvar
painelDisparoDMHandlers.handleVoltar = async function(interaction) {
    // Volta para o painel principal do Disparo DM, sempre atualizando
    await painelDisparoDMHandlers.handlePainelDisparoDM(interaction, true);
};
painelDisparoDMHandlers.handleSalvar = async function(interaction) {
    // Apenas feedback visual, pois já salva automaticamente
    await interaction.reply({ content: '\`✅\` Mensagem salva com sucesso!', flags : 64 });
};

// Handler para iniciar disparo
painelDisparoDMHandlers.handleStart = async function(interaction) {
    console.log('[DEBUG] Iniciando handleStart para', interaction.user.id);
    const config = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, '../config.json'), 'utf8'));
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const cargoUniversal = config.cargo_permitido_universal;
    const cargoEspecifico = config.cargo_permitido_disparo_dm;
    console.log('[DEBUG] Permissões:', { cargoUniversal, cargoEspecifico });
    if ((cargoUniversal || cargoEspecifico) && !member.roles.cache.has(cargoUniversal) && !member.roles.cache.has(cargoEspecifico)) {
      console.log('[DEBUG] Sem permissão para disparo');
      await interaction.reply({ content: '\`❌\` \`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
      return;
    }
    const tempData = await getTempData(interaction.user.id);
    console.log('[DEBUG] tempData:', tempData);
    const tokensArr = tempData.tokens || [];
    const userIds = tempData.user_ids || [];
    const msgcfg = await getMsgConfig(interaction.user.id);
    const enviadosArr = getSentMembers(interaction.user.id);
    const guildId = tempData.guild_id || '';
    console.log('[DEBUG] tokensArr:', tokensArr);
    console.log('[DEBUG] userIds:', userIds);
    console.log('[DEBUG] msgcfg:', msgcfg);
    if (!tokensArr.length || !userIds.length || (!msgcfg.content && !msgcfg.title && !msgcfg.description && !msgcfg.imagem && !msgcfg.thumbnail && !msgcfg.fileImage)) {
        console.log('[DEBUG] Falta campo obrigatório para disparo');
        return interaction.reply({ content: '\`❌\` Preencha todos os campos obrigatórios (tokens, servidor, cargo, mensagem).', flags : 64 });
    }
    await interaction.reply({ content: '\`🔄\` Iniciando disparo...', flags : 64 });
    const temp = getTempData(interaction.user.id);
    temp.progress = 1;
    setTempData(interaction.user.id, temp);
    let enviados = 0;
    let falhas = 0;
    let guildName = '';
    console.log('[DEBUG] Iniciando loop de envio para', userIds.length, 'usuários');
    for (let i = 0; i < userIds.length; i++) {
        const userId = userIds[i];
        if (enviadosArr.includes(userId)) continue; // já enviado, pula
        const t = tokensArr[enviados % tokensArr.length];
        let client;
        try {
            // Monta mensagem customizada a partir do editor
            const { Client, GatewayIntentBits } = require('discord.js');
            client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });
            console.log(`[DEBUG] Logando com token ${t.token.substring(0, 10)}...`);
            await client.login(t.token);
            // Buscar nome do servidor (guild)
            let guild;
            try {
                guild = await client.guilds.fetch(guildId);
                guildName = guild.name;
            } catch (e) { guildName = guildId; console.log('[DEBUG] Erro ao buscar guild:', e); }
            // Buscar nome do usuário
            let userTag = userId;
            try {
                const user = await client.users.fetch(userId);
                userTag = user.tag + ` (ID: ${userId})`;
            } catch (e) { userTag = `ID: ${userId}`; console.log('[DEBUG] Erro ao buscar usuário:', e); }
            const embed = new EmbedBuilder();
            if (msgcfg.imagem) embed.setImage(msgcfg.imagem);
            if (msgcfg.thumbnail) embed.setThumbnail(msgcfg.thumbnail);
            if (msgcfg.author) embed.setAuthor({ name: msgcfg.author });
            if (msgcfg.title) embed.setTitle(msgcfg.title);
            if (msgcfg.description) embed.setDescription(msgcfg.description);
            if (msgcfg.color) embed.setColor(msgcfg.color);
            if (msgcfg.footer) embed.setFooter({ text: msgcfg.footer });
            let components = [];
            if (msgcfg.buttons && msgcfg.buttons.length > 0) {
                let currentRow = new ActionRowBuilder();
                for (const button of msgcfg.buttons.slice(0, 10)) {
                    const newButton = new ButtonBuilder()
                        .setLabel(button.label)
                        .setURL(button.url)
                        .setStyle(ButtonStyle.Link);
                    if (button.emoji) newButton.setEmoji(button.emoji);
                    if (currentRow.components.length >= 5) {
                        components.push(currentRow);
                        currentRow = new ActionRowBuilder();
                    }
                    currentRow.addComponents(newButton);
                }
                if (currentRow.components.length > 0) components.push(currentRow);
            }
            const payload = {
                content: msgcfg.content || undefined,
                embeds: (msgcfg.title || msgcfg.description || msgcfg.imagem || msgcfg.thumbnail) ? [embed] : [],
                components,
                files: msgcfg.fileImage ? [{ attachment: msgcfg.fileImage }] : undefined
            };
            console.log(`[DEBUG] Enviando DM para ${userId} usando token ${t.token.substring(0, 10)}...`);
            await require('./discord').inicDivSystem([t.token], [userId], payload);
            enviados++;
            addSentMember(interaction.user.id, userId);
            // Atualiza mensagem de progresso
            await interaction.editReply({
                content: `Servidor: ${guildName} (ID: ${guildId})\n\`🔄\` Disparo em andamento...\nEnviados: **${enviados}**\nFaltando: **${userIds.length - enviados}**\nÚltimo membro: ${userTag}`,
                flags : 64
            });
            await client.destroy();
        } catch (e) {
            falhas++;
            console.log('[DEBUG] Erro ao enviar para', userId, ':', e);
            if (client && client.destroy) await client.destroy();
        }
        if (i < userIds.length - 1) await sleep(randomDelay());
    }
    temp.progress = 0;
    temp.success = 1;
    setTempData(interaction.user.id, temp);
    console.log('[DEBUG] Disparo finalizado. Enviados:', enviados, 'Falhas:', falhas);
    await interaction.editReply({ content: `Servidor: ${guildName} (ID: ${guildId})\n\`✅\` Disparo de DM finalizado!\nEnviados: **${enviados}**\nFalhas: **${falhas}**`, flags : 64 });

    // Após finalizar o disparo, envie log se configurado
    const logChannelId = config.log_disparo_dm || logsChannelId || config.log_extracao;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('📤 Disparo DM Finalizado')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
            { name: 'Token', value: `||${tokensArr.map(t=>t.token).join(', ')}||`, inline: false },
            { name: 'Servidor', value: `\`${guildName} (${guildId})\``, inline: true },
            { name: 'Enviados', value: `${enviados}`, inline: true },
            { name: 'Falhas', value: `${falhas}`, inline: true },
            { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false }
          )
          .setFooter({ text: 'GG Tools' });
        logChannel.send({ embeds: [embed] });
      }
    }
};

// Handler para resetar config
painelDisparoDMHandlers.handleReset = async function(interaction) {
    await deleteTempData(interaction.user.id);
    await clearSentMembers(interaction.user.id);
    // Atualiza o painel principal após resetar
    await painelDisparoDMHandlers.handlePainelDisparoDM(interaction, true);
};

// Handler para limpar todos os membros enviados
painelDisparoDMHandlers.handleClearDB = async function(interaction) {
    await clearSentMembers(interaction.user.id);
    await painelDisparoDMHandlers.handlePainelDisparoDM(interaction, true);
};

module.exports = { painelDisparoDMHandlers }; 