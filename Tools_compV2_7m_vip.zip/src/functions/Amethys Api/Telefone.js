const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../../config.json'), 'utf8'));

async function consultaTelefone(query, interaction) {
  const url = `https://getvyenx.cloud/consulta/telefone?query=${encodeURIComponent(query)}&apikey=6b106542-4bc6-46a8-afe9-6152848a0a25`;
  try {
    const res = await fetch(url);
    const contentType = res.headers.get('content-type');
    if (!res.ok) {
      const text = await res.text();
      console.error(`Erro da API: ${res.status} - ${text}`);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: `Erro ao consultar telefone: ${res.status}. Tente novamente mais tarde ou contate o suporte.`, flags : 64 });
      } else {
        await interaction.followUp({ content: `Erro ao consultar telefone: ${res.status}. Tente novamente mais tarde ou contate o suporte.`, flags : 64 });
      }
      return false;
    }
    if (!contentType || !contentType.includes('application/json')) {
      const text = await res.text();
      console.error(`Resposta inesperada da API: ${contentType}, corpo: ${text}`);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: `A API retornou um formato inesperado. Tente novamente mais tarde ou contate o suporte.`, flags : 64 });
      } else {
        await interaction.followUp({ content: `A API retornou um formato inesperado. Tente novamente mais tarde ou contate o suporte.`, flags : 64 });
      }
      return false;
    }
    const data = await res.json();
    let txt = '';
    if (Array.isArray(data.resultado)) {
      txt = data.resultado.map((r, i) =>
        `Resultado ${i+1}:
` +
        (r.name ? `Nome: ${r.name}
` : '') +
        (r.cpf ? `CPF: ${r.cpf}
` : '') +
        (r.gender ? `Sexo: ${r.gender}
` : '') +
        (r.birth ? `Nascimento: ${r.birth.trim()}
` : '') +
        (r.age ? `Idade: ${r.age}
` : '') +
        (r.ddd ? `DDD: ${r.ddd}
` : '') +
        (r.phone_number ? `Telefone: ${r.phone_number}
` : '')
      ).join('\n');
    } else {
      txt = 'Nenhum resultado encontrado.';
    }
    let pasteUrl = null;
    try {
      const pasteRes = await fetch('https://api.paste.ee/v1/pastes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Auth-Token': 'a7w4GCtTLZ3qryCDgQqvi7aciJFUsX4qUXFdAzMM5'
        },
        body: JSON.stringify({
          description: `Consulta Telefone - ${query}`,
          sections: [{ name: `Consulta Telefone`, contents: txt }]
        })
      });
      const pasteData = await pasteRes.json();
      pasteUrl = pasteData.link;
    } catch (e) {
      pasteUrl = null;
    }
    let userEmbed = new EmbedBuilder()
      .setTitle('Consulta Telefone')
      .setDescription((pasteUrl ? `Veja no site: ${pasteUrl}` : 'Resultado disponível no arquivo .txt') + `\nConsulta realizada para o telefone: \`${query}\``)
      .setColor(0x5865F2)
      .setTimestamp();
    let userComponents = pasteUrl ? [{ type: 1, components: [{ type: 2, style: 5, label: 'Ver no Site', url: pasteUrl }] }] : [];
    try {
      await interaction.user.send({ embeds: [userEmbed], components: userComponents, files: [{ attachment: Buffer.from(txt), name: `consulta_telefone_${query}.txt` }] });
    } catch (err) {
      if (err.code === 50007) {
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: 'Não foi possível enviar DM, desbloqueie ela para continuar.', ephemeral: true });
        } else {
          await interaction.reply({ content: 'Não foi possível enviar DM, desbloqueie ela para continuar.', ephemeral: true });
        }
        return false;
      } else {
        throw err;
      }
    }
    const logChannelId = config.log_consulta_telefone;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('Consulta Telefone')
          .setDescription(`Consulta realizada por <@${interaction.user.id}> para o telefone: \`${query}\`\n` + (pasteUrl ? `${pasteUrl}` : 'Resultado disponível no arquivo .txt.'))
          .setColor(0x5865F2)
          .setTimestamp();
        let logComponents = pasteUrl ? [{ type: 1, components: [{ type: 2, style: 5, label: 'Ver no Site', emoji: { id: '1387208260389699695' }, url: pasteUrl }] }] : [];
        await logChannel.send({ embeds: [embed], components: logComponents, files: [{ attachment: Buffer.from(txt), name: `consulta_telefone_${query}.txt` }] });
      }
    }
    return true;
  } catch (err) {
    try {
      await interaction.user.send('Erro ao consultar telefone, se esse erro persistir, contate o suporte.');
    } catch {}
    return false;
  }
}

module.exports = { consultaTelefone };