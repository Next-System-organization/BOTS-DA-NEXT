const axios = require('axios');
const config = require('../../config.json');

const apiKey = '6b106542-4bc6-46a8-afe9-6152848a0a25';
const apiBase = 'https://getvyenx.cloud/free-fire';

async function sendLikes(uid) {
  const url = `${apiBase}/send-likes?uid=${encodeURIComponent(uid)}&apikey=${apiKey}&region=BR`;
  const response = await axios.get(url);
  return response.data;
}

async function viewAccount() {
  const url = `${apiBase}/view-account?apikey=${apiKey}`;
  const response = await axios.get(url);
  return response.data;
}

async function infoAccount(uid) {
  const url = `${apiBase}/info-account?uid=${encodeURIComponent(uid)}&apikey=${apiKey}`;
  const response = await axios.get(url);
  return response.data;
}

async function checkBan(uid) {
  const url = `${apiBase}/check-ban?uid=${encodeURIComponent(uid)}&apikey=${apiKey}`;
  const response = await axios.get(url);
  return response.data;
}

module.exports = {
  sendLikes,
  viewAccount,
  infoAccount,
  checkBan
};