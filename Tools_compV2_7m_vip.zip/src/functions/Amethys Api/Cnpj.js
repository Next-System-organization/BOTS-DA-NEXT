const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../../config.json'), 'utf8'));

async function consultaCNPJ(query, interaction) {
  const url = `https://getvyenx.cloud/consulta/cnpj?query=${encodeURIComponent(query)}&apikey=6b106542-4bc6-46a8-afe9-6152848a0a25`;
  try {
    const res = await fetch(url);
    const data = await res.json();
    let txt = '';
    if (data.resultado && typeof data.resultado === 'object') {
      const r = data.resultado;
      txt =
        `CNPJ: ${r.cnpj || '-'}\n` +
        `Razão Social: ${r.business_name || '-'}\n` +
        `Nome Fantasia: ${r.trade_name || '-'}\n` +
        `Data de Fundação: ${r.foundation_date || '-'}\n` +
        `Endereço: ${r.address || '-'}\n` +
        `Bairro: ${r.neighborhood || '-'}\n` +
        `Cidade: ${r.city || '-'}\n` +
        `Estado: ${r.state || '-'}\n` +
        `CEP: ${r.zip_code || '-'}\n` +
        `Natureza Jurídica: ${r.legal_nature || '-'}\n` +
        `CNAE: ${r.cnae || '-'} (${r.cnae_sg || '-'})\n` +
        `Situação Cadastral: ${r.registration_status_code || '-'}\n` +
        `Data Situação Cadastral: ${r.registration_status_date || '-'}\n` +
        `Status: ${r.status || '-'}\n` +
        `Risco: ${r.risk || '-'}\n` +
        `Google Maps: ${r.google_maps || '-'}\n`;
    } else {
      txt = 'Nenhum resultado encontrado.';
    }
    let pasteUrl = null;
    try {
      const pasteRes = await fetch('https://api.paste.ee/v1/pastes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Auth-Token': 'a7w4GCtTLZ3qryCDgQqvi7aciJFUsX4qUXFdAzMM5'
        },
        body: JSON.stringify({
          description: `Consulta CNPJ - ${query}`,
          sections: [{ name: `Consulta CNPJ`, contents: txt }]
        })
      });
      const pasteData = await pasteRes.json();
      pasteUrl = pasteData.link;
    } catch (e) {
      pasteUrl = null;
    }
    let userEmbed = new EmbedBuilder()
      .setTitle('Consulta CNPJ')
      .setDescription((pasteUrl ? `Veja no site: ${pasteUrl}` : 'Resultado disponível no arquivo .txt') + `\nConsulta realizada para o CNPJ: \`${query}\``)
      .setColor(0x5865F2)
      .setTimestamp();
    let userComponents = pasteUrl ? [{ type: 1, components: [{ type: 2, style: 5, label: 'Ver no Site', url: pasteUrl }] }] : [];
    try {
      await interaction.user.send({ embeds: [userEmbed], components: userComponents, files: [{ attachment: Buffer.from(txt), name: `consulta_cnpj_${query}.txt` }] });
    } catch (err) {
      if (err.code === 50007) {
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: 'Não foi possível enviar DM, desbloqueie ela para continuar.', flags:64 });
        } else {
          await interaction.reply({ content: 'Não foi possível enviar DM, desbloqueie ela para continuar.', flags: 64 });
        }
        return;
      } else {
        throw err;
      }
    }
    const logChannelId = config.log_consulta_cnpj;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('Consulta CNPJ')
          .setDescription(`Consulta realizada por <@${interaction.user.id}> para o CNPJ: \`${query}\`\n` + (pasteUrl ? `${pasteUrl}` : 'Resultado disponível no arquivo .txt.'))
          .setColor(0x5865F2)
          .setTimestamp();
        let logComponents = pasteUrl ? [{ type: 1, components: [{ type: 2, style: 5, label: 'Ver no Site', emoji: { id: '1387208260389699695' }, url: pasteUrl }] }] : [];
        await logChannel.send({ embeds: [embed], components: logComponents, files: [{ attachment: Buffer.from(txt), name: `consulta_cnpj_${query}.txt` }] });
      }
    }
  } catch (err) {
    await interaction.user.send('Erro ao consultar CNPJ, se esse erro persistir, contate o suporte.');
    throw err;
  }
}

module.exports = { consultaCNPJ };