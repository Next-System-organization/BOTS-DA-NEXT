const axios = require('axios');

const apiKey = '6b106542-4bc6-46a8-afe9-6152848a0a25';
const apiBase = 'https://getvyenx.cloud/email';

const createEmail = async () => {
  const response = await axios.get(`${apiBase}/criar-email?apikey=${apiKey}`);
  return response.data;
};

const getEmails = async (token) => {
  const response = await axios.get(`${apiBase}/ver-emails/${token}?apikey=${apiKey}`);
  return response.data;
};

const deleteEmail = async (token) => {
  const response = await axios.get(`${apiBase}/deletar-email/${token}?apikey=${apiKey}`);
  return response.data;
};

module.exports = { createEmail, getEmails, deleteEmail };