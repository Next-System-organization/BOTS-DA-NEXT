const axios = require('axios');
const cheerio = require('cheerio');
const path = require('path');
const url = require('url');

/**
 * Clona um site, baixando o HTML e ajustando os links de recursos para caminhos locais.
 * @param {string} siteUrl - URL do site a ser clonado
 * @returns {Promise<Buffer|null>} - Buffer do HTML clonado ou null em caso de erro
 */
async function clonerSite(siteUrl) {
    // Busca a página HTML
    const fetchPage = async (pageUrl) => {
        try {
            const response = await axios.get(pageUrl);
            return response.data;
        } catch (error) {
            console.error(`Erro ao buscar a página: ${error.message}`);
            return null;
        }
    };

    // Atualiza os links de recursos (href/src) para caminhos locais
    const updateLinks = async (html, baseUrl) => {
        const $ = cheerio.load(html);

        const updateLink = async (elem, attr) => {
            const link = $(elem).attr(attr);
            if (link) {
                const absoluteLink = url.resolve(baseUrl, link);
                const parsedUrl = url.parse(absoluteLink);
                // Não baixa recursos, apenas ajusta o caminho para local
                $(elem).attr(attr, parsedUrl.pathname);
            }
        };

        const promises = [];
        $('a[href]').each((i, elem) => promises.push(updateLink(elem, 'href')));
        $('img[src]').each((i, elem) => promises.push(updateLink(elem, 'src')));
        $('link[href]').each((i, elem) => promises.push(updateLink(elem, 'href')));
        $('script[src]').each((i, elem) => promises.push(updateLink(elem, 'src')));

        await Promise.all(promises);
        return $.html();
    };

    // Retorna o HTML como Buffer
    const sendHtml = async (htmlContent) => {
        return Buffer.from(htmlContent, 'utf-8');
    };

    // Processo principal
    const htmlContent = await fetchPage(siteUrl);
    if (!htmlContent) return null;
    const updatedHtml = await updateLinks(htmlContent, siteUrl);
    return sendHtml(updatedHtml);
}

module.exports = { clonerSite };
