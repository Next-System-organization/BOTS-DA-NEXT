const axios = require('axios');
const { Client, GatewayIntentBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../config.json');
let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

let botIAClient = null;

/**
 * Gera uma sugestão de estrutura de servidor Discord usando IA.
 * @param {string} mensagemPrompt - O que o usuário descreveu no modal.
 * @returns {Promise<string>} - Resposta da IA (estrutura sugerida).
 */
async function gerarEstruturaServidorIA(mensagemPrompt) {
    try {
        const apiResponse = await axios.get('https://getvyenx.cloud/ai/ask', {
            params: {
                query: mensagemPrompt,
                apikey: '6b106542-4bc6-46a8-afe9-6152848a0a25'
            }
        });
        // A resposta da IA provavelmente estará em apiResponse.data.response ou similar
        return apiResponse.data.response || apiResponse.data;
    } catch (error) {
        console.error('Erro ao chamar a IA:', error);
        return 'Erro ao gerar sugestão de servidor. Tente novamente.';
    }
}

async function startBotIA() {
    if (botIAClient) return botIAClient;
    config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    if (!config.token_bot_ia) throw new Error('Token do bot IA não configurada em config.json');
    botIAClient = new Client({
        intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.MessageContent
        ]
    });
    await botIAClient.login(config.token_bot_ia);
    return botIAClient;
}

module.exports = {
    gerarEstruturaServidorIA,
    startBotIA
};
