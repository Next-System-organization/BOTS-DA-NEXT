const fetch = require('node-fetch');

function generateHeaders(token) {
  return {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9007 Chrome/91.0.4472.164 Electron/13.6.6 Safari/537.36',
    'Accept-Language': 'en-GB',
    'locale': 'en-GB',
    'X-Debug-Options': 'bugReporterEnabled',
    'X-Discord-Locale': 'en-GB',
    'X-Super-Properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDA3Iiwib3NfdmVyc2lvbiI6IjEwLjAuMjI2MjEiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLUdCIiwiY2xpZW50X2J1aWxkX251bWJlciI6MTU2MDgwLCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsfQ==',
    'Authorization': token,
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Host': 'discord.com'
  };
}

function randomDelay() {
  return 2600 + Math.floor(Math.random() * 200) + 100;
}

// Função para remover amizades. O canal de log recomendado é config.log_unfriend (configurável pelo painel /config).
async function unfriendAll({ token, userId, whitelistedUsers = [], whitelistedFriendships = [], interaction }, log = () => {}) {
  const config = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, '../config.json'), 'utf8'));
  if (interaction) {
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const cargoUniversal = config.cargo_permitido_universal;
    const cargoEspecifico = config.cargo_permitido_unfriend;
    if ((cargoUniversal || cargoEspecifico) && !member.roles.cache.has(cargoUniversal) && !member.roles.cache.has(cargoEspecifico)) {
      await interaction.editReply({ content: '\`❌\` \`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
      return;
    }
  }
  // Buscar todos os amigos via API
  const headers = generateHeaders(token);
  const res = await fetch('https://discord.com/api/v9/users/@me/relationships', { headers });
  if (!res.ok) {
    log(`Erro ao buscar amigos: ${res.status}`);
    throw new Error('Não foi possível buscar a lista de amigos.');
  }
  const relationships = await res.json();
  let removed = 0;
  let errors = 0;
  for (const rel of relationships) {
    if (rel.type !== 1) continue; // Apenas amigos
    const friendId = rel.id || (rel.user && rel.user.id);
    if (!friendId) continue;
    if (whitelistedUsers.includes(friendId) || whitelistedFriendships.includes(friendId)) {
      log(`Ignorando amizade com ${friendId} (whitelist)`);
      continue;
    }
    try {
      const del = await fetch(`https://discord.com/api/v9/users/@me/relationships/${friendId}`, {
        method: 'DELETE',
        headers
      });
      if (del.status === 204) {
        removed++;
        log(`Amizade removida com ${friendId}`);
      } else {
        errors++;
        log(`Erro ao remover amizade com ${friendId} - Status: ${del.status}`);
      }
      await new Promise(res => setTimeout(res, randomDelay()));
    } catch (e) {
      errors++;
      log(`Erro ao remover amizade com ${friendId}: ${e.message}`);
    }
  }
  return { removed, errors };
}

module.exports = { unfriendAll }; 