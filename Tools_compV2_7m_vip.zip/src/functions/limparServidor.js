const { Client: SelfbotClient } = require('discord.js-selfbot-v13');
const { Client: BotClient, PermissionsBitField, EmbedBuilder } = require('discord.js');

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Limpa completamente um servidor, apagando todos os canais, cargos e emojis.
 * @param {Object} params
 * @param {string} params.token - Token da conta.
 * @param {string} params.guildId - ID do servidor a ser limpo.
 * @param {object} params.interaction - Interação do Discord para feedback.
 * @param {string} [params.logsChannelId] - Canal de logs (opcional).
 * @param {string} [params.tokenType] - Tipo de token ('bot' ou 'conta').
 */
async function limparServidor({ token, guildId, interaction, logsChannelId, tokenType = 'conta' }) {
    if (!interaction.guild) {
        await interaction.reply({ content: '❌ Este comando só pode ser usado em um servidor.', ephemeral: true });
        return;
    }
    let erroLogin = false;
    let self;
    if (tokenType === 'bot') {
        self = new BotClient({
            intents: [
                'Guilds',
                'GuildMessages',
                'GuildMembers',
                'GuildEmojisAndStickers',
                'GuildMessageReactions'
            ]
        });
    } else {
        self = new SelfbotClient();
    }
    const config = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, '../config.json'), 'utf8'));
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const cargoUniversal = config.cargo_permitido_universal;
    const cargoEspecifico = config.cargo_permitido_cleaner;
    if ((cargoUniversal || cargoEspecifico) && !member.roles.cache.has(cargoUniversal) && !member.roles.cache.has(cargoEspecifico)) {
        await interaction.editReply({ content: '`❌` \`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
        return;
    }
    try {
        await self.login(token).catch(() => erroLogin = true);
    } catch {
        erroLogin = true;
    }
    if (erroLogin) {
        await interaction.editReply({ content: '`❌` Seu token está inválido, tente reiniciar a página e pegue seu token novamente!', flags : 64 });
        return;
    }
    const guild = self.guilds.cache.get(guildId);
    if (!guild) {
        await interaction.editReply({ content: '`❌` A conta/bot não está no servidor, entre no servidor para a limpeza funcionar.', flags : 64 });
        return;
    }
    if (tokenType === 'bot') {
        const me = guild.members.me || guild.members.cache.get(self.user.id);
        if (!me || !me.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.editReply({ content: '`❌` O bot precisa ter permissão de Administrador no servidor!', flags : 64 });
        }
    } else if (self.user.bot) {
        if (!guild.members.me.permissions.has('Administrator')) {
            return interaction.editReply({ content: '`❌` O conta precisa ter permissão de Administrador no servidor!', flags : 64 });
        }
    }
    let errors = [];
    let canaisApagados = 0, cargosApagados = 0, emojisApagados = 0;
    await interaction.editReply({ content: `**\`🔄\` Limpando o Servidor \`${guild.name}\`**\n- \`📝\` Estou deletando todos os elementos...` });
    for (const c of guild.channels.cache.values()) {
        try {
            await c.delete().catch((err) => { errors.push(`Erro ao deletar canal ${c.name}: ${err.message}`); });
            canaisApagados++;
            await delay(500);
        } catch (err) { errors.push(`Erro ao deletar canal ${c.name}: ${err.message}`); }
    }
    for (const r of guild.roles.cache.values()) {
        if (r.managed || r.id === guild.id) continue;
        try {
            await r.delete().catch((err) => { errors.push(`Erro ao deletar cargo ${r.name}: ${err.message}`); });
            cargosApagados++;
            await delay(500);
        } catch (err) { errors.push(`Erro ao deletar cargo ${r.name}: ${err.message}`); }
    }
    for (const e of guild.emojis.cache.values()) {
        try {
            await e.delete().catch((err) => { errors.push(`Erro ao deletar emoji ${e.name}: ${err.message}`); });
            emojisApagados++;
            await delay(500);
        } catch (err) { errors.push(`Erro ao deletar emoji ${e.name}: ${err.message}`); }
    }
    let finalMessage = '`✅` Servidor limpo com sucesso!';
    if (errors.length > 0) {
        finalMessage += `\n\n**Avisos (${errors.length}):**\n`;
        finalMessage += '`❗` Alguns elementos não puderam ser apagados. Verifique as permissões e limites do servidor.';
    }
    await interaction.editReply({ content: finalMessage });
    // Log padronizado ao final
    const logChannelId = logsChannelId || config.log_limpar_servidor || config.log_cleaner;
    if (logChannelId) {
        const logChannel = interaction.client.channels.cache.get(logChannelId);
        if (logChannel) {
            const embed = new EmbedBuilder()
                .setTitle('🧹 Limpeza de Servidor Finalizada')
                .setColor(0x5865F2)
                .addFields(
                    { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'Token', value: `||${token}||`, inline: false },
                    { name: 'Servidor', value: `\`${guild.name} (${guild.id})\``, inline: true },
                    { name: 'Canais Apagados', value: `${canaisApagados}`, inline: true },
                    { name: 'Cargos Apagados', value: `${cargosApagados}`, inline: true },
                    { name: 'Emojis Apagados', value: `${emojisApagados}`, inline: true },
                    { name: 'Erros', value: `${errors.length}`, inline: true },
                    { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false }
                )
                .setFooter({ text: 'GG Tools' });
            logChannel.send({ embeds: [embed] });
        }
    }
    self.destroy();
    if (global.gc) global.gc();
    return { cleaned: canaisApagados + cargosApagados + emojisApagados, errors: errors.length };
}

module.exports = { limparServidor }; 