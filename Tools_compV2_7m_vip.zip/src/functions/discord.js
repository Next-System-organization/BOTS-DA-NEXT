const axios = require("axios");
const { Client: BotClient, GatewayIntentBits, Partials } = require('discord.js');
const { Client: SelfbotClient } = require('discord.js-selfbot-v13');

async function getInfo(token) {
    try {
        const response = await axios.get("https://discord.com/api/v9/users/@me", {
            headers: {
                "Authorization": token,
                "Content-Type": "application/json"
            }
        });
        return response.data;
    } catch(err) {
        return { err: err.message, status: err.response?.status, response: err.response?.data };
    }
}

async function guildVerify(tokens, idServer) {
  const tkValid = [];
  let onlineTotal = 0, disponiveis = 0, ausentes = 0, naoPerturbe = 0, offlines = 0, membros = 0, scrapped = [];
  let verify = false;
  for (const token of tokens) {
    try {
      let client;
      const buti = token.startsWith('Bot ');
      if (buti) {
        client = new BotClient({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildPresences] });
        await new Promise((resolve, reject) => { client.once('ready', resolve); client.login(token).catch(reject); });
        const guild = await client.guilds.fetch(idServer);
        if (!verify) {
          try {
            const members = await guild.members.fetch({ withPresences: true });
            membros = members.size;
            scrapped = members.map((member) => member.id);
            members.forEach(member => {
              const presence = member.presence?.status;
              if (!presence) offlines++;
              else {
                onlineTotal++;
                if (presence === 'online') disponiveis++;
                if (presence === 'idle') ausentes++;
                if (presence === 'dnd') naoPerturbe++;
              }
            });
          } catch {
            const members = await guild.members.fetch();
            membros = members.size;
            offlines += members.size;
            scrapped = members.map((member) => member.id);
          }
          verify = true;
        }
        tkValid.push(token);
        client.destroy();
      } else {
        client = new SelfbotClient();
        await new Promise((resolve, reject) => { client.once('ready', resolve); client.login(token).catch(reject); });
        const guild = await client.guilds.fetch(idServer);
        if (!verify) {
          try {
            const members = await guild.members.fetch({ withPresences: true });
            membros = members.size;
            scrapped = members.map((member) => member.id);
            members.forEach(member => {
              const presence = member.presence?.status;
              if (!presence) offlines++;
              else {
                onlineTotal++;
                if (presence === 'online') disponiveis++;
                if (presence === 'idle') ausentes++;
                if (presence === 'dnd') naoPerturbe++;
              }
            });
          } catch {
            const members = await guild.members.fetch();
            scrapped = members.map((member) => member.id);
            membros = members.size;
            offlines += members.size;
          }
          verify = true;
        }
        tkValid.push(token);
        client.destroy();
      }
    } catch (err) {}
  }
  return {
    Online: { total: onlineTotal, Disponiveis: disponiveis, ausentes: ausentes, 'Não perturbe': naoPerturbe },
    Offlines: offlines,
    membros: membros,
    tokens: tkValid,
    scrapped
  };
}

async function inicDivSystem(tokens, usersId, message) {
    const clients = [];
    for (const token of tokens) {
        const client = new BotClient({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMembers,
                GatewayIntentBits.DirectMessages
            ],
            partials: Object.values(Partials)
        });
        await new Promise((resolve, reject) => {
            client.once('ready', () => resolve());
            client.login(token).catch(reject);
        });
        console.log('[DEBUG] Após login, client.user:', client.user ? client.user.tag : client.user);
        clients.push(client);
    }
    setTimeout(() => {
        console.log('[DEBUG] Timeout: loop travado?');
    }, 10000);
    for (let i = 0; i < usersId.length; i++) {
        const client = clients[i % tokens.length];
        const userId = usersId[i];
        if (client.user && userId === client.user.id) {
            console.log(`[DEBUG] Ignorando envio para o próprio bot (${userId})`);
            continue;
        }
        try {
            console.log('[DEBUG] [1] Tentando buscar usuário:', userId);
            const user = await client.users.fetch(userId);
            console.log('[DEBUG] [2] Usuário encontrado:', user.tag);
            const dm = await user.createDM();
            console.log('[DEBUG] [3] Canal de DM criado');
            await dm.send(message);
            console.log('[DEBUG] [4] DM enviada para', userId);
        } catch (err) {
            console.error(`[DEBUG] Erro ao enviar DM para ${userId}:`, err);
        }
        await new Promise((resolve) => setTimeout(resolve, 5000));
    }
    for (const client of clients) {
        client.destroy?.();
    }
    return true;
}

async function changeUser(token, username) {
    const axios = require('axios');
    try {
        await axios.patch(
            "https://discord.com/api/v10/users/@me",
            { username: username },
            { headers: { Authorization: token, "Content-Type": "application/json" } }
        );
        return true;
    } catch (err) { return false; }
}

async function changeAvatar(token, url) {
    const axios = require('axios');
    try {
        const imageResponse = await axios.get(url, { responseType: "arraybuffer" });
        const imageBuffer = Buffer.from(imageResponse.data, "binary");
        const imageBase64 = imageBuffer.toString("base64");
        const mimeType = imageResponse.headers["content-type"];
        const urlData = `data:${mimeType};base64,${imageBase64}`;
        await axios.patch(
            "https://discord.com/api/v10/users/@me",
            { avatar: urlData },
            { headers: { Authorization: token, "Content-Type": "application/json" } }
        );
        return true;
    } catch (err) { return false; }
}

module.exports = {
    getInfo,
    guildVerify,
    changeAvatar,
    changeUser,
    inicDivSystem
}; 