import discord
from datetime import datetime
import json

ROXO   = 0x9B59B6
VERDE  = 0x2ECC71
VERM   = 0xE74C3C
OURO   = 0xFFD700
AZUL   = 0x3498DB
EMOJI  = "🎉"
FOOTER = "7M Vazamentos • Sorteios V2"


def embed_ativo(s: dict) -> discord.Embed:
    termina = datetime.fromisoformat(s["termina_em"])
    ts      = int(termina.timestamp())
    partic  = len(json.loads(s.get("participantes","[]")))

    desc = [f"```fix\n  Reaja com {EMOJI} para participar!\n```"]
    if s.get("descricao"):
        desc.append(f"> 📝 {s['descricao']}\n")
    desc += [
        f"⏰ **Encerra:** <t:{ts}:R>",
        f"🏆 **Vencedores:** `{s['n_vencedores']}`",
        f"👥 **Participantes:** `{partic}`",
    ]
    if s.get("cargo_req"):
        desc.append(f"🎭 **Cargo obrigatório:** <@&{s['cargo_req']}>")
    if s.get("min_dias_conta",0):
        desc.append(f"📅 **Conta mínima:** `{s['min_dias_conta']} dias`")
    if s.get("min_dias_serv",0):
        desc.append(f"🏠 **No servidor mín.:** `{s['min_dias_serv']} dias`")
    desc.append(f"\n👑 **Criado por:** <@{s['criador_id']}>")

    e = discord.Embed(title=f"🎉  {s['premio']}", description="\n".join(desc),
                      color=ROXO, timestamp=termina)
    e.set_footer(text=f"{FOOTER}  |  Encerra em")
    return e


def embed_finalizado(s: dict) -> discord.Embed:
    partic = len(json.loads(s.get("participantes","[]")))
    vencs  = json.loads(s.get("vencedores","[]"))

    if vencs:
        v_str = "\n".join(f"  🏆 <@{v}>" for v in vencs)
        cor   = VERDE
    else:
        v_str = "  ⚠️ Nenhum participante elegível."
        cor   = VERM

    desc = [
        "```fix\n  ✅  SORTEIO ENCERRADO  ✅\n```",
        f"**Vencedor(es):**\n{v_str}\n",
        f"👥 **Participantes:** `{partic}`",
        f"👑 **Criado por:** <@{s['criador_id']}>",
    ]
    if s.get("resorteado_por",0):
        desc.append(f"🔄 **Re-sorteado por:** <@{s['resorteado_por']}>")

    e = discord.Embed(title=f"🎊  {s['premio']}", description="\n".join(desc),
                      color=cor, timestamp=datetime.utcnow())
    e.set_footer(text=f"{FOOTER}  |  Finalizado em")
    return e


def embed_dm(premio: str, item: str, servidor: str, msg_custom: str = "") -> discord.Embed:
    e = discord.Embed(title="🎊  Você ganhou!", color=OURO, timestamp=datetime.utcnow())
    if msg_custom:
        e.description = msg_custom.replace("{premio}", premio).replace("{servidor}", servidor)
    else:
        e.description = (
            f"Parabéns! Você foi sorteado em **{servidor}** e ganhou:\n\n"
            f"🎁 **{premio}**\n\nSeu prêmio está abaixo 👇"
        )
    e.add_field(name="📦 Seu prêmio", value=f"```\n{item}\n```", inline=False)
    e.add_field(name="⚠️ Atenção",
                value="Não compartilhe! Em caso de dúvidas contate a equipe do servidor.", inline=False)
    e.set_footer(text=f"{servidor} • 7M Vazamentos")
    return e


def embed_stock(cats, guild_name: str) -> discord.Embed:
    e = discord.Embed(title=f"📦  Estoque — {guild_name}", color=AZUL, timestamp=datetime.utcnow())
    if not cats:
        e.description = "📭 Estoque vazio."
    else:
        for cat in cats:
            nome, total, disp = cat[0], cat[1], cat[2]
            pct  = int((disp / total) * 10) if total else 0
            bar  = "🟩" * pct + "⬛" * (10 - pct)
            e.add_field(name=f"📦 {nome}", value=f"{bar}\n`{disp}/{total}` disponíveis", inline=False)
    e.set_footer(text=FOOTER)
    return e


def embed_log(s: dict, vencs: list, itens_dm) -> discord.Embed:
    partic = len(json.loads(s.get("participantes","[]")))
    e = discord.Embed(title="📋 Log de Sorteio", color=OURO, timestamp=datetime.utcnow())
    e.add_field(name="🎁 Prêmio",      value=s["premio"],              inline=True)
    e.add_field(name="👑 Criador",      value=f"<@{s['criador_id']}>",  inline=True)
    e.add_field(name="👥 Participantes",value=str(partic),              inline=True)
    if vencs:
        e.add_field(name="🏆 Vencedores",
                    value="\n".join(f"<@{v}>" for v in vencs), inline=False)
    if itens_dm:
        txt = "\n".join(f"`{i['item']}`" for i in itens_dm[:5])
        if len(itens_dm) > 5:
            txt += f"\n...+{len(itens_dm)-5}"
        e.add_field(name="📦 Entregue via DM", value=txt, inline=False)
    e.set_footer(text=f"MSG ID: {s['message_id']}  |  {FOOTER}")
    return e


def embed_ajuda() -> discord.Embed:
    e = discord.Embed(
        title="❓ Ajuda — 7M Vazamentos Sorteios V2",
        description="Sistema completo de sorteios com entrega automática via DM!",
        color=ROXO,
        timestamp=datetime.utcnow()
    )
    cmds = [
        ("🎉 /sorteio",          "Cria sorteio (abre painel de config)"),
        ("⏹️ /encerrar [ID]",    "Encerra sorteio pelo ID da mensagem"),
        ("📋 /listar",           "Lista sorteios ativos"),
        ("📜 /historico",        "Últimos 10 sorteios encerrados"),
        ("📦 /stock add",        "Adiciona itens ao estoque (entregues via DM)"),
        ("📊 /stock ver",        "Ver estoque por categoria"),
        ("🗑️ /stock limpar",    "Remove itens não usados de uma categoria"),
        ("⚙️ /config log",      "Define canal de logs"),
        ("✉️ /config dm",       "Ativa/desativa DM automática"),
        ("📝 /config mensagem",  "Personaliza mensagem de DM"),
        ("👁️ /config ver",      "Ver configurações atuais"),
        ("🚫 /blacklist add",    "Bloqueia usuário dos sorteios"),
        ("✅ /blacklist remove", "Desbloqueia usuário"),
        ("📋 /blacklist ver",    "Ver lista de bloqueados"),
        ("❓ /ajuda",            "Este menu"),
    ]
    for nome, desc in cmds:
        e.add_field(name=nome, value=desc, inline=False)
    e.set_footer(text=f"{FOOTER}  |  Requer Gerenciar Servidor para comandos admin")
    return e
