import discord
from discord.ext import commands
import asyncio
import os
from dotenv import load_dotenv
from database import Database

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.all()

class BotSorteio(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents, help_command=None)
        self.db = Database()

    async def setup_hook(self):
        await self.db.init()
        for cog in ["cogs.sorteio", "cogs.stock", "cogs.admin"]:
            await self.load_extension(cog)
        synced = await self.tree.sync()
        print(f"📡 {len(synced)} comando(s) sincronizado(s).")

    async def on_ready(self):
        print(f"\n{'═'*40}")
        print(f"  ✅  {self.user}")
        print(f"  🎉  7M Vazamentos — V2")
        print(f"{'═'*40}\n")
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="🎉 7M Vazamentos"
            )
        )

bot = BotSorteio()

if __name__ == "__main__":
    if not TOKEN or TOKEN == "SEU_TOKEN_AQUI":
        print("❌ Coloque seu token no arquivo .env !")
    else:
        bot.run(TOKEN)
