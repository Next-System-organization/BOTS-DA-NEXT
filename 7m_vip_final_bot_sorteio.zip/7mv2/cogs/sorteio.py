import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
import random
import json
from datetime import datetime, timedelta
from embeds import embed_ativo, embed_finalizado, embed_dm, embed_log

EMOJI = "🎉"
ROXO  = 0x9B59B6


# ═══════════════════════════════════════════════════════════
#   PAINEL DE CONFIGURAÇÃO (antes do Modal)
# ═══════════════════════════════════════════════════════════
class PainelConfig(discord.ui.View):
    def __init__(self, autor_id: int, cog):
        super().__init__(timeout=120)
        self.autor_id   = autor_id
        self.cog        = cog
        self.canal_alvo = None
        self.cargo_req  = None
        self.min_conta  = 0
        self.min_serv   = 0

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.autor_id:
            await interaction.response.send_message("❌ Este painel não é seu.", ephemeral=True)
            return False
        return True

    @discord.ui.select(
        cls=discord.ui.ChannelSelect,
        placeholder="📢 Canal do sorteio (padrão: canal atual)",
        min_values=0, max_values=1,
        channel_types=[discord.ChannelType.text],
        row=0,
    )
    async def sel_canal(self, interaction: discord.Interaction, select: discord.ui.ChannelSelect):
        self.canal_alvo = select.values[0] if select.values else None
        await interaction.response.edit_message(view=self)

    @discord.ui.select(
        cls=discord.ui.RoleSelect,
        placeholder="🎭 Cargo obrigatório para participar (opcional)",
        min_values=0, max_values=1,
        row=1,
    )
    async def sel_cargo(self, interaction: discord.Interaction, select: discord.ui.RoleSelect):
        self.cargo_req = select.values[0] if select.values else None
        await interaction.response.edit_message(view=self)

    @discord.ui.button(label="📅 Conta mín: 0 dias", style=discord.ButtonStyle.secondary, row=2)
    async def btn_conta(self, interaction: discord.Interaction, btn: discord.ui.Button):
        opts = [0, 7, 14, 30, 60, 90]
        idx  = opts.index(self.min_conta) if self.min_conta in opts else 0
        self.min_conta = opts[(idx + 1) % len(opts)]
        btn.label = f"📅 Conta mín: {self.min_conta} dias"
        await interaction.response.edit_message(view=self)

    @discord.ui.button(label="🏠 Servidor mín: 0 dias", style=discord.ButtonStyle.secondary, row=2)
    async def btn_serv(self, interaction: discord.Interaction, btn: discord.ui.Button):
        opts = [0, 1, 3, 7, 14, 30]
        idx  = opts.index(self.min_serv) if self.min_serv in opts else 0
        self.min_serv = opts[(idx + 1) % len(opts)]
        btn.label = f"🏠 Servidor mín: {self.min_serv} dias"
        await interaction.response.edit_message(view=self)

    @discord.ui.button(label="▶️ Continuar", style=discord.ButtonStyle.success, emoji="🎉", row=3)
    async def btn_continuar(self, interaction: discord.Interaction, btn: discord.ui.Button):
        canal = self.canal_alvo or interaction.channel
        modal = ModalSorteio(canal, self.cargo_req, self.min_conta, self.min_serv, self.cog)
        await interaction.response.send_modal(modal)
        self.stop()

    @discord.ui.button(label="✖ Cancelar", style=discord.ButtonStyle.danger, row=3)
    async def btn_cancelar(self, interaction: discord.Interaction, btn: discord.ui.Button):
        await interaction.response.edit_message(content="❌ Cancelado.", embed=None, view=None)
        self.stop()


# ═══════════════════════════════════════════════════════════
#   MODAL DO SORTEIO
# ═══════════════════════════════════════════════════════════
class ModalSorteio(discord.ui.Modal, title="🎉 Criar Sorteio — 7M Vazamentos"):

    f_premio = discord.ui.TextInput(
        label="🎁 Prêmio",
        placeholder="Ex: Plano mensal Axia, Netflix 1 mês...",
        max_length=100,
        required=True,
    )
    f_descricao = discord.ui.TextInput(
        label="📝 Descrição (opcional)",
        placeholder="Detalhes extras sobre o prêmio ou regras...",
        required=False,
        max_length=300,
        style=2,
    )
    f_duracao = discord.ui.TextInput(
        label="⏰ Duração  (ex: 30m | 2h | 1d | 7d)",
        placeholder="10m = 10 min  |  2h = 2 horas  |  1d = 1 dia",
        max_length=10,
        required=True,
    )
    f_vencedores = discord.ui.TextInput(
        label="🏆 Número de vencedores",
        placeholder="1",
        max_length=2,
        required=True,
        default="1",
    )
    f_stock = discord.ui.TextInput(
        label="📦 Categoria do estoque (vazio = não usar)",
        placeholder="Ex: netflix  |  axia  |  spotify",
        required=False,
        max_length=50,
    )

    def __init__(self, canal_alvo, cargo_req, min_conta, min_serv, cog):
        super().__init__()
        self.canal_alvo = canal_alvo
        self.cargo_req  = cargo_req
        self.min_conta  = min_conta
        self.min_serv   = min_serv
        self.cog        = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        # Parse duração
        raw = self.f_duracao.value.strip().lower()
        try:
            if   raw.endswith("d"): seg = int(raw[:-1]) * 86400
            elif raw.endswith("h"): seg = int(raw[:-1]) * 3600
            elif raw.endswith("m"): seg = int(raw[:-1]) * 60
            elif raw.endswith("s"): seg = int(raw[:-1])
            else:                   seg = int(raw) * 60
        except ValueError:
            await interaction.followup.send("❌ Duração inválida. Use: `30m`, `2h`, `1d`", ephemeral=True)
            return
        if seg < 10:
            await interaction.followup.send("❌ Duração mínima é 10 segundos.", ephemeral=True)
            return
        if seg > 60 * 86400:
            await interaction.followup.send("❌ Duração máxima é 60 dias.", ephemeral=True)
            return

        # Parse vencedores
        try:
            n = max(1, int(self.f_vencedores.value.strip()))
        except ValueError:
            await interaction.followup.send("❌ Número de vencedores inválido.", ephemeral=True)
            return

        # Categoria stock
        categoria = self.f_stock.value.strip().lower() if self.f_stock.value.strip() else ""

        # Verifica estoque suficiente
        if categoria:
            disp = await interaction.client.db.pegar_stock(interaction.guild.id, categoria, n)
            if len(disp) < n:
                await interaction.followup.send(
                    f"❌ Estoque insuficiente! Categoria `{categoria}` tem "
                    f"`{len(disp)}` item(ns) mas você quer `{n}` vencedor(es).",
                    ephemeral=True,
                )
                return

        termina_em = datetime.utcnow() + timedelta(seconds=seg)
        dados = {
            "message_id":      0,
            "channel_id":      self.canal_alvo.id,
            "guild_id":        interaction.guild.id,
            "criador_id":      interaction.user.id,
            "premio":          self.f_premio.value.strip(),
            "descricao":       self.f_descricao.value.strip() if self.f_descricao.value else "",
            "n_vencedores":    n,
            "termina_em":      termina_em.isoformat(),
            "cargo_req":       self.cargo_req.id if self.cargo_req else 0,
            "min_dias_conta":  self.min_conta,
            "min_dias_serv":   self.min_serv,
            "categoria_stock": categoria,
            "participantes":   "[]",
        }

        embed = embed_ativo(dados)
        msg   = await self.canal_alvo.send(embed=embed)
        await msg.add_reaction(EMOJI)

        dados["message_id"] = msg.id
        await interaction.client.db.criar(dados)

        await interaction.followup.send(
            f"✅ Sorteio **{dados['premio']}** criado em {self.canal_alvo.mention}!",
            ephemeral=True,
        )
        await self.cog.agendar(msg.id, self.canal_alvo, seg, categoria)


# ═══════════════════════════════════════════════════════════
#   VIEW DO SORTEIO ENCERRADO
# ═══════════════════════════════════════════════════════════
class ViewEncerrado(discord.ui.View):
    def __init__(self, message_id: int, cog):
        super().__init__(timeout=None)
        self.message_id = message_id
        self.cog        = cog

    def _tem_perm(self, interaction: discord.Interaction, criador_id: int) -> bool:
        return (
            interaction.user.id == criador_id
            or interaction.user.guild_permissions.manage_guild
        )

    @discord.ui.button(label="🔄 Reroll", style=discord.ButtonStyle.secondary, custom_id="reroll_btn")
    async def btn_reroll(self, interaction: discord.Interaction, btn: discord.ui.Button):
        s = await interaction.client.db.get(self.message_id)
        if not s:
            await interaction.response.send_message("❌ Sorteio não encontrado.", ephemeral=True)
            return
        if not self._tem_perm(interaction, s["criador_id"]):
            await interaction.response.send_message("❌ Apenas o criador ou admins podem fazer reroll.", ephemeral=True)
            return

        await interaction.response.defer()
        partic = json.loads(s.get("participantes", "[]"))
        if not partic:
            await interaction.followup.send("⚠️ Sem participantes para reroll.")
            return

        vencs = random.sample(partic, min(s["n_vencedores"], len(partic)))
        await interaction.client.db.resorteio(self.message_id, vencs, interaction.user.id)

        s["vencedores"]     = json.dumps(vencs)
        s["resorteado_por"] = interaction.user.id

        try:
            msg = await interaction.channel.fetch_message(self.message_id)
            await msg.edit(embed=embed_finalizado(s), view=self)
        except Exception:
            pass

        mencoes = " ".join(f"<@{v}>" for v in vencs)
        await interaction.followup.send(
            f"🔄 **Reroll!** Novos vencedores de **{s['premio']}**: {mencoes} 🎊\n"
            f"> Re-sorteado por {interaction.user.mention}"
        )
        await self.cog.entregar(interaction.guild, s, vencs)

    @discord.ui.button(label="👥 Participantes", style=discord.ButtonStyle.primary, custom_id="partic_btn")
    async def btn_partic(self, interaction: discord.Interaction, btn: discord.ui.Button):
        s = await interaction.client.db.get(self.message_id)
        if not s:
            await interaction.response.send_message("❌ Não encontrado.", ephemeral=True)
            return
        partic = json.loads(s.get("participantes", "[]"))
        if not partic:
            await interaction.response.send_message("📭 Nenhum participante.", ephemeral=True)
            return
        lista = "\n".join(f"<@{p}>" for p in partic[:40])
        if len(partic) > 40:
            lista += f"\n...e mais {len(partic) - 40}"
        embed = discord.Embed(
            title=f"👥 Participantes — {s['premio']}",
            description=lista,
            color=ROXO,
        )
        embed.set_footer(text=f"Total: {len(partic)}  |  7M Vazamentos")
        await interaction.response.send_message(embed=embed, ephemeral=True)


# ═══════════════════════════════════════════════════════════
#   COG PRINCIPAL
# ═══════════════════════════════════════════════════════════
class SorteioCog(commands.Cog):
    def __init__(self, bot):
        self.bot   = bot
        self.tasks = {}
        self.recarregar.start()

    def cog_unload(self):
        self.recarregar.cancel()
        for t in self.tasks.values():
            t.cancel()

    @tasks.loop(count=1)
    async def recarregar(self):
        await self.bot.wait_until_ready()
        await asyncio.sleep(3)
        for guild in self.bot.guilds:
            for s in await self.bot.db.ativos(guild.id):
                termina = datetime.fromisoformat(s["termina_em"])
                restam  = max(5, int((termina - datetime.utcnow()).total_seconds()))
                canal   = self.bot.get_channel(s["channel_id"])
                if canal:
                    await self.agendar(s["message_id"], canal, restam, s.get("categoria_stock", ""))
        print("✅ Sorteios ativos recarregados.")

    async def agendar(self, message_id: int, canal, segundos: int, categoria: str):
        if message_id in self.tasks:
            self.tasks[message_id].cancel()

        async def loop():
            intervalo = 20
            elapsed   = 0
            while elapsed < segundos:
                espera  = min(intervalo, segundos - elapsed)
                await asyncio.sleep(espera)
                elapsed += espera
                if elapsed >= segundos:
                    break
                try:
                    s = await self.bot.db.get(message_id)
                    if not s or s.get("finalizado"):
                        return
                    msg    = await canal.fetch_message(message_id)
                    partic = await self._coletar(msg, canal.guild, s)
                    await self.bot.db.upd_participantes(message_id, partic)
                    s["participantes"] = json.dumps(partic)
                    await msg.edit(embed=embed_ativo(s))
                except Exception:
                    pass

            await self._encerrar(message_id, canal, categoria)

        self.tasks[message_id] = self.bot.loop.create_task(loop())

    async def _coletar(self, msg, guild, s: dict) -> list:
        cargo_req = s.get("cargo_req", 0)
        min_conta = s.get("min_dias_conta", 0)
        min_serv  = s.get("min_dias_serv", 0)
        partic    = set()
        for reacao in msg.reactions:
            if str(reacao.emoji) != EMOJI:
                continue
            async for user in reacao.users():
                if user.bot:
                    continue
                if await self.bot.db.bl_check(guild.id, user.id):
                    continue
                member = guild.get_member(user.id)
                if not member:
                    continue
                if cargo_req and not any(r.id == cargo_req for r in member.roles):
                    continue
                if min_conta:
                    dias = (datetime.utcnow() - member.created_at.replace(tzinfo=None)).days
                    if dias < min_conta:
                        continue
                if min_serv and member.joined_at:
                    dias_s = (datetime.utcnow() - member.joined_at.replace(tzinfo=None)).days
                    if dias_s < min_serv:
                        continue
                partic.add(user.id)
        return list(partic)

    async def _encerrar(self, message_id: int, canal, categoria: str):
        s = await self.bot.db.get(message_id)
        if not s or s.get("finalizado"):
            return

        try:
            msg = await canal.fetch_message(message_id)
        except Exception:
            return

        partic = await self._coletar(msg, canal.guild, s)
        await self.bot.db.upd_participantes(message_id, partic)

        n     = s["n_vencedores"]
        vencs = random.sample(partic, min(n, len(partic))) if partic else []
        await self.bot.db.finalizar(message_id, vencs)

        s["participantes"]  = json.dumps(partic)
        s["vencedores"]     = json.dumps(vencs)
        s["resorteado_por"] = 0

        view = ViewEncerrado(message_id=message_id, cog=self)
        await msg.edit(embed=embed_finalizado(s), view=view)

        if vencs:
            mencoes = " ".join(f"<@{v}>" for v in vencs)
            await canal.send(
                f"🎊 Parabéns {mencoes}! Vocês ganharam **{s['premio']}**!\n"
                f"> Contate <@{s['criador_id']}> para resgatar. 🏆"
            )
        else:
            await canal.send(f"⚠️ Sorteio **{s['premio']}** encerrou sem participantes elegíveis.")

        itens_dm = await self.entregar(canal.guild, s, vencs)

        cfg = await self.bot.db.get_cfg(canal.guild.id)
        if cfg.get("log_channel"):
            log_ch = canal.guild.get_channel(cfg["log_channel"])
            if log_ch:
                await log_ch.send(embed=embed_log(s, vencs, itens_dm))

    async def entregar(self, guild, s: dict, vencs: list):
        categoria = s.get("categoria_stock", "")
        if not categoria or not vencs:
            return None

        cfg = await self.bot.db.get_cfg(guild.id)
        if not cfg.get("dm_ativo", 1):
            return None

        itens = await self.bot.db.pegar_stock(guild.id, categoria, len(vencs))
        if not itens:
            return None

        await self.bot.db.usar_stock([i["id"] for i in itens])
        entregues = []
        canal_s   = guild.get_channel(s["channel_id"])

        for i, uid in enumerate(vencs):
            if i >= len(itens):
                break
            member = guild.get_member(uid)
            if not member:
                continue
            try:
                await member.send(embed=embed_dm(
                    s["premio"], itens[i]["item"], guild.name, cfg.get("msg_custom", "")
                ))
                entregues.append(itens[i])
            except discord.Forbidden:
                if canal_s:
                    await canal_s.send(
                        f"⚠️ <@{uid}> com DMs fechadas — contate <@{s['criador_id']}> para resgatar."
                    )
        return entregues

    # ──────────────────────────────────────────────────────
    #   SLASH COMMANDS
    # ──────────────────────────────────────────────────────
    @app_commands.command(name="sorteio", description="🎉 Criar um novo sorteio com painel completo")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def cmd_sorteio(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="🎉 Configurar Sorteio — 7M Vazamentos",
            description=(
                "**Configure as opções antes de criar o sorteio:**\n\n"
                "📢 Selecione o **canal** onde o sorteio será enviado\n"
                "🎭 Selecione um **cargo obrigatório** (opcional)\n"
                "📅 Clique para definir **idade mínima** da conta Discord\n"
                "🏠 Clique para definir **tempo mínimo** no servidor\n\n"
                "Depois clique em **▶️ Continuar** para preencher o prêmio e duração."
            ),
            color=ROXO,
        )
        embed.set_footer(text="7M Vazamentos • Sorteios V2")
        view = PainelConfig(autor_id=interaction.user.id, cog=self)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @app_commands.command(name="encerrar", description="⏹️ Encerrar um sorteio manualmente")
    @app_commands.describe(message_id="ID da mensagem do sorteio")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def cmd_encerrar(self, interaction: discord.Interaction, message_id: str):
        try:
            mid = int(message_id)
        except ValueError:
            await interaction.response.send_message("❌ ID inválido.", ephemeral=True)
            return

        s = await self.bot.db.get(mid)
        if not s or s.get("finalizado"):
            await interaction.response.send_message("❌ Sorteio não encontrado ou já encerrado.", ephemeral=True)
            return

        await interaction.response.send_message("⏳ Encerrando sorteio...", ephemeral=True)
        if mid in self.tasks:
            self.tasks[mid].cancel()
        canal = self.bot.get_channel(s["channel_id"])
        if canal:
            await self._encerrar(mid, canal, s.get("categoria_stock", ""))

    @app_commands.command(name="listar", description="📋 Listar todos os sorteios ativos")
    async def cmd_listar(self, interaction: discord.Interaction):
        ativos = await self.bot.db.ativos(interaction.guild.id)
        if not ativos:
            await interaction.response.send_message("📭 Nenhum sorteio ativo no momento.", ephemeral=True)
            return
        embed = discord.Embed(title="📋 Sorteios Ativos — 7M Vazamentos", color=ROXO)
        for s in ativos:
            ts = int(datetime.fromisoformat(s["termina_em"]).timestamp())
            np = len(json.loads(s.get("participantes", "[]")))
            embed.add_field(
                name=f"🎁 {s['premio']}",
                value=f"Encerra: <t:{ts}:R>\nParticipantes: `{np}`\nID: `{s['message_id']}`",
                inline=False,
            )
        embed.set_footer(text="7M Vazamentos • Sorteios V2")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="historico", description="📜 Ver os últimos 10 sorteios encerrados")
    async def cmd_historico(self, interaction: discord.Interaction):
        hist = await self.bot.db.historico(interaction.guild.id)
        if not hist:
            await interaction.response.send_message("📭 Nenhum sorteio encerrado ainda.", ephemeral=True)
            return
        embed = discord.Embed(
            title="📜 Histórico de Sorteios — 7M Vazamentos",
            color=0xFFD700,
            timestamp=datetime.utcnow(),
        )
        for s in hist:
            vencs = json.loads(s.get("vencedores", "[]"))
            vstr  = " ".join(f"<@{v}>" for v in vencs) if vencs else "Nenhum"
            np    = len(json.loads(s.get("participantes", "[]")))
            embed.add_field(
                name=f"🎁 {s['premio']}",
                value=f"🏆 {vstr}\n👥 `{np}` participantes\n👑 <@{s['criador_id']}>",
                inline=False,
            )
        embed.set_footer(text="7M Vazamentos • Sorteios V2")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @cmd_sorteio.error
    @cmd_encerrar.error
    async def perm_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("❌ Você precisa de **Gerenciar Servidor**.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(SorteioCog(bot))
