import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime
from embeds import embed_ajuda

ROXO = 0x9B59B6
VERM = 0xE74C3C
OURO = 0xFFD700


class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ══════════════════════════════════════════
    #   BLACKLIST
    # ══════════════════════════════════════════
    grp_bl = app_commands.Group(name="blacklist", description="🚫 Gerenciar blacklist dos sorteios")

    @grp_bl.command(name="add", description="🚫 Bloquear usuário de participar dos sorteios")
    @app_commands.describe(usuario="Usuário a bloquear", motivo="Motivo (opcional)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def bl_add(self, interaction: discord.Interaction, usuario: discord.Member, motivo: str = ""):
        await self.bot.db.bl_add(interaction.guild.id, usuario.id, motivo)
        embed = discord.Embed(
            title="🚫 Usuário Bloqueado",
            description=f"{usuario.mention} foi adicionado à blacklist dos sorteios.",
            color=VERM,
            timestamp=datetime.utcnow(),
        )
        if motivo:
            embed.add_field(name="Motivo", value=motivo)
        embed.set_footer(text=f"Por: {interaction.user}  |  7M Vazamentos")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @grp_bl.command(name="remove", description="✅ Desbloquear usuário da blacklist")
    @app_commands.describe(usuario="Usuário a desbloquear")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def bl_remove(self, interaction: discord.Interaction, usuario: discord.Member):
        await self.bot.db.bl_remove(interaction.guild.id, usuario.id)
        await interaction.response.send_message(
            f"✅ {usuario.mention} removido da blacklist!", ephemeral=True
        )

    @grp_bl.command(name="ver", description="📋 Ver lista de usuários bloqueados")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def bl_ver(self, interaction: discord.Interaction):
        lista = await self.bot.db.bl_lista(interaction.guild.id)
        if not lista:
            await interaction.response.send_message("✅ Blacklist vazia!", ephemeral=True)
            return
        embed = discord.Embed(title="🚫 Blacklist de Sorteios", color=VERM, timestamp=datetime.utcnow())
        for item in lista[:20]:
            motivo = item.get("motivo") or "—"
            embed.add_field(name=f"<@{item['user_id']}>", value=f"Motivo: {motivo}", inline=False)
        embed.set_footer(text=f"Total: {len(lista)} usuário(s)  |  7M Vazamentos")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @bl_add.error
    @bl_remove.error
    @bl_ver.error
    async def bl_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("❌ Sem permissão.", ephemeral=True)

    # ══════════════════════════════════════════
    #   CONFIG
    # ══════════════════════════════════════════
    grp_cfg = app_commands.Group(name="config", description="⚙️ Configurações do bot de sorteios")

    @grp_cfg.command(name="log", description="📋 Definir canal de logs dos sorteios")
    @app_commands.describe(canal="Canal onde os logs serão enviados")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def cfg_log(self, interaction: discord.Interaction, canal: discord.TextChannel):
        await self.bot.db.set_cfg(interaction.guild.id, log_channel=canal.id)
        await interaction.response.send_message(
            f"✅ Canal de logs definido para {canal.mention}!", ephemeral=True
        )

    @grp_cfg.command(name="dm", description="✉️ Ativar ou desativar DM automática ao vencedor")
    @app_commands.describe(ativo="True = ativa  |  False = desativa")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def cfg_dm(self, interaction: discord.Interaction, ativo: bool):
        await self.bot.db.set_cfg(interaction.guild.id, dm_ativo=int(ativo))
        status = "✅ ativada" if ativo else "❌ desativada"
        await interaction.response.send_message(f"DM automática ao vencedor {status}!", ephemeral=True)

    @grp_cfg.command(name="mensagem", description="📝 Personalizar mensagem de DM ao vencedor")
    @app_commands.describe(mensagem="Use {premio} e {servidor} como variáveis")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def cfg_msg(self, interaction: discord.Interaction, mensagem: str):
        await self.bot.db.set_cfg(interaction.guild.id, msg_custom=mensagem)
        await interaction.response.send_message(
            f"✅ Mensagem salva!\n**Preview:** {mensagem}", ephemeral=True
        )

    @grp_cfg.command(name="ver", description="👁️ Ver configurações atuais do bot")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def cfg_ver(self, interaction: discord.Interaction):
        cfg    = await self.bot.db.get_cfg(interaction.guild.id)
        log_ch = f"<#{cfg['log_channel']}>" if cfg.get("log_channel") else "Não definido"
        dm     = "✅ Ativada" if cfg.get("dm_ativo", 1) else "❌ Desativada"
        msg    = cfg.get("msg_custom") or "Padrão"
        embed  = discord.Embed(title="⚙️ Configurações — 7M Vazamentos", color=ROXO, timestamp=datetime.utcnow())
        embed.add_field(name="📋 Canal de Logs",  value=log_ch, inline=True)
        embed.add_field(name="✉️ DM ao Vencedor", value=dm,     inline=True)
        embed.add_field(name="📝 Mensagem DM",    value=f"```{msg}```", inline=False)
        embed.set_footer(text="7M Vazamentos • Config V2")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @cfg_log.error
    @cfg_dm.error
    @cfg_msg.error
    @cfg_ver.error
    async def cfg_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("❌ Sem permissão.", ephemeral=True)

    # ══════════════════════════════════════════
    #   AJUDA
    # ══════════════════════════════════════════
    @app_commands.command(name="ajuda", description="❓ Ver todos os comandos do bot")
    async def cmd_ajuda(self, interaction: discord.Interaction):
        await interaction.response.send_message(embed=embed_ajuda(), ephemeral=True)


async def setup(bot):
    await bot.add_cog(AdminCog(bot))
