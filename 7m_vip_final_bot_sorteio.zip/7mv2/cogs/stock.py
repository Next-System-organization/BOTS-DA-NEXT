import discord
from discord.ext import commands
from discord import app_commands
from embeds import embed_stock

VERDE = 0x2ECC71


class ModalAddStock(discord.ui.Modal, title="📦 Adicionar Itens ao Estoque"):

    f_cat = discord.ui.TextInput(
        label="Categoria",
        placeholder="Ex: netflix  |  axia  |  spotify  |  crunchyroll",
        max_length=50,
        required=True,
    )
    # style=2 = paragraph (multi-linha) - inteiro aceito pelo discord.py 2.x
    f_itens = discord.ui.TextInput(
        label="Itens — 1 por linha",
        placeholder="usuario:senha\noutra_conta:senha456\ntoken_ou_codigo_aqui",
        required=True,
        max_length=4000,
        style=2,
    )

    async def on_submit(self, interaction: discord.Interaction):
        cat   = self.f_cat.value.strip().lower()
        itens = [i.strip() for i in self.f_itens.value.splitlines() if i.strip()]
        if not itens:
            await interaction.response.send_message("❌ Nenhum item válido fornecido.", ephemeral=True)
            return
        await interaction.client.db.add_stock(interaction.guild.id, cat, itens)
        embed = discord.Embed(
            title="📦 Estoque Atualizado!",
            description=(
                f"✅ **{len(itens)}** item(ns) adicionado(s) à categoria **`{cat}`**!\n\n"
                f"Use `/stock ver` para visualizar o estoque completo."
            ),
            color=VERDE,
        )
        embed.set_footer(text="7M Vazamentos • Estoque V2")
        await interaction.response.send_message(embed=embed, ephemeral=True)


class StockCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    grp = app_commands.Group(name="stock", description="📦 Gerenciar estoque de prêmios")

    @grp.command(name="add", description="📦 Adicionar itens ao estoque (entregues via DM ao vencedor)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def cmd_add(self, interaction: discord.Interaction):
        await interaction.response.send_modal(ModalAddStock())

    @grp.command(name="ver", description="📊 Ver estoque atual por categoria")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def cmd_ver(self, interaction: discord.Interaction):
        cats  = await self.bot.db.listar_stock(interaction.guild.id)
        embed = embed_stock(cats, interaction.guild.name)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @grp.command(name="limpar", description="🗑️ Remove itens não usados de uma categoria")
    @app_commands.describe(categoria="Nome exato da categoria a limpar")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def cmd_limpar(self, interaction: discord.Interaction, categoria: str):
        await self.bot.db.limpar_stock(interaction.guild.id, categoria.lower())
        await interaction.response.send_message(
            f"✅ Itens não usados da categoria **`{categoria.lower()}`** removidos!",
            ephemeral=True,
        )

    @cmd_add.error
    @cmd_ver.error
    @cmd_limpar.error
    async def perm_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("❌ Você precisa de **Gerenciar Servidor**.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(StockCog(bot))
