import aiosqlite
import json
from datetime import datetime

DB = "sorteios.db"

class Database:
    async def init(self):
        async with aiosqlite.connect(DB) as db:
            await db.executescript("""
                CREATE TABLE IF NOT EXISTS sorteios (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    message_id      INTEGER UNIQUE,
                    channel_id      INTEGER,
                    guild_id        INTEGER,
                    criador_id      INTEGER,
                    premio          TEXT,
                    descricao       TEXT DEFAULT '',
                    n_vencedores    INTEGER DEFAULT 1,
                    termina_em      TEXT,
                    criado_em       TEXT,
                    finalizado      INTEGER DEFAULT 0,
                    cargo_req       INTEGER DEFAULT 0,
                    min_dias_conta  INTEGER DEFAULT 0,
                    min_dias_serv   INTEGER DEFAULT 0,
                    participantes   TEXT DEFAULT '[]',
                    vencedores      TEXT DEFAULT '[]',
                    resorteado_por  INTEGER DEFAULT 0,
                    categoria_stock TEXT DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS stock (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id    INTEGER,
                    categoria   TEXT,
                    item        TEXT,
                    usado       INTEGER DEFAULT 0,
                    adicionado  TEXT
                );
                CREATE TABLE IF NOT EXISTS config (
                    guild_id    INTEGER PRIMARY KEY,
                    log_channel INTEGER DEFAULT 0,
                    dm_ativo    INTEGER DEFAULT 1,
                    msg_custom  TEXT DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS blacklist (
                    guild_id    INTEGER,
                    user_id     INTEGER,
                    motivo      TEXT DEFAULT '',
                    PRIMARY KEY (guild_id, user_id)
                );
            """)
            await db.commit()

    # ── SORTEIOS ────────────────────────────────────────────
    async def criar(self, d: dict):
        async with aiosqlite.connect(DB) as db:
            await db.execute("""
                INSERT INTO sorteios
                (message_id,channel_id,guild_id,criador_id,premio,descricao,
                 n_vencedores,termina_em,criado_em,cargo_req,min_dias_conta,
                 min_dias_serv,categoria_stock)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                d["message_id"], d["channel_id"], d["guild_id"], d["criador_id"],
                d["premio"], d.get("descricao",""), d["n_vencedores"],
                d["termina_em"], datetime.utcnow().isoformat(),
                d.get("cargo_req",0), d.get("min_dias_conta",0),
                d.get("min_dias_serv",0), d.get("categoria_stock","")
            ))
            await db.commit()

    async def get(self, message_id: int):
        async with aiosqlite.connect(DB) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM sorteios WHERE message_id=?", (message_id,)) as c:
                r = await c.fetchone()
                return dict(r) if r else None

    async def ativos(self, guild_id: int):
        async with aiosqlite.connect(DB) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM sorteios WHERE guild_id=? AND finalizado=0", (guild_id,)
            ) as c:
                return [dict(r) for r in await c.fetchall()]

    async def historico(self, guild_id: int):
        async with aiosqlite.connect(DB) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM sorteios WHERE guild_id=? AND finalizado=1 ORDER BY id DESC LIMIT 10",
                (guild_id,)
            ) as c:
                return [dict(r) for r in await c.fetchall()]

    async def upd_participantes(self, message_id: int, lista: list):
        async with aiosqlite.connect(DB) as db:
            await db.execute(
                "UPDATE sorteios SET participantes=? WHERE message_id=?",
                (json.dumps(lista), message_id)
            )
            await db.commit()

    async def finalizar(self, message_id: int, vencedores: list):
        async with aiosqlite.connect(DB) as db:
            await db.execute(
                "UPDATE sorteios SET finalizado=1, vencedores=? WHERE message_id=?",
                (json.dumps(vencedores), message_id)
            )
            await db.commit()

    async def resorteio(self, message_id: int, vencedores: list, quem: int):
        async with aiosqlite.connect(DB) as db:
            await db.execute(
                "UPDATE sorteios SET vencedores=?, resorteado_por=? WHERE message_id=?",
                (json.dumps(vencedores), quem, message_id)
            )
            await db.commit()

    # ── STOCK ───────────────────────────────────────────────
    async def add_stock(self, guild_id: int, categoria: str, itens: list):
        async with aiosqlite.connect(DB) as db:
            now = datetime.utcnow().isoformat()
            await db.executemany(
                "INSERT INTO stock(guild_id,categoria,item,adicionado) VALUES(?,?,?,?)",
                [(guild_id, categoria.lower(), item, now) for item in itens]
            )
            await db.commit()

    async def pegar_stock(self, guild_id: int, categoria: str, qtd: int):
        async with aiosqlite.connect(DB) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM stock WHERE guild_id=? AND categoria=? AND usado=0 LIMIT ?",
                (guild_id, categoria.lower(), qtd)
            ) as c:
                return [dict(r) for r in await c.fetchall()]

    async def usar_stock(self, ids: list):
        async with aiosqlite.connect(DB) as db:
            await db.executemany(
                "UPDATE stock SET usado=1 WHERE id=?", [(i,) for i in ids]
            )
            await db.commit()

    async def listar_stock(self, guild_id: int):
        async with aiosqlite.connect(DB) as db:
            async with db.execute(
                """SELECT categoria,
                          COUNT(*) as total,
                          SUM(CASE WHEN usado=0 THEN 1 ELSE 0 END) as disp
                   FROM stock WHERE guild_id=? GROUP BY categoria""",
                (guild_id,)
            ) as c:
                return await c.fetchall()

    async def limpar_stock(self, guild_id: int, categoria: str):
        async with aiosqlite.connect(DB) as db:
            await db.execute(
                "DELETE FROM stock WHERE guild_id=? AND categoria=? AND usado=0",
                (guild_id, categoria.lower())
            )
            await db.commit()

    # ── CONFIG ──────────────────────────────────────────────
    async def get_cfg(self, guild_id: int):
        async with aiosqlite.connect(DB) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM config WHERE guild_id=?", (guild_id,)) as c:
                r = await c.fetchone()
                if r:
                    return dict(r)
                return {"guild_id": guild_id, "log_channel": 0, "dm_ativo": 1, "msg_custom": ""}

    async def set_cfg(self, guild_id: int, **kw):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR IGNORE INTO config(guild_id) VALUES(?)", (guild_id,))
            for k, v in kw.items():
                await db.execute(f"UPDATE config SET {k}=? WHERE guild_id=?", (v, guild_id))
            await db.commit()

    # ── BLACKLIST ────────────────────────────────────────────
    async def bl_add(self, guild_id: int, user_id: int, motivo: str = ""):
        async with aiosqlite.connect(DB) as db:
            await db.execute(
                "INSERT OR IGNORE INTO blacklist(guild_id,user_id,motivo) VALUES(?,?,?)",
                (guild_id, user_id, motivo)
            )
            await db.commit()

    async def bl_remove(self, guild_id: int, user_id: int):
        async with aiosqlite.connect(DB) as db:
            await db.execute(
                "DELETE FROM blacklist WHERE guild_id=? AND user_id=?", (guild_id, user_id)
            )
            await db.commit()

    async def bl_check(self, guild_id: int, user_id: int) -> bool:
        async with aiosqlite.connect(DB) as db:
            async with db.execute(
                "SELECT 1 FROM blacklist WHERE guild_id=? AND user_id=?", (guild_id, user_id)
            ) as c:
                return await c.fetchone() is not None

    async def bl_lista(self, guild_id: int):
        async with aiosqlite.connect(DB) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM blacklist WHERE guild_id=?", (guild_id,)
            ) as c:
                return [dict(r) for r in await c.fetchall()]
